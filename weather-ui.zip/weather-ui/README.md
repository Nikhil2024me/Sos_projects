# ESP32-S3-N16R8 Weather Station

A complete Wi-Fi weather station for the **ESP32-S3-N16R8** (16 MB flash,
8 MB octal PSRAM) driving an **ILI9341 320×240** panel through **LVGL 9.6**
and **TFT_eSPI**, with an **XPT2046** resistive touch panel.

Everything the station needs is configured on the touch screen:

* touch calibration on first boot and from **Settings → Calibrate touch**
  (stock TFT_eSPI 4-corner routine, stored in NVS)
* Wi-Fi scan, password entry, connect, error + retry, forget
* city search with an on-screen keyboard (Open-Meteo geocoding)
* current conditions, 5-hour strip and 5-day forecast
* °C/°F, 12/24 h clock, brightness, About

There are **no hard-coded credentials, API keys, SSIDs or coordinates**.
The device talks to the real network: real `WiFi.scanNetworks()`, real HTTPS
to Open-Meteo with **verified TLS** (the ESP-IDF CA bundle, no `setInsecure()`),
and real NTP time.

---

## 1. Repository layout

```
weather-ui/
├── ui.h                 # data structures, callbacks, public setters
├── ui.c                 # pure LVGL: screens, widgets, navigation, formatting
├── device/
│   ├── device.ino       # all I/O: display, touch, NVS, Wi-Fi, HTTPS, NTP, JSON
│   ├── lv_conf.h        # LVGL 9.6 configuration (RGB565, 256 KB PSRAM pool)
│   └── User_Setup.h     # canonical TFT_eSPI pin/SPI configuration
├── build.sh             # reproducible staged-library build (and optional upload)
├── docs/screenshots/    # 19 simulator screenshots (320×240 UI at 2× scale)
└── README.md
```

`ui.c` contains **no** `Arduino.h`, `WiFi.h`, `TFT_eSPI.h`, `HTTPClient`,
`NetworkClientSecure`, `Preferences` or NTP code. It includes only `ui.h` and
`lvgl.h`. The device layer calls the `ui_*` setters; the UI calls the
callbacks. This boundary is checked by `grep` in §10.

---

## 2. Hardware and pin map

### 2.1 Board memory configuration (N16R8)

The **ESP32-S3-WROOM-1-N16R8** module is documented in the *ESP32-S3-WROOM-1
Datasheet*, Table 1-1 ("ESP32-S3-WROOM-1 series comparison"):

| Variant | Flash | PSRAM |
|---------|-------|-------|
| N16R8  | 16 MB **Quad SPI** flash | 8 MB **Octal SPI** PSRAM |

Consequences that the firmware honours:

* PSRAM **must** be initialised in octal (OPI) mode — the build therefore
  selects `PSRAM=opi` and links the `qio_opi` prebuilt ESP-IDF libraries.
* On modules with octal PSRAM, **GPIO35, GPIO36 and GPIO37 are not
  available** (*ESP32-S3-WROOM-1 Datasheet*, Table 3-1, note b). They are
  never used here.
* **GPIO26–GPIO32** are the SPI flash lines and are never used.
* **GPIO0, GPIO3, GPIO45 and GPIO46 are strapping pins** (*ESP32-S3 Series
  Datasheet*, Table 3-1 "Strapping Pins"). None of them is used.
* **GPIO19/GPIO20** are the USB D−/D+ pins and **GPIO43/GPIO44** are
  U0TXD/U0RXD; none is used for the panel or touch.

### 2.2 Pin assignment

This is the pin map already used on this board (recovered memlab firmware:
`hardware.json` and `tft_setup.h`). The four SPI signals sit on the ESP32-S3
**SPI2 (GPSPI2/FSPI) IO_MUX** pins documented in the ESP-IDF *SPI master*
IO_MUX table and the datasheet "Peripheral Pin Configurations":
`SPI2_CS0 = GPIO10`, `SPI2_SCLK = GPIO12`, `SPI2_MISO = GPIO13`,
`SPI2_MOSI = GPIO11`. DC and RST are plain GPIO outputs — they are toggled,
not clocked, so they do not need an IO_MUX function.

| Signal | GPIO | Notes |
|--------|-----:|-------|
| TFT_SCLK | 12 | SPI2 native SCLK |
| TFT_MOSI | 11 | SPI2 native MOSI |
| TFT_MISO | 13 | SPI2 native MISO (shared with touch) |
| TFT_CS   | 10 | SPI2 native CS0 |
| TFT_DC   | 7  | data/command, plain GPIO |
| TFT_RST  | 6  | panel reset, plain GPIO |
| TFT_BL   | 21 | LEDC PWM backlight (5 kHz, 10-bit) |
| TOUCH_CS | 15 | XPT2046 chip select |
| TOUCH_IRQ| 16 | polled, not used as an interrupt |

Why these are safe:

* none is a flash pin (26–32) or an unavailable octal-PSRAM pin (35–37);
* none is a strapping pin (0, 3, 45, 46);
* none is USB (19, 20) or UART0 (43, 44).

`TOUCH_IRQ` is configured as `INPUT_PULLUP` but touch is **polled** through
TFT_eSPI's `getTouchRaw()` / `getTouchRawZ()`; the IRQ line is informational.

> **Backlight note:** the panel backlight is driven by LEDC, not by TFT_eSPI
> (`TFT_BACKLIGHT_ON` is deliberately undefined). This lets brightness be a
> real 0–100 % PWM setting.

---

## 3. Memory and flash layout

| Item | Setting |
|------|---------|
| Flash | 16 MB, `FlashSize=16M` (WROOM-1 N16R8 uses **QSPI** flash, so keep the default `FlashMode=qio`, 80 MHz) |
| PSRAM | Octal, `PSRAM=opi` (links `qio_opi` ESP-IDF libs) |
| Partition table | `app3M_fat9M_16MB` |
| Serial port | CH343-class USB-UART bridge on UART0 (`1a86:55d3`, `/dev/ttyACM0`) → `CDCOnBoot=default` so `Serial` maps to `Serial0` |

### 3.1 Partition table (`app3M_fat9M_16MB.csv`)

```
# Name,   Type, SubType, Offset,   Size
nvs,      data, nvs,     0x9000,   0x5000
otadata,  data, ota,     0xe000,   0x2000
app0,     app,  ota_0,   0x10000,  0x300000
app1,     app,  ota_1,   0x310000, 0x300000
ffat,     data, fat,     0x610000, 0x9E0000
coredump, data, coredump,0xFF0000, 0x10000
```

Two 3 MB OTA slots, 0x5000 of NVS, and ~9.9 MB of FAT space that this
firmware does not currently use (reserved for future icons/audio).

### 3.2 LVGL memory

* Colour format: `LV_COLOR_FORMAT_RGB565`
* **Partial render mode** with a single PSRAM tile buffer, 40 lines tall:
  `320 × 40 × 2 B = 25,600 B` (25 KB). LVGL renders each invalidated area
  into this band and passes the flush callback a pointer to that rectangle's
  first pixel, so no whole-screen framebuffer has to be kept in sync.
* LVGL heap: `LV_MEM_SIZE = 256 KB`, allocated with `ps_malloc` (PSRAM)
* Display flush is a single `TFT_eSPI::pushColors()` blit per area, inside
  `startWrite()/endWrite()`.

Partial mode was chosen over direct double-buffering deliberately: in direct
mode LVGL must copy every invalidated area from the buffer currently on the
panel into the other buffer before it renders, and any missed area reappears
as stripes under a pressed button or as garbage inside a refreshed widget.
A partial band has no such cross-buffer state.

Putting the tile buffer and the LVGL pool in PSRAM leaves the ~512 KB of
internal SRAM for Wi-Fi/TLS stacks and the FreeRTOS tasks.

### 3.3 Tasking model

* **Arduino `loop()` task** is the only task that touches LVGL.
* A dedicated **network worker task** owns Wi-Fi, NTP, HTTPS and JSON.
  Commands (`CMD_BOOT`, `CMD_SCAN`, `CMD_CONNECT`, `CMD_CANCEL`,
  `CMD_FORGET`, `CMD_REFRESH`, `CMD_CITY_SEARCH`) go in on a queue; results
  come back as events on another queue and are applied on the LVGL task.
* This is why a slow TLS handshake can never freeze the UI.

### 3.4 Serial logging and the console port

This board exposes one USB serial port: a **CH343-class USB-UART bridge**
(`lsusb`: `1a86:55d3 QinHeng Electronics USB Single Serial`) wired to **UART0**.
It is *not* the ESP32-S3 native USB-Serial/JTAG (which would enumerate as
`303a:1001`). That single fact drives the console build option:

| Port you plug into | `CDCOnBoot` | Arduino `Serial` maps to | Typical device |
|---|---|---|---|
| UART bridge (CH343 — this board) | **Disabled** (`CDCOnBoot=default`) | `Serial0` (UART0) | `/dev/ttyACM0` |
| Native USB (GPIO19/20) | Enabled (`CDCOnBoot=cdc`) | `HWCDCSerial` | another `/dev/ttyACM*` |

If `CDCOnBoot` does not match the physical port, `Serial` output is sent to a
peripheral with no cable attached, so the log is silent even though flashing
through the UART bridge still works. That is exactly what happened during
bring-up.

Firmware logs therefore go through the **ESP-IDF console**
(`esp_rom_printf`), which always targets UART0 (plus the USB-Serial/JTAG
secondary console when present). This keeps messages visible before
`Serial.begin()` and independent of the CDC menu. A 30 s `HB:` heartbeat line
proves the application is alive.

---

## 4. Build and flash

### 4.1 Prerequisites

* `arduino-cli` ≥ 1.0
* ESP32 core **3.3.12**: `arduino-cli core install esp32:esp32`
* A data-capable USB cable to the board's **UART port** (the CH343 bridge)

### 4.2 Find the port

```bash
arduino-cli board list
# Port         Protocol Type              Board Name  FQBN  Core
# /dev/ttyACM0 serial   Serial Port (USB) Unknown

ls -l /dev/serial/by-id/
# usb-1a86_USB_Single_Serial_595B063836-if00 -> ../../ttyACM0
```

The board shows as **Unknown** because a plain USB-UART bridge carries no
board ID. That is expected: uploads still work when you pass the FQBN and the
port explicitly. Use `/dev/ttyACM0` on this machine.

### 4.3 One-command build

```bash
cd weather-ui
./build.sh            # stage pinned libraries + compile
./build.sh --upload   # compile + flash /dev/ttyACM0
```

`build.sh` pins and stages, in a private directory:

| Library | Version |
|---------|---------|
| lvgl | 9.6.0 |
| TFT_eSPI | 2.5.43 |
| ArduinoJson | 7.4.3 |

It then copies the project's `device/lv_conf.h` into `lvgl/src/` and
`device/User_Setup.h` into the TFT_eSPI root, so the installed Arduino
libraries are never modified.

### 4.4 Manual commands

```bash
FQBN='esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB'

arduino-cli compile --fqbn "$FQBN" \
  --libraries /tmp/weather-station-build/libs \
  --build-path /tmp/weather-station-build/build \
  weather-ui/device

arduino-cli upload -p /dev/ttyACM0 --fqbn "$FQBN" \
  --input-dir /tmp/weather-station-build/build \
  weather-ui/device
```

> **Why these options?** Espressif's module table lists the **ESP32-S3-WROOM-1
> N16R8** as *Flash Mode = QSPI, PSRAM = OPI*. So `PSRAM=opi` and
> `FlashSize=16M`, while `FlashMode` keeps its QIO 80 MHz default.
> `FlashMode=opi` is only for WROOM-2 (octal flash); selecting it on an N16R8
> prevents the board from booting. `CDCOnBoot=default` is explained in §3.4 —
> this board is connected through its UART bridge, so `Serial` must be UART0.

### 4.5 A real TFT_eSPI/ESP32-S3 pitfall that was fixed

The first flashed build crashed in a boot loop:

```
Guru Meditation Error: Core 1 panic'ed (StoreProhibited)
EXCVADDR: 0x00000010
Backtrace: TFT_eSPI::begin_tft_write() ... TFT_eSPI::init() ... setup()
```

Root cause: TFT_eSPI pokes SPI registers through `SPI_PORT`, whose ESP32-S3
default is `FSPI`. With arduino-esp32 3.x, `FSPI` is the Arduino bus number
**0**, but ESP-IDF defines

```c
#define REG_SPI_BASE(i) (((i)>=2) ? (DR_REG_SPI2_BASE + (i-2)*0x1000) : (0))
```

so `SPI_USER_REG(0)` evaluated to address **0x10** and the first
`begin_tft_write()` faulted. The fix is `#define USE_FSPI_PORT` in
`User_Setup.h`, which makes TFT_eSPI use the literal GPSPI index **2**
(`REG_SPI_BASE(2) == DR_REG_SPI2_BASE`) and construct its `SPIClass` on
`FSPI` (0), which the core maps to `SPI2_HOST` — the same controller.
The file documents this inline.

---

## 5. First boot

1. If no calibration is stored (`tc_ok` absent) the device runs the **stock
   TFT_eSPI 4-corner calibration routine** (`TFT_eSPI::calibrateTouch()`, the
   same one as the bundled `Generic/Touch_calibrate` example) before LVGL
   starts, with the backlight already on.
2. Touch the corner indicated by the magenta arrow, four times (one per
   corner). `calibrateTouch()` averages eight raw XPT2046 samples per corner
   and derives the five `uint16_t` values consumed by `setTouch()`.
3. The five values are stored in NVS as `tc0 … tc4` together with `tc_ok`,
   and loaded with `setTouch()` on every later boot.
4. The **Wi-Fi scan** screen then appears.

Calibration can be repeated at any time from **Settings → Calibrate touch**,
which calls the same routine on the LVGL task (the panel is repainted
afterwards by invalidating the active screen).

---

## 6. Wi-Fi flow

* `WiFi.scanNetworks()` runs on the worker task; the UI shows SSID, signal
  bars, secured/locked icon and a **Rescan** button.
* Tapping a network opens the password screen with an LVGL keyboard, a
  **Show/Hide** toggle (masked by default), **Connect** and **Cancel**.
* Connecting shows a spinner, the target SSID and a **Cancel** button.
* Success shows an on-screen check mark, the IP and RSSI, and offers
  **Continue** or **Change network**.
* Failure maps the `wl_status_t` / disconnect reason to a specific message
  (wrong password, AP not found, timeout, …) and offers **Retry**.

Credentials are written to NVS **only after a successful connection**.
`Settings → Forget network` erases them. On boot the saved network is
reconnected automatically.

> **Security limitation:** NVS is ordinary flash, so the Wi-Fi password is
> stored unencrypted at rest. On a shared or stolen device, use
> `Settings → Forget network`. NVS encryption / flash encryption is a
> per-device provisioning step and is not enabled by this firmware.

---

## 7. Weather, TLS and time

### 7.1 Endpoints

| Purpose | Endpoint |
|---------|----------|
| Current + hourly + daily | `https://api.open-meteo.com/v1/forecast` |
| City search | `https://geocoding-api.open-meteo.com/v1/search` |

No API key is required, and **no key is embedded**.

### 7.2 TLS

`NetworkClientSecure` is used with:

```cpp
client.useBuiltinCACertBundle();
```

This validates the server chain against the ESP-IDF CA bundle and checks the
hostname. There is **no** `setInsecure()` call anywhere in the tree (§10).

Because certificate validation needs a plausible clock, the firmware first
synchronises **UTC via NTP** (`pool.ntp.org`), and only then performs the first
HTTPS request. After the forecast response it applies the API's timezone:

* preferred: `configTzTime(iana_tz, ...)` when Open-Meteo returns a usable
  IANA name (e.g. `Europe/Berlin`);
* fallback: `configTime(utc_offset_seconds, 0, ...)`.

The next refresh re-applies the timezone so daylight-saving transitions are
picked up. **Caveat:** if a region changes its DST rules between API responses
and the device is offline, the displayed local time can be off by one hour.

### 7.3 Data shown

* city name, last-updated time and Wi-Fi + RSSI
* large current temperature and a condition icon **drawn from LVGL
  primitives** (sun, cloud, rain, snow, storm, fog)
* feels-like, humidity, wind, pressure
* 5-hour strip (next hours)
* 5-day forecast with high/low, icon and precipitation probability

The API supplies WMO weather codes; `ui.c` maps them to an icon enum and draws
the icon with circles, rectangles and arcs — no image assets.

---

## 8. Error states

Every network failure produces a real, actionable screen with a **Retry**
button:

| Condition | Message |
|-----------|---------|
| `WiFi.status() == WL_NO_SSID_AVAIL` | network not found |
| wrong password (`WL_CONNECT_FAILED` / reason 15) | check the password |
| connect timeout | timed out, retry |
| DNS failure | could not resolve host |
| TLS failure | certificate/secure connection failed |
| HTTP non-200 | server returned HTTP n |
| JSON error | malformed response |
| timeout | request timed out |
| scan returns 0 | no networks found |

A monotonic **weather sequence number** makes stale results from an old
city/request harmless: results whose `seq` is not the current one are ignored.

---

## 9. Settings and NVS

`Settings` provides °C/°F, 12/24 h, a 10–100 % brightness slider, the Wi-Fi
card (Change network / Forget / saved-network indicator) and About (version,
IP, MAC, free heap, free PSRAM, uptime).

NVS namespace: **`weather`**

| Key | Type | Meaning |
|-----|------|---------|
| `w_ssid`, `w_pass` | string | saved network |
| `w_ok` | bool | credentials are valid |
| `c_name`, `c_region`, `c_country`, `c_tz` | string | selected city |
| `c_lat`, `c_lon` | float | city coordinates |
| `c_ok` | bool | city is set |
| `tc_ok` | bool | touch calibrated |
| `tc0 … tc4` | uint16 | raw `setTouch()` calibration values |
| `s_fahr`, `s_24h` | bool | unit / clock |
| `s_bright` | int | backlight percent |

Settings are written 1.2 s after the last change (debounced), so dragging the
brightness slider does not wear the flash.

---

## 10. Static proof (no hardware I/O in the UI)

```console
$ grep -nE '#include[[:space:]]*[<"](Arduino|WiFi|TFT_eSPI|HTTPClient|NetworkClientSecure|Preferences|time)\.h' weather-ui/ui.c
NONE

$ grep -rn setInsecure weather-ui/ui.c weather-ui/ui.h weather-ui/device/
NONE

$ grep -rniE '(ssid|password|api[_-]?key|lat|lon)[[:space:]]*=[[:space:]]*"[^"]+"' weather-ui/
NONE
```

The only textual matches for "WiFi" inside `ui.c` are a source comment and the
splash subtitle string `"Open-Meteo | NTP | TLS verified"`.

---

## 11. Simulator verification

The pure-LVGL UI was rendered at **320×240, RGB565, 256 KB memory budget**
with the LVGL 9.6 MCP simulator and the project fonts
`montserrat_10/12/14/16/20/24/48`.

**Result: zero diagnostics** — no clipped text, no missing glyphs, no
low-contrast text, no overlaps. All named touch targets are at least
**40×40 px** (the simulator warns below 40×40 at 130 dpi). The only reported
overflow is intentional vertical scrolling in the Wi-Fi list and city results.

19 screenshots are in [`docs/screenshots/`](docs/screenshots):

| # | Screen | # | Screen |
|---|--------|---|--------|
| 01 | Touch calibration (TFT_eSPI) | 11 | Settings |
| 02 | Splash / progress | 12 | About |
| 03 | Wi-Fi scan | 13 | Error: DNS |
| 04 | Wi-Fi password | 14 | Error: TLS |
| 05 | Wi-Fi connecting | 15 | Error: HTTP |
| 06 | Wi-Fi result (success) | 16 | Error: timeout |
| 07 | Wi-Fi result (error) | 17 | Error: no network |
| 08 | Weather main | 18 | Wi-Fi: no networks |
| 09 | 5-day forecast | 19 | City results |
| 10 | City search | | |

Interaction flows exercised in the simulator (captured events): Wi-Fi rescan →
row select → password show/hide → connect → failure → retry → success →
Continue; Forecast / Search / Settings navigation; **Settings → Calibrate
touch** firing `on_calibrate`; °F and 12 h toggles; brightness; Change
network → Cancel; Forget; About.

Screenshot 01 is the stock **TFT_eSPI** `calibrateTouch()` screen (white font
on black, magenta corner arrow), which the device draws directly before LVGL
starts; it is not an LVGL screen. The other 18 screenshots are LVGL renders.

---

## 12. Hardware verification log

Build and flash were run with `arduino-cli 1.5.1`, core `esp32 3.3.12`, using
the FQBN from §4.4 and the port `/dev/ttyACM0`.

```console
$ arduino-cli board list
Port         Protocol Type              Board Name  FQBN  Core
/dev/ttyACM0 serial   Serial Port (USB) Unknown
```

The board is an **ESP32-S3 rev v0.2, 16 MB flash, 8 MB embedded PSRAM**,
MAC `a0:85:e3:f0:77:1c` (esptool `flash_id`). Upload writes the bootloader,
partition table, `boot_app0` and the ~1.64 MB application; every hash is
verified.

This build uses the **same pin map as the board's earlier memlab firmware**
(§2.2): DC 7, RST 6, BL 21, TOUCH_CS 15, TOUCH_IRQ 16. Real boot transcript
from `/dev/ttyACM0` (UART0 through the CH343 bridge, 115200 8N1), captured
with DTR deasserted and an RTS reset pulse:

```text
ESP-ROM:esp32s3-20210327
Build:Mar 27 2021
rst:0x1 (POWERON),boot:0x8 (SPI_FAST_FLASH_BOOT)
SPIWP:0xee
mode:DIO, clock div:1
load:0x3fce2820,len:0x10cc
load:0x403c8700,len:0xc2c
load:0x403cb700,len:0x30b0
entry 0x403c88b8

Weather Station 1.0.0
Chip: ESP32-S3 rev 2, 240 MHz
Flash: 16 MB, PSRAM: 8 MB (found)
NVS: wifi=no city=Tirupur tcal=yes fahr=0 24h=0 bright=100
PANEL: readback F800 07E0 001F, expect F800 07E0 001F -> OK
TFT: 320x240, rotation 1
Touch: calibration loaded {450, 3432, 370, 3379, 3}
PARTIAL: fillRect reference -> OK
...
PARTIAL: push 73x29 at 61,37 -> OK
LVGL: 25600-byte PSRAM tile buffer (40 lines), pool 256 KB
Heap: 278432 internal free, 8089640 PSRAM free
Touch: calibration ready
FLUSH 0: 320x40 at 0,0
FLUSH 1: 320x40 at 0,40
...
FLUSH 5: 320x40 at 0,200
WiFi: scanning
...
WiFi: scan found 2 named networks
HB: up=30s heap=235944 psram=8079672 wifi=6 ip=Not connected
```

`FLUSH n:` lines come from the optional `FLUSH_TRACE` diagnostic, which logs
the first 20 flush rectangles after LVGL starts. `tcal=yes` is the log label
for the `tc_ok` calibration flag.

This proves, on the physical board:

* the ESP32-S3 boots the image (no boot loop after the `USE_FSPI_PORT` fix);
* **16 MB flash and 8 MB octal PSRAM are detected** (`8079672` bytes free);
* the ILI9341 was initialised at 320×240, rotation 1 and its pixel read-back
  matches the source buffer for all three channel patterns;
* a 73×29 rectangle written through the exact LVGL flush helper reads back
  bit-for-bit correct, proving the partial-mode address window and byte order;
* LVGL allocated one 25,600-byte tile buffer in PSRAM and the 256 KB pool,
  and a full repaint arrived as six clean 320×40 bands;
* the XPT2046 calibration was loaded from NVS;
* a **real `WiFi.scanNetworks()`** completed and found 2 named networks;
* the 30 s heartbeat shows a healthy heap (`235944` internal free) with Wi-Fi
  disconnected (`wifi=6` = `WL_DISCONNECTED`), as expected with no credentials.

The panel and touch are live, not just initialised: during the first capture
after this flash, the log showed

```text
WiFi: connecting to "SAMSUNG"
```

That line can only be produced by `app_on_wifi_connect()`, which runs from the
LVGL touch callback after a network is selected on the scan screen. NVS
reported `wifi=no` at boot, so there was no saved network and no automatic
path to that call — the tap came from the XPT2046 wired to **TOUCH_CS 15**.
The display side is equally exercised: LVGL rendered the scan list and the
password screen that accepted the input on the ILI9341 (DC 7, RST 6).

Compile statistics (final, 0 warnings):

```text
Sketch uses 1644142 bytes (52%) of program storage space. Maximum is 3145728 bytes.
Global variables use 52252 bytes (15%) of dynamic memory, leaving 275428 bytes for local variables.
```

The final build's compile database proves the two critical options took effect:

```text
esp32s3-libs/3.3.12/qio_opi/        <- octal-PSRAM prebuilt IDF libs
CONFIG_SPIRAM_MODE_OCT 1            <- in that variant's sdkconfig.h
ARDUINO_USB_CDC_ON_BOOT=0           <- Serial == Serial0 (UART0)
ARDUINO_USB_MODE=1
```

Remaining:

* a successful Wi-Fi join and therefore a live HTTPS/NTP exchange — the panel
  was used to select a network, but no password was saved to NVS
  (`wifi=no`), so the boot still ends at `WL_DISCONNECTED`;
* a visual check of colours/backlight on the actual panel (the driver path is
  confirmed, but colour order is a panel-tolerance call: see §13.1);
* an eye check of the two rendering fixes — a held button should show a flat
  dark shade, and partial updates (spinners, refreshed values) should not
  smear. The on-panel self-test verifies the rectangle path bit-for-bit; the
  final composite is a visual call.

---

## 13. Assumptions

1. The panel is a 3.3 V ILI9341 with an XPT2046 controller on the same SPI bus,
   `TFT_RGB_ORDER = TFT_BGR` (the common case). If colours look swapped, change
   it to `TFT_RGB` in `User_Setup.h`.
2. The backlight is active-high on GPIO21.
3. Touch uses the TFT_eSPI XPT2046 driver. Calibration is produced by the
   stock `calibrateTouch()` routine and consumed by `getTouch()` after
   `setTouch()`, which also corrects axis inversion and rotation.
4. Open-Meteo's free endpoints and field names remain stable.
5. A 40 MHz SPI clock is safe for the wiring; drop `SPI_FREQUENCY` to 27 MHz
   for long jumper leads.
6. The board is powered from a supply that can deliver the panel's backlight
   current; a weak USB port can brown out with the backlight at 100 %.

---

## 14. Troubleshooting

| Symptom | Fix |
|---------|-----|
| Boot loop, `StoreProhibited` at `0x10` | ensure `USE_FSPI_PORT` is in the staged `User_Setup.h` (§4.4) |
| No serial output on `/dev/ttyACM0` | this board uses its CH343 **UART** port: build with `CDCOnBoot=default` (§3.4), and open the port without asserting DTR/RTS. `arduino-cli board list` will show the board as `Unknown`; pass `--fqbn` explicitly |
| Blank panel | check `TFT_RST`/`TFT_DC`/`TFT_CS`, and that the backlight pin is high |
| Colours inverted | switch `TFT_RGB_ORDER` between `TFT_BGR` and `TFT_RGB` |
| Touch mirrored/rotated | **Settings → Calibrate touch**, or erase `tc_ok` to force the first-boot routine |
| `PSRAM not found` | the module is not N16R8, or the build used QSPI; use `PSRAM=opi` |
| TLS fails at boot | the clock is not set; check that NTP is reachable on port 123 |

---

## 15. Licence / credits

* LVGL 9.6.0 — MIT
* TFT_eSPI 2.5.43 — free BSD/MIT
* ArduinoJson 7.4.3 — MIT
* Weather and geocoding data — [Open-Meteo](https://open-meteo.com/) (CC BY 4.0)