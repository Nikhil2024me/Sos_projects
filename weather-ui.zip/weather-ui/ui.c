/**
 * ui.c - pure LVGL implementation of the weather station UI.
 *
 * No Arduino, WiFi, HTTP, NTP or TFT code lives here.  The device layer calls
 * the setters declared in ui.h and receives user intent through ui_callbacks_t.
 */
#include "ui.h"

#include "lvgl.h"

#include <stdio.h>
#include <string.h>

#define UI_W 320
#define UI_H 240

#define C_BG      0x0B1220
#define C_PANEL   0x121C2E
#define C_PANEL2  0x16213A
#define C_ACCENT  0x4CC9F0
#define C_TEXT    0xF2F6FF
#define C_MUTED   0x9FB3D1
#define C_GREEN   0x34D399
#define C_RED     0xF87171
#define C_AMBER   0xFBBF24
#define C_BTN     0x1E3A5F
#define C_DIM     0x334155

#define F10 (&lv_font_montserrat_10)
#define F12 (&lv_font_montserrat_12)
#define F14 (&lv_font_montserrat_14)
#define F16 (&lv_font_montserrat_16)
#define F20 (&lv_font_montserrat_20)
#define F24 (&lv_font_montserrat_24)
#define F48 (&lv_font_montserrat_48)

/* ------------------------------------------------------------------ */
/* State                                                              */
/* ------------------------------------------------------------------ */

static ui_callbacks_t g_cb;

static lv_obj_t *g_scr_splash;
static lv_obj_t *g_scr_scan;
static lv_obj_t *g_scr_pw;
static lv_obj_t *g_scr_connecting;
static lv_obj_t *g_scr_result;
static lv_obj_t *g_scr_weather;
static lv_obj_t *g_scr_forecast;
static lv_obj_t *g_scr_city;
static lv_obj_t *g_scr_settings;
static lv_obj_t *g_scr_about;

/* splash */
static lv_obj_t *g_splash_bar;
static lv_obj_t *g_splash_status;

/* scan */
static lv_obj_t *g_scan_status;
static lv_obj_t *g_scan_spinner;
static lv_obj_t *g_scan_rows[12];
static lv_obj_t *g_scan_ssid[12];
static lv_obj_t *g_scan_sec[12];
static lv_obj_t *g_scan_rssi[12];
static lv_obj_t *g_scan_bars[12][4];

/* password */
static lv_obj_t *g_pw_title;
static lv_obj_t *g_pw_input;
static lv_obj_t *g_pw_show;
static lv_obj_t *g_pw_show_label;
static lv_obj_t *g_pw_keyboard;
static bool g_pw_visible;

/* connecting */
static lv_obj_t *g_conn_ssid;

/* result */
static lv_obj_t *g_res_icon;
static lv_obj_t *g_res_icon_label;
static lv_obj_t *g_res_title;
static lv_obj_t *g_res_detail;
static lv_obj_t *g_res_primary;
static lv_obj_t *g_res_primary_label;
static bool g_res_success;

/* weather */
static lv_obj_t *g_weather_city;
static lv_obj_t *g_weather_updated;
static lv_obj_t *g_weather_wifi;
static lv_obj_t *g_weather_wifi_bars[4];
static lv_obj_t *g_weather_rssi;
static lv_obj_t *g_weather_hero;
static lv_obj_t *g_weather_temp;
static lv_obj_t *g_weather_icon;
static lv_obj_t *g_weather_cond;
static lv_obj_t *g_weather_feels;
static lv_obj_t *g_weather_metrics;
static lv_obj_t *g_weather_hum;
static lv_obj_t *g_weather_wind;
static lv_obj_t *g_weather_press;
static lv_obj_t *g_weather_metric_feels;
static lv_obj_t *g_weather_hourly;
static lv_obj_t *g_hour_tile[5];
static lv_obj_t *g_hour_time[5];
static lv_obj_t *g_hour_icon[5];
static lv_obj_t *g_hour_temp[5];
static lv_obj_t *g_weather_error;
static lv_obj_t *g_weather_error_title;
static lv_obj_t *g_weather_error_detail;

/* forecast */
static lv_obj_t *g_fc_day[5];
static lv_obj_t *g_fc_icon[5];
static lv_obj_t *g_fc_cond[5];
static lv_obj_t *g_fc_high[5];
static lv_obj_t *g_fc_low[5];
static lv_obj_t *g_fc_precip[5];
static lv_obj_t *g_fc_rows[5];

/* city search */
static lv_obj_t *g_city_input;
static lv_obj_t *g_city_status;
static lv_obj_t *g_city_keyboard;
static lv_obj_t *g_city_results;
static lv_obj_t *g_city_rows[UI_CITY_MAX];
static lv_obj_t *g_city_name[UI_CITY_MAX];
static lv_obj_t *g_city_region[UI_CITY_MAX];

/* settings */
static lv_obj_t *g_set_unit_c;
static lv_obj_t *g_set_unit_f;
static lv_obj_t *g_set_clock_12;
static lv_obj_t *g_set_clock_24;
static lv_obj_t *g_set_brightness;
static lv_obj_t *g_set_bright_value;
static lv_obj_t *g_set_wifi_ssid;
static lv_obj_t *g_set_wifi_sub;
static lv_obj_t *g_set_wifi_dot;
static lv_obj_t *g_set_forget;
static lv_obj_t *g_set_forget_label;
static lv_obj_t *g_set_saved;
static int g_forget_armed;

/* about */
static lv_obj_t *g_about_values[9];

/* data */
static bool g_fahrenheit;
static bool g_clock24;
static int g_brightness;
static ui_wifi_t g_nets[UI_WIFI_MAX];
static int g_net_count;
static ui_city_t g_cities[UI_CITY_MAX];
static int g_city_count;
static char g_selected_ssid[33];
static ui_current_t g_current;
static bool g_have_current;
static ui_hour_t g_hours[5];
static int g_hour_count;
static ui_day_t g_days[5];
static int g_day_count;
static char g_updated_raw[8];

/* ------------------------------------------------------------------ */
/* Small helpers                                                      */
/* ------------------------------------------------------------------ */

static void copy_ascii(char *dst, size_t n, const char *src)
{
    size_t o = 0;
    if (dst == NULL || n == 0) {
        return;
    }
    if (src == NULL) {
        src = "";
    }
    while (*src != '\0' && o + 1 < n) {
        unsigned char c = (unsigned char)*src++;
        if (c >= 0x20 && c < 0x7F) {
            dst[o++] = (char)c;
        } else if (c == '\n' || c == '\t') {
            dst[o++] = ' ';
        }
        /* UTF-8 continuation/lead bytes are dropped: Montserrat has no glyphs. */
    }
    dst[o] = '\0';
}

static void fmt_temp(char *buf, size_t n, float celsius)
{
    float v = g_fahrenheit ? (celsius * 9.0f / 5.0f + 32.0f) : celsius;
    int iv = (int)(v >= 0.0f ? v + 0.5f : v - 0.5f);
    snprintf(buf, n, "%d\xC2\xB0", iv);
}

static int wifi_level(int rssi)
{
    if (rssi >= -55) return 4;
    if (rssi >= -67) return 3;
    if (rssi >= -78) return 2;
    return 1;
}

static lv_obj_t *box(lv_obj_t *parent, const char *name,
                     int x, int y, int w, int h, uint32_t bg, int radius)
{
    lv_obj_t *o = lv_obj_create(parent);
    if (name != NULL) {
        lv_obj_set_name(o, name);
    }
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(o, radius, 0);
    lv_obj_set_style_border_width(o, 0, 0);
    lv_obj_set_style_pad_all(o, 0, 0);
    lv_obj_set_scrollable(o, false);
    lv_obj_set_clickable(o, false);
    return o;
}

static lv_obj_t *clear_box(lv_obj_t *parent, const char *name,
                           int x, int y, int w, int h)
{
    lv_obj_t *o = box(parent, name, x, y, w, h, C_BG, 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_TRANSP, 0);
    lv_obj_set_clickable(o, false);
    return o;
}

static lv_obj_t *label(lv_obj_t *parent, const char *name, const char *text,
                       const lv_font_t *font, uint32_t color,
                       int x, int y, int w)
{
    lv_obj_t *l = lv_label_create(parent);
    if (name != NULL) {
        lv_obj_set_name(l, name);
    }
    lv_label_set_text(l, text);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color), 0);
    lv_obj_set_pos(l, x, y);
    if (w > 0) {
        lv_obj_set_width(l, w);
        lv_label_set_long_mode(l, LV_LABEL_LONG_DOT);
    }
    lv_obj_set_clickable(l, false);
    return l;
}

static lv_obj_t *button(lv_obj_t *parent, const char *name, const char *text,
                        int x, int y, int w, int h,
                        uint32_t bg, uint32_t fg, const lv_font_t *font)
{
    lv_obj_t *b = lv_button_create(parent);
    if (name != NULL) {
        lv_obj_set_name(b, name);
    }
    lv_obj_set_pos(b, x, y);
    lv_obj_set_size(b, w, h);
    lv_obj_set_style_bg_color(b, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(b, LV_OPA_COVER, 0);
    /* Pressed state: a plain opaque shade.  The default theme also applies a
       grow transform and a recolour overlay, which forces the press through
       a temporary layer; keep it to a simple rectangle repaint instead. */
    lv_obj_set_style_bg_color(b, lv_color_darken(lv_color_hex(bg), LV_OPA_20),
                              LV_STATE_PRESSED);
    lv_obj_set_style_bg_opa(b, LV_OPA_COVER, LV_STATE_PRESSED);
    lv_obj_set_style_recolor_opa(b, 0, LV_STATE_PRESSED);
    lv_obj_set_style_transform_width(b, 0, LV_STATE_PRESSED);
    lv_obj_set_style_transform_height(b, 0, LV_STATE_PRESSED);
    lv_obj_set_style_radius(b, 6, 0);
    lv_obj_set_style_border_width(b, 0, 0);
    lv_obj_set_style_pad_all(b, 0, 0);
    lv_obj_set_style_shadow_width(b, 0, 0);
    lv_obj_set_scrollable(b, false);
    lv_obj_t *l = lv_label_create(b);
    lv_label_set_text(l, text);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(fg), 0);
    lv_obj_center(l);
    return b;
}

static void set_button_text(lv_obj_t *btn, const char *text)
{
    lv_obj_t *l = lv_obj_get_child(btn, 0);
    if (l != NULL) {
        lv_label_set_text(l, text);
    }
}

static void set_button_colors(lv_obj_t *btn, uint32_t bg, uint32_t fg)
{
    lv_obj_set_style_bg_color(btn, lv_color_hex(bg), 0);
    lv_obj_t *l = lv_obj_get_child(btn, 0);
    if (l != NULL) {
        lv_obj_set_style_text_color(l, lv_color_hex(fg), 0);
    }
}

static lv_obj_t *mk_screen(const char *name)
{
    lv_obj_t *s = lv_obj_create(NULL);
    lv_obj_set_name(s, name);
    lv_obj_set_size(s, UI_W, UI_H);
    lv_obj_set_style_bg_color(s, lv_color_hex(C_BG), 0);
    lv_obj_set_style_bg_opa(s, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(s, 0, 0);
    lv_obj_set_style_pad_all(s, 0, 0);
    lv_obj_set_scrollable(s, false);
    return s;
}

static void style_segment(lv_obj_t *btn, bool selected)
{
    set_button_colors(btn, selected ? C_ACCENT : C_PANEL2,
                      selected ? C_BG : C_TEXT);
}

/* ------------------------------------------------------------------ */
/* Weather icons: independent LVGL primitives, no sibling overlap      */
/* ------------------------------------------------------------------ */

static lv_obj_t *icon_part(lv_obj_t *parent, int x, int y, int w, int h,
                           int radius, uint32_t color)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, lv_color_hex(color), 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(o, radius, 0);
    lv_obj_set_style_border_width(o, 0, 0);
    lv_obj_set_style_pad_all(o, 0, 0);
    lv_obj_set_scrollable(o, false);
    lv_obj_set_clickable(o, false);
    return o;
}

static void icon_sun_big(lv_obj_t *p)
{
    icon_part(p, 18, 18, 28, 28, 14, C_AMBER);
    icon_part(p, 29, 4, 6, 10, 3, C_AMBER);
    icon_part(p, 29, 50, 6, 10, 3, C_AMBER);
    icon_part(p, 4, 29, 10, 6, 3, C_AMBER);
    icon_part(p, 50, 29, 10, 6, 3, C_AMBER);
}

static void icon_cloud_big(lv_obj_t *p, uint32_t color)
{
    icon_part(p, 6, 36, 52, 18, 9, color);
    icon_part(p, 16, 26, 36, 10, 5, color);
    icon_part(p, 26, 18, 18, 8, 4, color);
}

static void icon_rain_big(lv_obj_t *p, uint32_t color)
{
    icon_part(p, 6, 30, 52, 16, 8, color);
    icon_part(p, 16, 20, 36, 10, 5, color);
    icon_part(p, 26, 14, 18, 6, 3, color);
    icon_part(p, 14, 50, 4, 10, 2, C_ACCENT);
    icon_part(p, 30, 50, 4, 10, 2, C_ACCENT);
    icon_part(p, 46, 50, 4, 10, 2, C_ACCENT);
}

static void icon_snow_big(lv_obj_t *p, uint32_t color)
{
    icon_part(p, 6, 30, 52, 16, 8, color);
    icon_part(p, 16, 20, 36, 10, 5, color);
    icon_part(p, 26, 14, 18, 6, 3, color);
    icon_part(p, 14, 52, 6, 6, 3, C_TEXT);
    icon_part(p, 30, 52, 6, 6, 3, C_TEXT);
    icon_part(p, 46, 52, 6, 6, 3, C_TEXT);
}

static void icon_storm_big(lv_obj_t *p)
{
    icon_part(p, 6, 28, 52, 16, 8, C_MUTED);
    icon_part(p, 16, 18, 36, 10, 5, C_MUTED);
    icon_part(p, 26, 12, 18, 6, 3, C_MUTED);
    icon_part(p, 34, 46, 8, 8, 2, C_AMBER);
    icon_part(p, 26, 54, 8, 6, 2, C_AMBER);
}

static void icon_fog_big(lv_obj_t *p)
{
    icon_part(p, 4, 18, 56, 8, 4, C_MUTED);
    icon_part(p, 12, 32, 44, 8, 4, C_MUTED);
    icon_part(p, 20, 46, 32, 8, 4, C_MUTED);
}

static void icon_moon_big(lv_obj_t *p)
{
    lv_obj_t *arc = lv_arc_create(p);
    lv_obj_set_pos(arc, 10, 8);
    lv_obj_set_size(arc, 42, 42);
    lv_obj_set_style_bg_opa(arc, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(arc, 0, 0);
    lv_obj_set_style_pad_all(arc, 0, 0);
    lv_obj_set_style_arc_width(arc, 13, LV_PART_MAIN);
    lv_obj_set_style_arc_color(arc, lv_color_hex(C_TEXT), LV_PART_MAIN);
    lv_obj_set_style_arc_opa(arc, LV_OPA_TRANSP, LV_PART_INDICATOR);
    lv_arc_set_bg_angles(arc, 55, 305);
    lv_arc_set_rotation(arc, 0);
    lv_obj_set_scrollable(arc, false);
    lv_obj_set_clickable(arc, false);
    icon_part(p, 54, 10, 6, 6, 3, C_AMBER);
    icon_part(p, 46, 22, 4, 4, 2, C_AMBER);
}

static void icon_partly_big(lv_obj_t *p)
{
    icon_part(p, 4, 4, 20, 20, 10, C_AMBER);
    icon_part(p, 10, 0, 4, 4, 2, C_AMBER);
    icon_part(p, 10, 24, 4, 4, 2, C_AMBER);
    icon_part(p, 0, 10, 4, 4, 2, C_AMBER);
    icon_part(p, 24, 10, 4, 4, 2, C_AMBER);
    icon_part(p, 24, 38, 40, 14, 7, C_TEXT);
    icon_part(p, 32, 30, 26, 8, 4, C_TEXT);
    icon_part(p, 40, 24, 14, 6, 3, C_TEXT);
}

static int icon_kind(int code)
{
    if (code == 0) return 0;
    if (code == 1 || code == 2) return 1;
    if (code == 3) return 2;
    if (code == 45 || code == 48) return 3;
    if ((code >= 51 && code <= 67) || (code >= 80 && code <= 82)) return 4;
    if (code == 71 || code == 73 || code == 75 || code == 77 ||
        code == 85 || code == 86) return 5;
    if (code >= 95) return 6;
    return 2;
}

static void icon_build_big(lv_obj_t *p, int code, bool is_day)
{
    lv_obj_clean(p);
    int kind = icon_kind(code);
    if (kind == 0) {
        if (is_day) icon_sun_big(p); else icon_moon_big(p);
    } else if (kind == 1) {
        icon_partly_big(p);
    } else if (kind == 2) {
        icon_cloud_big(p, C_TEXT);
    } else if (kind == 3) {
        icon_fog_big(p);
    } else if (kind == 4) {
        icon_rain_big(p, C_TEXT);
    } else if (kind == 5) {
        icon_snow_big(p, C_TEXT);
    } else {
        icon_storm_big(p);
    }
}

/* Compact 18/24 px variants for the hourly strip and forecast list. */
static void icon_build_small(lv_obj_t *p, int code, bool is_day, int s)
{
    lv_obj_clean(p);
    int kind = icon_kind(code);
    int cloud_y = (s * 55) / 100;
    int cloud_h = (s * 30) / 100;
    if (kind == 0 && !is_day) {
        lv_obj_t *arc = lv_arc_create(p);
        lv_obj_set_size(arc, s, s);
        lv_obj_set_pos(arc, 0, 0);
        lv_obj_set_style_bg_opa(arc, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_width(arc, 0, 0);
        lv_obj_set_style_pad_all(arc, 0, 0);
        lv_obj_set_style_arc_width(arc, s / 5, LV_PART_MAIN);
        lv_obj_set_style_arc_color(arc, lv_color_hex(C_TEXT), LV_PART_MAIN);
        lv_obj_set_style_arc_opa(arc, LV_OPA_TRANSP, LV_PART_INDICATOR);
        lv_arc_set_bg_angles(arc, 55, 305);
        lv_obj_set_scrollable(arc, false);
        lv_obj_set_clickable(arc, false);
        return;
    }
    if (kind == 0) {
        int d = (s * 55) / 100;
        int r = (s * 18) / 100;
        int o = (s - d) / 2;
        icon_part(p, o, o, d, d, d / 2, C_AMBER);
        icon_part(p, o + d / 2 - r / 2, 0, r, (s - d) / 2, r / 2, C_AMBER);
        icon_part(p, o + d / 2 - r / 2, d + (s - d) / 2, r, (s - d) / 2, r / 2, C_AMBER);
        icon_part(p, 0, o + d / 2 - r / 2, (s - d) / 2, r, r / 2, C_AMBER);
        icon_part(p, d + (s - d) / 2, o + d / 2 - r / 2, (s - d) / 2, r, r / 2, C_AMBER);
        return;
    }
    if (kind == 1) {
        int d = s / 3;
        icon_part(p, 0, 0, d, d, d / 2, C_AMBER);
        icon_part(p, s / 4, s / 2, s - s / 4, cloud_h, cloud_h / 2, C_TEXT);
        icon_part(p, s / 3, s / 2 - s / 8, s / 2, s / 8, s / 16, C_TEXT);
        return;
    }
    if (kind == 3) {
        icon_part(p, 0, s / 5, s, s / 6, s / 12, C_MUTED);
        icon_part(p, s / 8, (s * 3) / 5, (s * 7) / 8, s / 6, s / 12, C_MUTED);
        return;
    }
    icon_part(p, 1, cloud_y, s - 2, cloud_h, cloud_h / 2, C_TEXT);
    icon_part(p, s / 4, cloud_y - s / 8, s / 2, s / 8, s / 16, C_TEXT);
    if (kind == 4) {
        icon_part(p, s / 4, cloud_y + cloud_h + 2, 2, 2, 1, C_ACCENT);
        icon_part(p, s / 2, cloud_y + cloud_h + 2, 2, 2, 1, C_ACCENT);
        icon_part(p, (s * 3) / 4, cloud_y + cloud_h + 2, 2, 2, 1, C_ACCENT);
    } else if (kind == 5) {
        icon_part(p, s / 4, cloud_y + cloud_h + 2, 2, 2, 1, C_TEXT);
        icon_part(p, s / 2, cloud_y + cloud_h + 2, 2, 2, 1, C_TEXT);
        icon_part(p, (s * 3) / 4, cloud_y + cloud_h + 2, 2, 2, 1, C_TEXT);
    } else if (kind == 6) {
        icon_part(p, s / 2, cloud_y + cloud_h + 1, 4, 3, 1, C_AMBER);
    }
}

/* ------------------------------------------------------------------ */
/* Event handlers                                                     */
/* ------------------------------------------------------------------ */

static void cb_refresh(lv_event_t *e)
{
    (void)e;
    if (g_cb.on_refresh != NULL) g_cb.on_refresh();
}

static void cb_rescan(lv_event_t *e)
{
    (void)e;
    ui_set_wifi_scan(true, "Scanning...");
    if (g_cb.on_wifi_scan != NULL) g_cb.on_wifi_scan();
}

static void cb_scan_cancel(lv_event_t *e)
{
    (void)e;
    if (g_cb.on_wifi_cancel != NULL) g_cb.on_wifi_cancel();
    ui_show_weather();
}

static void cb_wifi_row(lv_event_t *e)
{
    lv_obj_t *row = (lv_obj_t *)lv_event_get_current_target(e);
    int idx = (int)(intptr_t)lv_obj_get_user_data(row);
    if (idx < 0 || idx >= g_net_count) return;
    copy_ascii(g_selected_ssid, sizeof(g_selected_ssid), g_nets[idx].ssid);
    ui_show_wifi_password(g_selected_ssid);
}

static void cb_pw_show(lv_event_t *e)
{
    (void)e;
    g_pw_visible = !g_pw_visible;
    lv_textarea_set_password_mode(g_pw_input, !g_pw_visible);
    set_button_text(g_pw_show, g_pw_visible ? "Hide" : "Show");
}

static void cb_pw_connect(lv_event_t *e)
{
    (void)e;
    if (g_pw_input == NULL) return;
    const char *pw = lv_textarea_get_text(g_pw_input);
    if (g_cb.on_wifi_connect != NULL) {
        g_cb.on_wifi_connect(g_selected_ssid, pw);
    }
    ui_show_wifi_connecting(g_selected_ssid);
}

static void cb_pw_cancel(lv_event_t *e)
{
    (void)e;
    if (g_cb.on_wifi_cancel != NULL) g_cb.on_wifi_cancel();
    ui_show_wifi_scan();
}

static void cb_pw_ready(lv_event_t *e)
{
    (void)e;
    cb_pw_connect(NULL);
}

static void cb_conn_cancel(lv_event_t *e)
{
    (void)e;
    if (g_cb.on_wifi_cancel != NULL) g_cb.on_wifi_cancel();
    ui_show_wifi_scan();
}

static void cb_result_primary(lv_event_t *e)
{
    (void)e;
    if (g_res_success) {
        if (g_cb.on_wifi_continue != NULL) g_cb.on_wifi_continue();
        ui_show_weather();
    } else {
        if (g_cb.on_wifi_retry != NULL) g_cb.on_wifi_retry();
        ui_show_wifi_connecting(g_selected_ssid);
    }
}

static void cb_result_secondary(lv_event_t *e)
{
    (void)e;
    ui_show_wifi_scan();
    if (g_cb.on_wifi_scan != NULL) g_cb.on_wifi_scan();
}

static void cb_nav_forecast(lv_event_t *e)
{
    (void)e;
    ui_show_forecast();
}

static void cb_nav_search(lv_event_t *e)
{
    (void)e;
    ui_show_city_search();
}

static void cb_nav_settings(lv_event_t *e)
{
    (void)e;
    ui_show_settings();
}

static void cb_forecast_back(lv_event_t *e)
{
    (void)e;
    ui_show_weather();
}

static void cb_city_back(lv_event_t *e)
{
    (void)e;
    ui_show_weather();
}

static void cb_city_focus(lv_event_t *e)
{
    (void)e;
    lv_obj_set_hidden(g_city_keyboard, false);
    lv_obj_set_hidden(g_city_results, true);
    lv_keyboard_set_textarea(g_city_keyboard, g_city_input);
}

static void cb_city_do_search(lv_event_t *e)
{
    (void)e;
    const char *q = lv_textarea_get_text(g_city_input);
    lv_obj_set_hidden(g_city_keyboard, true);
    lv_obj_set_hidden(g_city_results, false);
    for (int i = 0; i < UI_CITY_MAX; i++) {
        lv_obj_set_hidden(g_city_rows[i], true);
    }
    lv_label_set_text(g_city_status, "Searching...");
    if (g_cb.on_city_search != NULL) g_cb.on_city_search(q);
}

static void cb_city_ready(lv_event_t *e)
{
    (void)e;
    cb_city_do_search(NULL);
}

static void cb_city_row(lv_event_t *e)
{
    lv_obj_t *row = (lv_obj_t *)lv_event_get_current_target(e);
    int idx = (int)(intptr_t)lv_obj_get_user_data(row);
    if (idx < 0 || idx >= g_city_count) return;
    if (g_cb.on_city_select != NULL) g_cb.on_city_select(&g_cities[idx]);
}

static void cb_settings_back(lv_event_t *e)
{
    (void)e;
    ui_show_weather();
}

static void cb_about_open(lv_event_t *e)
{
    (void)e;
    ui_show_about();
}

static void cb_about_back(lv_event_t *e)
{
    (void)e;
    ui_show_settings();
}

static void settings_changed(void)
{
    if (g_cb.on_settings_changed != NULL) {
        g_cb.on_settings_changed(g_fahrenheit, g_clock24, g_brightness);
    }
}

static void cb_unit_c(lv_event_t *e)
{
    (void)e;
    g_fahrenheit = false;
    style_segment(g_set_unit_c, true);
    style_segment(g_set_unit_f, false);
    if (g_have_current) ui_set_weather(&g_current);
    if (g_hour_count > 0) ui_set_hourly(g_hours, g_hour_count);
    if (g_day_count > 0) ui_set_daily(g_days, g_day_count);
    settings_changed();
}

static void cb_unit_f(lv_event_t *e)
{
    (void)e;
    g_fahrenheit = true;
    style_segment(g_set_unit_c, false);
    style_segment(g_set_unit_f, true);
    if (g_have_current) ui_set_weather(&g_current);
    if (g_hour_count > 0) ui_set_hourly(g_hours, g_hour_count);
    if (g_day_count > 0) ui_set_daily(g_days, g_day_count);
    settings_changed();
}

static void cb_clock_12(lv_event_t *e)
{
    (void)e;
    g_clock24 = false;
    style_segment(g_set_clock_12, true);
    style_segment(g_set_clock_24, false);
    if (g_have_current) ui_set_weather(&g_current);
    if (g_hour_count > 0) ui_set_hourly(g_hours, g_hour_count);
    settings_changed();
}

static void cb_clock_24(lv_event_t *e)
{
    (void)e;
    g_clock24 = true;
    style_segment(g_set_clock_12, false);
    style_segment(g_set_clock_24, true);
    if (g_have_current) ui_set_weather(&g_current);
    if (g_hour_count > 0) ui_set_hourly(g_hours, g_hour_count);
    settings_changed();
}

static void cb_brightness(lv_event_t *e)
{
    lv_obj_t *slider = (lv_obj_t *)lv_event_get_target(e);
    g_brightness = (int)lv_slider_get_value(slider);
    char buf[8];
    snprintf(buf, sizeof(buf), "%d%%", g_brightness);
    lv_label_set_text(g_set_bright_value, buf);
    settings_changed();
}

static void cb_change_net(lv_event_t *e)
{
    (void)e;
    ui_show_wifi_scan();
    if (g_cb.on_wifi_scan != NULL) g_cb.on_wifi_scan();
}

static void cb_forget(lv_event_t *e)
{
    (void)e;
    if (!g_forget_armed) {
        g_forget_armed = 1;
        set_button_text(g_set_forget, "Tap again to forget");
        set_button_colors(g_set_forget, C_RED, C_TEXT);
        lv_label_set_text(g_set_saved, "Confirm forget");
        return;
    }
    g_forget_armed = 0;
    set_button_text(g_set_forget, "Forget network");
    set_button_colors(g_set_forget, C_PANEL2, C_TEXT);
    lv_label_set_text(g_set_saved, "No saved network");
    lv_label_set_text(g_set_wifi_ssid, "Not connected");
    lv_label_set_text(g_set_wifi_sub, "No saved network");
    lv_obj_set_style_bg_color(g_set_wifi_dot, lv_color_hex(C_DIM), 0);
    if (g_cb.on_wifi_forget != NULL) g_cb.on_wifi_forget();
}

static void cb_calibrate_request(lv_event_t *e)
{
    (void)e;
    if (g_cb.on_calibrate != NULL) g_cb.on_calibrate();
}

/* ------------------------------------------------------------------ */
/* Screen builders                                                    */
/* ------------------------------------------------------------------ */

static void build_splash(void)
{
    g_scr_splash = mk_screen("splash");
    lv_obj_t *t = label(g_scr_splash, "splash_title", "Weather Station", F24, C_TEXT, 0, 58, 320);
    lv_obj_set_style_text_align(t, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_t *s = label(g_scr_splash, "splash_sub", "ESP32-S3 | LVGL 9.6 | 320x240", F10, C_MUTED, 0, 92, 320);
    lv_obj_set_style_text_align(s, LV_TEXT_ALIGN_CENTER, 0);

    g_splash_bar = lv_bar_create(g_scr_splash);
    lv_obj_set_name(g_splash_bar, "splash_bar");
    lv_obj_set_pos(g_splash_bar, 40, 150);
    lv_obj_set_size(g_splash_bar, 240, 10);
    lv_bar_set_range(g_splash_bar, 0, 100);
    lv_bar_set_value(g_splash_bar, 0, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(g_splash_bar, lv_color_hex(C_PANEL2), LV_PART_MAIN);
    lv_obj_set_style_bg_color(g_splash_bar, lv_color_hex(C_ACCENT), LV_PART_INDICATOR);
    lv_obj_set_style_radius(g_splash_bar, 5, LV_PART_MAIN);
    lv_obj_set_style_radius(g_splash_bar, 5, LV_PART_INDICATOR);

    g_splash_status = label(g_scr_splash, "splash_status", "Starting...", F10, C_MUTED, 0, 168, 320);
    lv_obj_set_style_text_align(g_splash_status, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_t *a = label(g_scr_splash, "splash_credit", "Open-Meteo | NTP | TLS verified", F10, C_MUTED, 0, 214, 320);
    lv_obj_set_style_text_align(a, LV_TEXT_ALIGN_CENTER, 0);
}

static void build_scan(void)
{
    g_scr_scan = mk_screen("wifi_scan");
    label(g_scr_scan, "scan_title", "Wi-Fi networks", F16, C_TEXT, 10, 10, 240);
    lv_obj_t *rescan = button(g_scr_scan, "wifi_rescan", LV_SYMBOL_REFRESH,
                              276, 0, 44, 40, C_BTN, C_ACCENT, F16);
    lv_obj_add_event_cb(rescan, cb_rescan, LV_EVENT_CLICKED, NULL);

    g_scan_status = label(g_scr_scan, "wifi_scan_status", "Scanning...", F10, C_MUTED, 10, 42, 276);
    g_scan_spinner = lv_spinner_create(g_scr_scan);
    lv_obj_set_name(g_scan_spinner, "wifi_scan_spinner");
    lv_obj_set_pos(g_scan_spinner, 296, 40);
    lv_obj_set_size(g_scan_spinner, 18, 18);
    lv_obj_set_style_arc_width(g_scan_spinner, 3, LV_PART_MAIN);
    lv_obj_set_style_arc_width(g_scan_spinner, 3, LV_PART_INDICATOR);
    /* A visible track is what makes this read as a spinner instead of a
       floating arc on a TN panel. */
    lv_obj_set_style_arc_color(g_scan_spinner, lv_color_hex(C_MUTED), LV_PART_MAIN);
    lv_obj_set_style_arc_opa(g_scan_spinner, LV_OPA_30, LV_PART_MAIN);
    lv_obj_set_style_arc_color(g_scan_spinner, lv_color_hex(C_ACCENT), LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(g_scan_spinner, LV_OPA_TRANSP, 0);

    lv_obj_t *list = clear_box(g_scr_scan, "wifi_list", 0, 58, 320, 140);
    lv_obj_set_scrollable(list, true);
    lv_obj_set_scroll_dir(list, LV_DIR_VER);
    lv_obj_set_style_pad_all(list, 0, 0);

    for (int i = 0; i < 12; i++) {
        char nm[20];
        snprintf(nm, sizeof(nm), "wifi_row_%d", i);
        lv_obj_t *row = lv_button_create(list);
        lv_obj_set_name(row, nm);
        lv_obj_set_pos(row, 0, i * 47);
        lv_obj_set_size(row, 320, 46);
        lv_obj_set_style_bg_color(row, lv_color_hex(C_PANEL), 0);
        lv_obj_set_style_radius(row, 0, 0);
        lv_obj_set_style_border_width(row, 0, 0);
        lv_obj_set_style_pad_all(row, 0, 0);
        lv_obj_set_style_shadow_width(row, 0, 0);
        lv_obj_set_user_data(row, (void *)(intptr_t)i);
        lv_obj_add_event_cb(row, cb_wifi_row, LV_EVENT_CLICKED, NULL);
        lv_obj_set_hidden(row, true);

        g_scan_rows[i] = row;
        char sn[24];
        snprintf(sn, sizeof(sn), "wifi_ssid_%d", i);
        g_scan_ssid[i] = label(row, sn, "", F14, C_TEXT, 10, 2, 200);
        snprintf(sn, sizeof(sn), "wifi_sec_%d", i);
        g_scan_sec[i] = label(row, sn, "", F10, C_MUTED, 10, 26, 120);
        snprintf(sn, sizeof(sn), "wifi_rssi_%d", i);
        g_scan_rssi[i] = label(row, sn, "", F10, C_MUTED, 226, 26, 44);
        lv_obj_set_style_text_align(g_scan_rssi[i], LV_TEXT_ALIGN_RIGHT, 0);
        for (int b = 0; b < 4; b++) {
            g_scan_bars[i][b] = icon_part(row, 276 + b * 7, 36 - (4 + b * 4), 4, 4 + b * 4, 1, C_DIM);
        }
    }

    lv_obj_t *cancel = button(g_scr_scan, "wifi_cancel", "Cancel", 110, 200, 100, 40, C_PANEL2, C_TEXT, F14);
    lv_obj_add_event_cb(cancel, cb_scan_cancel, LV_EVENT_CLICKED, NULL);
}

static void build_password(void)
{
    g_scr_pw = mk_screen("wifi_password");
    g_pw_title = label(g_scr_pw, "wifi_pw_title", "Connect to network", F14, C_TEXT, 10, 4, 300);

    g_pw_input = lv_textarea_create(g_scr_pw);
    lv_obj_set_name(g_pw_input, "password_input");
    lv_obj_set_pos(g_pw_input, 10, 22);
    lv_obj_set_size(g_pw_input, 300, 36);
    lv_textarea_set_one_line(g_pw_input, true);
    lv_textarea_set_password_mode(g_pw_input, true);
    lv_textarea_set_placeholder_text(g_pw_input, "Password");
    lv_textarea_set_max_length(g_pw_input, 64);
    lv_obj_set_style_bg_color(g_pw_input, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_text_color(g_pw_input, lv_color_hex(C_TEXT), 0);
    lv_obj_set_style_text_font(g_pw_input, F14, 0);
    lv_obj_set_style_border_width(g_pw_input, 1, 0);
    lv_obj_set_style_border_color(g_pw_input, lv_color_hex(C_BTN), 0);
    lv_obj_set_style_border_color(g_pw_input, lv_color_hex(C_ACCENT), LV_STATE_FOCUSED);
    lv_obj_set_style_radius(g_pw_input, 6, 0);
    lv_obj_set_style_pad_left(g_pw_input, 8, 0);
    lv_obj_set_style_pad_right(g_pw_input, 8, 0);
    lv_obj_set_style_text_color(g_pw_input, lv_color_hex(C_MUTED), LV_PART_TEXTAREA_PLACEHOLDER);
    lv_obj_set_style_bg_color(g_pw_input, lv_color_hex(C_ACCENT), LV_PART_CURSOR);
    lv_obj_set_style_bg_opa(g_pw_input, LV_OPA_COVER, LV_PART_CURSOR);

    g_pw_show = button(g_scr_pw, "show_password", "Show", 10, 62, 60, 40, C_PANEL2, C_TEXT, F12);
    g_pw_show_label = lv_obj_get_child(g_pw_show, 0);
    (void)g_pw_show_label;
    lv_obj_add_event_cb(g_pw_show, cb_pw_show, LV_EVENT_CLICKED, NULL);

    lv_obj_t *connect = button(g_scr_pw, "connect_btn", "Connect", 110, 62, 100, 40, C_ACCENT, C_BG, F14);
    lv_obj_add_event_cb(connect, cb_pw_connect, LV_EVENT_CLICKED, NULL);

    lv_obj_t *cancel = button(g_scr_pw, "cancel_btn", "Cancel", 214, 62, 100, 40, C_PANEL2, C_TEXT, F14);
    lv_obj_add_event_cb(cancel, cb_pw_cancel, LV_EVENT_CLICKED, NULL);

    g_pw_keyboard = lv_keyboard_create(g_scr_pw);
    lv_obj_set_name(g_pw_keyboard, "keyboard");
    lv_obj_set_size(g_pw_keyboard, 320, 136);
    lv_obj_align(g_pw_keyboard, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_keyboard_set_textarea(g_pw_keyboard, g_pw_input);
    lv_keyboard_set_mode(g_pw_keyboard, LV_KEYBOARD_MODE_TEXT_LOWER);
    lv_obj_set_style_bg_color(g_pw_keyboard, lv_color_hex(C_BG), 0);
    lv_obj_set_style_border_width(g_pw_keyboard, 0, 0);
    lv_obj_set_style_pad_all(g_pw_keyboard, 2, 0);
    lv_obj_set_style_bg_color(g_pw_keyboard, lv_color_hex(C_PANEL2), LV_PART_ITEMS);
    lv_obj_set_style_text_color(g_pw_keyboard, lv_color_hex(C_TEXT), LV_PART_ITEMS);
    lv_obj_set_style_border_color(g_pw_keyboard, lv_color_hex(C_BG), LV_PART_ITEMS);
    lv_obj_set_style_border_width(g_pw_keyboard, 1, LV_PART_ITEMS);
    lv_obj_set_style_radius(g_pw_keyboard, 4, LV_PART_ITEMS);
    /* Control keys are CHECKED; without an explicit checked selector they
       fall back to the light theme's white checked style. */
    lv_obj_set_style_bg_color(g_pw_keyboard, lv_color_hex(C_PANEL2), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_text_color(g_pw_keyboard, lv_color_hex(C_TEXT), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_border_color(g_pw_keyboard, lv_color_hex(C_BG), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_bg_color(g_pw_keyboard, lv_color_hex(C_ACCENT), LV_PART_ITEMS | LV_STATE_PRESSED);
    lv_obj_set_style_text_color(g_pw_keyboard, lv_color_hex(C_BG), LV_PART_ITEMS | LV_STATE_PRESSED);
    lv_obj_add_event_cb(g_pw_keyboard, cb_pw_ready, LV_EVENT_READY, NULL);
}

static void build_connecting(void)
{
    g_scr_connecting = mk_screen("wifi_connecting");
    lv_obj_t *sp = lv_spinner_create(g_scr_connecting);
    lv_obj_set_name(sp, "connect_spinner");
    lv_obj_set_pos(sp, 136, 48);
    lv_obj_set_size(sp, 48, 48);
    lv_obj_set_style_arc_width(sp, 5, LV_PART_MAIN);
    lv_obj_set_style_arc_width(sp, 5, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(sp, lv_color_hex(C_MUTED), LV_PART_MAIN);
    lv_obj_set_style_arc_opa(sp, LV_OPA_30, LV_PART_MAIN);
    lv_obj_set_style_arc_color(sp, lv_color_hex(C_ACCENT), LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(sp, LV_OPA_TRANSP, 0);

    lv_obj_t *t = label(g_scr_connecting, "connect_title", "Connecting...", F16, C_TEXT, 0, 108, 320);
    lv_obj_set_style_text_align(t, LV_TEXT_ALIGN_CENTER, 0);
    g_conn_ssid = label(g_scr_connecting, "connect_ssid", "", F12, C_MUTED, 0, 134, 320);
    lv_obj_set_style_text_align(g_conn_ssid, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_t *h = label(g_scr_connecting, "connect_hint", "This can take up to 15 seconds", F10, C_MUTED, 0, 156, 320);
    lv_obj_set_style_text_align(h, LV_TEXT_ALIGN_CENTER, 0);

    lv_obj_t *cancel = button(g_scr_connecting, "connect_cancel", "Cancel", 110, 190, 100, 40, C_PANEL2, C_TEXT, F14);
    lv_obj_add_event_cb(cancel, cb_conn_cancel, LV_EVENT_CLICKED, NULL);
}

static void build_result(void)
{
    g_scr_result = mk_screen("wifi_result");
    g_res_icon = icon_part(g_scr_result, 136, 26, 48, 48, 24, C_GREEN);
    lv_obj_set_name(g_res_icon, "wifi_result_icon");
    g_res_icon_label = label(g_res_icon, "wifi_result_symbol", LV_SYMBOL_OK, F20, C_BG, 0, 0, 48);
    lv_obj_set_style_text_align(g_res_icon_label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_pos(g_res_icon_label, 0, 12);

    g_res_title = label(g_scr_result, "wifi_result_title", "Connected", F16, C_TEXT, 0, 84, 320);
    lv_obj_set_style_text_align(g_res_title, LV_TEXT_ALIGN_CENTER, 0);
    g_res_detail = label(g_scr_result, "wifi_result_detail", "", F12, C_MUTED, 10, 108, 300);
    lv_obj_set_style_text_align(g_res_detail, LV_TEXT_ALIGN_CENTER, 0);
    lv_label_set_long_mode(g_res_detail, LV_LABEL_LONG_WRAP);
    lv_obj_set_height(g_res_detail, 46);

    g_res_primary = button(g_scr_result, "wifi_result_primary", "Continue", 44, 186, 112, 40, C_ACCENT, C_BG, F14);
    g_res_primary_label = lv_obj_get_child(g_res_primary, 0);
    (void)g_res_primary_label;
    lv_obj_add_event_cb(g_res_primary, cb_result_primary, LV_EVENT_CLICKED, NULL);

    lv_obj_t *sec = button(g_scr_result, "wifi_result_secondary", "Change network", 164, 186, 112, 40, C_PANEL2, C_TEXT, F12);
    lv_obj_add_event_cb(sec, cb_result_secondary, LV_EVENT_CLICKED, NULL);
}

static void build_weather(void)
{
    g_scr_weather = mk_screen("weather");

    /* Top bar */
    lv_obj_t *top = clear_box(g_scr_weather, "top_bar", 0, 0, 320, 40);
    lv_obj_set_style_bg_color(top, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_bg_opa(top, LV_OPA_COVER, 0);
    g_weather_city = label(top, "weather_city", "No city", F16, C_TEXT, 8, 3, 190);
    g_weather_updated = label(top, "weather_updated", "Updated --:--", F10, C_MUTED, 8, 24, 150);
    g_weather_wifi = label(top, "weather_wifi", LV_SYMBOL_WIFI, F14, C_ACCENT, 206, 12, 20);
    for (int i = 0; i < 4; i++) {
        g_weather_wifi_bars[i] = icon_part(top, 228 + i * 6, 28 - (4 + i * 4), 4, 4 + i * 4, 1, C_ACCENT);
    }
    g_weather_rssi = label(top, "weather_rssi", "--", F10, C_MUTED, 252, 22, 28);
    lv_obj_t *refresh = button(top, "refresh_btn", LV_SYMBOL_REFRESH, 280, 0, 40, 40, C_BTN, C_ACCENT, F16);
    lv_obj_add_event_cb(refresh, cb_refresh, LV_EVENT_CLICKED, NULL);

    /* Hero */
    g_weather_hero = clear_box(g_scr_weather, "hero", 0, 40, 320, 80);
    g_weather_temp = label(g_weather_hero, "weather_temp", "--\xC2\xB0", F48, C_TEXT, 8, 8, 106);
    g_weather_icon = clear_box(g_weather_hero, "weather_icon", 116, 8, 64, 64);
    g_weather_cond = label(g_weather_hero, "weather_cond", "--", F14, C_TEXT, 190, 14, 122);
    g_weather_feels = label(g_weather_hero, "weather_feels", "Feels like --", F12, C_MUTED, 190, 38, 122);

    /* Metrics */
    g_weather_metrics = clear_box(g_scr_weather, "metrics", 0, 120, 320, 36);
    lv_obj_set_style_bg_color(g_weather_metrics, lv_color_hex(C_PANEL2), 0);
    lv_obj_set_style_bg_opa(g_weather_metrics, LV_OPA_COVER, 0);
    const char *mlabel[4] = {"Humidity", "Wind", "Pressure", "Feels"};
    const char *mname[4] = {"metric_hum_label", "metric_wind_label", "metric_press_label", "metric_feels_label"};
    for (int i = 0; i < 4; i++) {
        label(g_weather_metrics, mname[i], mlabel[i], F10, C_MUTED, 6 + i * 80, 2, 74);
    }
    g_weather_hum = label(g_weather_metrics, "weather_humidity", "--", F12, C_TEXT, 6, 17, 74);
    g_weather_wind = label(g_weather_metrics, "weather_wind", "--", F12, C_TEXT, 86, 17, 74);
    g_weather_press = label(g_weather_metrics, "weather_pressure", "--", F12, C_TEXT, 166, 17, 74);
    g_weather_metric_feels = label(g_weather_metrics, "weather_feels_metric", "--", F12, C_TEXT, 246, 17, 68);

    /* Hourly strip */
    g_weather_hourly = clear_box(g_scr_weather, "hourly_strip", 0, 156, 320, 44);
    for (int i = 0; i < 5; i++) {
        char nm[16];
        snprintf(nm, sizeof(nm), "hour_tile_%d", i);
        lv_obj_t *tile = clear_box(g_weather_hourly, nm, i * 64, 0, 64, 44);
        lv_obj_set_style_bg_color(tile, lv_color_hex(i == 0 ? C_PANEL2 : C_PANEL), 0);
        lv_obj_set_style_bg_opa(tile, LV_OPA_COVER, 0);
        g_hour_tile[i] = tile;
        snprintf(nm, sizeof(nm), "hour_time_%d", i);
        g_hour_time[i] = label(tile, nm, i == 0 ? "Now" : "--:--", F10, C_MUTED, 4, 3, 56);
        snprintf(nm, sizeof(nm), "hour_icon_%d", i);
        g_hour_icon[i] = clear_box(tile, nm, 5, 15, 18, 18);
        snprintf(nm, sizeof(nm), "hour_temp_%d", i);
        g_hour_temp[i] = label(tile, nm, "--\xC2\xB0", F12, C_TEXT, 28, 17, 34);
    }

    /* Error card (hidden until a fetch fails) */
    g_weather_error = clear_box(g_scr_weather, "weather_error_panel", 10, 52, 300, 140);
    lv_obj_set_style_bg_color(g_weather_error, lv_color_hex(C_PANEL2), 0);
    lv_obj_set_style_bg_opa(g_weather_error, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(g_weather_error, 8, 0);
    lv_obj_set_hidden(g_weather_error, true);
    lv_obj_t *wi = label(g_weather_error, "weather_error_icon", LV_SYMBOL_WARNING, F24, C_AMBER, 0, 8, 300);
    lv_obj_set_style_text_align(wi, LV_TEXT_ALIGN_CENTER, 0);
    g_weather_error_title = label(g_weather_error, "weather_error_title", "Update failed", F14, C_TEXT, 10, 38, 280);
    lv_obj_set_style_text_align(g_weather_error_title, LV_TEXT_ALIGN_CENTER, 0);
    g_weather_error_detail = label(g_weather_error, "weather_error_detail", "", F10, C_MUTED, 10, 58, 280);
    lv_obj_set_style_text_align(g_weather_error_detail, LV_TEXT_ALIGN_CENTER, 0);
    lv_label_set_long_mode(g_weather_error_detail, LV_LABEL_LONG_WRAP);
    lv_obj_set_height(g_weather_error_detail, 34);
    lv_obj_t *retry = button(g_weather_error, "weather_retry", "Retry", 100, 94, 100, 40, C_ACCENT, C_BG, F14);
    lv_obj_add_event_cb(retry, cb_refresh, LV_EVENT_CLICKED, NULL);

    /* Bottom navigation */
    lv_obj_t *nav = clear_box(g_scr_weather, "bottom_nav", 0, 200, 320, 40);
    lv_obj_set_style_bg_color(nav, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_bg_opa(nav, LV_OPA_COVER, 0);
    lv_obj_t *b1 = button(nav, "nav_forecast", "Forecast", 4, 0, 100, 40, C_BTN, C_TEXT, F12);
    lv_obj_add_event_cb(b1, cb_nav_forecast, LV_EVENT_CLICKED, NULL);
    lv_obj_t *b2 = button(nav, "nav_search", "Search", 110, 0, 100, 40, C_BTN, C_TEXT, F12);
    lv_obj_add_event_cb(b2, cb_nav_search, LV_EVENT_CLICKED, NULL);
    lv_obj_t *b3 = button(nav, "nav_settings", "Settings", 216, 0, 100, 40, C_BTN, C_TEXT, F12);
    lv_obj_add_event_cb(b3, cb_nav_settings, LV_EVENT_CLICKED, NULL);
}

static void build_forecast(void)
{
    g_scr_forecast = mk_screen("forecast");
    lv_obj_t *back = button(g_scr_forecast, "forecast_back", LV_SYMBOL_LEFT, 0, 0, 40, 40, C_PANEL, C_TEXT, F16);
    lv_obj_add_event_cb(back, cb_forecast_back, LV_EVENT_CLICKED, NULL);
    label(g_scr_forecast, "forecast_title", "5-day forecast", F16, C_TEXT, 48, 10, 160);
    lv_obj_t *src = label(g_scr_forecast, "forecast_source", "Open-Meteo", F10, C_MUTED, 214, 14, 98);
    lv_obj_set_style_text_align(src, LV_TEXT_ALIGN_RIGHT, 0);

    for (int i = 0; i < 5; i++) {
        char nm[20];
        snprintf(nm, sizeof(nm), "forecast_row_%d", i);
        lv_obj_t *row = clear_box(g_scr_forecast, nm, 0, 40 + i * 40, 320, 40);
        lv_obj_set_style_bg_color(row, lv_color_hex((i & 1) ? C_PANEL : C_BG), 0);
        lv_obj_set_style_bg_opa(row, LV_OPA_COVER, 0);
        g_fc_rows[i] = row;
        snprintf(nm, sizeof(nm), "forecast_day_%d", i);
        g_fc_day[i] = label(row, nm, "--", F12, C_TEXT, 8, 12, 52);
        snprintf(nm, sizeof(nm), "forecast_icon_%d", i);
        g_fc_icon[i] = clear_box(row, nm, 64, 8, 24, 24);
        snprintf(nm, sizeof(nm), "forecast_cond_%d", i);
        g_fc_cond[i] = label(row, nm, "--", F10, C_MUTED, 94, 13, 104);
        snprintf(nm, sizeof(nm), "forecast_high_%d", i);
        g_fc_high[i] = label(row, nm, "--", F12, C_TEXT, 204, 12, 36);
        snprintf(nm, sizeof(nm), "forecast_low_%d", i);
        g_fc_low[i] = label(row, nm, "--", F12, C_MUTED, 240, 12, 36);
        snprintf(nm, sizeof(nm), "forecast_precip_%d", i);
        g_fc_precip[i] = label(row, nm, "--", F10, C_ACCENT, 276, 14, 36);
        lv_obj_set_style_text_align(g_fc_precip[i], LV_TEXT_ALIGN_RIGHT, 0);
    }
}

static void build_city(void)
{
    g_scr_city = mk_screen("city_search");
    lv_obj_t *back = button(g_scr_city, "city_back", LV_SYMBOL_LEFT, 0, 0, 40, 40, C_PANEL, C_TEXT, F16);
    lv_obj_add_event_cb(back, cb_city_back, LV_EVENT_CLICKED, NULL);
    label(g_scr_city, "city_title", "Find a city", F16, C_TEXT, 48, 10, 200);

    g_city_input = lv_textarea_create(g_scr_city);
    lv_obj_set_name(g_city_input, "city_input");
    lv_obj_set_pos(g_city_input, 10, 46);
    lv_obj_set_size(g_city_input, 224, 36);
    lv_textarea_set_one_line(g_city_input, true);
    lv_textarea_set_placeholder_text(g_city_input, "City name");
    lv_textarea_set_max_length(g_city_input, 40);
    lv_obj_set_style_bg_color(g_city_input, lv_color_hex(C_PANEL), 0);
    lv_obj_set_style_text_color(g_city_input, lv_color_hex(C_TEXT), 0);
    lv_obj_set_style_text_font(g_city_input, F14, 0);
    lv_obj_set_style_border_width(g_city_input, 1, 0);
    lv_obj_set_style_border_color(g_city_input, lv_color_hex(C_BTN), 0);
    lv_obj_set_style_border_color(g_city_input, lv_color_hex(C_ACCENT), LV_STATE_FOCUSED);
    lv_obj_set_style_radius(g_city_input, 6, 0);
    lv_obj_set_style_pad_left(g_city_input, 8, 0);
    lv_obj_set_style_pad_right(g_city_input, 8, 0);
    lv_obj_set_style_text_color(g_city_input, lv_color_hex(C_MUTED), LV_PART_TEXTAREA_PLACEHOLDER);
    lv_obj_set_style_bg_color(g_city_input, lv_color_hex(C_ACCENT), LV_PART_CURSOR);
    lv_obj_set_style_bg_opa(g_city_input, LV_OPA_COVER, LV_PART_CURSOR);
    lv_obj_add_event_cb(g_city_input, cb_city_focus, LV_EVENT_CLICKED, NULL);

    lv_obj_t *search = button(g_scr_city, "city_search_btn", "Search", 242, 44, 68, 40, C_ACCENT, C_BG, F12);
    lv_obj_add_event_cb(search, cb_city_do_search, LV_EVENT_CLICKED, NULL);

    g_city_status = label(g_scr_city, "city_status", "Type a city and press ready", F10, C_MUTED, 10, 86, 300);

    g_city_results = clear_box(g_scr_city, "city_results", 0, 102, 320, 136);
    lv_obj_set_hidden(g_city_results, true);
    for (int i = 0; i < UI_CITY_MAX; i++) {
        char nm[20];
        snprintf(nm, sizeof(nm), "city_row_%d", i);
        lv_obj_t *row = lv_button_create(g_city_results);
        lv_obj_set_name(row, nm);
        lv_obj_set_pos(row, 0, i * 40);
        lv_obj_set_size(row, 320, 40);
        lv_obj_set_style_bg_color(row, lv_color_hex((i & 1) ? C_PANEL : C_BG), 0);
        lv_obj_set_style_bg_opa(row, LV_OPA_COVER, 0);
        lv_obj_set_style_radius(row, 0, 0);
        lv_obj_set_style_border_width(row, 0, 0);
        lv_obj_set_style_pad_all(row, 0, 0);
        lv_obj_set_style_shadow_width(row, 0, 0);
        lv_obj_set_user_data(row, (void *)(intptr_t)i);
        lv_obj_add_event_cb(row, cb_city_row, LV_EVENT_CLICKED, NULL);
        g_city_rows[i] = row;
        snprintf(nm, sizeof(nm), "city_name_%d", i);
        g_city_name[i] = label(row, nm, "", F12, C_TEXT, 10, 3, 280);
        snprintf(nm, sizeof(nm), "city_region_%d", i);
        g_city_region[i] = label(row, nm, "", F10, C_MUTED, 10, 21, 280);
        lv_obj_set_hidden(row, true);
    }

    g_city_keyboard = lv_keyboard_create(g_scr_city);
    lv_obj_set_name(g_city_keyboard, "city_keyboard");
    lv_obj_set_size(g_city_keyboard, 320, 136);
    lv_obj_align(g_city_keyboard, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_keyboard_set_textarea(g_city_keyboard, g_city_input);
    lv_keyboard_set_mode(g_city_keyboard, LV_KEYBOARD_MODE_TEXT_LOWER);
    lv_obj_set_style_bg_color(g_city_keyboard, lv_color_hex(C_BG), 0);
    lv_obj_set_style_border_width(g_city_keyboard, 0, 0);
    lv_obj_set_style_pad_all(g_city_keyboard, 2, 0);
    lv_obj_set_style_bg_color(g_city_keyboard, lv_color_hex(C_PANEL2), LV_PART_ITEMS);
    lv_obj_set_style_text_color(g_city_keyboard, lv_color_hex(C_TEXT), LV_PART_ITEMS);
    lv_obj_set_style_border_color(g_city_keyboard, lv_color_hex(C_BG), LV_PART_ITEMS);
    lv_obj_set_style_border_width(g_city_keyboard, 1, LV_PART_ITEMS);
    lv_obj_set_style_radius(g_city_keyboard, 4, LV_PART_ITEMS);
    /* Control keys are CHECKED; without an explicit checked selector they
       fall back to the light theme's white checked style. */
    lv_obj_set_style_bg_color(g_city_keyboard, lv_color_hex(C_PANEL2), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_text_color(g_city_keyboard, lv_color_hex(C_TEXT), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_border_color(g_city_keyboard, lv_color_hex(C_BG), LV_PART_ITEMS | LV_STATE_CHECKED);
    lv_obj_set_style_bg_color(g_city_keyboard, lv_color_hex(C_ACCENT), LV_PART_ITEMS | LV_STATE_PRESSED);
    lv_obj_set_style_text_color(g_city_keyboard, lv_color_hex(C_BG), LV_PART_ITEMS | LV_STATE_PRESSED);
    lv_obj_add_event_cb(g_city_keyboard, cb_city_ready, LV_EVENT_READY, NULL);
}

static void build_settings(void)
{
    g_scr_settings = mk_screen("settings");
    lv_obj_t *back = button(g_scr_settings, "settings_back", LV_SYMBOL_LEFT, 0, 0, 40, 40, C_PANEL, C_TEXT, F16);
    lv_obj_add_event_cb(back, cb_settings_back, LV_EVENT_CLICKED, NULL);
    label(g_scr_settings, "settings_title", "Settings", F16, C_TEXT, 48, 10, 190);

    lv_obj_t *about = button(g_scr_settings, "settings_about", "About", 252, 0, 60, 40, C_BTN, C_TEXT, F12);
    lv_obj_add_event_cb(about, cb_about_open, LV_EVENT_CLICKED, NULL);

    label(g_scr_settings, "units_label", "Units", F12, C_MUTED, 8, 54, 44);
    g_set_unit_c = button(g_scr_settings, "unit_c", "\xC2\xB0""C", 54, 44, 40, 40, C_ACCENT, C_BG, F12);
    g_set_unit_f = button(g_scr_settings, "unit_f", "\xC2\xB0""F", 96, 44, 40, 40, C_PANEL2, C_TEXT, F12);
    lv_obj_add_event_cb(g_set_unit_c, cb_unit_c, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(g_set_unit_f, cb_unit_f, LV_EVENT_CLICKED, NULL);

    label(g_scr_settings, "clock_label", "Clock", F12, C_MUTED, 150, 54, 42);
    g_set_clock_12 = button(g_scr_settings, "clock_12", "12h", 194, 44, 40, 40, C_PANEL2, C_TEXT, F12);
    g_set_clock_24 = button(g_scr_settings, "clock_24", "24h", 236, 44, 40, 40, C_ACCENT, C_BG, F12);
    lv_obj_add_event_cb(g_set_clock_12, cb_clock_12, LV_EVENT_CLICKED, NULL);
    lv_obj_add_event_cb(g_set_clock_24, cb_clock_24, LV_EVENT_CLICKED, NULL);

    label(g_scr_settings, "brightness_label", "Brightness", F12, C_MUTED, 8, 100, 92);
    lv_obj_t *sl = lv_slider_create(g_scr_settings);
    g_set_brightness = sl;
    lv_obj_set_name(sl, "brightness_slider");
    lv_obj_set_pos(sl, 104, 88);
    lv_obj_set_size(sl, 150, 40);
    lv_slider_set_range(sl, 10, 100);
    lv_slider_set_value(sl, 100, LV_ANIM_OFF);
    lv_obj_set_style_bg_color(sl, lv_color_hex(C_PANEL2), LV_PART_MAIN);
    lv_obj_set_style_bg_color(sl, lv_color_hex(C_ACCENT), LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(sl, lv_color_hex(C_TEXT), LV_PART_KNOB);
    lv_obj_add_event_cb(sl, cb_brightness, LV_EVENT_VALUE_CHANGED, NULL);
    g_set_bright_value = label(g_scr_settings, "brightness_value", "100%", F10, C_TEXT, 272, 104, 40);
    lv_obj_set_style_text_align(g_set_bright_value, LV_TEXT_ALIGN_RIGHT, 0);

    lv_obj_t *card = clear_box(g_scr_settings, "settings_wifi_card", 8, 132, 304, 44);
    lv_obj_set_style_bg_color(card, lv_color_hex(C_PANEL2), 0);
    lv_obj_set_style_bg_opa(card, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(card, 8, 0);
    g_set_wifi_dot = icon_part(card, 12, 18, 8, 8, 4, C_GREEN);
    lv_obj_set_name(g_set_wifi_dot, "settings_wifi_dot");
    g_set_wifi_ssid = label(card, "settings_wifi_ssid", "Not connected", F12, C_TEXT, 28, 5, 180);
    g_set_wifi_sub = label(card, "settings_wifi_sub", "No saved network", F10, C_MUTED, 28, 23, 180);
    lv_obj_t *change = button(card, "settings_change_net", "Change", 214, 2, 80, 40, C_BTN, C_TEXT, F12);
    lv_obj_add_event_cb(change, cb_change_net, LV_EVENT_CLICKED, NULL);

    g_set_forget = button(g_scr_settings, "settings_forget", "Forget network", 8, 182, 136, 40, C_PANEL2, C_TEXT, F12);
    g_set_forget_label = lv_obj_get_child(g_set_forget, 0);
    (void)g_set_forget_label;
    lv_obj_add_event_cb(g_set_forget, cb_forget, LV_EVENT_CLICKED, NULL);

    lv_obj_t *cal = button(g_scr_settings, "settings_calibrate", "Calibrate touch",
                           150, 182, 162, 40, C_BTN, C_TEXT, F12);
    lv_obj_add_event_cb(cal, cb_calibrate_request, LV_EVENT_CLICKED, NULL);

    g_set_saved = label(g_scr_settings, "settings_saved", "No saved network", F10, C_MUTED, 8, 224, 304);
    lv_obj_set_style_text_align(g_set_saved, LV_TEXT_ALIGN_CENTER, 0);


    style_segment(g_set_unit_c, !g_fahrenheit);
    style_segment(g_set_unit_f, g_fahrenheit);
    style_segment(g_set_clock_12, !g_clock24);
    style_segment(g_set_clock_24, g_clock24);
}

static void build_about(void)
{
    g_scr_about = mk_screen("about");
    lv_obj_t *back = button(g_scr_about, "about_back", LV_SYMBOL_LEFT, 0, 0, 40, 40, C_PANEL, C_TEXT, F16);
    lv_obj_add_event_cb(back, cb_about_back, LV_EVENT_CLICKED, NULL);
    label(g_scr_about, "about_title", "About", F16, C_TEXT, 48, 10, 200);

    const char *keys[9] = {"Firmware", "GUI", "Wi-Fi", "IP address", "MAC",
                           "Free heap", "Free PSRAM", "Uptime", "Data"};
    for (int i = 0; i < 9; i++) {
        int y = 42 + i * 22;
        char nm[20];
        snprintf(nm, sizeof(nm), "about_key_%d", i);
        label(g_scr_about, nm, keys[i], F10, C_MUTED, 10, y, 92);
        snprintf(nm, sizeof(nm), "about_val_%d", i);
        g_about_values[i] = label(g_scr_about, nm, "--", F10, C_TEXT, 104, y, 206);
        lv_obj_set_style_text_align(g_about_values[i], LV_TEXT_ALIGN_RIGHT, 0);
    }
    lv_label_set_text(g_about_values[0], "1.0.0");
    lv_label_set_text(g_about_values[1], "LVGL 9.6");
    lv_label_set_text(g_about_values[2], "Not connected");
    lv_label_set_text(g_about_values[8], "Open-Meteo.com");
}

/* ------------------------------------------------------------------ */
/* Public API                                                        */
/* ------------------------------------------------------------------ */

void ui_init(const ui_callbacks_t *callbacks)
{
    if (callbacks != NULL) {
        g_cb = *callbacks;
    } else {
        memset(&g_cb, 0, sizeof(g_cb));
    }
    g_fahrenheit = false;
    g_clock24 = true;
    g_brightness = 100;
    g_pw_visible = false;
    g_res_success = false;
    g_forget_armed = 0;
    g_have_current = false;
    g_net_count = 0;
    g_city_count = 0;
    g_hour_count = 0;
    g_day_count = 0;
    memset(g_updated_raw, 0, sizeof(g_updated_raw));
    memset(&g_current, 0, sizeof(g_current));

    build_splash();
    build_scan();
    build_password();
    build_connecting();
    build_result();
    build_weather();
    build_forecast();
    build_city();
    build_settings();
    build_about();

    lv_screen_load(g_scr_splash);
}

void ui_show_splash(void)
{
    lv_screen_load(g_scr_splash);
}

void ui_set_splash_progress(int percent, const char *status)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    lv_bar_set_value(g_splash_bar, percent, LV_ANIM_OFF);
    if (status != NULL) {
        char buf[64];
        copy_ascii(buf, sizeof(buf), status);
        lv_label_set_text(g_splash_status, buf);
    }
}

void ui_show_wifi_scan(void)
{
    lv_screen_load(g_scr_scan);
}

void ui_set_wifi_scan(bool scanning, const char *status)
{
    lv_obj_set_hidden(g_scan_spinner, !scanning);
    if (status != NULL) {
        char buf[80];
        copy_ascii(buf, sizeof(buf), status);
        lv_label_set_text(g_scan_status, buf);
    }
}

void ui_set_wifi_list(const ui_wifi_t *networks, int count)
{
    if (networks == NULL || count < 0) count = 0;
    if (count > UI_WIFI_MAX) count = UI_WIFI_MAX;
    g_net_count = count;
    for (int i = 0; i < count; i++) {
        g_nets[i] = networks[i];
        g_nets[i].ssid[sizeof(g_nets[i].ssid) - 1] = '\0';
    }
    int rows = count > 12 ? 12 : count;
    for (int i = 0; i < 12; i++) {
        bool show = i < rows;
        lv_obj_set_hidden(g_scan_rows[i], !show);
        if (!show) continue;
        char buf[40];
        copy_ascii(buf, sizeof(buf), g_nets[i].ssid);
        lv_label_set_text(g_scan_ssid[i], buf);
        lv_label_set_text(g_scan_sec[i], g_nets[i].secure ? "WPA2" : "Open");
        snprintf(buf, sizeof(buf), "%d", (int)g_nets[i].rssi);
        lv_label_set_text(g_scan_rssi[i], buf);
        int lvl = wifi_level(g_nets[i].rssi);
        for (int b = 0; b < 4; b++) {
            lv_obj_set_style_bg_color(g_scan_bars[i][b],
                                      lv_color_hex(b < lvl ? C_ACCENT : C_DIM), 0);
        }
    }
}

void ui_show_wifi_password(const char *ssid)
{
    char buf[48];
    copy_ascii(g_selected_ssid, sizeof(g_selected_ssid), ssid != NULL ? ssid : "");
    snprintf(buf, sizeof(buf), "Connect to %.28s", g_selected_ssid);
    lv_label_set_text(g_pw_title, buf);
    lv_textarea_set_text(g_pw_input, "");
    g_pw_visible = false;
    lv_textarea_set_password_mode(g_pw_input, true);
    set_button_text(g_pw_show, "Show");
    lv_keyboard_set_textarea(g_pw_keyboard, g_pw_input);
    lv_obj_add_state(g_pw_input, LV_STATE_FOCUSED);
    lv_screen_load(g_scr_pw);
}

void ui_show_wifi_connecting(const char *ssid)
{
    char buf[33];
    copy_ascii(buf, sizeof(buf), ssid != NULL ? ssid : g_selected_ssid);
    if (buf[0] != '\0') {
        copy_ascii(g_selected_ssid, sizeof(g_selected_ssid), buf);
    }
    lv_label_set_text(g_conn_ssid, g_selected_ssid);
    lv_screen_load(g_scr_connecting);
}

void ui_show_wifi_result(bool success, ui_error_t error,
                         const char *ssid, const char *detail)
{
    g_res_success = success;
    char title[48];
    char det[160];
    if (success) {
        snprintf(title, sizeof(title), "Connected");
        lv_obj_set_style_bg_color(g_res_icon, lv_color_hex(C_GREEN), 0);
        lv_label_set_text(g_res_icon_label, LV_SYMBOL_OK);
        set_button_text(g_res_primary, "Continue");
        set_button_colors(g_res_primary, C_ACCENT, C_BG);
        if (ssid != NULL) copy_ascii(g_selected_ssid, sizeof(g_selected_ssid), ssid);
    } else {
        switch (error) {
        case UI_ERR_WRONG_PASSWORD: snprintf(title, sizeof(title), "Wrong password"); break;
        case UI_ERR_NET_NOT_FOUND: snprintf(title, sizeof(title), "Network not found"); break;
        case UI_ERR_NO_NETWORKS: snprintf(title, sizeof(title), "No networks found"); break;
        case UI_ERR_AUTH: snprintf(title, sizeof(title), "Authentication failed"); break;
        case UI_ERR_TIMEOUT: snprintf(title, sizeof(title), "Connection timed out"); break;
        default: snprintf(title, sizeof(title), "Connection failed"); break;
        }
        lv_obj_set_style_bg_color(g_res_icon, lv_color_hex(C_RED), 0);
        lv_label_set_text(g_res_icon_label, LV_SYMBOL_CLOSE);
        set_button_text(g_res_primary, "Retry");
        set_button_colors(g_res_primary, C_ACCENT, C_BG);
    }
    lv_label_set_text(g_res_title, title);
    if (detail != NULL && detail[0] != '\0') {
        copy_ascii(det, sizeof(det), detail);
    } else {
        copy_ascii(det, sizeof(det), ssid != NULL ? ssid : "");
    }
    lv_label_set_text(g_res_detail, det);
    lv_screen_load(g_scr_result);
}

static void render_updated(void)
{
    char buf[32];
    int hh = 0, mm = 0;
    if (sscanf(g_updated_raw, "%d:%d", &hh, &mm) == 2 && hh >= 0 && hh < 24) {
        if (g_clock24) {
            snprintf(buf, sizeof(buf), "Updated %02d:%02d", hh, mm);
        } else {
            int h12 = hh % 12;
            if (h12 == 0) h12 = 12;
            snprintf(buf, sizeof(buf), "Updated %d:%02d %s", h12, mm, hh < 12 ? "AM" : "PM");
        }
    } else {
        snprintf(buf, sizeof(buf), "Updated --:--");
    }
    lv_label_set_text(g_weather_updated, buf);
}

static void render_weather(void)
{
    char buf[48];
    if (!g_have_current) return;

    copy_ascii(buf, sizeof(buf), g_current.city);
    lv_label_set_text(g_weather_city, buf[0] ? buf : "No city");

    copy_ascii(g_updated_raw, sizeof(g_updated_raw), g_current.updated);
    render_updated();

    lv_obj_set_hidden(g_weather_wifi, !g_current.wifi_ok);
    for (int i = 0; i < 4; i++) {
        lv_obj_set_hidden(g_weather_wifi_bars[i], !g_current.wifi_ok);
    }
    if (g_current.wifi_ok) {
        snprintf(buf, sizeof(buf), "%d", g_current.rssi);
        lv_label_set_text(g_weather_rssi, buf);
        int lvl = wifi_level(g_current.rssi);
        for (int i = 0; i < 4; i++) {
            lv_obj_set_style_bg_color(g_weather_wifi_bars[i],
                                      lv_color_hex(i < lvl ? C_ACCENT : C_DIM), 0);
        }
    } else {
        lv_label_set_text(g_weather_rssi, "off");
    }

    fmt_temp(buf, sizeof(buf), g_current.temp_c);
    lv_label_set_text(g_weather_temp, buf);
    copy_ascii(buf, sizeof(buf), g_current.condition);
    lv_label_set_text(g_weather_cond, buf[0] ? buf : "--");
    fmt_temp(buf, sizeof(buf), g_current.feels_c);
    char fbuf[64];
    snprintf(fbuf, sizeof(fbuf), "Feels like %s", buf);
    lv_label_set_text(g_weather_feels, fbuf);
    lv_label_set_text(g_weather_metric_feels, buf);

    snprintf(buf, sizeof(buf), "%d%%", g_current.humidity);
    lv_label_set_text(g_weather_hum, buf);
    snprintf(buf, sizeof(buf), "%d km/h", g_current.wind);
    lv_label_set_text(g_weather_wind, buf);
    snprintf(buf, sizeof(buf), "%d hPa", g_current.pressure);
    lv_label_set_text(g_weather_press, buf);

    icon_build_big(g_weather_icon, g_current.code, g_current.is_day);

    lv_obj_set_hidden(g_weather_error, true);
    lv_obj_set_hidden(g_weather_hero, false);
    lv_obj_set_hidden(g_weather_metrics, false);
    lv_obj_set_hidden(g_weather_hourly, false);
}

void ui_show_weather(void)
{
    lv_screen_load(g_scr_weather);
}

void ui_set_weather(const ui_current_t *current)
{
    if (current == NULL) return;
    g_current = *current;
    g_current.city[sizeof(g_current.city) - 1] = '\0';
    g_current.condition[sizeof(g_current.condition) - 1] = '\0';
    g_current.updated[sizeof(g_current.updated) - 1] = '\0';
    g_have_current = true;
    render_weather();
}

static void format_hour(char *out, size_t n, const char *raw)
{
    int hh = 0, mm = 0;
    if (raw != NULL && strcmp(raw, "Now") == 0) {
        snprintf(out, n, "Now");
        return;
    }
    if (raw != NULL && sscanf(raw, "%d:%d", &hh, &mm) == 2 && hh >= 0 && hh < 24) {
        if (g_clock24) {
            snprintf(out, n, "%02d:%02d", hh, mm);
        } else {
            int h12 = hh % 12;
            if (h12 == 0) h12 = 12;
            snprintf(out, n, "%d:%02d %s", h12, mm, hh < 12 ? "AM" : "PM");
        }
    } else {
        copy_ascii(out, n, raw != NULL ? raw : "");
    }
}

void ui_set_hourly(const ui_hour_t *hours, int count)
{
    if (hours == NULL || count < 0) count = 0;
    if (count > 5) count = 5;
    g_hour_count = count;
    for (int i = 0; i < 5; i++) {
        bool show = i < count;
        lv_obj_set_hidden(g_hour_tile[i], !show);
        if (!show) continue;
        g_hours[i] = hours[i];
        char buf[16];
        format_hour(buf, sizeof(buf), hours[i].time);
        lv_label_set_text(g_hour_time[i], buf);
        fmt_temp(buf, sizeof(buf), hours[i].temp_c);
        lv_label_set_text(g_hour_temp[i], buf);
        icon_build_small(g_hour_icon[i], hours[i].code, true, 18);
    }
}

void ui_set_weather_error(ui_error_t error, const char *detail)
{
    const char *title = "Weather update failed";
    switch (error) {
    case UI_ERR_DNS: title = "Can't find weather server"; break;
    case UI_ERR_TLS: title = "Secure connection failed"; break;
    case UI_ERR_HTTP: title = "Weather service error"; break;
    case UI_ERR_TIMEOUT: title = "Request timed out"; break;
    case UI_ERR_NO_NETWORKS: title = "No network"; break;
    default: break;
    }
    lv_label_set_text(g_weather_error_title, title);
    char buf[160];
    copy_ascii(buf, sizeof(buf), detail != NULL ? detail : "");
    lv_label_set_text(g_weather_error_detail, buf);
    lv_obj_set_hidden(g_weather_hero, true);
    lv_obj_set_hidden(g_weather_metrics, true);
    lv_obj_set_hidden(g_weather_hourly, true);
    lv_obj_set_hidden(g_weather_error, false);
}

void ui_show_forecast(void)
{
    lv_screen_load(g_scr_forecast);
}

static const char *wind_label(int code)
{
    switch (icon_kind(code)) {
    case 0: return "Clear";
    case 1: return "Partly cloudy";
    case 2: return "Cloudy";
    case 3: return "Fog";
    case 4: return "Rain";
    case 5: return "Snow";
    default: return "Thunder";
    }
}

void ui_set_daily(const ui_day_t *days, int count)
{
    if (days == NULL || count < 0) count = 0;
    if (count > 5) count = 5;
    g_day_count = count;
    for (int i = 0; i < 5; i++) {
        bool show = i < count;
        lv_obj_set_hidden(g_fc_rows[i], !show);
        if (!show) continue;
        g_days[i] = days[i];
        char buf[16];
        copy_ascii(buf, sizeof(buf), days[i].day);
        lv_label_set_text(g_fc_day[i], buf);
        icon_build_small(g_fc_icon[i], days[i].code, true, 24);
        lv_label_set_text(g_fc_cond[i], wind_label(days[i].code));
        fmt_temp(buf, sizeof(buf), days[i].tmax_c);
        lv_label_set_text(g_fc_high[i], buf);
        fmt_temp(buf, sizeof(buf), days[i].tmin_c);
        lv_label_set_text(g_fc_low[i], buf);
        snprintf(buf, sizeof(buf), "%d%%", days[i].precip);
        lv_label_set_text(g_fc_precip[i], buf);
    }
}

void ui_show_city_search(void)
{
    lv_textarea_set_text(g_city_input, "");
    lv_label_set_text(g_city_status, "Type a city and press ready");
    lv_obj_set_hidden(g_city_keyboard, false);
    lv_obj_set_hidden(g_city_results, true);
    for (int i = 0; i < UI_CITY_MAX; i++) {
        lv_obj_set_hidden(g_city_rows[i], true);
    }
    lv_keyboard_set_textarea(g_city_keyboard, g_city_input);
    lv_obj_add_state(g_city_input, LV_STATE_FOCUSED);
    lv_screen_load(g_scr_city);
}

void ui_set_city_results(const ui_city_t *cities, int count, const char *status)
{
    if (cities == NULL || count < 0) count = 0;
    if (count > UI_CITY_MAX) count = UI_CITY_MAX;
    g_city_count = count;
    for (int i = 0; i < UI_CITY_MAX; i++) {
        bool show = i < count;
        lv_obj_set_hidden(g_city_rows[i], !show);
        if (!show) continue;
        g_cities[i] = cities[i];
        g_cities[i].name[sizeof(g_cities[i].name) - 1] = '\0';
        g_cities[i].region[sizeof(g_cities[i].region) - 1] = '\0';
        g_cities[i].country[sizeof(g_cities[i].country) - 1] = '\0';
        char buf[96];
        copy_ascii(buf, sizeof(buf), cities[i].name);
        lv_label_set_text(g_city_name[i], buf);
        if (cities[i].region[0] != '\0' && cities[i].country[0] != '\0') {
            snprintf(buf, sizeof(buf), "%.32s, %.8s", cities[i].region, cities[i].country);
        } else if (cities[i].country[0] != '\0') {
            snprintf(buf, sizeof(buf), "%.8s", cities[i].country);
        } else {
            buf[0] = '\0';
        }
        lv_label_set_text(g_city_region[i], buf);
    }
    if (status != NULL) {
        char buf[96];
        copy_ascii(buf, sizeof(buf), status);
        lv_label_set_text(g_city_status, buf);
    }
    lv_obj_set_hidden(g_city_keyboard, true);
    lv_obj_set_hidden(g_city_results, false);
}

void ui_show_settings(void)
{
    g_forget_armed = 0;
    set_button_text(g_set_forget, "Forget network");
    set_button_colors(g_set_forget, C_PANEL2, C_TEXT);
    lv_screen_load(g_scr_settings);
}

void ui_set_settings(bool fahrenheit, bool clock24, int brightness)
{
    g_fahrenheit = fahrenheit;
    g_clock24 = clock24;
    if (brightness < 10) brightness = 10;
    if (brightness > 100) brightness = 100;
    g_brightness = brightness;
    style_segment(g_set_unit_c, !g_fahrenheit);
    style_segment(g_set_unit_f, g_fahrenheit);
    style_segment(g_set_clock_12, !g_clock24);
    style_segment(g_set_clock_24, g_clock24);
    if (g_set_brightness != NULL) {
        lv_slider_set_value(g_set_brightness, g_brightness, LV_ANIM_OFF);
    }
    char buf[8];
    snprintf(buf, sizeof(buf), "%d%%", g_brightness);
    lv_label_set_text(g_set_bright_value, buf);
    if (g_have_current) render_weather();
}

void ui_set_wifi_card(const char *ssid, bool connected, int rssi)
{
    char buf[96];
    if (ssid != NULL && ssid[0] != '\0') {
        copy_ascii(buf, sizeof(buf), ssid);
        lv_label_set_text(g_set_wifi_ssid, buf);
        if (connected) {
            snprintf(buf, sizeof(buf), "Connected, %d dBm", rssi);
        } else {
            snprintf(buf, sizeof(buf), "Saved, not connected");
        }
        lv_label_set_text(g_set_wifi_sub, buf);
        lv_label_set_text(g_set_saved, "Saved network");
        lv_label_set_text(g_about_values[2], connected ? "Connected" : "Saved");
        lv_obj_set_style_bg_color(g_set_wifi_dot, lv_color_hex(connected ? C_GREEN : C_AMBER), 0);
    } else {
        lv_label_set_text(g_set_wifi_ssid, "Not connected");
        lv_label_set_text(g_set_wifi_sub, "No saved network");
        lv_label_set_text(g_set_saved, "No saved network");
        lv_label_set_text(g_about_values[2], "Not connected");
        lv_obj_set_style_bg_color(g_set_wifi_dot, lv_color_hex(C_DIM), 0);
    }
}

void ui_show_about(void)
{
    lv_screen_load(g_scr_about);
}

void ui_set_system_info(const char *firmware, const char *ip, const char *mac,
                        uint32_t free_heap, uint32_t free_psram, uint32_t uptime_s)
{
    char buf[64];
    if (firmware != NULL) {
        copy_ascii(buf, sizeof(buf), firmware);
        lv_label_set_text(g_about_values[0], buf);
    }
    if (ip != NULL) {
        copy_ascii(buf, sizeof(buf), ip);
        lv_label_set_text(g_about_values[3], buf);
    }
    if (mac != NULL) {
        copy_ascii(buf, sizeof(buf), mac);
        lv_label_set_text(g_about_values[4], buf);
    }
    snprintf(buf, sizeof(buf), "%u KB", (unsigned)(free_heap / 1024));
    lv_label_set_text(g_about_values[5], buf);
    snprintf(buf, sizeof(buf), "%u KB", (unsigned)(free_psram / 1024));
    lv_label_set_text(g_about_values[6], buf);
    snprintf(buf, sizeof(buf), "%uh %02um", (unsigned)(uptime_s / 3600),
             (unsigned)((uptime_s / 60) % 60));
    lv_label_set_text(g_about_values[7], buf);
}
