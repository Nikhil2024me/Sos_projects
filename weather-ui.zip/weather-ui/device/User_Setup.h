/**
 * User_Setup.h - TFT_eSPI hardware configuration for the weather station.
 *
 * This file is the canonical copy.  The build helper in README.md stages a
 * TFT_eSPI library copy and puts this file at its root, so the installed
 * library is never modified.
 *
 * Target board: ESP32-S3-N16R8 (16 MB flash, 8 MB octal PSRAM)
 * Panel:        ILI9341 240x320 SPI, used in landscape at 320x240
 * Touch:        XPT2046 resistive controller on the same SPI bus
 *
 * Pin choice rationale is documented in README.md.  In short: SCLK/MOSI/MISO/CS
 * use the ESP32-S3 FSPI IOMUX pins (GPIO10..13), DC and RST are plain GPIO,
 * and no pin here is in the flash/PSRAM (26..37), strapping, USB (19/20) or
 * UART0 reserved sets.
 *
 * This pin map matches the configuration used on this board previously
 * (memlab firmware): DC 7, RST 6, BL 21, TOUCH_CS 15, TOUCH_IRQ 16.
 */
#ifndef WEATHER_USER_SETUP_H
#define WEATHER_USER_SETUP_H

#define USER_SETUP_INFO "Weather Station ESP32-S3-N16R8"

/* ILI9341 panel, 4-wire SPI, 240x320 native (landscape via setRotation(1)). */
#define ILI9341_DRIVER

#define TFT_MISO 13
#define TFT_MOSI 11
#define TFT_SCLK 12
#define TFT_CS   10
#define TFT_DC    7
#define TFT_RST   6

/* Backlight is driven by LEDC in device.ino.  TFT_BACKLIGHT_ON is
   deliberately not defined so TFT_eSPI leaves the pin alone. */
#define TFT_BL   21

/* XPT2046 chip select.  Its IRQ is polled separately on GPIO16. */
#define TOUCH_CS 15

/* 40 MHz is a conservative ILI9341 SPI clock for Dupont wiring. */
#define SPI_FREQUENCY       40000000
#define SPI_READ_FREQUENCY  16000000
#define SPI_TOUCH_FREQUENCY  2500000

/* Force TFT_eSPI onto the GPSPI2 peripheral.
 *
 * TFT_eSPI pokes the SPI registers directly through SPI_PORT, and its ESP32-S3
 * default is `#define SPI_PORT FSPI`.  With arduino-esp32 3.x `FSPI` is the
 * Arduino bus number 0, while the IDF register macro expands to
 * `REG_SPI_BASE(i) = ((i)>=2 ? DR_REG_SPI2_BASE + (i-2)*0x1000 : 0)`.
 * SPI_PORT=0 therefore evaluated to register address 0x10 and the first
 * begin_tft_write() faulted with a StoreProhibited exception at 0x10.
 *
 * USE_FSPI_PORT makes TFT_eSPI use the literal GPSPI index 2 for the register
 * block (REG_SPI_BASE(2) == DR_REG_SPI2_BASE) and constructs its SPIClass on
 * FSPI (0), which the core maps to SPI2_HOST - i.e. the same controller. */
#define USE_FSPI_PORT

/* Most ILI9341 modules use the BGR colour order. */
#define TFT_RGB_ORDER TFT_BGR

/* No TFT_eSPI fonts, sprites or smooth fonts are used: LVGL renders
   everything and only raw RGB565 blocks are pushed.  Keeping these off
   saves flash and avoids pulling the Adafruit font tables into the image. */

#endif /* WEATHER_USER_SETUP_H */
