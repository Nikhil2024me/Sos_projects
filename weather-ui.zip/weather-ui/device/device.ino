/**
 * device.ino - ESP32-S3-N16R8 weather station device layer.
 *
 * Hardware:
 *   - ESP32-S3-N16R8: 16 MB flash, 8 MB octal PSRAM
 *   - ILI9341 240x320 SPI panel, landscape 320x240, RGB565
 *   - XPT2046 resistive touch controller on the same SPI bus
 *
 * Architecture:
 *   - The Arduino loop task is the only task that touches LVGL (and the TFT).
 *   - A FreeRTOS worker task owns Wi-Fi, DNS, HTTPS/TLS, NTP and JSON.  It
 *     communicates with the UI task through two fixed-size queues, so a slow
 *     TLS handshake can never freeze the display or the touch input.
 *   - ui.c is pure LVGL and is compiled into this translation unit; it never
 *     sees Arduino, Wi-Fi or TFT types.
 *
 * No credentials, API keys or coordinates are compiled in.  Wi-Fi credentials
 * and the chosen city are read from NVS and are only written after a
 * successful connection / explicit city selection.
 */

#include <Arduino.h>
#include <WiFi.h>
#include <NetworkClientSecure.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <TFT_eSPI.h>
#include <lvgl.h>

#include <stdarg.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include <stddef.h>
#include <string.h>
#include "esp_rom_sys.h"

#include "../ui.h"
#include "../ui.c"

/* ------------------------------------------------------------------------- */
/* Configuration                                                             */
/* ------------------------------------------------------------------------- */

#define APP_VERSION        "1.0.0"
#define LCD_W              320
#define LCD_H              240
/* PARTIAL render mode draws a band this many lines tall per pass.  320x40
   RGB565 is 25.6 KB, small enough to live in PSRAM with room to spare. */
#define LCD_TILE_LINES     40
#define LCD_BUF_BYTES      (LCD_W * LCD_TILE_LINES * 2)

#ifndef TFT_BL
#define TFT_BL             21
#endif
#define PIN_BACKLIGHT      TFT_BL
#define PIN_TOUCH_IRQ      16

#define TOUCH_Z_THRESHOLD  600
#define WIFI_CONNECT_MS    15000
#define HTTP_TIMEOUT_MS    15000
#define NTP_WAIT_MS        8000
#define NTP_SERVER_1       "pool.ntp.org"
#define NTP_SERVER_2       "time.cloudflare.com"
#define NTP_SERVER_3       "time.google.com"
#define NVS_NAMESPACE      "weather"

#define WEATHER_HOST       "api.open-meteo.com"
#define GEOCODE_HOST       "geocoding-api.open-meteo.com"

/* ------------------------------------------------------------------------- */
/* Worker messages                                                           */
/* ------------------------------------------------------------------------- */

enum cmd_type_t : uint8_t {
    CMD_BOOT = 0,
    CMD_SCAN,
    CMD_CONNECT,
    CMD_CANCEL,
    CMD_FORGET,
    CMD_REFRESH,
    CMD_CITY_SEARCH
};

enum evt_type_t : uint8_t {
    EV_SPLASH = 0,
    EV_SCAN,
    EV_CONNECT,
    EV_WEATHER,
    EV_WEATHER_ERR,
    EV_CITY,
    EV_NEED_WIFI,
    EV_WIFI_STATE
};

struct AppCmd {
    uint8_t type;
    uint16_t seq;
    char ssid[33];
    char pass[65];
    char query[80];
};

struct AppEvent {
    uint8_t type;
    bool ok;
    uint8_t error;
    uint8_t n_hours;
    uint8_t n_days;
    int16_t rssi;
    int16_t percent;
    uint16_t seq;
    char text[192];
    char ssid[33];
    char pass[65];
    ui_wifi_t nets[UI_WIFI_MAX];
    ui_city_t cities[UI_CITY_MAX];
    ui_current_t current;
    ui_hour_t hours[5];
    ui_day_t days[5];
};

/* ------------------------------------------------------------------------- */
/* Logging                                                                   */
/* ------------------------------------------------------------------------- */
/* Logs go to the ESP-IDF console, which is routed to UART0 and to the
 * USB-Serial/JTAG secondary console (the same path the panic handler uses).
 *
 * The Arduino HWCDC path is deliberately not used for logging.  On this core
 * its transmit ring stays gated on an internal "connected" flag that never
 * latches for some USB hosts, silently swallowing every write while the ROM and
 * panic console still print.  esp_rom_printf needs no such handshake.
 *
 * These helpers are defined *after* every namespace-scope type on purpose:
 * the Arduino build injects auto-generated function prototypes immediately
 * before the first function definition in the sketch.  If the first function
 * definition came before struct AppEvent, the injected prototype for
 * send_event()/handle_event() would reference an undeclared AppEvent. */
static void logf(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void logf(const char *fmt, ...)
{
    char buf[224];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    esp_rom_printf("%s", buf);
}

static void logln(const char *s)
{
    logf("%s\n", s);
}

/* ------------------------------------------------------------------------- */
/* Shared state                                                              */
/* ------------------------------------------------------------------------- */

static Preferences s_prefs;
static TFT_eSPI s_tft;

static lv_display_t *s_disp;
static lv_indev_t *s_indev;
/* One full-screen frame buffer.  DIRECT mode with a single buffer means the
   buffer always contains exactly what the panel shows, so a partial refresh
   only has to redraw the invalidated objects -- no cross-buffer copying. */
static uint16_t *s_buf1;

static QueueHandle_t s_cmd_q;
static QueueHandle_t s_evt_q;

/* Touch calibration: the five values produced by TFT_eSPI's stock
   calibrateTouch() routine (the Touch_calibrate example sketch). */
static bool s_tcal_ok;
static uint16_t s_tcal[5];
static bool s_touch_down;

/* Settings and persisted data (UI task owns NVS). */
static bool s_fahrenheit;
static bool s_clock24;
static int s_brightness;
static bool s_settings_dirty;
static uint32_t s_settings_dirty_ms;

static bool s_have_saved;
static char s_saved_ssid[33];
static char s_saved_pass[65];
static bool s_have_pending;
static char s_pending_ssid[33];
static char s_pending_pass[65];

static bool s_have_city;
static ui_city_t s_city;

static char s_scan_raw[UI_WIFI_MAX][33];
static int s_scan_count;

/* UI/task flags.  volatile is enough for aligned bool/int flags on the ESP32. */
static volatile bool s_booting;
static volatile bool s_abort;
static volatile bool s_wifi_connected;
static volatile bool s_wifi_state_dirty;
static volatile int s_rssi;
static volatile uint8_t s_disc_reason;

static bool s_have_weather;
static ui_current_t s_last_current;  /* kept so Wi-Fi loss can be reflected */
static bool s_weather_failed;
static bool s_weather_pending;
static bool s_wait_weather;
static uint16_t s_weather_seq;
static ui_error_t s_weather_err;
static char s_weather_detail[160];

static uint32_t s_last_sysinfo_ms;
static bool s_boot_posted;

/* ------------------------------------------------------------------------- */
/* Small helpers                                                             */
/* ------------------------------------------------------------------------- */

static void copy_text(char *dst, size_t n, const char *src)
{
    if (dst == NULL || n == 0) {
        return;
    }
    if (src == NULL) {
        src = "";
    }
    snprintf(dst, n, "%s", src);
}

/* The Montserrat fonts in the firmware do not contain non-ASCII glyphs.
   Keep the real UTF-8 string in NVS/API structures, but transliterate the
   copy that is shown on the glass.  Unknown code points become '?'. */
static char ascii_latin(uint32_t cp)
{
    if ((cp >= 0x00C0 && cp <= 0x00C5) || cp == 0x0100 || cp == 0x0102 || cp == 0x0104) return 'A';
    if (cp == 0x00C6 || cp == 0x01FC) return 'A';
    if (cp == 0x00C7 || cp == 0x0106 || cp == 0x0108 || cp == 0x010A || cp == 0x010C) return 'C';
    if ((cp >= 0x00C8 && cp <= 0x00CB) || cp == 0x0112 || cp == 0x0114 || cp == 0x0116 || cp == 0x0118 || cp == 0x011A) return 'E';
    if ((cp >= 0x00CC && cp <= 0x00CF) || cp == 0x012A || cp == 0x012C || cp == 0x012E || cp == 0x0130) return 'I';
    if (cp == 0x00D1 || cp == 0x0143 || cp == 0x0145 || cp == 0x0147) return 'N';
    if ((cp >= 0x00D2 && cp <= 0x00D6) || cp == 0x00D8 || cp == 0x014C || cp == 0x014E || cp == 0x0150) return 'O';
    if (cp == 0x0152) return 'O';
    if ((cp >= 0x00D9 && cp <= 0x00DC) || cp == 0x016A || cp == 0x016C || cp == 0x016E || cp == 0x0170 || cp == 0x0172) return 'U';
    if (cp == 0x00DD || cp == 0x0178) return 'Y';
    if (cp == 0x0179 || cp == 0x017B || cp == 0x017D) return 'Z';
    if (cp == 0x00DF) return 's';
    if ((cp >= 0x00E0 && cp <= 0x00E5) || cp == 0x0101 || cp == 0x0103 || cp == 0x0105) return 'a';
    if (cp == 0x00E6 || cp == 0x01FD) return 'a';
    if (cp == 0x00E7 || cp == 0x0107 || cp == 0x0109 || cp == 0x010B || cp == 0x010D) return 'c';
    if ((cp >= 0x00E8 && cp <= 0x00EB) || cp == 0x0113 || cp == 0x0115 || cp == 0x0117 || cp == 0x0119 || cp == 0x011B) return 'e';
    if ((cp >= 0x00EC && cp <= 0x00EF) || cp == 0x012B || cp == 0x012D || cp == 0x012F || cp == 0x0131) return 'i';
    if (cp == 0x00F1 || cp == 0x0144 || cp == 0x0146 || cp == 0x0148) return 'n';
    if ((cp >= 0x00F2 && cp <= 0x00F6) || cp == 0x00F8 || cp == 0x014D || cp == 0x014F || cp == 0x0151) return 'o';
    if (cp == 0x0153) return 'o';
    if ((cp >= 0x00F9 && cp <= 0x00FC) || cp == 0x016B || cp == 0x016D || cp == 0x016F || cp == 0x0171 || cp == 0x0173) return 'u';
    if (cp == 0x00FD || cp == 0x00FF) return 'y';
    if (cp == 0x017A || cp == 0x017C || cp == 0x017E) return 'z';
    return '?';
}

static void ascii_copy(char *dst, size_t n, const char *src)
{
    size_t o = 0;
    if (dst == NULL || n == 0) {
        return;
    }
    if (src == NULL) {
        src = "";
    }
    while (*src != '\0' && o + 1 < n) {
        unsigned char c = (unsigned char)*src;
        if (c < 0x80) {
            if (c >= 0x20 && c < 0x7F) {
                dst[o++] = (char)c;
            } else if (c == '\n' || c == '\t' || c == '\r') {
                dst[o++] = ' ';
            }
            src++;
        } else {
            uint32_t cp = 0;
            int len = 1;
            if ((c & 0xE0) == 0xC0 && (src[1] & 0xC0) == 0x80) {
                cp = ((uint32_t)(c & 0x1F) << 6) | (uint32_t)(src[1] & 0x3F);
                len = 2;
            } else if ((c & 0xF0) == 0xE0 && (src[1] & 0xC0) == 0x80 && (src[2] & 0xC0) == 0x80) {
                cp = ((uint32_t)(c & 0x0F) << 12) |
                     ((uint32_t)(src[1] & 0x3F) << 6) |
                     (uint32_t)(src[2] & 0x3F);
                len = 3;
            } else if ((c & 0xF8) == 0xF0 && (src[1] & 0xC0) == 0x80 &&
                       (src[2] & 0xC0) == 0x80 && (src[3] & 0xC0) == 0x80) {
                cp = ((uint32_t)(c & 0x07) << 18) |
                     ((uint32_t)(src[1] & 0x3F) << 12) |
                     ((uint32_t)(src[2] & 0x3F) << 6) |
                     (uint32_t)(src[3] & 0x3F);
                len = 4;
            }
            src += len;
            dst[o++] = ascii_latin(cp);
        }
    }
    dst[o] = '\0';
}

static const char *condition_text(int code)
{
    if (code == 0) return "Clear sky";
    if (code == 1) return "Mainly clear";
    if (code == 2) return "Partly cloudy";
    if (code == 3) return "Overcast";
    if (code == 45 || code == 48) return "Fog";
    if (code >= 51 && code <= 55) return "Drizzle";
    if (code == 56 || code == 57) return "Freezing drizzle";
    if (code >= 61 && code <= 65) return "Rain";
    if (code == 66 || code == 67) return "Freezing rain";
    if (code >= 71 && code <= 75) return "Snow";
    if (code == 77) return "Snow grains";
    if (code >= 80 && code <= 82) return "Rain showers";
    if (code == 85 || code == 86) return "Snow showers";
    if (code == 95) return "Thunderstorm";
    if (code == 96 || code == 99) return "Thunderstorm, hail";
    return "Unknown";
}

static bool time_is_valid(void)
{
    return time(NULL) > 1700000000;   /* after 2023-11-14 */
}

static void day_label(char *out, size_t n, const char *iso, bool first)
{
    if (first) {
        copy_text(out, n, "Today");
        return;
    }
    int y = 0, m = 0, d = 0;
    if (iso != NULL && sscanf(iso, "%d-%d-%d", &y, &m, &d) == 3) {
        struct tm t;
        memset(&t, 0, sizeof(t));
        t.tm_year = y - 1900;
        t.tm_mon = m - 1;
        t.tm_mday = d;
        t.tm_hour = 12;
        t.tm_isdst = -1;
        if (mktime(&t) != (time_t)-1) {
            if (strftime(out, n, "%a", &t) > 0) {
                return;
            }
        }
    }
    copy_text(out, n, iso != NULL ? iso : "");
}

static int clamp_int(int v, int lo, int hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static void url_encode(const char *in, char *out, size_t n)
{
    size_t o = 0;
    if (out == NULL || n == 0) {
        return;
    }
    for (const unsigned char *p = (const unsigned char *)in; p != NULL && *p != '\0'; p++) {
        unsigned char c = *p;
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            if (o + 1 < n) out[o++] = (char)c;
        } else {
            if (o + 3 < n) {
                snprintf(out + o, n - o, "%%%02X", c);
                o += 3;
            }
        }
    }
    out[o] = '\0';
}

/* ------------------------------------------------------------------------- */
/* NVS                                                                       */
/* ------------------------------------------------------------------------- */

static void nvs_load(void)
{
    s_fahrenheit = false;
    s_clock24 = true;
    s_brightness = 100;
    s_have_saved = false;
    s_saved_ssid[0] = '\0';
    s_saved_pass[0] = '\0';
    s_have_city = false;
    memset(&s_city, 0, sizeof(s_city));
    s_tcal_ok = false;
    memset(s_tcal, 0, sizeof(s_tcal));

    if (!s_prefs.begin(NVS_NAMESPACE, true)) {
        logln("NVS: namespace not found, using defaults");
        return;
    }

    s_fahrenheit = s_prefs.getBool("s_fahr", false);
    s_clock24 = s_prefs.getBool("s_24h", true);
    s_brightness = clamp_int(s_prefs.getInt("s_bright", 100), 10, 100);

    s_have_saved = s_prefs.getBool("w_ok", false);
    if (s_have_saved) {
        copy_text(s_saved_ssid, sizeof(s_saved_ssid), s_prefs.getString("w_ssid", "").c_str());
        copy_text(s_saved_pass, sizeof(s_saved_pass), s_prefs.getString("w_pass", "").c_str());
        if (s_saved_ssid[0] == '\0') {
            s_have_saved = false;
        }
    }

    s_have_city = s_prefs.getBool("c_ok", false);
    if (s_have_city) {
        copy_text(s_city.name, sizeof(s_city.name), s_prefs.getString("c_name", "").c_str());
        copy_text(s_city.region, sizeof(s_city.region), s_prefs.getString("c_region", "").c_str());
        copy_text(s_city.country, sizeof(s_city.country), s_prefs.getString("c_country", "").c_str());
        copy_text(s_city.tz, sizeof(s_city.tz), s_prefs.getString("c_tz", "").c_str());
        s_city.lat = s_prefs.getFloat("c_lat", 0.0f);
        s_city.lon = s_prefs.getFloat("c_lon", 0.0f);
        if (s_city.name[0] == '\0' || s_city.lat < -90.0f || s_city.lat > 90.0f ||
            s_city.lon < -180.0f || s_city.lon > 180.0f) {
            s_have_city = false;
            memset(&s_city, 0, sizeof(s_city));
        }
    }

    s_tcal_ok = s_prefs.getBool("tc_ok", false);
    if (s_tcal_ok) {
        for (int i = 0; i < 5; i++) {
            char key[5] = {'t', 'c', '0', '\0', '\0'};
            key[2] = (char)('0' + i);
            s_tcal[i] = s_prefs.getUShort(key, 0);
        }
        if (s_tcal[0] == 0 || s_tcal[1] == 0 ||
            s_tcal[2] == 0 || s_tcal[3] == 0) {
            s_tcal_ok = false;
        }
    }

    s_prefs.end();
    logf("NVS: wifi=%s city=%s tcal=%s fahr=%d 24h=%d bright=%d\n",
                  s_have_saved ? "yes" : "no",
                  s_have_city ? s_city.name : "no",
                  s_tcal_ok ? "yes" : "no",
                  s_fahrenheit ? 1 : 0, s_clock24 ? 1 : 0, s_brightness);
}

static void nvs_save_settings(void)
{
    if (!s_prefs.begin(NVS_NAMESPACE, false)) {
        logln("NVS: settings write failed");
        return;
    }
    s_prefs.putBool("s_fahr", s_fahrenheit);
    s_prefs.putBool("s_24h", s_clock24);
    s_prefs.putInt("s_bright", s_brightness);
    s_prefs.end();
}

/* Caller supplies the raw SSID/password.  This is only invoked after a
   successful connection, never while a password is merely being typed. */
static void nvs_save_credentials(const char *ssid, const char *pass)
{
    if (ssid == NULL || ssid[0] == '\0') {
        return;
    }
    if (s_have_saved && strcmp(ssid, s_saved_ssid) == 0 &&
        pass != NULL && strcmp(pass, s_saved_pass) == 0) {
        return;
    }
    if (!s_prefs.begin(NVS_NAMESPACE, false)) {
        logln("NVS: credential write failed");
        return;
    }
    s_prefs.putString("w_ssid", ssid);
    s_prefs.putString("w_pass", pass != NULL ? pass : "");
    s_prefs.putBool("w_ok", true);
    s_prefs.end();

    copy_text(s_saved_ssid, sizeof(s_saved_ssid), ssid);
    copy_text(s_saved_pass, sizeof(s_saved_pass), pass != NULL ? pass : "");
    s_have_saved = true;
}

static void nvs_clear_credentials(void)
{
    if (s_prefs.begin(NVS_NAMESPACE, false)) {
        s_prefs.remove("w_ssid");
        s_prefs.remove("w_pass");
        s_prefs.remove("w_ok");
        s_prefs.end();
    }
    s_have_saved = false;
    s_saved_ssid[0] = '\0';
    s_saved_pass[0] = '\0';
}

static void nvs_save_city(void)
{
    if (!s_prefs.begin(NVS_NAMESPACE, false)) {
        logln("NVS: city write failed");
        return;
    }
    s_prefs.putString("c_name", s_city.name);
    s_prefs.putString("c_region", s_city.region);
    s_prefs.putString("c_country", s_city.country);
    s_prefs.putString("c_tz", s_city.tz);
    s_prefs.putFloat("c_lat", s_city.lat);
    s_prefs.putFloat("c_lon", s_city.lon);
    s_prefs.putBool("c_ok", true);
    s_prefs.end();
}

static void nvs_save_touch_calibration(void)
{
    if (!s_prefs.begin(NVS_NAMESPACE, false)) {
        logln("NVS: touch calibration write failed");
        return;
    }
    s_prefs.putBool("tc_ok", true);
    for (int i = 0; i < 5; i++) {
        char key[5] = {'t', 'c', '0', '\0', '\0'};
        key[2] = (char)('0' + i);
        s_prefs.putUShort(key, s_tcal[i]);
    }
    /* Remove the old affine map so a downgrade cannot silently reuse it. */
    s_prefs.remove("cal_ok");
    s_prefs.remove("cal_a");
    s_prefs.remove("cal_b");
    s_prefs.remove("cal_c");
    s_prefs.remove("cal_d");
    s_prefs.remove("cal_e");
    s_prefs.remove("cal_f");
    s_prefs.end();
}

/* ------------------------------------------------------------------------- */
/* Display / LVGL                                                            */
/* ------------------------------------------------------------------------- */

static uint32_t tick_cb(void)
{
    return (uint32_t)millis();
}

/* Boot diagnostics: the first flush rectangles show whether LVGL is sending
   a handful of sub-areas (normal) or repainting the full screen repeatedly.
   Set to 0 for a silent log. */
#define FLUSH_TRACE 1
#if FLUSH_TRACE
static uint32_t s_flush_trace;
#endif

/* Push one rectangle of pixels to the panel.  In PARTIAL render mode the
   buffer passed to the flush callback holds exactly this rectangle, starting
   at its first pixel, so the panel only needs the address window and the
   pixel stream.  No whole-screen stride or buffer offset is involved. */
static void panel_push_area(const uint16_t *pixels, const lv_area_t *area)
{
    int32_t w = lv_area_get_width(area);
    int32_t h = lv_area_get_height(area);
    if (w <= 0 || h <= 0) {
        return;
    }

    s_tft.startWrite();
    s_tft.setAddrWindow(area->x1, area->y1, w, h);
    s_tft.pushColors((uint16_t *)pixels, (uint32_t)w * (uint32_t)h, true);
    s_tft.endWrite();
}

static void flush_cb(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map)
{
#if FLUSH_TRACE
    if (s_flush_trace < 20) {
        logf("FLUSH %u: %dx%d at %d,%d\n", (unsigned)s_flush_trace,
             (int)lv_area_get_width(area), (int)lv_area_get_height(area),
             (int)area->x1, (int)area->y1);
        s_flush_trace++;
    }
#endif
    panel_push_area((const uint16_t *)px_map, area);
    lv_display_flush_ready(disp);
}

/* Verify the exact flush path with the panel itself: fill a small,
   deliberately unaligned rectangle of the tile buffer, push it through the
   same helper the LVGL flush callback uses, then read the pixels back over
   MISO.  Runs with the backlight still off. */
static void display_partial_flush_test(uint16_t *tile)
{
    const int x0 = 61;
    const int y0 = 37;
    const int w = 73;
    const int h = 29;
    lv_area_t area = { x0, y0, x0 + w - 1, y0 + h - 1 };
    const int px[4] = { 0, 1, w - 1, w / 2 };
    const int py[4] = { 0, h - 1, h - 1, h / 2 };

    /* Reference: the same rectangle through TFT_eSPI's own fillRect. */
    s_tft.fillRect(x0, y0, w, h, 0xF81F);
    delay(5);
    int ref_bad = 0;
    for (int i = 0; i < 4; i++) {
        if (s_tft.readPixel(x0 + px[i], y0 + py[i]) != 0xF81F) {
            ref_bad++;
        }
    }
    logf("PARTIAL: fillRect reference -> %s\n", ref_bad == 0 ? "OK" : "MISMATCH");

    /* Now the flush helper, from a position-dependent pattern. */
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            uint16_t c = (uint16_t)((((x + y) & 1) ? 0xF800U : 0x07E0U) |
                                    (uint16_t)((x * 3 + y) & 0x001FU));
            tile[(uint32_t)y * (uint32_t)w + (uint32_t)x] = c;
        }
    }
    panel_push_area(tile, &area);
    delay(5);

    int bad = 0;
    for (int i = 0; i < 4; i++) {
        uint16_t want = tile[(uint32_t)py[i] * (uint32_t)w + (uint32_t)px[i]];
        uint16_t got = s_tft.readPixel(x0 + px[i], y0 + py[i]);
        logf("PARTIAL: px %d,%d got %04X want %04X\n",
             x0 + px[i], y0 + py[i], (unsigned)got, (unsigned)want);
        if (got != want) {
            bad++;
        }
    }
    logf("PARTIAL: push %dx%d at %d,%d -> %s\n", w, h, x0, y0,
         bad == 0 ? "OK" : "MISMATCH");

    s_tft.fillScreen(TFT_BLACK);
}

static void set_backlight(int percent)
{
    percent = clamp_int(percent, 0, 100);
    uint32_t duty = (uint32_t)((1023U * (uint32_t)percent) / 100U);
    ledcWrite(PIN_BACKLIGHT, duty);
}

/* One-shot panel self-test, run with the backlight still off so it is not
   visible.  It writes three known blocks and reads them back over MISO.  A
   match proves CS/DC/RST addressing and the address-window geometry, which is
   exactly what distinguishes a wiring problem from a rendering problem. */
static void display_self_test(void)
{
    s_tft.fillScreen(TFT_BLACK);
    s_tft.fillRect(0, 0, 40, 40, TFT_RED);
    s_tft.fillRect(140, 100, 40, 40, TFT_GREEN);
    s_tft.fillRect(280, 200, 40, 40, TFT_BLUE);

    uint16_t r = s_tft.readPixel(20, 20);
    uint16_t g = s_tft.readPixel(160, 120);
    uint16_t b = s_tft.readPixel(300, 220);
    bool ok = (r == TFT_RED && g == TFT_GREEN && b == TFT_BLUE);

    logf("PANEL: readback %04X %04X %04X, expect %04X %04X %04X -> %s\n",
         (unsigned)r, (unsigned)g, (unsigned)b,
         (unsigned)TFT_RED, (unsigned)TFT_GREEN, (unsigned)TFT_BLUE,
         ok ? "OK" : "MISMATCH");

    s_tft.fillScreen(TFT_BLACK);
}

/* Stock TFT_eSPI calibration, the same routine used by the
   Generic/Touch_calibrate example sketch.  It draws four corner markers,
   averages eight raw samples per corner and derives the five values consumed
   by setTouch().  The backlight is already on when this is called from
   Settings; at first boot it runs before LVGL exists. */
static void run_touch_calibration(void)
{
    s_tft.fillScreen(TFT_BLACK);
    s_tft.setTextColor(TFT_WHITE, TFT_BLACK);
    s_tft.setTextFont(2);
    s_tft.setCursor(20, 0);
    s_tft.println("Touch corners as indicated");

    uint16_t cal[5];
    s_tft.calibrateTouch(cal, TFT_MAGENTA, TFT_BLACK, 15);
    memcpy(s_tcal, cal, sizeof(s_tcal));
    s_tft.setTouch(s_tcal);
    s_tcal_ok = true;

    logf("TOUCH CAL: {%u, %u, %u, %u, %u}\n",
         (unsigned)s_tcal[0], (unsigned)s_tcal[1], (unsigned)s_tcal[2],
         (unsigned)s_tcal[3], (unsigned)s_tcal[4]);
    nvs_save_touch_calibration();

    s_tft.fillScreen(TFT_BLACK);
    s_tft.setTextColor(TFT_GREEN, TFT_BLACK);
    s_tft.setTextFont(2);
    s_tft.setCursor(10, 100);
    s_tft.println("Calibration complete!");
    delay(1200);
    s_tft.fillScreen(TFT_BLACK);

    /* The routine drew straight to the panel, bypassing LVGL.  Mark the active
       screen dirty so the next timer pass repaints it. */
    if (s_disp != NULL) {
        lv_obj_invalidate(lv_screen_active());
    }
}

static void fatal_screen(const char *msg)
{
    logf("FATAL: %s\n", msg);
    s_tft.fillScreen(TFT_RED);
    s_tft.setTextColor(TFT_WHITE, TFT_RED);
    s_tft.setTextSize(2);
    s_tft.drawString("Weather station", 10, 20);
    s_tft.setTextSize(1);
    s_tft.drawString(msg, 10, 60);
    while (true) {
        delay(1000);
    }
}

/* ------------------------------------------------------------------------- */
/* Touch                                                                     */
/* ------------------------------------------------------------------------- */

static void touch_read_cb(lv_indev_t *indev, lv_indev_data_t *data)
{
    (void)indev;
    uint16_t x = 0, y = 0;

    /* getTouch() is the stock TFT_eSPI reader used by the calibration sketch:
       it validates pressure, double-samples the position and applies the five
       values loaded with setTouch(). */
    bool pressed = s_tft.getTouch(&x, &y, TOUCH_Z_THRESHOLD) != 0;
    if (pressed) {
        data->point.x = x;
        data->point.y = y;
    }
    data->state = pressed ? LV_INDEV_STATE_PRESSED : LV_INDEV_STATE_RELEASED;

    if (pressed != s_touch_down) {
        if (pressed) {
            logf("TOUCH: %u,%u\n", (unsigned)x, (unsigned)y);
        } else {
            logln("TOUCH: release");
        }
        s_touch_down = pressed;
    }
}

/* ------------------------------------------------------------------------- */
/* Lua-free UI callbacks (all run in the Arduino/LVGL task)                  */
/* ------------------------------------------------------------------------- */

static void app_start_boot(void);

static void app_on_calibrate_request(void)
{
    logln("Touch: calibration requested from Settings");
    run_touch_calibration();
}

static const char *raw_ssid_for(const char *display_ssid)
{
    if (display_ssid == NULL) {
        return "";
    }
    char tmp[33];
    for (int i = 0; i < s_scan_count; i++) {
        ascii_copy(tmp, sizeof(tmp), s_scan_raw[i]);
        if (strcmp(tmp, display_ssid) == 0) {
            return s_scan_raw[i];
        }
    }
    return display_ssid;
}

static void app_on_wifi_scan(void)
{
    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_SCAN;
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(100));
    }
}

static void app_on_wifi_connect(const char *ssid, const char *password)
{
    if (ssid == NULL || ssid[0] == '\0') {
        return;
    }
    const char *raw = raw_ssid_for(ssid);
    copy_text(s_pending_ssid, sizeof(s_pending_ssid), raw);
    copy_text(s_pending_pass, sizeof(s_pending_pass), password != NULL ? password : "");
    s_have_pending = true;
    s_weather_seq++;
    s_abort = false;

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_CONNECT;
    cmd.seq = s_weather_seq;
    copy_text(cmd.ssid, sizeof(cmd.ssid), raw);
    copy_text(cmd.pass, sizeof(cmd.pass), password != NULL ? password : "");
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(200));
    }
}

static void app_on_wifi_cancel(void)
{
    s_abort = true;
    s_have_pending = false;
    s_weather_pending = false;
    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_CANCEL;
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(100));
    }

    /* Cancelling tears down whatever link the module had.  Stop lying about the
       Wi-Fi state on the weather panel, then restore the saved network if we
       have one; otherwise explain what to do next. */
    if (s_have_weather) {
        s_last_current.wifi_ok = false;
        s_last_current.rssi = 0;
        ui_set_weather(&s_last_current);
    }
    if (s_have_saved) {
        s_weather_seq++;
        s_weather_pending = true;
        AppCmd again;
        memset(&again, 0, sizeof(again));
        again.type = CMD_REFRESH;
        again.seq = s_weather_seq;
        if (s_cmd_q != NULL) {
            xQueueSend(s_cmd_q, &again, pdMS_TO_TICKS(100));
        }
    } else {
        ui_set_weather_error(UI_ERR_NO_NETWORKS,
                             "Wi-Fi setup canceled. Open Settings > Change network.");
    }
}

static void app_on_wifi_retry(void)
{
    const char *ssid = s_pending_ssid;
    const char *pass = s_pending_pass;
    if (!s_have_pending || ssid[0] == '\0') {
        ssid = s_saved_ssid;
        pass = s_saved_pass;
    }
    if (ssid == NULL || ssid[0] == '\0') {
        ui_show_wifi_result(false, UI_ERR_NET_NOT_FOUND, "", "No network selected");
        return;
    }
    s_weather_seq++;
    s_abort = false;

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_CONNECT;
    cmd.seq = s_weather_seq;
    copy_text(cmd.ssid, sizeof(cmd.ssid), ssid);
    copy_text(cmd.pass, sizeof(cmd.pass), pass != NULL ? pass : "");
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(200));
    }
}

static void app_on_wifi_continue(void)
{
    if (!s_have_city) {
        ui_show_city_search();
        ui_set_city_results(NULL, 0, "Search for your city");
        return;
    }
    if (!s_wifi_connected) {
        ui_show_weather();
        ui_set_weather_error(UI_ERR_NO_NETWORKS, "Wi-Fi is not connected.");
        return;
    }
    if (s_have_weather) {
        ui_show_weather();
        return;
    }
    if (s_weather_failed) {
        ui_show_weather();
        return;                       /* error panel is already configured */
    }
    s_wait_weather = true;
    ui_show_splash();
    ui_set_splash_progress(70, "Loading weather...");
}

static void app_on_wifi_forget(void)
{
    nvs_clear_credentials();
    s_have_pending = false;
    s_wifi_connected = false;
    s_rssi = 0;
    ui_set_wifi_card(NULL, false, 0);
    if (s_have_weather) {
        s_last_current.wifi_ok = false;
        s_last_current.rssi = 0;
        ui_set_weather(&s_last_current);
    }
    ui_set_weather_error(UI_ERR_NO_NETWORKS,
                         "Network forgotten. Open Settings > Change network to reconnect.");

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_FORGET;
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(100));
    }
}

static void app_on_refresh(void)
{
    if (!s_have_city) {
        ui_show_city_search();
        ui_set_city_results(NULL, 0, "Search for your city");
        return;
    }
    if (!s_wifi_connected && !s_have_saved) {
        ui_set_weather_error(UI_ERR_NO_NETWORKS,
                             "Wi-Fi is not connected. Open Settings > Change network.");
        return;
    }
    s_weather_seq++;
    s_weather_pending = true;
    if (!s_wifi_connected) {
        s_wait_weather = true;
        ui_show_splash();
        ui_set_splash_progress(40, "Reconnecting Wi-Fi...");
    }

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_REFRESH;
    cmd.seq = s_weather_seq;
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(100));
    }
}

static void app_on_city_search(const char *query)
{
    if (query == NULL) {
        query = "";
    }
    char q[72];
    copy_text(q, sizeof(q), query);
    char *start = q;
    while (*start == ' ') start++;
    char *end = start + strlen(start);
    while (end > start && end[-1] == ' ') {
        *--end = '\0';
    }
    if (*start == '\0') {
        ui_set_city_results(NULL, 0, "Type a city name first");
        return;
    }
    if (!s_wifi_connected && !s_have_saved) {
        ui_set_city_results(NULL, 0, "Wi-Fi is not connected. Set it up first.");
        return;
    }

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_CITY_SEARCH;
    copy_text(cmd.query, sizeof(cmd.query), start);
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(100));
    }
}

static void app_on_city_select(const ui_city_t *city)
{
    if (city == NULL || city->name[0] == '\0') {
        return;
    }
    s_city = *city;
    s_city.name[sizeof(s_city.name) - 1] = '\0';
    s_city.region[sizeof(s_city.region) - 1] = '\0';
    s_city.country[sizeof(s_city.country) - 1] = '\0';
    s_city.tz[sizeof(s_city.tz) - 1] = '\0';
    s_have_city = true;
    nvs_save_city();

    s_weather_seq++;
    s_weather_failed = false;
    s_weather_pending = true;
    s_wait_weather = true;

    if (!s_wifi_connected && !s_have_saved) {
        s_wait_weather = false;
        ui_show_weather();
        ui_set_weather_error(UI_ERR_NO_NETWORKS, "Wi-Fi is not connected. Set it up first.");
        return;
    }

    char status[80];
    ascii_copy(status, sizeof(status), s_city.name);
    ui_show_splash();
    ui_set_splash_progress(25, status[0] ? "Loading weather for this city" : "Loading weather...");

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_REFRESH;
    cmd.seq = s_weather_seq;
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(100));
    }
}

static void app_on_settings_changed(bool fahrenheit, bool clock24, int brightness)
{
    s_fahrenheit = fahrenheit;
    s_clock24 = clock24;
    s_brightness = clamp_int(brightness, 10, 100);
    set_backlight(s_brightness);
    s_settings_dirty = true;
    s_settings_dirty_ms = millis();
}

/* ------------------------------------------------------------------------- */
/* Worker helpers                                                            */
/* ------------------------------------------------------------------------- */

static bool send_event(const AppEvent &ev, uint32_t timeout_ms)
{
    if (s_evt_q == NULL) {
        return false;
    }
    return xQueueSend(s_evt_q, &ev, pdMS_TO_TICKS(timeout_ms)) == pdTRUE;
}

static void send_splash(int percent, const char *status)
{
    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_SPLASH;
    ev.percent = (int16_t)percent;
    copy_text(ev.text, sizeof(ev.text), status);
    send_event(ev, 300);
}

static void send_need_wifi(void)
{
    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_NEED_WIFI;
    send_event(ev, 1000);
}

static void send_wifi_state(void)
{
    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_WIFI_STATE;
    ev.ok = s_wifi_connected;
    ev.rssi = (int16_t)s_rssi;
    copy_text(ev.ssid, sizeof(ev.ssid), s_saved_ssid);
    send_event(ev, 500);
}

static void send_connect_result(bool ok, ui_error_t error, const char *ssid,
                                const char *pass, const char *detail)
{
    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_CONNECT;
    ev.ok = ok;
    ev.error = (uint8_t)error;
    copy_text(ev.ssid, sizeof(ev.ssid), ssid != NULL ? ssid : "");
    copy_text(ev.pass, sizeof(ev.pass), ok && pass != NULL ? pass : "");
    copy_text(ev.text, sizeof(ev.text), detail != NULL ? detail : "");
    ev.rssi = (int16_t)s_rssi;
    send_event(ev, 2000);
}

static void send_weather_error(uint16_t seq, ui_error_t error, const char *detail)
{
    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_WEATHER_ERR;
    ev.error = (uint8_t)error;
    ev.seq = seq;
    copy_text(ev.text, sizeof(ev.text), detail != NULL ? detail : "");
    send_event(ev, 2000);
}

static void send_weather(const AppEvent &src)
{
    send_event(src, 3000);
}

static void send_city_results(const ui_city_t *cities, int count, const char *status)
{
    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_CITY;
    ev.n_days = (uint8_t)clamp_int(count, 0, UI_CITY_MAX);
    for (int i = 0; i < ev.n_days; i++) {
        ev.cities[i] = cities[i];
    }
    copy_text(ev.text, sizeof(ev.text), status);
    send_event(ev, 2000);
}

static bool sync_clock_utc(void)
{
    if (time_is_valid()) {
        return true;
    }
    logln("NTP: syncing UTC clock (needed for TLS validation)");
    configTime(0, 0, NTP_SERVER_1, NTP_SERVER_2, NTP_SERVER_3);
    uint32_t start = millis();
    while (millis() - start < NTP_WAIT_MS) {
        if (time_is_valid()) {
            logf("NTP: clock valid after %lu ms\n", (unsigned long)(millis() - start));
            return true;
        }
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    logln("NTP: sync timeout");
    return false;
}

/* Apply the API timezone.  ESP-IDF newlib often only understands POSIX TZ
   strings, so an IANA name that does not change the offset is replaced by the
   exact utc_offset_seconds returned by Open-Meteo.  The offset is refreshed
   with every weather fetch, which also picks up DST changes. */
static void apply_timezone(const char *tz, int utc_offset_seconds)
{
    bool applied = false;
    if (tz != NULL && tz[0] != '\0') {
        configTzTime(tz, NTP_SERVER_1, NTP_SERVER_2, NTP_SERVER_3);
        time_t now = time(NULL);
        struct tm lt, gt;
        if (now > 0 && localtime_r(&now, &lt) != NULL && gmtime_r(&now, &gt) != NULL) {
            int diff = (lt.tm_hour * 60 + lt.tm_min) - (gt.tm_hour * 60 + gt.tm_min);
            if (diff > 720) diff -= 1440;
            if (diff < -720) diff += 1440;
            int want = utc_offset_seconds / 60;
            if (abs(diff - want) <= 1) {
                applied = true;
                logf("TZ: IANA %s accepted (offset %d s)\n", tz, utc_offset_seconds);
            }
        }
    }
    if (!applied) {
        configTime((long)utc_offset_seconds, 0, NTP_SERVER_1, NTP_SERVER_2, NTP_SERVER_3);
        logf("TZ: fixed offset %d s (IANA string not usable)\n", utc_offset_seconds);
    }
}

static bool wifi_connect_blocking(const char *ssid, const char *pass)
{
    if (ssid == NULL || ssid[0] == '\0') {
        return false;
    }
    s_abort = false;
    s_disc_reason = 0;
    WiFi.persistent(false);
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);
    WiFi.setAutoReconnect(false);

    if (WiFi.status() == WL_CONNECTED && WiFi.SSID() == String(ssid)) {
        s_wifi_connected = true;
        s_rssi = WiFi.RSSI();
        return true;
    }
    if (WiFi.status() != WL_DISCONNECTED) {
        WiFi.disconnect(false, false);
        delay(200);
    }
    logf("WiFi: connecting to \"%s\"\n", ssid);
    WiFi.begin(ssid, pass != NULL ? pass : "");

    uint32_t start = millis();
    while (millis() - start < WIFI_CONNECT_MS) {
        if (s_abort) {
            WiFi.disconnect(false, false);
            s_wifi_connected = false;
            logln("WiFi: canceled by user");
            return false;
        }
        wl_status_t st = WiFi.status();
        if (st == WL_CONNECTED) {
            s_wifi_connected = true;
            s_rssi = WiFi.RSSI();
            WiFi.setAutoReconnect(true);
            logf("WiFi: connected, IP %s, RSSI %d\n",
                          WiFi.localIP().toString().c_str(), (int)s_rssi);
            return true;
        }
        if (st == WL_CONNECT_FAILED || st == WL_NO_SSID_AVAIL) {
            delay(350);
            if (WiFi.status() != WL_CONNECTED) {
                WiFi.disconnect(false, false);
                s_wifi_connected = false;
                logf("WiFi: failed, status %d reason %u\n", (int)st, (unsigned)s_disc_reason);
                return false;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    WiFi.disconnect(false, false);
    s_wifi_connected = false;
    logf("WiFi: timeout, reason %u\n", (unsigned)s_disc_reason);
    return false;
}

static void connect_error(ui_error_t *err, char *detail, size_t dn)
{
    uint8_t reason = s_disc_reason;
    wl_status_t st = WiFi.status();

    if (reason == 201 || st == WL_NO_SSID_AVAIL) {
        *err = UI_ERR_NET_NOT_FOUND;
        copy_text(detail, dn, "Network not found. It may be out of range or hidden.");
        return;
    }
    if (reason == 15 || reason == 204 || reason == 202 || reason == 203 ||
        st == WL_CONNECT_FAILED) {
        *err = UI_ERR_WRONG_PASSWORD;
        copy_text(detail, dn, "Wrong password. Check it and try again, or change network.");
        return;
    }
    if (reason == 200 || reason == 205) {
        *err = UI_ERR_TIMEOUT;
        copy_text(detail, dn, "The access point did not answer. Try again.");
        return;
    }
    *err = UI_ERR_TIMEOUT;
    snprintf(detail, dn, "Could not connect (reason %u). Check the network and retry.",
             (unsigned)reason);
}

/* Reusable HTTPS GET with real certificate validation (built-in CA bundle).
   On success the parsed document is returned in doc. */
static bool https_get_json(const char *url, const char *host, JsonDocument &doc,
                           ui_error_t *err, char *detail, size_t dn)
{
    *err = UI_ERR_NONE;
    if (detail != NULL && dn > 0) detail[0] = '\0';

    if (WiFi.status() != WL_CONNECTED) {
        *err = UI_ERR_NO_NETWORKS;
        copy_text(detail, dn, "Wi-Fi is not connected.");
        return false;
    }
    if (!sync_clock_utc()) {
        *err = UI_ERR_TIMEOUT;
        copy_text(detail, dn, "Clock not set; TLS certificate validation needs NTP.");
        return false;
    }

    IPAddress ip;
    if (!WiFi.hostByName(host, ip)) {
        *err = UI_ERR_DNS;
        snprintf(detail, dn, "DNS lookup failed for %.90s.", host);
        logf("HTTPS: DNS failed for %s\n", host);
        return false;
    }

    NetworkClientSecure client;
    client.useBuiltinCACertBundle();
    client.setHandshakeTimeout(15);

    HTTPClient http;
    http.setConnectTimeout(HTTP_TIMEOUT_MS);
    http.setTimeout(HTTP_TIMEOUT_MS);
    http.setReuse(false);
    http.useHTTP10(true);
    http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);

    if (!http.begin(client, String(url))) {
        *err = UI_ERR_UNKNOWN;
        copy_text(detail, dn, "Could not initialize the HTTPS request.");
        return false;
    }
    http.addHeader("Accept-Encoding", "identity");
    http.setUserAgent("ESP32-WeatherStation/1.0");

    int code = http.GET();
    if (code <= 0) {
        char tls[96] = {0};
        int tls_err = client.lastError(tls, sizeof(tls));
        String es = http.errorToString(code);
        logf("HTTPS: GET failed code=%d tls=%d heap=%u\n", code, tls_err,
                      (unsigned)ESP.getFreeHeap());
        http.end();

        if (code == HTTPC_ERROR_READ_TIMEOUT) {
            *err = UI_ERR_TIMEOUT;
            copy_text(detail, dn, "The weather server timed out while sending data.");
        } else if (code == HTTPC_ERROR_TOO_LESS_RAM) {
            *err = UI_ERR_UNKNOWN;
            copy_text(detail, dn, "Not enough RAM for the secure connection.");
        } else if (tls[0] != '\0') {
            *err = UI_ERR_TLS;
            snprintf(detail, dn, "TLS: %.110s", tls);
        } else {
            *err = UI_ERR_TLS;
            snprintf(detail, dn, "Secure connection failed (%d, %.40s).", code, es.c_str());
        }
        return false;
    }

    if (code != HTTP_CODE_OK) {
        logf("HTTPS: HTTP %d from %s\n", code, host);
        *err = UI_ERR_HTTP;
        snprintf(detail, dn, "HTTP %d from %.80s.", code, host);
        http.end();
        return false;
    }

    DeserializationError je = deserializeJson(doc, http.getStream());
    http.end();
    if (je) {
        *err = UI_ERR_HTTP;
        snprintf(detail, dn, "Invalid JSON (%.40s).", je.c_str());
        logf("HTTPS: JSON error %s\n", je.c_str());
        return false;
    }
    logf("HTTPS: %s OK, heap=%u psram=%u\n", host,
                  (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
    return true;
}

/* ------------------------------------------------------------------------- */
/* Worker operations                                                         */
/* ------------------------------------------------------------------------- */

static void worker_scan(void)
{
    WiFi.mode(WIFI_STA);
    WiFi.scanDelete();
    logln("WiFi: scanning");
    int found = WiFi.scanNetworks(false, true);
    if (found < 0) {
        WiFi.scanDelete();
        AppEvent ev;
        memset(&ev, 0, sizeof(ev));
        ev.type = EV_SCAN;
        ev.n_hours = 0;
        copy_text(ev.text, sizeof(ev.text), "Scan failed. Tap refresh to try again.");
        send_event(ev, 2000);
        logf("WiFi: scan error %d\n", found);
        return;
    }

    struct Entry {
        char ssid[33];
        int rssi;
        bool secure;
    };
    Entry best[12];
    int count = 0;

    for (int i = 0; i < found; i++) {
        String ssid = WiFi.SSID(i);
        if (ssid.length() == 0) {
            continue;
        }
        int rssi = (int)WiFi.RSSI(i);
        bool secure = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;
        int existing = -1;
        for (int j = 0; j < count; j++) {
            if (strcmp(best[j].ssid, ssid.c_str()) == 0) {
                existing = j;
                break;
            }
        }
        if (existing >= 0) {
            if (rssi > best[existing].rssi) {
                best[existing].rssi = rssi;
                best[existing].secure = secure;
            }
        } else if (count < 12) {
            copy_text(best[count].ssid, sizeof(best[count].ssid), ssid.c_str());
            best[count].rssi = rssi;
            best[count].secure = secure;
            count++;
        }
    }
    WiFi.scanDelete();

    /* Strongest first.  Twelve entries is exactly what the UI list shows;
       the other entries would be unreachable below the scroll viewport. */
    for (int i = 0; i < count - 1; i++) {
        for (int j = i + 1; j < count; j++) {
            if (best[j].rssi > best[i].rssi) {
                Entry t = best[i];
                best[i] = best[j];
                best[j] = t;
            }
        }
    }

    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_SCAN;
    ev.n_hours = (uint8_t)count;
    for (int i = 0; i < count; i++) {
        copy_text(ev.nets[i].ssid, sizeof(ev.nets[i].ssid), best[i].ssid);
        ev.nets[i].rssi = (int16_t)best[i].rssi;
        ev.nets[i].secure = best[i].secure;
    }
    if (count == 0) {
        copy_text(ev.text, sizeof(ev.text), "No networks found. Tap refresh to scan again.");
    } else {
        snprintf(ev.text, sizeof(ev.text), "%d network%s found", count, count == 1 ? "" : "s");
    }
    send_event(ev, 3000);
    logf("WiFi: scan found %d named networks\n", count);
}

static void worker_connect(const char *ssid, const char *pass, uint16_t seq)
{
    if (!wifi_connect_blocking(ssid, pass)) {
        if (s_abort) {
            return;
        }
        ui_error_t err = UI_ERR_UNKNOWN;
        char detail[160];
        connect_error(&err, detail, sizeof(detail));
        send_connect_result(false, err, ssid, "", detail);
        return;
    }

    char detail[96];
    snprintf(detail, sizeof(detail), "IP %s, %d dBm",
             WiFi.localIP().toString().c_str(), (int)WiFi.RSSI());
    send_connect_result(true, UI_ERR_NONE, ssid, pass, detail);

    if (s_have_city) {
        extern void worker_weather(uint16_t seq);
        worker_weather(seq);
    }
}

static void worker_weather(uint16_t seq)
{
    if (!s_have_city || s_city.name[0] == '\0') {
        send_weather_error(seq, UI_ERR_UNKNOWN, "Search for a city first.");
        return;
    }

    if (WiFi.status() != WL_CONNECTED) {
        if (!s_have_saved) {
            send_weather_error(seq, UI_ERR_NO_NETWORKS, "Wi-Fi is not connected.");
            return;
        }
        send_splash(50, "Reconnecting Wi-Fi...");
        if (!wifi_connect_blocking(s_saved_ssid, s_saved_pass)) {
            send_weather_error(seq, UI_ERR_NO_NETWORKS, "Saved Wi-Fi network is unreachable.");
            return;
        }
        send_wifi_state();
    }

    if (s_booting) {
        send_splash(55, "Syncing clock...");
    }
    if (!sync_clock_utc()) {
        send_weather_error(seq, UI_ERR_TIMEOUT,
                           "NTP failed; TLS validation needs a correct clock.");
        return;
    }

    char url[640];
    snprintf(url, sizeof(url),
             "https://" WEATHER_HOST "/v1/forecast?latitude=%.4f&longitude=%.4f"
             "&current=temperature_2m,apparent_temperature,relative_humidity_2m,"
             "pressure_msl,wind_speed_10m,weather_code,is_day"
             "&hourly=temperature_2m,weather_code,precipitation_probability"
             "&daily=weather_code,temperature_2m_max,temperature_2m_min,"
             "precipitation_probability_max"
             "&timezone=auto&forecast_days=6&forecast_hours=24"
             "&wind_speed_unit=kmh&temperature_unit=celsius",
             (double)s_city.lat, (double)s_city.lon);

    logf("Weather: fetching for %s (%.4f, %.4f)\n",
                  s_city.name, (double)s_city.lat, (double)s_city.lon);

    JsonDocument doc;
    ui_error_t err = UI_ERR_NONE;
    char detail[160];
    if (!https_get_json(url, WEATHER_HOST, doc, &err, detail, sizeof(detail))) {
        send_weather_error(seq, err, detail);
        return;
    }

    JsonObject cur = doc["current"];
    JsonArray h_time = doc["hourly"]["time"];
    JsonArray h_temp = doc["hourly"]["temperature_2m"];
    JsonArray h_code = doc["hourly"]["weather_code"];
    JsonArray h_precip = doc["hourly"]["precipitation_probability"];
    JsonArray d_time = doc["daily"]["time"];
    JsonArray d_code = doc["daily"]["weather_code"];
    JsonArray d_max = doc["daily"]["temperature_2m_max"];
    JsonArray d_min = doc["daily"]["temperature_2m_min"];
    JsonArray d_precip = doc["daily"]["precipitation_probability_max"];

    if (cur.isNull() || h_time.size() == 0 || d_time.size() == 0) {
        send_weather_error(seq, UI_ERR_HTTP, "Weather response is missing data.");
        return;
    }

    const char *tz = doc["timezone"] | "";
    int utc_offset = doc["utc_offset_seconds"] | 0;
    apply_timezone(tz, utc_offset);

    AppEvent ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = EV_WEATHER;
    ev.seq = seq;

    ui_current_t &wc = ev.current;
    copy_text(wc.city, sizeof(wc.city), s_city.name);
    copy_text(wc.condition, sizeof(wc.condition),
              condition_text(doc["current"]["weather_code"] | 2));
    wc.temp_c = doc["current"]["temperature_2m"] | 0.0f;
    wc.feels_c = doc["current"]["apparent_temperature"] | wc.temp_c;
    wc.humidity = doc["current"]["relative_humidity_2m"] | 0;
    wc.pressure = (int)lroundf((float)(doc["current"]["pressure_msl"] | 0.0f));
    wc.wind = (int)lroundf((float)(doc["current"]["wind_speed_10m"] | 0.0f));
    wc.code = doc["current"]["weather_code"] | 2;
    wc.is_day = (doc["current"]["is_day"] | 1) != 0;
    wc.rssi = (int)WiFi.RSSI();
    wc.wifi_ok = WiFi.status() == WL_CONNECTED;

    time_t now = time(NULL);
    if (now > 1700000000) {
        struct tm lt;
        if (localtime_r(&now, &lt) != NULL) {
            strftime(wc.updated, sizeof(wc.updated), "%H:%M", &lt);
        }
    }
    if (wc.updated[0] == '\0') {
        const char *ct = doc["current"]["time"] | "";
        if (strlen(ct) >= 16) {
            memcpy(wc.updated, ct + 11, 5);
            wc.updated[5] = '\0';
        } else {
            copy_text(wc.updated, sizeof(wc.updated), "--:--");
        }
    }

    char cur_hour[14] = {0};
    const char *ct = doc["current"]["time"] | "";
    if (strlen(ct) >= 13) {
        memcpy(cur_hour, ct, 13);
        cur_hour[13] = '\0';
    }
    int start = 0;
    if (cur_hour[0] != '\0') {
        for (size_t i = 0; i < h_time.size(); i++) {
            const char *t = h_time[i] | "";
            if (strlen(t) >= 13 && strncmp(t, cur_hour, 13) >= 0) {
                start = (int)i;
                break;
            }
        }
    }

    int hc = 0;
    for (int k = 0; k < 5 && (start + k) < (int)h_time.size(); k++) {
        const char *t = h_time[start + k] | "";
        ui_hour_t &h = ev.hours[hc];
        if (k == 0) {
            copy_text(h.time, sizeof(h.time), "Now");
        } else if (strlen(t) >= 16) {
            memcpy(h.time, t + 11, 5);
            h.time[5] = '\0';
        } else {
            copy_text(h.time, sizeof(h.time), "--:--");
        }
        h.temp_c = h_temp[start + k] | 0.0f;
        h.code = h_code[start + k] | 2;
        h.precip = h_precip[start + k] | 0;
        hc++;
    }
    ev.n_hours = (uint8_t)hc;

    int dc = 0;
    for (int k = 0; k < 5 && k < (int)d_time.size(); k++) {
        const char *date = d_time[k] | "";
        ui_day_t &d = ev.days[dc];
        day_label(d.day, sizeof(d.day), date, k == 0);
        d.code = d_code[k] | 2;
        d.tmax_c = d_max[k] | 0.0f;
        d.tmin_c = d_min[k] | 0.0f;
        d.precip = d_precip[k] | 0;
        dc++;
    }
    ev.n_days = (uint8_t)dc;

    send_weather(ev);

    if (s_booting) {
        send_splash(90, "Drawing weather...");
    }
    logf("Weather: %s %.1f C, code %d, %d hourly, %d daily\n",
                  wc.condition, wc.temp_c, wc.code, ev.n_hours, ev.n_days);
}

static void worker_city_search(const char *query)
{
    if (query == NULL || query[0] == '\0') {
        send_city_results(NULL, 0, "Type a city name first");
        return;
    }
    if (WiFi.status() != WL_CONNECTED) {
        if (!s_have_saved) {
            send_city_results(NULL, 0, "Wi-Fi is not connected. Set it up first.");
            return;
        }
        if (!wifi_connect_blocking(s_saved_ssid, s_saved_pass)) {
            send_city_results(NULL, 0, "Wi-Fi is not connected.");
            return;
        }
        send_wifi_state();
    }

    char encoded[220];
    url_encode(query, encoded, sizeof(encoded));
    char url[360];
    snprintf(url, sizeof(url),
             "https://" GEOCODE_HOST "/v1/search?name=%s&count=3&language=en&format=json",
             encoded);

    JsonDocument doc;
    ui_error_t err = UI_ERR_NONE;
    char detail[160];
    if (!https_get_json(url, GEOCODE_HOST, doc, &err, detail, sizeof(detail))) {
        char status[160];
        snprintf(status, sizeof(status), "Search failed: %.120s", detail);
        send_city_results(NULL, 0, status);
        return;
    }

    JsonArray results = doc["results"];
    ui_city_t cities[UI_CITY_MAX];
    int count = 0;
    if (!results.isNull()) {
        for (JsonObject r : results) {
            if (count >= UI_CITY_MAX) break;
            ui_city_t &c = cities[count];
            memset(&c, 0, sizeof(c));
            copy_text(c.name, sizeof(c.name), r["name"] | "");
            copy_text(c.region, sizeof(c.region), r["admin1"] | "");
            copy_text(c.country, sizeof(c.country), r["country_code"] | "");
            copy_text(c.tz, sizeof(c.tz), r["timezone"] | "");
            c.lat = r["latitude"] | 0.0f;
            c.lon = r["longitude"] | 0.0f;
            if (c.name[0] == '\0') continue;
            count++;
        }
    }

    if (count == 0) {
        char status[120];
        char qascii[64];
        ascii_copy(qascii, sizeof(qascii), query);
        snprintf(status, sizeof(status), "No matches for %.60s. Try another spelling.", qascii);
        send_city_results(NULL, 0, status);
    } else {
        char status[64];
        snprintf(status, sizeof(status), "%d match%s. Tap a city to use it.",
                 count, count == 1 ? "" : "es");
        send_city_results(cities, count, status);
    }
    logf("Geocode: \"%s\" -> %d results\n", query, count);
}

static void worker_boot(uint16_t seq)
{
    if (!s_have_saved || s_saved_ssid[0] == '\0') {
        send_need_wifi();
        return;
    }
    send_splash(8, "Connecting to saved Wi-Fi...");
    if (!wifi_connect_blocking(s_saved_ssid, s_saved_pass)) {
        if (s_abort) return;
        ui_error_t err = UI_ERR_UNKNOWN;
        char detail[160];
        connect_error(&err, detail, sizeof(detail));
        send_connect_result(false, err, s_saved_ssid, "", detail);
        return;
    }

    char detail[96];
    snprintf(detail, sizeof(detail), "IP %s, %d dBm",
             WiFi.localIP().toString().c_str(), (int)WiFi.RSSI());
    send_connect_result(true, UI_ERR_NONE, s_saved_ssid, s_saved_pass, detail);

    if (!s_have_city) {
        return;                       /* UI offers city search after Continue */
    }
    worker_weather(seq);
}

static void worker_forget(void)
{
    s_abort = true;
    WiFi.setAutoReconnect(false);
    WiFi.disconnect(false, false);
    s_wifi_connected = false;
    s_rssi = 0;
    send_wifi_state();
    logln("WiFi: credentials forgotten");
    s_abort = false;
}

static void worker_task(void *arg)
{
    (void)arg;
    AppCmd cmd;
    for (;;) {
        if (xQueueReceive(s_cmd_q, &cmd, portMAX_DELAY) != pdTRUE) {
            continue;
        }
        switch (cmd.type) {
        case CMD_BOOT:
            worker_boot(cmd.seq);
            break;
        case CMD_SCAN:
            worker_scan();
            break;
        case CMD_CONNECT:
            worker_connect(cmd.ssid, cmd.pass, cmd.seq);
            break;
        case CMD_CANCEL:
            s_abort = true;
            if (WiFi.status() == WL_CONNECTED) {
                WiFi.disconnect(false, false);
            }
            s_wifi_connected = false;
            break;
        case CMD_FORGET:
            worker_forget();
            break;
        case CMD_REFRESH:
            worker_weather(cmd.seq);
            break;
        case CMD_CITY_SEARCH:
            worker_city_search(cmd.query);
            break;
        default:
            break;
        }
    }
}

/* ------------------------------------------------------------------------- */
/* UI task event handling                                                    */
/* ------------------------------------------------------------------------- */

static void refresh_wifi_card(void)
{
    bool connected = s_wifi_connected && WiFi.status() == WL_CONNECTED;
    if (connected) {
        s_rssi = WiFi.RSSI();
        ui_set_wifi_card(s_saved_ssid, true, (int)s_rssi);
    } else if (s_saved_ssid[0] != '\0') {
        ui_set_wifi_card(s_saved_ssid, false, 0);
    } else {
        ui_set_wifi_card(NULL, false, 0);
    }
    /* A dropped link must not keep showing the "connected" badge on the
       weather panel. */
    if (!connected && s_have_weather && s_last_current.wifi_ok) {
        s_last_current.wifi_ok = false;
        s_last_current.rssi = 0;
        ui_set_weather(&s_last_current);
    }
}

static void update_system_info(void)
{
    char ip[20] = "Not connected";
    if (WiFi.status() == WL_CONNECTED) {
        IPAddress a = WiFi.localIP();
        snprintf(ip, sizeof(ip), "%u.%u.%u.%u", a[0], a[1], a[2], a[3]);
    }
    char mac[20];
    copy_text(mac, sizeof(mac), WiFi.macAddress().c_str());
    ui_set_system_info(APP_VERSION, ip, mac, (uint32_t)ESP.getFreeHeap(),
                       (uint32_t)ESP.getFreePsram(), (uint32_t)(millis() / 1000UL));

    /* Low-rate heartbeat: the only periodic console line, useful when the
       panel is not reachable but the board is. */
    static uint32_t last_beat;
    if ((millis() - last_beat) > 30000U) {
        last_beat = millis();
        logf("HB: up=%lus heap=%u psram=%u wifi=%d ip=%s\n",
                      (unsigned long)(millis() / 1000UL),
                      (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram(),
                      (int)WiFi.status(), ip);
    }
}

static void handle_event(const AppEvent &ev)
{
    switch (ev.type) {
    case EV_SPLASH:
        if (s_booting) {
            ui_show_splash();
            ui_set_splash_progress(ev.percent, ev.text);
        }
        break;

    case EV_SCAN:
        s_scan_count = ev.n_hours > UI_WIFI_MAX ? UI_WIFI_MAX : ev.n_hours;
        for (int i = 0; i < s_scan_count; i++) {
            copy_text(s_scan_raw[i], sizeof(s_scan_raw[i]), ev.nets[i].ssid);
        }
        ui_set_wifi_list(ev.nets, s_scan_count);
        ui_set_wifi_scan(false, ev.text);
        break;

    case EV_CONNECT: {
        if (ev.ok) {
            s_wifi_connected = true;
            s_rssi = ev.rssi;
            nvs_save_credentials(ev.ssid, ev.pass);
            s_have_pending = false;
            if (s_booting) {
                ui_set_splash_progress(45, "Connected. Preparing weather...");
                if (!s_have_city) {
                    s_booting = false;
                    s_weather_pending = false;
                    ui_show_city_search();
                    ui_set_city_results(NULL, 0, "Search for your city");
                }
            } else {
                ui_show_wifi_result(true, UI_ERR_NONE, ev.ssid, ev.text);
            }
            refresh_wifi_card();
        } else {
            s_weather_pending = false;
            if (s_booting) {
                s_booting = false;
            }
            ui_show_wifi_result(false, (ui_error_t)ev.error, ev.ssid, ev.text);
            refresh_wifi_card();
            logf("WiFi: connection failed (%s)\n", ev.text);
        }
        break;
    }

    case EV_WEATHER:
        if (ev.seq != s_weather_seq) {
            logf("Weather: ignoring stale result seq %u (current %u)\n",
                          (unsigned)ev.seq, (unsigned)s_weather_seq);
            break;
        }
        s_weather_pending = false;
        s_weather_failed = false;
        s_have_weather = true;
        s_rssi = ev.current.rssi;
        s_last_current = ev.current;
        ui_set_weather(&ev.current);
        ui_set_hourly(ev.hours, ev.n_hours);
        ui_set_daily(ev.days, ev.n_days);
        refresh_wifi_card();
        if (s_booting) {
            s_booting = false;
            ui_show_weather();
        } else if (s_wait_weather) {
            s_wait_weather = false;
            ui_show_weather();
        }
        break;

    case EV_WEATHER_ERR:
        if (ev.seq != s_weather_seq) {
            logf("Weather: ignoring stale error seq %u (current %u)\n",
                          (unsigned)ev.seq, (unsigned)s_weather_seq);
            break;
        }
        s_weather_pending = false;
        s_weather_failed = true;
        s_weather_err = (ui_error_t)ev.error;
        copy_text(s_weather_detail, sizeof(s_weather_detail), ev.text);
        ui_set_weather_error(s_weather_err, s_weather_detail);
        logf("Weather: error %d: %s\n", (int)s_weather_err, s_weather_detail);
        if (s_booting) {
            s_booting = false;
            ui_show_weather();
        } else if (s_wait_weather) {
            s_wait_weather = false;
            ui_show_weather();
        }
        break;

    case EV_CITY:
        ui_set_city_results(ev.cities, ev.n_days, ev.text);
        break;

    case EV_NEED_WIFI:
        s_booting = false;
        s_weather_pending = false;
        ui_show_wifi_scan();
        ui_set_wifi_scan(true, "Scanning...");
        ui_set_wifi_list(NULL, 0);
        app_on_wifi_scan();
        break;

    case EV_WIFI_STATE:
        s_wifi_connected = ev.ok;
        s_rssi = ev.rssi;
        refresh_wifi_card();
        break;

    default:
        break;
    }
}

/* ------------------------------------------------------------------------- */
/* Setup / loop                                                              */
/* ------------------------------------------------------------------------- */

/* Wi-Fi events arrive on the Wi-Fi task.  Only flags/atomics are touched here;
   the Arduino task applies them to the UI. */
static void on_wifi_event(WiFiEvent_t event)
{
    switch (event) {
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:
        s_wifi_connected = true;
        s_wifi_state_dirty = true;
        break;
    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
        s_wifi_connected = false;
        s_rssi = 0;
        s_wifi_state_dirty = true;
        break;
    default:
        break;
    }
}

static void app_start_boot(void)
{
    if (s_boot_posted) {
        return;
    }
    s_boot_posted = true;
    s_booting = true;
    s_weather_seq++;
    s_weather_pending = false;
    s_weather_failed = false;
    s_wait_weather = false;
    ui_show_splash();
    ui_set_splash_progress(3, "Starting...");

    AppCmd cmd;
    memset(&cmd, 0, sizeof(cmd));
    cmd.type = CMD_BOOT;
    cmd.seq = s_weather_seq;
    if (s_cmd_q != NULL) {
        xQueueSend(s_cmd_q, &cmd, pdMS_TO_TICKS(200));
    }
}

void setup()
{
    /* Console logging is unconditional (see logf); no host handshake needed. */
    logf("\n\nWeather Station %s\n", APP_VERSION);
    logf("Chip: %s rev %d, %d MHz\n", ESP.getChipModel(), ESP.getChipRevision(),
                  (int)getCpuFrequencyMhz());
    logf("Flash: %u MB, PSRAM: %u MB (%s)\n",
                  (unsigned)(ESP.getFlashChipSize() / (1024U * 1024U)),
                  (unsigned)(ESP.getPsramSize() / (1024U * 1024U)),
                  psramFound() ? "found" : "MISSING");

    pinMode(PIN_TOUCH_IRQ, INPUT_PULLUP);   /* IRQ is not used; touch is polled */
    nvs_load();

    WiFi.onEvent(on_wifi_event);
    WiFi.persistent(false);

    /* Backlight off during panel init, then restore the saved level. */
    if (!ledcAttach(PIN_BACKLIGHT, 5000, 10)) {
        logln("Backlight: ledcAttach failed");
    }
    ledcWrite(PIN_BACKLIGHT, 0);

    s_tft.init();
    s_tft.setRotation(1);
    display_self_test();
    s_tft.fillScreen(TFT_BLACK);
    logf("TFT: %dx%d, rotation %d\n", s_tft.width(), s_tft.height(), s_tft.getRotation());

    if (!psramFound()) {
        fatal_screen("PSRAM not found (N16R8 requires OPI PSRAM)");
    }
    if (ESP.getFreePsram() < (768U * 1024U)) {
        fatal_screen("Not enough PSRAM for LVGL buffers");
    }

    if (s_tcal_ok) {
        s_tft.setTouch(s_tcal);
        logf("Touch: calibration loaded {%u, %u, %u, %u, %u}\n",
             (unsigned)s_tcal[0], (unsigned)s_tcal[1], (unsigned)s_tcal[2],
             (unsigned)s_tcal[3], (unsigned)s_tcal[4]);
    } else {
        /* First boot after this firmware (or after an NVS wipe): run the stock
           TFT_eSPI calibration sketch flow.  The backlight is still off, so
           turn it on for the corner markers. */
        logln("Touch: no stored calibration, starting stock 4-corner routine");
        set_backlight(s_brightness);
        run_touch_calibration();
    }

    lv_init();
    lv_tick_set_cb(tick_cb);

    s_buf1 = (uint16_t *)ps_malloc(LCD_BUF_BYTES);
    if (s_buf1 == NULL) {
        fatal_screen("PSRAM draw buffer allocation failed");
    }
    display_partial_flush_test(s_buf1);
    logf("LVGL: %u-byte PSRAM tile buffer (%d lines), pool 256 KB\n",
                  (unsigned)LCD_BUF_BYTES, LCD_TILE_LINES);

    s_disp = lv_display_create(LCD_W, LCD_H);
    lv_display_set_flush_cb(s_disp, flush_cb);
    /* PARTIAL render mode.  LVGL renders the invalidated area into this band
       buffer and passes the flush callback a pointer to the rectangle's first
       pixel.  There is no whole-screen frame buffer to keep in sync, so a
       partial update cannot expose stale pixels (the DIRECT double-buffer
       mode copies only the invalidated areas between its two buffers, and any
       missed area reappears as stripes or garbage on a later refresh). */
    lv_display_set_buffers(s_disp, s_buf1, NULL, LCD_BUF_BYTES,
                           LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_color_format(s_disp, LV_COLOR_FORMAT_RGB565);
    lv_display_set_default(s_disp);

    lv_theme_t *theme = lv_theme_default_init(s_disp, lv_color_hex(0x4CC9F0),
                                             lv_color_hex(0x16213A), true,
                                             &lv_font_montserrat_14);
    lv_display_set_theme(s_disp, theme);

    s_indev = lv_indev_create();
    lv_indev_set_type(s_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(s_indev, touch_read_cb);
    lv_indev_set_display(s_indev, s_disp);

    static const ui_callbacks_t callbacks = {
        app_on_wifi_scan,
        app_on_wifi_connect,
        app_on_wifi_cancel,
        app_on_wifi_retry,
        app_on_wifi_continue,
        app_on_wifi_forget,
        app_on_refresh,
        app_on_city_search,
        app_on_city_select,
        app_on_calibrate_request,
        app_on_settings_changed
    };

    ui_init(&callbacks);
    ui_set_settings(s_fahrenheit, s_clock24, s_brightness);
    ui_set_wifi_card(s_have_saved ? s_saved_ssid : NULL, false, 0);
    update_system_info();

    s_cmd_q = xQueueCreate(6, sizeof(AppCmd));
    s_evt_q = xQueueCreate(6, sizeof(AppEvent));
    if (s_cmd_q == NULL || s_evt_q == NULL) {
        fatal_screen("FreeRTOS queue allocation failed");
    }
    xTaskCreatePinnedToCore(worker_task, "weather_net", 16384, NULL, 2, NULL, 0);

    set_backlight(s_brightness);
    s_last_sysinfo_ms = millis();

    logf("Heap: %u internal free, %u PSRAM free\n",
                  (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());

    logln("Touch: calibration ready");
    app_start_boot();
}

void loop()
{
    lv_timer_handler();

    AppEvent ev;
    while (s_evt_q != NULL && xQueueReceive(s_evt_q, &ev, 0) == pdTRUE) {
        handle_event(ev);
    }

    if (s_wifi_state_dirty) {
        s_wifi_state_dirty = false;
        refresh_wifi_card();
    }

    if (s_settings_dirty && (millis() - s_settings_dirty_ms) > 1200U) {
        s_settings_dirty = false;
        nvs_save_settings();
    }

    if ((millis() - s_last_sysinfo_ms) > 5000U) {
        s_last_sysinfo_ms = millis();
        update_system_info();
        if (!s_wifi_connected && s_saved_ssid[0] == '\0') {
            refresh_wifi_card();
        }
    }

    delay(5);
}
