#!/usr/bin/env bash
#
# Reproducible build/upload helper for the ESP32-S3-N16R8 weather station.
#
#   ./build.sh              # stage libraries (first run) and compile
#   ./build.sh --upload     # compile, then flash /dev/ttyACM0
#   PORT=/dev/ttyUSB0 ./build.sh --upload
#
# The script never modifies the libraries installed for the Arduino IDE.  It
# downloads pinned versions into a private "library user" directory, copies
# them into a staging folder, and compiles against that folder only.
#
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEVICE="$ROOT/device"

WORK="${WORK:-/tmp/weather-station-build}"
STAGE="${STAGE:-$WORK/libs}"
LIB_USER="${LIB_USER:-$WORK/lib-user}"
EMPTY_USER="${EMPTY_USER:-$WORK/empty-user}"
BUILD="${BUILD:-$WORK/build}"
DOWNLOAD_CFG="${DOWNLOAD_CFG:-$WORK/cli-download.yaml}"
BUILD_CFG="${BUILD_CFG:-$WORK/cli-build.yaml}"

# N16R8: 16 MB flash, OPI (octal) PSRAM, and the 3 MB app / 9 MB FAT
# partition table so both OTA slots are usable.
#
# PSRAM/Flash come straight from Espressif's module table
# (ESP32-S3-WROOM-1, code N16R8): Flash Mode = QSPI, PSRAM = OPI.
#   * FlashSize=16M  -> 16 MB QSPI flash (FlashMode keeps its QIO 80 MHz default;
#     do NOT set FlashMode=opi, that is only for WROOM-2 octal flash).
#   * PSRAM=opi      -> psram_type=opi, links the qio_opi prebuilt IDF libs.
#
# CDCOnBoot=default (Disabled) is deliberate.  This board is wired to a
# CH343-class USB-UART bridge on UART0 (VID 1a86:55d3, /dev/ttyACM0), not to
# the ESP32-S3 native USB pins.  In arduino-esp32:
#     CDC on boot disabled -> Serial == Serial0 (UART0)
#     CDC on boot enabled  -> Serial == HWCDCSerial (native USB)
# Enabling CDC here would move Serial to a port that is not connected, which is
# exactly why the first boot logs were silent.  If you instead plug into the
# board's native USB port (Espressif VID 303a), rebuild with
# USBMode=hwcdc,CDCOnBoot=cdc and use that port.
FQBN='esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB'
PORT="${PORT:-/dev/ttyACM0}"

LVGL_VER="9.6.0"
TFT_VER="2.5.43"
JSON_VER="7.4.3"

mkdir -p "$WORK" "$STAGE" "$LIB_USER" "$EMPTY_USER" "$BUILD"

write_cfg() {
  local file="$1" userdir="$2"
  cat > "$file" <<YAML
directories:
  data: $HOME/.arduino15
  user: $userdir
  downloads: $WORK/downloads
board_manager:
  additional_urls: []
YAML
}

write_cfg "$DOWNLOAD_CFG" "$LIB_USER"
write_cfg "$BUILD_CFG" "$EMPTY_USER"

stage_libraries() {
  if [[ -d "$STAGE/lvgl" && -d "$STAGE/TFT_eSPI" && -d "$STAGE/ArduinoJson" ]]; then
    echo ">> staged libraries already present in $STAGE"
  else
    echo ">> fetching pinned libraries (lvgl $LVGL_VER, TFT_eSPI $TFT_VER, ArduinoJson $JSON_VER)"
    arduino-cli --config-file "$DOWNLOAD_CFG" lib install --no-deps \
      "lvgl@$LVGL_VER" "TFT_eSPI@$TFT_VER" "ArduinoJson@$JSON_VER"
    rm -rf "$STAGE/lvgl" "$STAGE/TFT_eSPI" "$STAGE/ArduinoJson"
    cp -a "$LIB_USER/libraries/lvgl"        "$STAGE/lvgl"
    cp -a "$LIB_USER/libraries/TFT_eSPI"    "$STAGE/TFT_eSPI"
    cp -a "$LIB_USER/libraries/ArduinoJson" "$STAGE/ArduinoJson"
  fi

  # Project-owned configuration must win over the library defaults.
  cp "$DEVICE/lv_conf.h"     "$STAGE/lvgl/src/lv_conf.h"
  cp "$DEVICE/User_Setup.h"  "$STAGE/TFT_eSPI/User_Setup.h"

  echo ">> verifying staged versions"
  grep -H '^version=' \
    "$STAGE/lvgl/library.properties" \
    "$STAGE/TFT_eSPI/library.properties" \
    "$STAGE/ArduinoJson/library.properties"
  grep -q '^#define USE_FSPI_PORT' "$STAGE/TFT_eSPI/User_Setup.h" \
    || { echo "ERROR: USE_FSPI_PORT missing from staged User_Setup.h" >&2; exit 1; }
}

compile() {
  echo ">> compiling for $FQBN"
  arduino-cli --config-file "$BUILD_CFG" compile \
    --fqbn "$FQBN" \
    --libraries "$STAGE" \
    --build-path "$BUILD" \
    "$DEVICE"
}

upload() {
  echo ">> uploading to $PORT"
  arduino-cli --config-file "$BUILD_CFG" upload \
    -p "$PORT" \
    --fqbn "$FQBN" \
    --input-dir "$BUILD" \
    "$DEVICE"
}

stage_libraries
compile

if [[ "${1:-}" == "--upload" ]]; then
  upload
fi