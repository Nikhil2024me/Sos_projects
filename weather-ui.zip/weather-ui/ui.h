/**
 * ui.h - pure LVGL user interface for the ESP32-S3 weather station.
 *
 * This header intentionally contains no Arduino, WiFi, HTTP or TFT types.
 * The device layer owns every byte of I/O and pushes values in through the
 * setters below.  All pointers passed in are copied before the call returns.
 */
#ifndef WEATHER_UI_H
#define WEATHER_UI_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define UI_WIFI_MAX 20
#define UI_CITY_MAX 3

typedef enum {
    UI_ERR_NONE = 0,
    UI_ERR_DNS,
    UI_ERR_TLS,
    UI_ERR_HTTP,
    UI_ERR_TIMEOUT,
    UI_ERR_NO_NETWORKS,
    UI_ERR_WRONG_PASSWORD,
    UI_ERR_NET_NOT_FOUND,
    UI_ERR_AUTH,
    UI_ERR_UNKNOWN
} ui_error_t;

typedef struct {
    char ssid[33];
    int16_t rssi;
    bool secure;
} ui_wifi_t;

typedef struct {
    char name[48];
    char region[48];
    char country[8];
    char tz[40];
    float lat;
    float lon;
} ui_city_t;

typedef struct {
    char city[40];
    char updated[16];      /* local time, "18:02" */
    char condition[28];    /* ASCII condition text */
    float temp_c;
    float feels_c;
    int humidity;          /* % */
    int pressure;          /* hPa */
    int wind;              /* km/h */
    int code;              /* WMO weather code */
    bool is_day;
    int rssi;              /* dBm */
    bool wifi_ok;
} ui_current_t;

typedef struct {
    char time[8];          /* "Now" or "19:00" */
    float temp_c;
    int code;
    int precip;            /* % */
} ui_hour_t;

typedef struct {
    char day[12];          /* "Mon" or "Nov 3" */
    float tmax_c;
    float tmin_c;
    int code;
    int precip;            /* % */
} ui_day_t;

typedef struct {
    void (*on_wifi_scan)(void);
    void (*on_wifi_connect)(const char *ssid, const char *password);
    void (*on_wifi_cancel)(void);
    void (*on_wifi_retry)(void);
    void (*on_wifi_continue)(void);
    void (*on_wifi_forget)(void);
    void (*on_refresh)(void);
    void (*on_city_search)(const char *query);
    void (*on_city_select)(const ui_city_t *city);
    /* Run the stock TFT_eSPI 4-corner calibration routine. */
    void (*on_calibrate)(void);
    void (*on_settings_changed)(bool fahrenheit, bool clock24, int brightness);
} ui_callbacks_t;

/* Lifecycle */
void ui_init(const ui_callbacks_t *callbacks);

/* Splash */
void ui_show_splash(void);
void ui_set_splash_progress(int percent, const char *status);

/* Wi-Fi */
void ui_show_wifi_scan(void);
void ui_set_wifi_scan(bool scanning, const char *status);
void ui_set_wifi_list(const ui_wifi_t *networks, int count);
void ui_show_wifi_password(const char *ssid);
void ui_show_wifi_connecting(const char *ssid);
void ui_show_wifi_result(bool success, ui_error_t error,
                         const char *ssid, const char *detail);

/* Weather */
void ui_show_weather(void);
void ui_set_weather(const ui_current_t *current);
void ui_set_hourly(const ui_hour_t *hours, int count);
void ui_set_weather_error(ui_error_t error, const char *detail);

/* Forecast */
void ui_show_forecast(void);
void ui_set_daily(const ui_day_t *days, int count);

/* City search */
void ui_show_city_search(void);
void ui_set_city_results(const ui_city_t *cities, int count, const char *status);

/* Settings + about */
void ui_show_settings(void);
void ui_set_settings(bool fahrenheit, bool clock24, int brightness);
void ui_set_wifi_card(const char *ssid, bool connected, int rssi);
void ui_show_about(void);
void ui_set_system_info(const char *firmware, const char *ip, const char *mac,
                        uint32_t free_heap, uint32_t free_psram, uint32_t uptime_s);

#ifdef __cplusplus
}
#endif

#endif /* WEATHER_UI_H */
