# Simulator interaction log (LVGL 9.6, 320×240, RGB565, 256 KB pool)

Environment: LVGL 9.6 MCP simulator, `board=generic-320x240`,
`color_format=rgb565`, `mem_budget_kb=256`, fonts
`montserrat_10/12/14/16/20/24/48`, synthetic preview harness
(`.preview/preview.c`, not part of the firmware).

## Static render result

```json
{
  "diagnostics": [],
  "warnings": [],
  "mem": { "used_bytes": 150816, "budget_bytes": 262144, "over_budget": false },
  "issues": { "clipped": [], "overflowing": [], "offscreen": [], "hidden": ["weather_error_panel"] }
}
```

`weather_error_panel` is intentionally hidden while there is no error.

## Interaction script and observed callbacks

The UI was driven through 17 captures. The callback trace (stdout) was:

```
on_settings_changed F=1 24h=1 brightness=100
on_settings_changed F=1 24h=0 brightness=100
on_settings_changed F=1 24h=0 brightness=54
on_wifi_scan
scan finished: 5 networks
on_wifi_connect ssid=HomeNet-5G pw_len=7
connect failed: wrong password
on_wifi_retry
connect succeeded
on_wifi_continue
on_city_search query=Berlin
geocode finished: 3 matches
on_city_select city=Berlin lat=52.52 lon=13.41
on_wifi_forget
```

Representative LVGL events (t = ms):

| t | event | widget | meaning |
|---|-------|--------|---------|
| 390 | screen_loaded | forecast | Forecast nav |
| 633 | screen_loaded | weather | back |
| 876 | screen_loaded | settings | Settings nav |
| 1119 | clicked | unit_f | °F selected |
| 1212 | clicked | clock_12 | 12 h selected |
| 1505 | value_changed | brightness_slider | 54 % |
| 1798 | screen_loaded | wifi_scan | Change network |
| 2691 | screen_loaded | wifi_password | row selected |
| 3017 | value_changed ×7 | password_input | "hunter2" typed |
| 3110 | clicked | show_password | masked → visible |
| 3403 | screen_loaded | wifi_connecting | Connect |
| 4296 | screen_loaded | wifi_result | failure |
| 5096 | clicked | wifi_result_primary | Retry |
| 5987 | screen_loaded | wifi_result | success |
| 6589 | screen_loaded | splash → weather | Continue |
| 7782 | screen_loaded | city_search | Search nav |
| 8201 | clicked | city_search_btn | query "Berlin" |
| 9194 | screen_loaded | splash | city selected |
| 10680 | screen_loaded | about | About |
| 11459 | clicked | settings_forget | Forget (confirm twice) |

Every step ended on the expected screen, and the final `Settings` screen shows
`Not connected / No saved network` after Forget.

## Calibration entry point

Calibration no longer has an LVGL screen: the firmware runs the stock
TFT_eSPI `calibrateTouch()` routine from `on_calibrate(void)`. In the harness,
clicking the `settings_calibrate` button produced

```
preview: on_calibrate: stock TFT_eSPI routine
```

and returned to `Settings`, matching `run_touch_calibration()`, which redraws
the panel directly and then invalidates the active LVGL screen. Screenshot 01
shows the TFT_eSPI-drawn first corner, not an LVGL screen.

## Notes

* All named buttons and list rows are ≥ 40×40 px; the simulator raised no
  small-touch-target warnings.
* The F/12 h toggles re-rendered the weather screen as `47°` with `7:00 PM`
  style times, proving the setters reach the formatter.
* The password field was masked (`••••`) until **Show**, then displayed the
  typed text.