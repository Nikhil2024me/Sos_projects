#include <Wire.h>
#include <SPI.h>
#include <LoRa.h>
#include <U8g2lib.h>
#include <OneButton.h>

// Forward declaration for Arduino IDE auto-prototype compatibility
struct MenuState;

// Include bitmap header files
#include "bitmap1.h"  // Ambulance bitmap
#include "bitmap2.h"  // Fire engine bitmap
#include "bitmap3.h"  // Police bitmap
#include "bitmap4.h"  // Emergency service bitmap
#include "calmap.h"   // Calling bitmap

// =============================================
// DISPLAY
// =============================================
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

// =============================================
// BITMAP SCALING HELPER
// =============================================
// Scales Adafruit-style MSB-first PROGMEM bitmaps to any target size
void drawBitmapScaled(int16_t x, int16_t y, const uint8_t *bmp,
                      int16_t srcW, int16_t srcH,
                      int16_t dstW, int16_t dstH) {
  int16_t bw = (srcW + 7) / 8;
  for (int16_t j = 0; j < dstH; j++) {
    int16_t sY = (j * srcH) / dstH;
    for (int16_t i = 0; i < dstW; i++) {
      int16_t sX = (i * srcW) / dstW;
      if (pgm_read_byte(&bmp[sY * bw + sX / 8]) & (0x80 >> (sX & 7)))
        u8g2.drawPixel(x + i, y + j);
    }
  }
}

// =============================================
// HARDWARE PINS
// =============================================
#define BTN_BACK_PIN   2
#define BTN_SELECT_PIN 1
#define BTN_NEXT_PIN   3
#define BUZZER_PIN     20  // Buzzer + notification (merged)
#define RGB_LED_PIN    48  // ESP32-S3 built-in addressable RGB LED

// LoRa SX1276/SX1278 SPI pins
#define LORA_SS    5
#define LORA_RST   4
#define LORA_DIO0  2
#define LORA_FREQ  433E6   // 433 MHz (change for your region)

// RGB LED helper — only writes when color changes to avoid flicker
uint8_t ledR = 255, ledG = 255, ledB = 255; // init to impossible so first call always writes
void setLED(uint8_t r, uint8_t g, uint8_t b) {
  if (r == ledR && g == ledG && b == ledB) return; // no change
  ledR = r; ledG = g; ledB = b;
  rgbLedWrite(RGB_LED_PIN, r, g, b);
}

OneButton btnBack(BTN_BACK_PIN, true, true);    // active low, internal pullup
OneButton btnSelect(BTN_SELECT_PIN, true, true);
OneButton btnNext(BTN_NEXT_PIN, true, true);

// =============================================
// SYSTEM STATE
// =============================================
enum SystemState { SPLASH, MAIN_MENU, SOS_MENU, CONFIRM_SCREEN, CALLING_SCREEN, CONFIG_MENU };
enum Service     { AMBULANCE, FIRE_ENGINE, POLICE, EMERGENCY, NUM_SERVICES };
enum Language    { LANG_EN, LANG_HI, LANG_TA, NUM_LANGS };

SystemState currentState   = SPLASH;
SystemState prevState       = MAIN_MENU; // State to return to from config
Service     currentService  = AMBULANCE;
Language    currentLang     = LANG_EN;
uint8_t     configSelection = 0; // Selection index in config menu

unsigned long buzzerToggleTime = 0;
unsigned long systemStartTime = 0;
unsigned long callStartTime   = 0;

bool buzzerActive        = false;
bool emergencyCallActive = false;
bool loraOK              = false;  // LoRa init status
uint16_t loraPacketSeq   = 0;     // Packet sequence number

const unsigned long BUZZER_INTERVAL = 300;
const unsigned long CALL_DURATION   = 5000;

// =============================================
// MULTILINGUAL STRING TABLES
// =============================================
// Language names shown in config menu
const char* langNames[NUM_LANGS] = { "ENGLISH", "\xe0\xa4\xb9\xe0\xa4\xbf\xe0\xa4\xa8\xe0\xa5\x8d\xe0\xa4\xa6\xe0\xa5\x80", "\xe0\xae\xa4\xe0\xae\xae\xe0\xae\xbf\xe0\xae\xb4\xe0\xaf\x8d" };
// Hindi: हिन्दी  Tamil: தமிழ்

// Service names per language
const char* serviceNames[NUM_LANGS][NUM_SERVICES] = {
  { "AMBULANCE", "FIRE DEPT", "POLICE", "EMERGENCY" },                                              // EN
  { "\xe0\xa4\x8f\xe0\xa4\xae\xe0\xa5\x8d\xe0\xa4\xac\xe0\xa5\x81\xe0\xa4\xb2\xe0\xa5\x87\xe0\xa4\x82\xe0\xa4\xb8", "\xe0\xa4\xa6\xe0\xa4\xae\xe0\xa4\x95\xe0\xa4\xb2", "\xe0\xa4\xaa\xe0\xa5\x81\xe0\xa4\xb2\xe0\xa4\xbf\xe0\xa4\xb8", "\xe0\xa4\x86\xe0\xa4\xaa\xe0\xa4\xbe\xe0\xa4\xa4\xe0\xa4\x95\xe0\xa4\xbe\xe0\xa4\xb2" },  // HI
  { "\xe0\xae\x86\xe0\xae\xae\xe0\xaf\x8d\xe0\xae\xaa\xe0\xaf\x81\xe0\xae\xb2\xe0\xaf\x86\xe0\xae\xa9\xe0\xaf\x8d\xe0\xae\xb8\xe0\xaf\x8d", "\xe0\xae\xa4\xe0\xaf\x80\xe0\xae\xaf\xe0\xae\xa3\xe0\xaf\x88\xe0\xae\xaa\xe0\xaf\x8d\xe0\xae\xaa\xe0\xaf\x81", "\xe0\xae\x95\xe0\xae\xbe\xe0\xae\xb5\xe0\xae\xb2\xe0\xaf\x8d", "\xe0\xae\x85\xe0\xae\xb5\xe0\xae\xb8\xe0\xae\xb0\xe0\xae\xae\xe0\xaf\x8d" },             // TA
};
// HI: एम्बुलेंस, दमकल, पुलिस, आपातकाल
// TA: ஆம்புலென்ஸ், தீயணைப்பு, காவல், அவசரம்

// UI labels per language
const char* lblConfirm[NUM_LANGS]  = { "! CONFIRM !", "! \xe0\xa4\xaa\xe0\xa5\x81\xe0\xa4\xb7\xe0\xa5\x8d\xe0\xa4\x9f\xe0\xa4\xbf !", "! \xe0\xae\x89\xe0\xae\xb1\xe0\xaf\x81\xe0\xae\xa4\xe0\xae\xbf !" };
const char* lblCalling[NUM_LANGS]  = { "!! CALLING !!", "!! \xe0\xa4\x95\xe0\xa5\x89\xe0\xa4\xb2 !!", "!! \xe0\xae\x85\xe0\xae\xb4\xe0\xaf\x88\xe0\xae\xaa\xe0\xaf\x8d\xe0\xae\xaa\xe0\xaf\x81 !!" };
const char* lblSendSOS[NUM_LANGS]  = { "Send SOS alert?", "SOS \xe0\xa4\xad\xe0\xa5\x87\xe0\xa4\x9c\xe0\xa5\x87\xe0\xa4\x82?", "SOS \xe0\xae\x85\xe0\xae\xa9\xe0\xaf\x81\xe0\xae\xaa\xe0\xaf\x8d\xe0\xae\xaa?" };
const char* lblCancel[NUM_LANGS]   = { "[SEL] CANCEL", "[SEL] \xe0\xa4\xb0\xe0\xa4\xa6\xe0\xa5\x8d\xe0\xa4\xa6", "[SEL] \xe0\xae\xb0\xe0\xae\xa4\xe0\xaf\x8d\xe0\xae\xa4\xe0\xaf\x81" };
// HI: पुष्टि, कॉल, भेजें?, रद्द   TA: உறுதி, அழைப்பு, அனுப்ப?, ரத்து

// =============================================
// SERVICE DATA TABLE
// =============================================
struct ServiceInfo {
  const uint8_t* bitmap;
};

const ServiceInfo services[NUM_SERVICES] = {
  { (const uint8_t*)ambulanceBitmap  },
  { (const uint8_t*)fireEngineBitmap },
  { (const uint8_t*)policeBitmap     },
  { (const uint8_t*)emergencyBitmap  },
};

// Helper: get service name in current language
const char* getServiceName(uint8_t idx) {
  return serviceNames[currentLang][idx];
}

// Helper: set the right font for current language
void setLangFont() {
  switch (currentLang) {
    case LANG_HI: u8g2.setFont(u8g2_font_unifont_t_devanagari); break;
    case LANG_TA: u8g2.setFont(u8g2_font_unifont_te);              break;
    default:      u8g2.setFont(u8g2_font_7x14B_tr);             break;
  }
}
void setSmallFont() {
  u8g2.setFont(u8g2_font_5x7_tr);
}

// =============================================
// ICON MENU ANIMATION (inspired by U8g2 IconMenu example)
// =============================================
#define ICON_SIZE  32        // Scaled bitmap size per icon
#define ICON_GAP   6         // Gap between icons
#define ICON_Y     2         // Top y position of icons
#define LABEL_Y    56        // Y for the label text at bottom

// Smooth animation state
struct MenuState {
  int16_t scroll;    // Current pixel scroll offset
  int16_t target;    // Target pixel scroll offset
  uint8_t position;  // Current selection index
};

MenuState menuCurrent  = { 0, 0, 0 };
MenuState menuTarget   = { 0, 0, 0 };

// Move the scroll so the selected icon is centered
void computeScroll(MenuState *state) {
  int16_t centerX = (128 - ICON_SIZE) / 2;
  state->scroll = centerX - state->position * (ICON_SIZE + ICON_GAP);
}

// Smoothly animate current toward target (returns true if still animating)
bool animateMenu() {
  bool moving = false;
  if (menuCurrent.scroll < menuTarget.scroll) { menuCurrent.scroll += 8; moving = true; }
  else if (menuCurrent.scroll > menuTarget.scroll) { menuCurrent.scroll -= 8; moving = true; }
  // Snap if close
  if (abs(menuCurrent.scroll - menuTarget.scroll) < 9) menuCurrent.scroll = menuTarget.scroll;
  menuCurrent.position = menuTarget.position;
  return moving;
}

// =============================================
// DRAWING FUNCTIONS
// =============================================

void drawSplash() {
  u8g2.clearBuffer();
  
  // Big centered SOS circle
  u8g2.drawCircle(64, 24, 18);
  u8g2.drawCircle(64, 24, 20);
  
  u8g2.setFont(u8g2_font_logisoso16_tr);
  int w = u8g2.getStrWidth("SOS");
  u8g2.setCursor((128 - w) / 2, 16);
  u8g2.print("SOS");
  
  // Subtitle
  u8g2.setFont(u8g2_font_5x7_tr);
  w = u8g2.getStrWidth("EMERGENCY SYSTEM");
  u8g2.setCursor((128 - w) / 2, 48);
  u8g2.print("EMERGENCY SYSTEM");
  
  // Bottom line
  u8g2.drawLine(24, 58, 104, 58);
  
  u8g2.sendBuffer();
}

void drawMainMenu() {
  u8g2.clearBuffer();
  
  // Title bar
  u8g2.setFont(u8g2_font_7x14B_tr);
  int w = u8g2.getStrWidth("SOS SYSTEM");
  u8g2.setCursor((128 - w) / 2, 0);
  u8g2.print("SOS SYSTEM");
  u8g2.drawLine(0, 14, 127, 14);
  
  // Center content
  u8g2.setFont(u8g2_font_open_iconic_embedded_2x_t);
  u8g2.drawGlyph(56, 22, 72);
  
  setSmallFont();
  // Show LoRa status
  if (loraOK) {
    w = u8g2.getStrWidth("LoRa: READY");
    u8g2.setCursor((128 - w) / 2, 40);
    u8g2.print("LoRa: READY");
  } else {
    w = u8g2.getStrWidth("LoRa: OFFLINE");
    u8g2.setCursor((128 - w) / 2, 40);
    u8g2.print("LoRa: OFFLINE");
  }
  
  // Bottom hint bar
  u8g2.drawLine(0, 52, 127, 52);
  u8g2.setCursor(2, 55);
  u8g2.print("[SEL]");
  w = u8g2.getStrWidth("ENTER");
  u8g2.setCursor(128 - w - 2, 55);
  u8g2.print("ENTER");
  // Language indicator
  u8g2.setCursor(50, 55);
  u8g2.print(currentLang == LANG_EN ? "EN" : (currentLang == LANG_HI ? "HI" : "TA"));
  
  u8g2.sendBuffer();
}

void drawSOSMenu() {
  u8g2.clearBuffer();
  
  // === ROW 1: Icons (y=2 to y=33) ===
  int16_t x = menuCurrent.scroll;
  for (uint8_t i = 0; i < NUM_SERVICES; i++) {
    if (x >= -ICON_SIZE && x < 128) {
      drawBitmapScaled(x, ICON_Y, services[i].bitmap, 64, 64, ICON_SIZE, ICON_SIZE);
    }
    x += ICON_SIZE + ICON_GAP;
  }
  
  // Selection frame around currently centered icon
  int16_t frameX = menuCurrent.scroll + menuCurrent.position * (ICON_SIZE + ICON_GAP);
  u8g2.drawFrame(frameX - 2, ICON_Y - 2, ICON_SIZE + 4, ICON_SIZE + 4);
  u8g2.drawFrame(frameX - 3, ICON_Y - 3, ICON_SIZE + 6, ICON_SIZE + 6);
  
  // === ROW 2: Separator + Service Name (y=36 to y=49) ===
  u8g2.drawLine(0, 36, 127, 36);
  
  setLangFont();
  const char* svcName = getServiceName(menuCurrent.position);
  int w = u8g2.getUTF8Width(svcName);
  u8g2.setCursor((128 - w) / 2, 38);
  u8g2.drawUTF8((128 - w) / 2, 38, svcName);
  
  // === ROW 3: Page dots (y=53) ===
  // 4 dots, each 4px wide with 6px gap. Total = 4*4 + 3*6 = 34px
  // Start X = (128 - 34) / 2 = 47
  for (uint8_t i = 0; i < NUM_SERVICES; i++) {
    int16_t dotX = 47 + i * 10;
    if (i == menuCurrent.position)
      u8g2.drawBox(dotX, 53, 4, 3);
    else
      u8g2.drawFrame(dotX, 53, 4, 3);
  }
  
  // === ROW 4: Bottom hint bar (y=58 to y=63) ===
  u8g2.drawLine(0, 57, 127, 57);
  u8g2.setFont(u8g2_font_5x7_tr);
  u8g2.setCursor(2, 58);
  u8g2.print("[<]");
  
  w = u8g2.getStrWidth("[SEL]");
  u8g2.setCursor((128 - w) / 2, 58);
  u8g2.print("[SEL]");
  
  u8g2.setCursor(128 - u8g2.getStrWidth("[>]") - 2, 58);
  u8g2.print("[>]");
  
  u8g2.sendBuffer();
}

void drawConfirmScreen() {
  u8g2.clearBuffer();
  
  // Warning header (inverted)
  u8g2.setDrawColor(1);
  u8g2.drawBox(0, 0, 128, 16);
  u8g2.setDrawColor(0);
  setLangFont();
  int w = u8g2.getUTF8Width(lblConfirm[currentLang]);
  u8g2.drawUTF8((128 - w) / 2, 1, lblConfirm[currentLang]);
  u8g2.setDrawColor(1);
  
  // Service name
  setLangFont();
  const char* svcName = getServiceName(currentService);
  w = u8g2.getUTF8Width(svcName);
  u8g2.drawUTF8((128 - w) / 2, 20, svcName);
  
  // Question
  setSmallFont();
  if (currentLang == LANG_EN) {
    w = u8g2.getStrWidth(lblSendSOS[LANG_EN]);
    u8g2.setCursor((128 - w) / 2, 36);
    u8g2.print(lblSendSOS[LANG_EN]);
  } else {
    setLangFont();
    w = u8g2.getUTF8Width(lblSendSOS[currentLang]);
    u8g2.drawUTF8((128 - w) / 2, 36, lblSendSOS[currentLang]);
  }
  
  // Bottom choices
  u8g2.drawLine(0, 50, 127, 50);
  setSmallFont();
  u8g2.setCursor(8, 54);
  u8g2.print("[BCK] NO");
  w = u8g2.getStrWidth("YES [SEL]");
  u8g2.setCursor(128 - w - 8, 54);
  u8g2.print("YES [SEL]");
  
  u8g2.sendBuffer();
}

void drawCallingScreen() {
  u8g2.clearBuffer();
  
  // Alternating flash header
  static bool flashState = false;
  if (flashState) {
    u8g2.drawBox(0, 0, 128, 14);
    u8g2.setDrawColor(0);
  } else {
    u8g2.setDrawColor(1);
  }
  setLangFont();
  int w = u8g2.getUTF8Width(lblCalling[currentLang]);
  u8g2.drawUTF8((128 - w) / 2, 0, lblCalling[currentLang]);
  u8g2.setDrawColor(1);
  flashState = !flashState;
  
  // Service icon (small) + name
  drawBitmapScaled(4, 18, services[currentService].bitmap, 64, 64, 24, 24);
  
  setLangFont();
  const char* svcName = getServiceName(currentService);
  u8g2.drawUTF8(34, 22, svcName);
  
  // Progress bar
  unsigned long elapsed = millis() - callStartTime;
  int progress = map(elapsed, 0, CALL_DURATION, 0, 120);
  if (progress > 120) progress = 120;
  
  u8g2.drawFrame(3, 46, 122, 8);
  u8g2.drawBox(4, 47, progress, 6);
  
  // Bottom cancel hint
  setSmallFont();
  u8g2.drawLine(0, 56, 127, 56);
  if (currentLang == LANG_EN) {
    w = u8g2.getStrWidth(lblCancel[LANG_EN]);
    u8g2.setCursor((128 - w) / 2, 57);
    u8g2.print(lblCancel[LANG_EN]);
  } else {
    setLangFont();
    w = u8g2.getUTF8Width(lblCancel[currentLang]);
    u8g2.drawUTF8((128 - w) / 2, 57, lblCancel[currentLang]);
  }
  
  u8g2.sendBuffer();
}

// =============================================
// CONFIG MENU
// =============================================
void drawConfigMenu() {
  u8g2.clearBuffer();
  
  // Title bar (inverted)
  u8g2.drawBox(0, 0, 128, 14);
  u8g2.setDrawColor(0);
  u8g2.setFont(u8g2_font_7x14B_tr);
  int w = u8g2.getStrWidth("SETTINGS");
  u8g2.setCursor((128 - w) / 2, 1);
  u8g2.print("SETTINGS");
  u8g2.setDrawColor(1);
  
  // Language option
  setSmallFont();
  u8g2.setCursor(4, 20);
  u8g2.print("Language:");
  
  // Draw language selector with arrows
  u8g2.setFont(u8g2_font_7x14B_tr);
  // Show current language name (use English font for EN, special for others)
  if (currentLang == LANG_EN) {
    w = u8g2.getStrWidth(langNames[currentLang]);
    u8g2.setCursor((128 - w) / 2, 32);
    u8g2.print(langNames[currentLang]);
  } else {
    setLangFont();
    w = u8g2.getUTF8Width(langNames[currentLang]);
    u8g2.drawUTF8((128 - w) / 2, 32, langNames[currentLang]);
  }
  
  // Arrow indicators
  setSmallFont();
  u8g2.setCursor(4, 34);
  u8g2.print("<");
  u8g2.setCursor(120, 34);
  u8g2.print(">");
  
  // Selection frame around language area
  u8g2.drawFrame(2, 30, 124, 18);
  
  // Bottom hint bar
  u8g2.drawLine(0, 52, 127, 52);
  setSmallFont();
  u8g2.setCursor(4, 55);
  u8g2.print("[<][>] CHANGE");
  w = u8g2.getStrWidth("[SEL] OK");
  u8g2.setCursor(128 - w - 4, 55);
  u8g2.print("[SEL] OK");
  
  u8g2.sendBuffer();
}

// =============================================
// BUTTON HANDLERS
// =============================================
void handleBackPress() {
  Serial.println(F("BTN: BACK"));
  switch (currentState) {
    case MAIN_MENU:
      currentState = SOS_MENU;
      menuTarget.position = NUM_SERVICES - 1;
      computeScroll(&menuTarget);
      menuCurrent = menuTarget;
      break;
    case SOS_MENU:
      if (menuTarget.position > 0) menuTarget.position--;
      else menuTarget.position = NUM_SERVICES - 1;
      computeScroll(&menuTarget);
      break;
    case CONFIRM_SCREEN:
      currentState = SOS_MENU;
      break;
    case CALLING_SCREEN:
      emergencyCallActive = false;
      buzzerActive = false;
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(BUZZER_PIN, LOW);
      sendLoRaCancel();
      currentState = SOS_MENU;
      break;
    case CONFIG_MENU:
      // Cycle language backward
      currentLang = static_cast<Language>((currentLang + NUM_LANGS - 1) % NUM_LANGS);
      Serial.printf("Lang -> %d\n", currentLang);
      break;
    default: break;
  }
}

void handleSelectPress() {
  Serial.println(F("BTN: SELECT"));
  switch (currentState) {
    case MAIN_MENU:
      currentState = SOS_MENU;
      menuTarget.position = 0;
      computeScroll(&menuTarget);
      menuCurrent = menuTarget;
      break;
    case SOS_MENU:
      currentService = static_cast<Service>(menuTarget.position);
      currentState = CONFIRM_SCREEN;
      // Long warning buzz on confirm screen
      digitalWrite(BUZZER_PIN, HIGH);
      delay(500);
      digitalWrite(BUZZER_PIN, LOW);
      break;
    case CONFIRM_SCREEN:
      currentState = CALLING_SCREEN;
      emergencyCallActive = true;
      callStartTime = millis();
      digitalWrite(BUZZER_PIN, HIGH);
      buzzerActive = true;
      buzzerToggleTime = millis();
      sendSOSPacket(); // Initial LoRa transmission
      break;
    case CALLING_SCREEN:
      emergencyCallActive = false;
      buzzerActive = false;
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(BUZZER_PIN, LOW);
      sendLoRaCancel(); // Notify receiver of cancellation
      currentState = SOS_MENU;
      break;
    case CONFIG_MENU:
      // Confirm and return to previous state
      Serial.printf("Language set to %d\n", currentLang);
      currentState = prevState;
      break;
    default: break;
  }
}

void handleSelectLongPress() {
  Serial.println(F("BTN: SELECT LONG"));
  // Only open config from non-emergency states
  if (currentState == MAIN_MENU || currentState == SOS_MENU) {
    prevState = currentState;
    currentState = CONFIG_MENU;
    setLED(80, 0, 80); // Purple for config
  }
}

void handleNextPress() {
  Serial.println(F("BTN: NEXT"));
  switch (currentState) {
    case MAIN_MENU:
      currentState = SOS_MENU;
      menuTarget.position = 0;
      computeScroll(&menuTarget);
      menuCurrent = menuTarget;
      break;
    case SOS_MENU:
      if (menuTarget.position < NUM_SERVICES - 1) menuTarget.position++;
      else menuTarget.position = 0;
      computeScroll(&menuTarget);
      break;
    case CONFIG_MENU:
      // Cycle language forward
      currentLang = static_cast<Language>((currentLang + 1) % NUM_LANGS);
      Serial.printf("Lang -> %d\n", currentLang);
      break;
    default: break;
  }
}

// =============================================
// LORA FUNCTIONS
// =============================================
void initLoRa() {
  LoRa.setPins(LORA_SS, LORA_RST, LORA_DIO0);
  if (LoRa.begin(LORA_FREQ)) {
    LoRa.setTxPower(20);        // Max power for long range
    LoRa.setSpreadingFactor(12); // SF12 = max range
    LoRa.setSignalBandwidth(125E3);
    LoRa.setCodingRate4(8);      // 4/8 = max error correction
    LoRa.enableCrc();
    loraOK = true;
    Serial.println(F("LoRa: INIT OK"));
  } else {
    loraOK = false;
    Serial.println(F("LoRa: INIT FAILED"));
  }
}

void sendSOSPacket() {
  if (!loraOK) return;
  
  loraPacketSeq++;
  const char* svcEN = serviceNames[LANG_EN][currentService]; // Always send in English
  
  LoRa.beginPacket();
  LoRa.print("SOS|");
  LoRa.print(svcEN);
  LoRa.print("|DEV01|");
  LoRa.print(loraPacketSeq);
  LoRa.endPacket(true); // async (non-blocking)
  
  Serial.printf("LoRa TX: SOS|%s|DEV01|%d\n", svcEN, loraPacketSeq);
}

void sendLoRaCancel() {
  if (!loraOK) return;
  
  loraPacketSeq++;
  LoRa.beginPacket();
  LoRa.print("SOS_CANCEL|DEV01|");
  LoRa.print(loraPacketSeq);
  LoRa.endPacket(true);
  
  Serial.printf("LoRa TX: SOS_CANCEL|DEV01|%d\n", loraPacketSeq);
}

void sendLoRaEnd() {
  if (!loraOK) return;
  
  loraPacketSeq++;
  LoRa.beginPacket();
  LoRa.print("SOS_END|DEV01|");
  LoRa.print(loraPacketSeq);
  LoRa.endPacket(true);
  
  Serial.printf("LoRa TX: SOS_END|DEV01|%d\n", loraPacketSeq);
}

// =============================================
// BUZZER + RGB LED
// =============================================
void ToggleBuzzer() {
  static bool state = false;
  state = !state;
  digitalWrite(BUZZER_PIN, state ? HIGH : LOW);
  
  // Flash RGB LED red during emergency
  if (state) {
    setLED(255, 0, 0);
    // Re-transmit SOS on every buzzer ON cycle for redundancy
    sendSOSPacket();
  } else {
    setLED(0, 0, 0);
  }
}

// =============================================
// SETUP
// =============================================
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println(F("\n=== SOS System v2.0 ==="));
  systemStartTime = millis();
  
  u8g2.begin();
  u8g2.setFontPosTop();
  u8g2.setFontMode(1);
  u8g2.enableUTF8Print(); // Enable UTF-8 for Hindi/Tamil
  
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  
  // Initialize LoRa
  initLoRa();
  
  btnBack.setDebounceMs(40);
  btnBack.setClickMs(200);
  btnBack.attachClick(handleBackPress);
  
  btnSelect.setDebounceMs(40);
  btnSelect.setClickMs(200);
  btnSelect.attachClick(handleSelectPress);
  btnSelect.attachLongPressStart(handleSelectLongPress);
  
  btnNext.setDebounceMs(40);
  btnNext.setClickMs(200);
  btnNext.attachClick(handleNextPress);
  
  // RGB LED startup flash
  setLED(0, 0, 80);    // Blue boot indicator
  
  // Boot buzzer beep
  digitalWrite(BUZZER_PIN, HIGH);
  delay(100);
  digitalWrite(BUZZER_PIN, LOW);
  
  // Splash screen
  currentState = SPLASH;
  drawSplash();
  delay(2000);
  
  currentState = MAIN_MENU;
  drawMainMenu();
  setLED(0, 40, 0);    // Dim green = system ready
  
  Serial.println(F("System Ready."));
}

// =============================================
// LOOP
// =============================================
void loop() {
  btnBack.tick();
  btnSelect.tick();
  btnNext.tick();
  
  // Buzzer toggle
  if (buzzerActive && (millis() - buzzerToggleTime >= BUZZER_INTERVAL)) {
    ToggleBuzzer();
    buzzerToggleTime = millis();
  }
  
  // Emergency timeout
  if (emergencyCallActive && callStartTime > 0) {
    if (millis() - callStartTime >= CALL_DURATION) {
      callStartTime = 0;
      emergencyCallActive = false;
      buzzerActive = false;
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(BUZZER_PIN, LOW);
      sendLoRaEnd(); // Notify receiver call ended
      setLED(0, 40, 0);  // Back to green
      currentState = SOS_MENU;
    }
  }
  
  // Update RGB LED based on state (non-emergency)
  if (!emergencyCallActive) {
    switch (currentState) {
      case MAIN_MENU:      setLED(0, 40, 0);   break;  // Green
      case SOS_MENU:       setLED(0, 0, 60);   break;  // Blue
      case CONFIRM_SCREEN: setLED(80, 50, 0);  break;  // Amber
      case CONFIG_MENU:    setLED(80, 0, 80);  break;  // Purple
      default: break;
    }
  }
  
  // Redraw based on state
  switch (currentState) {
    case MAIN_MENU:
      drawMainMenu();
      break;
    case SOS_MENU:
      animateMenu();
      drawSOSMenu();
      break;
    case CONFIRM_SCREEN:
      drawConfirmScreen();
      break;
    case CALLING_SCREEN:
      drawCallingScreen();
      break;
    case CONFIG_MENU:
      drawConfigMenu();
      break;
    default:
      break;
  }
  
  delay(10);  // ~100fps for responsive buttons
}
