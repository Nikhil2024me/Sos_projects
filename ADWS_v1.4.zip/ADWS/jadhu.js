/*
 * Jadhu — ADWS Intelligent Disaster Assistant (Beta)
 * ---------------------------------------------------
 * An AI assistant that knows everything about the ADWS disaster warning system:
 * - 30 tribal-majority districts + 526 monitored cities
 * - 7 hazard alarms (fire, rain, wind, heat, quake, landslide, tsunami) + Ambee AQI + NASA GPM rain
 * - Offline LoRa village broadcasts (ESP32, SX1276, AS3/AS4 packet formats)
 * - Emergency helplines (112, 1078, 108, 101, 100)
 * - Site controls: language switching (18 languages), satellite/street map layers,
 *   disaster filtering, district selection, live refresh, and navigation.
 *
 * Integrates with Google Gemini Free API (Gemini 1.5/2.0 Flash) with an instant
 * local intelligent fallback engine that works 100% offline or keyless.
 */
(function (root) {
  "use strict";

  var JADHU_STORAGE_KEY = "adws_jadhu_gemini_key";
  var JADHU_HISTORY_KEY = "adws_jadhu_history_v1";

  var KNOWLEDGE = {
    appName: "ADWS (Advanced Disaster Warning System / Adivasi Suraksha)",
    version: "1.0.0 (Beta)",
    purpose: "Real-time multi-hazard surveillance and early warning platform designed primarily for 30 high-tribal-population districts across India, with supplementary coverage for 526 major cities.",
    helplines: [
      { name: "National Emergency Helpline", number: "112", desc: "Unified emergency service (Police, Fire, Ambulance)" },
      { name: "NDMA Disaster Management", number: "1078", desc: "National disaster helpline" },
      { name: "Medical Ambulance", number: "108", desc: "Emergency medical transport" },
      { name: "Fire Service", number: "101", desc: "Fire emergencies" },
      { name: "Police", number: "100", desc: "Police assistance" },
      { name: "Women Helpline", number: "1091", desc: "Women in distress" },
      { name: "State Disaster Management", number: "1070", desc: "State-level emergency operations" }
    ],
    hazards: {
      fire: "Monitored via NASA FIRMS (VIIRS 375m & MODIS 1km) thermal anomalies within 40 km of district centers.",
      rain: "Monitored via Open-Meteo 4-day forecast: Watch (40mm), Warning (80mm), Severe (120mm). Supplementary observed rain via NASA GPM IMERG.",
      heat: "Max temperature thresholds: Plains (Watch 40°C, Warning 43°C, Severe 46°C); Hills (Watch 30°C, Warning 33°C, Severe 36°C).",
      wind: "Sustained wind speeds: Watch (50 km/h), Warning (70 km/h), Severe (90 km/h).",
      quake: "USGS FDSN M4+ events in rolling 7 days: Watch (M5.0+ within 300km), Warning (M5.5+ within 300km), Severe (M6.5+ within 600km), Local small (M4.5+ within 150km).",
      landslide: "Rainfall-induced landslide hazard in steep terrain (elevation >= 600m combined with heavy rainfall >= 40mm).",
      tsunami: "High-magnitude offshore earthquake (M7.0+ within 400-1000km) in coastal/low-elevation areas (<= 250m).",
      air: "Real-time AQI and PM2.5/PM10 from Ambee API mapped to US EPA standards (Watch 101, Warning 151, Severe 201). Informational only."
    },
    lora: {
      purpose: "Transmits compact disaster codes over 433/868/915 MHz LoRa radio to village receivers with siren and LED indicators when cellular networks fail.",
      formats: "AS3,DD,OV,FRWHQLT,DDHHMM (7 hazards) or AS4,DD,OV,FRWHQLTA,DDHHMM (with air quality digit).",
      hardware: "ESP32 microcontrollers paired with Semtech SX1276/SX1278 transceivers, powered by solar + 18650 Li-ion battery."
    },
    apis: {
      firms: "NASA FIRMS (Fire Information for Resource Management System) — permanent free key.",
      bhuvan: "ISRO Bhuvan Shortest Path Routing API — token expires every 24 hours (1-day renewal required).",
      openmeteo: "Open-Meteo Weather API — open public service, no key needed.",
      usgs: "USGS FDSN Earthquake API — open GeoJSON service, no key needed.",
      ambee: "Ambee Air Quality API — trial evaluation key with 80-call daily guard.",
      gpm: "NASA GPM IMERG Early Run Precipitation — NASA Earthdata bearer token.",
      hazards: "GDACS RSS, NASA EONET v3, ReliefWeb v2 for regional situational awareness."
    },
    languages: [
      { code: "en", name: "English" },
      { code: "hi", name: "Hindi" },
      { code: "bn", name: "Bengali" },
      { code: "mr", name: "Marathi" },
      { code: "or", name: "Odia" },
      { code: "te", name: "Telugu" },
      { code: "ta", name: "Tamil" },
      { code: "gu", name: "Gujarati" },
      { code: "kn", name: "Kannada" },
      { code: "ml", name: "Malayalam" },
      { code: "as", name: "Assamese" },
      { code: "pa", name: "Punjabi" },
      { code: "sat", name: "Santali (Ol Chiki)" },
      { code: "gon", name: "Gondi (Devanagari)" },
      { code: "bhi", name: "Bhili (Devanagari)" },
      { code: "trp", name: "Kokborok (Tripura)" },
      { code: "lus", name: "Mizo (Mizoram)" },
      { code: "kha", name: "Khasi (Meghalaya)" }
    ]
  };

  function getApiKey() {
    try {
      return (window.localStorage.getItem(JADHU_STORAGE_KEY) || "").trim();
    } catch (e) {
      return "";
    }
  }

  function setApiKey(key) {
    try {
      if (key) {
        window.localStorage.setItem(JADHU_STORAGE_KEY, key.trim());
      } else {
        window.localStorage.removeItem(JADHU_STORAGE_KEY);
      }
    } catch (e) {}
  }

  /* -------------------------------------------------------------
   * Settings & Site Control Executor
   * ------------------------------------------------------------- */
  function executeSiteAction(action, value) {
    var ctrl = window.ADWS_CONTROL;
    if (!ctrl) return { success: false, message: "ADWS control system not yet initialized." };

    switch (action) {
      case "setLanguage":
        var lang = String(value).toLowerCase().trim();
        ctrl.setLanguage(lang);
        return { success: true, message: "Switched website language to " + lang.toUpperCase() + "." };

      case "setBaseLayer":
        var layer = value === "satellite" ? "satellite" : "street";
        ctrl.setBaseLayer(layer);
        return { success: true, message: "Map basemap set to " + (layer === "satellite" ? "Satellite Imagery" : "Street Map") + "." };

      case "selectRegion":
        ctrl.selectRegion(value, "card");
        var el = document.getElementById("detailPanel") || document.getElementById("map");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
        return { success: true, message: "Selected region: " + value + "." };

      case "setMapDisaster":
        var dis = String(value).toLowerCase().trim();
        ctrl.setMapDisaster(dis);
        return { success: true, message: "Filtered map disaster view to: " + dis + "." };

      case "refresh":
        ctrl.refresh();
        return { success: true, message: "Refreshing all live feeds and disaster data." };

      case "navigate":
        var target = document.querySelector(value);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          return { success: true, message: "Navigated to " + value + "." };
        }
        return { success: false, message: "Section " + value + " not found." };

      case "toggleGoogleTranslate":
        var gt = document.getElementById("google_translate_element");
        if (gt) {
          var isHidden = gt.style.display === "none" || !gt.style.display;
          gt.style.display = isHidden ? "block" : "none";
          return { success: true, message: isHidden ? "Opened Google Translate widget." : "Closed Google Translate widget." };
        }
        return { success: false, message: "Google translate widget not available." };

      default:
        return { success: false, message: "Unknown action: " + action };
    }
  }

  /* -------------------------------------------------------------
   * Intent Parsing for Settings & Site Actions
   * ------------------------------------------------------------- */
  function detectActionIntent(query) {
    var q = query.toLowerCase().trim();

    // Map layer actions
    if (/satellite\s*(view|map|layer|mode)?|switch\s*to\s*satellite/i.test(q)) {
      return { action: "setBaseLayer", value: "satellite", desc: "Switch map to Satellite view" };
    }
    if (/street\s*(view|map|layer|mode)?|normal\s*map|standard\s*map/i.test(q)) {
      return { action: "setBaseLayer", value: "street", desc: "Switch map to Street view" };
    }

    // Refresh action
    if (/^(refresh|reload|update|fetch)(\s*(live|data|alerts|feeds))?$/i.test(q) || /refresh\s*data/i.test(q)) {
      return { action: "refresh", value: true, desc: "Refresh live data" };
    }

    // Language actions
    var langMatch = q.match(/(?:change|switch|set)\s*(?:the\s*)?(?:language|lang)\s*(?:to\s*)?([a-z\s]+)/i) ||
                    q.match(/(?:in|to)\s*(hindi|english|bengali|marathi|odia|telugu|tamil|gujarati|kannada|malayalam|assamese|punjabi|santali|gondi|bhili|kokborok|mizo|khasi)/i);
    if (langMatch) {
      var name = langMatch[1].trim();
      var langMap = {
        "english": "en", "en": "en",
        "hindi": "hi", "hi": "hi",
        "bengali": "bn", "bangla": "bn", "bn": "bn",
        "marathi": "mr", "mr": "mr",
        "odia": "or", "oriya": "or", "or": "or",
        "telugu": "te", "te": "te",
        "tamil": "ta", "ta": "ta",
        "gujarati": "gu", "gu": "gu",
        "kannada": "kn", "kn": "kn",
        "malayalam": "ml", "ml": "ml",
        "assamese": "as", "as": "as",
        "punjabi": "pa", "pa": "pa",
        "santali": "sat", "sat": "sat",
        "gondi": "gon", "gon": "gon",
        "bhili": "bhi", "bhi": "bhi",
        "kokborok": "trp", "trp": "trp",
        "mizo": "lus", "lus": "lus",
        "khasi": "kha", "kha": "kha"
      };
      if (langMap[name]) {
        return { action: "setLanguage", value: langMap[name], desc: "Change language to " + name };
      }
    }

    // Disaster filter actions
    if (/show\s*fires?|filter\s*fires?|wildfires?/i.test(q)) {
      return { action: "setMapDisaster", value: "fire", desc: "Filter map for Fire alerts" };
    }
    if (/show\s*rain|filter\s*rain|floods?/i.test(q)) {
      return { action: "setMapDisaster", value: "rain", desc: "Filter map for Rain alerts" };
    }
    if (/show\s*quakes?|earthquakes?|filter\s*quakes?/i.test(q)) {
      return { action: "setMapDisaster", value: "quake", desc: "Filter map for Earthquakes" };
    }
    if (/show\s*wind|extreme\s*wind|cyclones?/i.test(q)) {
      return { action: "setMapDisaster", value: "wind", desc: "Filter map for High Winds" };
    }
    if (/show\s*heat|heatwaves?/i.test(q)) {
      return { action: "setMapDisaster", value: "heat", desc: "Filter map for Heatwaves" };
    }
    if (/show\s*all\s*disasters|all\s*hazards|reset\s*filter/i.test(q)) {
      return { action: "setMapDisaster", value: "all", desc: "Show all disasters on map" };
    }

    // Navigation actions
    if (/go\s*to\s*map|show\s*map/i.test(q)) {
      return { action: "navigate", value: "#map", desc: "Scroll to Live Map" };
    }
    if (/go\s*to\s*routing|evacuation|shortest\s*path|bhuvan/i.test(q)) {
      return { action: "navigate", value: "#routing", desc: "Scroll to Evacuation Route Planner" };
    }
    if (/show\s*cities|view\s*cities/i.test(q)) {
      return { action: "navigate", value: "#cities", desc: "Scroll to Cities Monitor" };
    }
    if (/show\s*districts|tribal\s*districts/i.test(q)) {
      return { action: "navigate", value: "#districts", desc: "Scroll to 30 Tribal Districts" };
    }
    if (/open\s*translate|google\s*translate/i.test(q)) {
      return { action: "toggleGoogleTranslate", value: true, desc: "Toggle Google Translate Widget" };
    }

    // District / City selection
    var ctrl = window.ADWS_CONTROL;
    if (ctrl && ctrl.getConfig) {
      var config = ctrl.getConfig();
      if (config && config.places) {
        for (var i = 0; i < config.places.length; i++) {
          var p = config.places[i];
          var enName = (p.name && p.name.en ? p.name.en : p.id).toLowerCase();
          var hiName = (p.name && p.name.hi ? p.name.hi : "");
          var regex = new RegExp("\\b(?:show|select|check|inspect|open|go to)\\s+" + p.id + "\\b", "i");
          var nameRegex = new RegExp("\\b(?:show|select|check|inspect|open|go to)\\s+" + enName + "\\b", "i");
          if (regex.test(q) || nameRegex.test(q) || (hiName && q.indexOf(hiName) !== -1)) {
            return { action: "selectRegion", value: p.id, desc: "Select " + (p.name.en || p.id) };
          }
        }
      }
    }

    return null;
  }

  /* -------------------------------------------------------------
   * Real-time State & Live Stats Summarizer
   * ------------------------------------------------------------- */
  function getLiveStateContext() {
    var ctrl = window.ADWS_CONTROL;
    if (!ctrl || !ctrl.getState) return "Live state loading...";
    var state = ctrl.getState();
    var firesCount = state.fires ? state.fires.length : 0;
    var quakesCount = state.quakes ? state.quakes.length : 0;
    var selected = state.selectedId || "bastar";
    var lang = state.lang || "en";
    var baseLayer = state.baseLayer || "street";

    var topRisk = "None";
    if (state.snapshot) {
      var keys = Object.keys(state.snapshot);
      var highestSev = -1;
      keys.forEach(function (k) {
        var snap = state.snapshot[k];
        if (snap && snap.severity > highestSev) {
          highestSev = snap.severity;
          topRisk = (snap.name && snap.name.en ? snap.name.en : k) + " (Level " + highestSev + ")";
        }
      });
    }

    return {
      firesCount: firesCount,
      quakesCount: quakesCount,
      selectedId: selected,
      lang: lang,
      baseLayer: baseLayer,
      topRisk: topRisk,
      disasterFilter: state.mapDisaster || "all"
    };
  }

  /* -------------------------------------------------------------
   * Instant Local Intelligence Engine (Fallback / Offline)
   * ------------------------------------------------------------- */
  function generateLocalResponse(query) {
    var q = query.toLowerCase().trim();
    var live = getLiveStateContext();

    // Check if there is an explicit settings action
    var intent = detectActionIntent(query);
    var actionNote = "";
    if (intent) {
      var res = executeSiteAction(intent.action, intent.value);
      actionNote = "\n\n⚡ **Action Applied:** " + res.message;
    }

    // 1. Live status questions
    if (/active\s*disasters?|what\s*(is|are)\s*(happening|active|detected)|status|live\s*summary/i.test(q)) {
      return "📊 **Current ADWS Live Status:**\n\n" +
        "• **Satellite Fire Detections:** " + live.firesCount + " active thermal anomalies (NASA FIRMS)\n" +
        "• **Earthquakes (Past 7 Days):** " + live.quakesCount + " M4+ events recorded (USGS FDSN)\n" +
        "• **Highest Alert Region:** " + live.topRisk + "\n" +
        "• **Active Basemap:** " + (live.baseLayer === "satellite" ? "Satellite Imagery" : "Street Basemap") + "\n" +
        "• **Current Language:** " + live.lang.toUpperCase() + "\n" +
        "• **Monitored Areas:** 30 high-tribal districts + 526 major Indian cities.\n\n" +
        "Would you like me to focus on a particular district or switch to satellite view?" + actionNote;
    }

    // 2. Fire questions
    if (/fire|thermal|modis|viirs|nasa firms/i.test(q)) {
      return "🔥 **Fire & Thermal Anomaly Monitoring:**\n\n" +
        "ADWS tracks wildfires and agricultural burns using NASA FIRMS satellites:\n" +
        "• **Sensors:** VIIRS (NOAA-20 & Suomi NPP at 375m resolution) and MODIS (Terra & Aqua at 1km).\n" +
        "• **Coverage Radius:** 40 km radius around each district headquarters.\n" +
        "• **Thresholds:** Watch (1+ fires), Warning (5+ fires), Severe (12+ fires).\n" +
        "• **Current Live Fires:** " + live.firesCount + " spots detected across India right now." + actionNote;
    }

    // 3. Earthquake questions
    if (/earthquake|quake|tremor|richter|usgs/i.test(q)) {
      return "🌍 **Earthquake Hazard System:**\n\n" +
        "ADWS streams live earthquake data directly from the USGS FDSN API:\n" +
        "• **Filter:** M4.0+ events within India and surrounding South Asia (6°N–37°N, 68°E–98°E).\n" +
        "• **Alarms:** M5.0+ (Watch within 300km), M5.5+ (Warning within 300km), M6.5+ (Severe within 600km).\n" +
        "• **Local Proximity Watch:** M4.5+ within 150 km of any monitored place.\n" +
        "• **Active Quakes:** " + live.quakesCount + " events logged in the rolling 7-day window." + actionNote;
    }

    // 4. LoRa & Offline broadcasts
    if (/lora|offline|radio|packet|esp32|village|hardware/i.test(q)) {
      return "📡 **LoRa Village Warning & Hardware Architecture:**\n\n" +
        "When cellular networks collapse during cyclones or floods, ADWS broadcasts over off-grid LoRa radio:\n" +
        "• **Frequencies:** 433 MHz, 868 MHz, or 915 MHz (Semtech SX1276/SX1278 transceiver).\n" +
        "• **Gateways:** ESP32 solar-powered microcontrollers in remote tribal villages.\n" +
        "• **Packet Format:** `" + KNOWLEDGE.lora.formats + "`\n" +
        "• **Coverage:** Exclusively covers the 30 tribal districts (indexes 01–30) to preserve emergency bandwidth.\n" +
        "• **Local Alerts:** Village receivers sound sirens and activate LED severity indicators (Green=Safe, Yellow=Watch, Orange=Warning, Red=Severe)." + actionNote;
    }

    // 5. Emergency helplines
    if (/helpline|emergency|phone|call|police|ambulance|hospital|112|contact/i.test(q)) {
      var lines = KNOWLEDGE.helplines.map(function (h) {
        return "• **" + h.number + "** — " + h.name + " (" + h.desc + ")";
      }).join("\n");
      return "🚨 **Emergency Helplines (24x7 India):**\n\n" + lines + "\n\nAll numbers are toll-free and accessible from any landline or mobile." + actionNote;
    }

    // 6. Language support
    if (/language|tribal language|languages|translate|santali|gondi|bhili|kokborok|mizo|khasi/i.test(q)) {
      var langNames = KNOWLEDGE.languages.map(function (l) { return l.name + " (`" + l.code + "`)"; }).join(", ");
      return "🌐 **Multilingual & Tribal Language Support:**\n\n" +
        "ADWS supports 18 native languages built into the client, including 6 tribal languages:\n" +
        langNames + ".\n\n" +
        "• In addition, Google Translate is embedded for over 130+ world languages!\n" +
        "• You can ask me anytime: *'Switch to Hindi'*, *'Change language to Santali'*, or *'Switch to English'*." + actionNote;
    }

    // 7. ISRO Bhuvan & Routing
    if (/bhuvan|route|routing|evacuation|shortest path|isro/i.test(q)) {
      return "🗺️ **ISRO Bhuvan Shortest Path Evacuation:**\n\n" +
        "ADWS uses ISRO's NRSC Bhuvan road network API to calculate the safest and shortest route from your live coordinates to district headquarters or relief shelters.\n" +
        "• ⚠️ **Note:** The Bhuvan API token expires every 24 hours (1-day validity) and requires same-state routing." + actionNote;
    }

    // 8. General ADWS summary or settings command
    if (intent) {
      return "✓ **Done!** I have executed your request:\n" + actionNote + "\n\nCan I help you with anything else on ADWS?";
    }

    return "Hello! I am **Jadhu**, your ADWS AI Assistant.\n\n" +
      "I know everything about this disaster monitoring platform:\n" +
      "• **7 Hazard Alarms:** Fire (NASA FIRMS), Rain & Heat (Open-Meteo), Quakes (USGS), Landslides, Tsunamis, and Air Quality (Ambee).\n" +
      "• **Locations:** 30 high-tribal districts + 526 Indian cities.\n" +
      "• **Offline Resilience:** ESP32 LoRa radio broadcasts (`AS3`/`AS4` packets).\n" +
      "• **18 Languages:** Including Santali, Gondi, Bhili, Kokborok, Mizo, and Khasi.\n\n" +
      "You can ask me questions or command site settings like:\n" +
      "👉 *'Switch to Satellite view'*\n" +
      "👉 *'Change language to Hindi'*\n" +
      "👉 *'Show Bastar district'*\n" +
      "👉 *'What disasters are active right now?'*\n\n" +
      "*(Tip: Click ⚙️ to add your free Google Gemini API key for open conversational intelligence!)*";
  }

  /* -------------------------------------------------------------
   * Gemini API Integration (Free Tier)
   * ------------------------------------------------------------- */
  async function queryGemini(promptText, history) {
    var apiKey = getApiKey();
    var live = getLiveStateContext();

    var systemInstructionText =
      "You are Jadhu, the intelligent disaster management assistant for ADWS (Advanced Disaster Warning System / Adivasi Suraksha).\n" +
      "ADWS monitors real-time natural hazards for 30 high-tribal districts and 526 cities across India.\n" +
      "Hazards tracked: NASA FIRMS (wildfires, 40km radius), Open-Meteo (rain forecast, extreme heat, wind), USGS (earthquakes M4+), Landslides (hills >600m + rain), Tsunamis (<250m elevation + offshore M7+ quake), Ambee AQI, NASA GPM rain, ISRO Bhuvan evacuation routes, and off-grid LoRa village radio broadcasts (ESP32, AS3/AS4 packets).\n" +
      "Languages supported: 18 (English, Hindi, Bengali, Marathi, Odia, Telugu, Tamil, Gujarati, Kannada, Malayalam, Assamese, Punjabi, and tribal languages: Santali, Gondi, Bhili, Kokborok, Mizo, Khasi) + Google Translate.\n" +
      "Current Live State: " + JSON.stringify(live) + ".\n" +
      "Capabilities: You can control site settings. If the user asks to switch language, toggle satellite/street view, select a district/city, filter map disasters, or refresh data, include an action block at the very end of your response in this exact format:\n" +
      "```action\n{\"action\": \"setLanguage\"|\"setBaseLayer\"|\"selectRegion\"|\"setMapDisaster\"|\"refresh\"|\"navigate\", \"value\": \"...\"}\n```\n" +
      "Keep answers helpful, accurate, and concise. Be courteous and protective of citizen safety. Emergency numbers: 112 (National), 1078 (Disaster), 108 (Ambulance), 101 (Fire).";

    // 1. First attempt: If running through local Node server (/api/jadhu)
    try {
      var serverRes = await fetch("/api/jadhu", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-gemini-key": apiKey },
        body: JSON.stringify({
          prompt: promptText,
          geminiKey: apiKey,
          systemInstruction: { parts: [{ text: systemInstructionText }] },
          contents: [
            { role: "user", parts: [{ text: promptText }] }
          ]
        })
      });
      if (serverRes.ok) {
        var resData = await serverRes.json();
        if (resData.status === "success" && resData.data) {
          var cand = resData.data.candidates && resData.data.candidates[0];
          if (cand && cand.content && cand.content.parts && cand.content.parts[0]) {
            return cand.content.parts[0].text;
          }
        }
      }
    } catch (e) {
      // Server not reachable or static-only deployment, continue to direct client call
    }

    // 2. Second attempt: Direct client-side call to Google Gemini free API if user provided key
    if (apiKey) {
      try {
        var directUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + encodeURIComponent(apiKey);
        var directRes = await fetch(directUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                role: "user",
                parts: [{ text: systemInstructionText + "\n\nUser Question: " + promptText }]
              }
            ],
            generationConfig: {
              temperature: 0.4,
              maxOutputTokens: 800
            }
          })
        });

        if (directRes.ok) {
          var dData = await directRes.json();
          var directCand = dData.candidates && dData.candidates[0];
          if (directCand && directCand.content && directCand.content.parts && directCand.content.parts[0]) {
            return directCand.content.parts[0].text;
          }
        }
      } catch (err) {
        console.warn("Direct Gemini call error, falling back to local engine:", err);
      }
    }

    // 3. Fallback to instant local intelligence engine
    return generateLocalResponse(promptText);
  }

  /* -------------------------------------------------------------
   * UI & Modal Creation
   * ------------------------------------------------------------- */
  function injectJadhuUI() {
    if (document.getElementById("jadhuContainer")) return;

    // 1. Star Trigger Button (bottom-right)
    var triggerBtn = document.createElement("button");
    triggerBtn.id = "jadhuTrigger";
    triggerBtn.className = "jadhu-star-btn";
    triggerBtn.setAttribute("type", "button");
    triggerBtn.setAttribute("aria-label", "Open Jadhu AI Assistant (Beta)");
    triggerBtn.setAttribute("title", "Jadhu — ADWS AI Assistant (Beta)");
    triggerBtn.innerHTML =
      '<span class="jadhu-star-glow"></span>' +
      '<span class="jadhu-star-icon">★</span>' +
      '<span class="jadhu-star-badge">Jadhu</span>';

    // 2. Jadhu Modal / Drawer Panel
    var container = document.createElement("div");
    container.id = "jadhuContainer";
    container.className = "jadhu-modal-container";
    container.setAttribute("aria-hidden", "true");
    container.innerHTML =
      '<div class="jadhu-modal" role="dialog" aria-labelledby="jadhuTitle">' +
      '  <div class="jadhu-header">' +
      '    <div class="jadhu-header-info">' +
      '      <span class="jadhu-header-star">★</span>' +
      '      <div>' +
      '        <h3 id="jadhuTitle" class="jadhu-title">Jadhu <span class="jadhu-pill">AI Beta</span></h3>' +
      '        <p class="jadhu-subtitle">ADWS Disaster Intelligence & Control</p>' +
      '      </div>' +
      '    </div>' +
      '    <div class="jadhu-header-actions">' +
      '      <button type="button" class="jadhu-icon-btn" id="jadhuSettingsBtn" title="Gemini API Key Settings" aria-label="API Settings">⚙️</button>' +
      '      <button type="button" class="jadhu-icon-btn" id="jadhuClearBtn" title="Clear Conversation" aria-label="Clear chat">🗑️</button>' +
      '      <button type="button" class="jadhu-icon-btn jadhu-close-btn" id="jadhuCloseBtn" title="Close Jadhu" aria-label="Close">✕</button>' +
      '    </div>' +
      '  </div>' +

      // Settings dropdown drawer
      '  <div class="jadhu-settings-drawer" id="jadhuSettingsDrawer" hidden>' +
      '    <div class="jadhu-settings-box">' +
      '      <label for="jadhuApiKeyInput" class="jadhu-settings-label">Google Gemini API Key (Free Tier):</label>' +
      '      <div class="jadhu-settings-row">' +
      '        <input type="password" id="jadhuApiKeyInput" class="jadhu-input" placeholder="AIzaSy... (leave empty for instant engine)" />' +
      '        <button type="button" class="btn btn-small" id="jadhuSaveKeyBtn">Save</button>' +
      '      </div>' +
      '      <p class="jadhu-settings-hint">Get a free Gemini key at <a href="https://aistudio.google.com/" target="_blank" rel="noopener">Google AI Studio</a>. Jadhu works with or without a key!</p>' +
      '    </div>' +
      '  </div>' +

      // Chat Messages List
      '  <div class="jadhu-body" id="jadhuMessages" role="log" aria-live="polite"></div>' +

      // Suggestion quick chips
      '  <div class="jadhu-chips" id="jadhuChips">' +
      '    <button type="button" class="jadhu-chip" data-prompt="What disasters are active right now?">⚡ Active Disasters</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="Switch map to Satellite view">🛰️ Satellite Map</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="Change website language to Hindi">🌐 Hindi</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="Show Bastar district details">📍 Bastar</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="How does LoRa village warning work?">📡 LoRa Broadcast</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="What are the emergency helpline numbers?">🚨 Helplines</button>' +
      '  </div>' +

      // Input Form
      '  <form class="jadhu-footer" id="jadhuForm">' +
      '    <input type="text" id="jadhuInput" class="jadhu-text-input" placeholder="Ask Jadhu or say \'switch to satellite\'..." autocomplete="off" />' +
      '    <button type="button" class="jadhu-mic-btn" id="jadhuMicBtn" title="Voice Input" aria-label="Voice input">🎙️</button>' +
      '    <button type="submit" class="jadhu-send-btn" id="jadhuSendBtn" aria-label="Send message">➤</button>' +
      '  </form>' +
      '</div>';

    document.body.appendChild(triggerBtn);
    document.body.appendChild(container);

    attachJadhuEvents();
    renderWelcomeMessage();
  }

  function renderWelcomeMessage() {
    var messagesEl = document.getElementById("jadhuMessages");
    if (!messagesEl) return;
    messagesEl.innerHTML = "";

    appendMessage("bot",
      "Namaste! I am **Jadhu**, your AI disaster & site assistant for ADWS (Beta).\n\n" +
      "I have full knowledge of our 30 tribal districts, 526 monitored cities, live satellite fires, USGS earthquakes, and off-grid LoRa village alerts.\n\n" +
      "I can also control the site for you — try asking me to **switch to satellite view**, **change language to Hindi**, or **check active disasters**!"
    );
  }

  function appendMessage(sender, text, isAction) {
    var messagesEl = document.getElementById("jadhuMessages");
    if (!messagesEl) return;

    var msgDiv = document.createElement("div");
    msgDiv.className = "jadhu-msg jadhu-msg-" + sender + (isAction ? " jadhu-msg-action" : "");

    // Simple markdown renderer for bold, lists, and code
    var formatted = escapeHtml(text)
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\n\n/g, "<br><br>")
      .replace(/\n•/g, "<br>•");

    msgDiv.innerHTML = formatted;
    messagesEl.appendChild(msgDiv);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function attachJadhuEvents() {
    var triggerBtn = document.getElementById("jadhuTrigger");
    var container = document.getElementById("jadhuContainer");
    var closeBtn = document.getElementById("jadhuCloseBtn");
    var form = document.getElementById("jadhuForm");
    var input = document.getElementById("jadhuInput");
    var clearBtn = document.getElementById("jadhuClearBtn");
    var settingsBtn = document.getElementById("jadhuSettingsBtn");
    var settingsDrawer = document.getElementById("jadhuSettingsDrawer");
    var apiKeyInput = document.getElementById("jadhuApiKeyInput");
    var saveKeyBtn = document.getElementById("jadhuSaveKeyBtn");
    var micBtn = document.getElementById("jadhuMicBtn");
    var chipsContainer = document.getElementById("jadhuChips");

    function openModal() {
      container.classList.add("is-open");
      container.setAttribute("aria-hidden", "false");
      input.focus();
    }

    function closeModal() {
      container.classList.remove("is-open");
      container.setAttribute("aria-hidden", "true");
    }

    triggerBtn.addEventListener("click", function () {
      if (container.classList.contains("is-open")) {
        closeModal();
      } else {
        openModal();
      }
    });

    closeBtn.addEventListener("click", closeModal);

    clearBtn.addEventListener("click", function () {
      renderWelcomeMessage();
    });

    settingsBtn.addEventListener("click", function () {
      var isHidden = settingsDrawer.hasAttribute("hidden");
      if (isHidden) {
        settingsDrawer.removeAttribute("hidden");
        apiKeyInput.value = getApiKey();
        apiKeyInput.focus();
      } else {
        settingsDrawer.setAttribute("hidden", "true");
      }
    });

    saveKeyBtn.addEventListener("click", function () {
      setApiKey(apiKeyInput.value);
      settingsDrawer.setAttribute("hidden", "true");
      appendMessage("bot", "✓ Gemini API key saved! Jadhu is connected to Google Gemini.");
    });

    // Voice recognition (Speech to text)
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      var recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "en-IN";

      recognition.onstart = function () {
        micBtn.classList.add("is-listening");
        micBtn.textContent = "🔴";
      };

      recognition.onresult = function (event) {
        var speech = event.results[0][0].transcript;
        input.value = speech;
        handleUserMessage(speech);
      };

      recognition.onend = function () {
        micBtn.classList.remove("is-listening");
        micBtn.textContent = "🎙️";
      };

      micBtn.addEventListener("click", function () {
        try {
          recognition.start();
        } catch (e) {
          recognition.stop();
        }
      });
    } else {
      micBtn.style.display = "none";
    }

    // Chips click handler
    chipsContainer.addEventListener("click", function (e) {
      var btn = e.target.closest(".jadhu-chip");
      if (btn) {
        var p = btn.getAttribute("data-prompt");
        if (p) {
          input.value = p;
          handleUserMessage(p);
        }
      }
    });

    // Form submit handler
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var text = input.value.trim();
      if (!text) return;
      handleUserMessage(text);
      input.value = "";
    });

    // Keyboard shortcut (Escape to close)
    window.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && container.classList.contains("is-open")) {
        closeModal();
      }
    });
  }

  async function handleUserMessage(userText) {
    var input = document.getElementById("jadhuInput");
    var sendBtn = document.getElementById("jadhuSendBtn");
    appendMessage("user", userText);

    if (input) input.disabled = true;
    if (sendBtn) sendBtn.disabled = true;

    // Show temporary typing indicator
    var messagesEl = document.getElementById("jadhuMessages");
    var typingDiv = document.createElement("div");
    typingDiv.className = "jadhu-msg jadhu-msg-bot jadhu-typing";
    typingDiv.innerHTML = "<span></span><span></span><span></span>";
    messagesEl.appendChild(typingDiv);
    messagesEl.scrollTop = messagesEl.scrollHeight;

    try {
      var response = await queryGemini(userText);

      // Check if response contains an action code block
      var actionBlockMatch = response.match(/```action\s*([\s\S]*?)\s*```/);
      var cleanResponse = response.replace(/```action[\s\S]*?```/g, "").trim();

      if (typingDiv.parentNode) typingDiv.parentNode.removeChild(typingDiv);

      appendMessage("bot", cleanResponse);

      if (actionBlockMatch) {
        try {
          var actObj = JSON.parse(actionBlockMatch[1]);
          if (actObj && actObj.action) {
            var actionResult = executeSiteAction(actObj.action, actObj.value);
            appendMessage("bot", "⚡ " + actionResult.message, true);
          }
        } catch (err) {
          console.warn("Failed to parse AI action payload:", err);
        }
      }
    } catch (err) {
      if (typingDiv.parentNode) typingDiv.parentNode.removeChild(typingDiv);
      var fallback = generateLocalResponse(userText);
      appendMessage("bot", fallback);
    } finally {
      if (input) {
        input.disabled = false;
        input.focus();
      }
      if (sendBtn) sendBtn.disabled = false;
    }
  }

  // Initialize once DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectJadhuUI);
  } else {
    injectJadhuUI();
  }

  root.JadhuAI = {
    open: function () {
      var container = document.getElementById("jadhuContainer");
      if (container) container.classList.add("is-open");
    },
    close: function () {
      var container = document.getElementById("jadhuContainer");
      if (container) container.classList.remove("is-open");
    },
    ask: handleUserMessage,
    execute: executeSiteAction
  };
})(typeof window !== "undefined" ? window : globalThis);
