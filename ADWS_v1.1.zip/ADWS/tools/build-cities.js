#!/usr/bin/env node
/*
 * Adivasi Suraksha — city list generator
 * --------------------------------------
 * Builds `cities.js` (CONFIG.cities) from the free GeoNames India dump, so the
 * dashboard can cover far more than the 30 tribal districts without anyone
 * hand-typing coordinates or inventing data.
 *
 * Data source (free, no API key, CC-BY 4.0 — GeoNames):
 *   https://download.geonames.org/export/dump/IN.zip               -> IN.txt
 *   https://download.geonames.org/export/dump/admin1CodesASCII.txt  -> state names
 *
 * IN.txt is tab-separated:
 *   0 geonameid  1 name  2 asciiname  3 alternatenames  4 lat  5 lon
 *   6 featureClass  7 featureCode  8 country  9 cc2  10 admin1  ...  14 population
 *
 * Usage:
 *   node tools/build-cities.js <IN.txt> <admin1CodesASCII.txt> [--min-pop=100000] [--out=cities.js] [--stats]
 *
 * Examples:
 *   node tools/build-cities.js IN.txt admin1CodesASCII.txt --stats
 *   node tools/build-cities.js IN.txt admin1CodesASCII.txt --min-pop=100000
 *   node tools/build-cities.js IN.txt admin1CodesASCII.txt --min-pop=15000
 */
"use strict";

const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
const positional = args.filter((a) => !a.startsWith("--"));
const flags = new Set(args.filter((a) => a.startsWith("--") && !a.includes("=")));
const options = {};
args.filter((a) => a.includes("=")).forEach((a) => {
  const i = a.indexOf("=");
  options[a.slice(2, i)] = a.slice(i + 1);
});

const inPath = positional[0];
const admin1Path = positional[1];
if (!inPath || !admin1Path) {
  console.error("usage: node tools/build-cities.js <IN.txt> <admin1CodesASCII.txt> [--min-pop=N] [--out=cities.js] [--stats]");
  process.exit(2);
}
if (!fs.existsSync(inPath)) {
  console.error("missing input file: " + inPath);
  process.exit(2);
}

const minPop = options["min-pop"] != null ? Number(options["min-pop"]) : 100000;
const statsOnly = flags.has("--stats");
const outPath = options.out || path.join(__dirname, "..", "cities.js");

const eprint = (s) => process.stderr.write(s + "\n");

/* ---- state names from GeoNames admin1 codes (IN.01 -> Andhra Pradesh) ---- */
const stateByCode = {};
if (fs.existsSync(admin1Path)) {
  fs.readFileSync(admin1Path, "utf8").split(/\r?\n/).forEach((line) => {
    if (!line) return;
    const f = line.split("\t");
    if (f[0] && f[0].startsWith("IN.")) stateByCode[f[0]] = f[1] || f[2] || "";
  });
}
eprint("state codes loaded: " + Object.keys(stateByCode).length);

/* ---- read the dump ---- */
const rows = fs.readFileSync(inPath, "utf8").split("\n");
eprint("IN.txt rows: " + rows.length);

const buckets = [0, 1000, 5000, 10000, 15000, 25000, 50000, 100000, 200000, 500000, 1000000, 5000000];
const counts = new Map(buckets.map((b) => [b, 0]));
/*
 * Dedupe on state + name, keeping the most populous row. GeoNames lists the
 * same settlement several times (different source surveys, "PPLX" sections),
 * so without this the dashboard would show Kanpur a dozen times.
 */
const byKey = new Map();
let classP = 0;
let skippedPplx = 0;

for (let i = 0; i < rows.length; i += 1) {
  const line = rows[i];
  if (!line) continue;
  const f = line.split("\t");
  if (f.length < 15 || f[6] !== "P") continue;
  classP += 1;

  const code = f[7];
  if (code === "PPLX" || code === "PPLCH" || code === "PPLH") { skippedPplx += 1; continue; }

  const pop = Number(f[14]) || 0;
  for (let b = 0; b < buckets.length; b += 1) if (pop >= buckets[b]) counts.set(buckets[b], counts.get(buckets[b]) + 1);

  const name = (f[1] || "").trim();
  const admin1 = f[10] || "";
  if (!name) continue;

  const key = admin1 + "|" + name.toLowerCase();
  const prev = byKey.get(key);
  if (!prev || pop > prev.pop) {
    byKey.set(key, {
      name,
      ascii: (f[2] || name).trim(),
      admin1,
      lat: Number(f[4]),
      lon: Number(f[5]),
      pop,
      geonameid: f[0]
    });
  }
}

eprint("feature class P: " + classP + "  (skipped PPLX/PPLH/PPLCH: " + skippedPplx + ")");
eprint("unique settlements after dedupe: " + byKey.size);
eprint("");
eprint("population threshold -> settlements (after dedupe)");
eprint("-------------------------------------------------");
const unique = Array.from(byKey.values());
buckets.forEach((b) => {
  const n = unique.filter((r) => r.pop >= b).length;
  eprint(String(b).padStart(9) + " -> " + n);
});
eprint("");

if (statsOnly) process.exit(0);

/* ---- select + slugify ---- */
const slug = (s) =>
  s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "place";

const selected = unique
  .filter((r) => r.pop >= minPop)
  .sort((a, b) => b.pop - a.pop || a.name.localeCompare(b.name));

const used = new Set();
const cities = [];
for (const r of selected) {
  let id = slug(r.ascii || r.name);
  if (used.has(id)) id = slug(r.ascii || r.name) + "-" + (r.admin1 || r.geonameid);
  let n = 2;
  while (used.has(id)) { id = id.replace(/-\d+$/, "") + "-" + n; n += 1; }
  used.add(id);

  // IN.txt stores admin1 as "16"; the lookup table keys are "IN.16".
  let state = stateByCode["IN." + r.admin1];
  if (!state) state = "India";

  cities.push({
    id,
    name: { en: r.name },
    state: { en: state },
    lat: Math.round(r.lat * 10000) / 10000,
    lon: Math.round(r.lon * 10000) / 10000,
    pop: r.pop
  });
}

eprint("writing " + cities.length + " cities (pop >= " + minPop + ") -> " + outPath);

/* ---- emit ---- */
const body = cities
  .map((c) => {
    const pop = c.pop ? ", pop: " + c.pop : "";
    return (
      '    { id: ' + JSON.stringify(c.id) +
      ", name: { en: " + JSON.stringify(c.name.en) + " }" +
      ", state: { en: " + JSON.stringify(c.state.en) + " }" +
      ", lat: " + c.lat + ", lon: " + c.lon + pop + " }"
    );
  })
  .join(",\n");

const header =
  "/*\n" +
  " * Adivasi Suraksha — Indian city list (generated)\n" +
  " * ------------------------------------------------\n" +
  " * GENERATED FILE — do not edit by hand. Rebuild with:\n" +
  " *   node tools/build-cities.js <IN.txt> <admin1CodesASCII.txt> --min-pop=" + minPop + "\n" +
  " *\n" +
  " * Source: GeoNames IN.txt (CC-BY 4.0), https://download.geonames.org/export/dump/\n" +
  " * " + cities.length + " settlements with population >= " + minPop + ", most populous first.\n" +
  " *\n" +
  " * Names are English only. The UI falls back to the English name when a\n" +
  " * regional/Hindi name is missing (see app.js districtLabel()), so these\n" +
  " * cities localise cleanly without a hand-written name per language.\n" +
  " * `pop` is the GeoNames population figure and may be an old census value.\n" +
  " */\n" +
  "(function (root) {\n" +
  '  "use strict";\n' +
  "  var cities = [\n" +
  body + "\n" +
  "  ];\n" +
  "  root.APP_CITIES = cities;\n" +
  '  if (typeof module !== "undefined" && module.exports) module.exports = cities;\n' +
  '})(typeof window !== "undefined" ? window : globalThis);\n';

fs.writeFileSync(outPath, header, "utf8");
eprint("done.");
