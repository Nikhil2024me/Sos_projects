/*
 * Adivasi Suraksha — server-only secrets.
 *
 * This file is read by Node (serve.js / ambee.js) and is explicitly blocked by
 * serve.js, so a browser cannot download it. Never rename it to something that
 * the static file handler will serve, and never import it from app.js.
 *
 * You can also leave ambeeKey empty and set AMBEE_KEY before starting serve.js.
 */
"use strict";

module.exports = {
  ambeeKey: "f78034ed86281ff6374ae75993fc7a10fe28f36a46b7d8d3a239036444b605f7",
  // NASA Earthdata Login bearer token for GES DISC / GPM IMERG.
  // Expires 2027-01-16. GES DISC EULA approved 2026-11-18; if NASA later asks
  // for approval again, use
  // https://urs.earthdata.nasa.gov/approve_app?client_id=e2WVk8Pw6weeLUKZYOxvTQ
  earthdataToken: "eyJ0eXAiOiJKV1QiLCJvcmlnaW4iOiJFYXJ0aGRhdGEgTG9naW4iLCJzaWciOiJlZGxqd3RwdWJrZXlfb3BzIiwiYWxnIjoiUlMyNTYifQ.eyJ0eXBlIjoiVXNlciIsInVpZCI6InRlamFzaHdpbiIsInN1YiI6InRlamFzaHdpbiIsImV4cCI6MTgwMDA4Njg1NiwiaWF0IjoxNzk0OTAyODU2LCJpc3MiOiJodHRwczovL3Vycy5lYXJ0aGRhdGEubmFzYS5nb3YiLCJpZGVudGl0eV9wcm92aWRlciI6ImVkbF9vcHMiLCJhY3IiOiJlZGwiLCJhc3N1cmFuY2VfbGV2ZWwiOjN9.IFYG9YbzCxcxhG1Mk9aF1Hro8ojKxBkyX0ZZTMWO7rgPdCQUwO3kQuPHyttd4VQq8-WUhMTF--UkUwMGTwF8VMbVu_0OjvSsOKoOAr-gS0EcXQ-wuKJxKKyxoTFX8pH2e9NuUXNgHnXEozO4mNYSXwVTwCrt6GA9Sf8qTWJX9jSGgj8DbpmwGVuTmwcRFYcbKjxdK9aTCv2l9hlYXGUhU1ICw8l5su5OkkILpBm-RV0qTFNJi9ZbdZIx7z93pk1Aizs9U04bx3ZCCMRF6ewCn3iMa8drh5FtC2jmXoyJUYM4spNslzDHsNj-I1zBh7HZUvQc59p8DRaVwuVixlloag",
  // ReliefWeb API v2 appname. The v1 API is decommissioned; v2 needs an
  // approved appname before /api/hazards can read South Asia disasters.
  // Request one at https://apidoc.reliefweb.int/parameters#appname
  reliefwebAppname: ""
};
