// ============================================================================
// SOS Emergency System v2.0 for ESP32-S3
// Button + Touch control (Z-pressure whole-screen touch button).
// Uses TFT_eSPI display, buzzer, notification LED, and RGB LED.
// Navigate services with button or touch; long-press opens config.
// Hold BOOT + reset to auto-calibrate touch Z threshold.
// ============================================================================

#include <SPI.h>
#include <TFT_eSPI.h>
#include <EEPROM.h>

// Include bitmap header files
#include "bitmap1.h"   // Ambulance bitmap
#include "bitmap2.h"   // Fire engine bitmap
#include "bitmap3.h"   // Police bitmap
#include "bitmap4.h"   // Emergency service bitmap
#include "webserver.h" // Web control panel (toggle WEBSERVER_ENABLED)

TFT_eSPI tft = TFT_eSPI();

// Screen dimensions
#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 240
#define FONT_SIZE 2

// Hardware pins
#define BUTTON_PIN 1
#define NOTIFICATION_PIN 25
#define BUZZER_PIN 33

// ── ESP32-S3 ONBOARD RGB LED (WS2812 on GPIO 48) ──
#define RGB_LED_PIN 48
#define RGB_BRIGHTNESS 15 // Low brightness (0–255)

// ── BOOT BUTTON (for touch calibration) ──
#define BOOT_BUTTON_PIN 0

// ── EEPROM ──
#define EEPROM_SIZE 8
#define EEPROM_MAGIC 0xBE
#define EEPROM_ADDR 0

// ── CALIBRATION SETTINGS ──
#define CAL_DURATION_MS 4000 // How long to sample idle noise (ms)
#define CAL_MARGIN 200       // Added above max idle Z for safety

// System states and services
enum SystemState
{
  MAIN_MENU,
  SOS_MENU,
  CONFIG_MENU,
  CALLING_SCREEN,
  SLIDESHOW_MODE
};
enum Service
{
  AMBULANCE,
  FIRE_ENGINE,
  POLICE,
  EMERGENCY
};

// State indicator colors (for top-left HUD dot)
const uint16_t STATE_COLORS[] = {
    TFT_GREEN,  // MAIN_MENU
    TFT_RED,    // SOS_MENU
    TFT_BLUE,   // CONFIG_MENU
    TFT_YELLOW, // CALLING_SCREEN
    TFT_MAGENTA // SLIDESHOW_MODE
};
const char *STATE_LABELS[] = {
    "MAIN", "SOS", "CFG", "CALL", "DEMO"};

// Global variables
SystemState currentState = MAIN_MENU;
Service currentService = AMBULANCE;

// Emergency call timing (global — replaces fragile static in handleEmergencyTimeout)
unsigned long callStartTime = 0;

// Double-press detection for service cycling vs calling
unsigned long lastShortPressTime = 0;
const unsigned long DOUBLE_PRESS_WINDOW = 500;
bool awaitingSecondPress = false;

// Boot diagnostics
int bootPassed = 0;
int bootFailed = 0;

// Slideshow variables
int currentSlide = 0;
const int totalSlides = 4;
bool slideChanged = true;
bool slideshowActive = false;
unsigned long slideChangeTime = 0;
const unsigned long AUTO_SLIDE_DURATION = 3000;

// Hardware control variables
unsigned long lastButtonPress = 0;
unsigned long buzzerToggleTime = 0;
unsigned long buttonPressStartTime = 0;
unsigned long systemStartTime = 0;

// Control flags
bool buzzerActive = false;
bool longPressDetected = false;
bool lastButtonState = HIGH;
bool emergencyCallActive = false;

// ── Touch input variables ──
uint16_t TOUCH_THRESHOLD = 6000; // Default fallback, auto-cal overrides
bool touchPressed = false;
bool prevTouchState = false;
unsigned long lastTouchPress = 0;
const unsigned long TOUCH_DEBOUNCE_TIME = 300;
unsigned long lastTouchShortPressTime = 0;
bool touchAwaitingSecondPress = false;

// Timing constants
const unsigned long BUTTON_DEBOUNCE_TIME = 300;
const unsigned long LONG_PRESS_DURATION = 2000;
const unsigned long BUZZER_TOGGLE_INTERVAL = 500;
const unsigned long CALL_DURATION = 5000;

// ---- Function Prototypes ----
void ShowMainMenu();
void ShowSlide(Service service);
void ConfigMenu();
void CallEmergencyService();
void ToggleBuzzer();
void DrawServiceScreen(Service service);
void DrawBitmapForService(Service service, uint16_t bgColor);
void showLogo();
void handleEmergencyTimeout();
void StartSlideshow();
void StopSlideshow();
void NextSlide();
void DisplayCurrentSlide();
void DisplayScaledBitmap(const uint16_t *bitmap, int x, int y, int w, int h, int scale);
void AutoAdvanceSlide();
void DrawServicePattern(int serviceIndex, int x, int y, uint16_t color);
void handleButtonInput();
void handleTouchInput();
void drawStateIndicator();
void drawHUDCorners(int x, int y, int w, int h, int len, uint16_t color);

// Touch / LED / EEPROM prototypes
void ledOff();
void ledColor(uint8_t r, uint8_t g, uint8_t b);
void ledRed();
void ledGreen();
void ledBlue();
void ledYellow();
void ledCyan();
void saveThreshold(uint16_t threshold);
bool loadThreshold(uint16_t *threshold);
void autoCalibrate();

// ============================================================================
// ESP32-S3 RGB LED — using neopixelWrite (built into ESP32 Arduino)
// ============================================================================
void ledOff()
{
  neopixelWrite(RGB_LED_PIN, 0, 0, 0);
}

void ledColor(uint8_t r, uint8_t g, uint8_t b)
{
  r = (r * RGB_BRIGHTNESS) / 255;
  g = (g * RGB_BRIGHTNESS) / 255;
  b = (b * RGB_BRIGHTNESS) / 255;
  neopixelWrite(RGB_LED_PIN, r, g, b);
}

void ledRed() { ledColor(255, 0, 0); }
void ledGreen() { ledColor(0, 255, 0); }
void ledBlue() { ledColor(0, 0, 255); }
void ledYellow() { ledColor(255, 255, 0); }
void ledCyan() { ledColor(0, 255, 255); }

// ============================================================================
// EEPROM: Save / Load touch threshold
// ============================================================================
void saveThreshold(uint16_t threshold)
{
  EEPROM.write(EEPROM_ADDR, EEPROM_MAGIC);
  EEPROM.write(EEPROM_ADDR + 1, threshold & 0xFF);
  EEPROM.write(EEPROM_ADDR + 2, (threshold >> 8) & 0xFF);
  EEPROM.commit();
}

bool loadThreshold(uint16_t *threshold)
{
  if (EEPROM.read(EEPROM_ADDR) != EEPROM_MAGIC)
    return false;
  *threshold = EEPROM.read(EEPROM_ADDR + 1) | (EEPROM.read(EEPROM_ADDR + 2) << 8);
  return true;
}

// ============================================================================
// AUTO-CALIBRATE Z THRESHOLD
// Hold BOOT button during reset to enter calibration.
// Samples idle Z noise for 4 seconds, sets threshold above max noise.
// ============================================================================
void autoCalibrate()
{
  Serial.println("\n── AUTO-CALIBRATE Z THRESHOLD ──");
  Serial.println("   DO NOT TOUCH THE SCREEN!\n");

  tft.fillScreen(TFT_BLACK);
  drawHUDCorners(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 15, TFT_DARKGREY);

  tft.setTextSize(2);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.drawString("CALIBRATING", 70, 20);

  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("DO NOT TOUCH!", 55, 55);

  tft.setTextSize(1);
  tft.setTextColor(TFT_DARKGREY, TFT_BLACK);
  tft.drawString("Reading idle noise for 4 seconds...", 30, 90);

  // Progress bar outline
  tft.drawRect(30, 120, 260, 20, TFT_DARKGREY);

  ledBlue(); // LED blue = calibrating

  uint16_t maxZ = 0;
  uint16_t minZ = 65535;
  uint32_t sampleCount = 0;
  uint32_t startTime = millis();

  while (millis() - startTime < CAL_DURATION_MS)
  {
    uint16_t z = tft.getTouchRawZ();

    if (z > maxZ)
      maxZ = z;
    if (z < minZ)
      minZ = z;
    sampleCount++;

    // Update progress bar
    uint32_t elapsed = millis() - startTime;
    uint16_t barW = map(elapsed, 0, CAL_DURATION_MS, 0, 258);
    tft.fillRect(31, 121, barW, 18, TFT_CYAN);

    // Live Z on screen
    tft.fillRect(30, 150, 260, 20, TFT_BLACK);
    tft.setTextSize(2);
    tft.setTextColor(TFT_GREEN, TFT_BLACK);
    char zBuf[20];
    sprintf(zBuf, "Z: %d", z);
    tft.drawString(zBuf, 30, 150);

    Serial.printf("   Sample %d: Z=%d  (min:%d  max:%d)\n", sampleCount, z, minZ, maxZ);
    delay(20);
  }

  // Calculate threshold
  uint16_t newThreshold = maxZ + CAL_MARGIN;
  TOUCH_THRESHOLD = newThreshold;

  Serial.println("\n   ── CALIBRATION RESULT ──");
  Serial.printf("   Idle Z range: %d – %d\n", minZ, maxZ);
  Serial.printf("   Max idle Z:   %d\n", maxZ);
  Serial.printf("   Margin:       +%d\n", CAL_MARGIN);
  Serial.printf("   NEW THRESHOLD: %d\n", newThreshold);
  Serial.printf("   Samples taken: %d\n\n", sampleCount);

  // Save to EEPROM
  saveThreshold(newThreshold);
  Serial.println("   Saved to EEPROM!\n");

  // Show result on screen
  tft.fillScreen(TFT_BLACK);
  drawHUDCorners(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 15, TFT_DARKGREY);

  tft.setTextSize(2);
  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.drawString("CALIBRATION DONE!", 30, 20);

  tft.setTextSize(1);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  char buf[40];
  sprintf(buf, "Idle Z noise: %d - %d", minZ, maxZ);
  tft.drawString(buf, 30, 55);

  sprintf(buf, "Safety margin: +%d", CAL_MARGIN);
  tft.drawString(buf, 30, 75);

  tft.setTextSize(2);
  tft.setTextColor(TFT_CYAN, TFT_BLACK);
  sprintf(buf, "Threshold: %d", newThreshold);
  tft.drawString(buf, 30, 105);

  tft.setTextSize(1);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.drawString("Saved to EEPROM!", 30, 140);
  tft.drawString("Starting in 3 seconds...", 30, 160);

  ledGreen();
  delay(3000);
  ledOff();
}

// ============================================================================
// State Indicator — drawn in the TOP-LEFT corner of every screen (Step 19)
// ============================================================================
void drawStateIndicator()
{
  uint16_t color = STATE_COLORS[currentState];
  const char *label = STATE_LABELS[currentState];

  // Background pill
  tft.fillRoundRect(2, 2, 52, 16, 4, TFT_BLACK);
  tft.drawRoundRect(2, 2, 52, 16, 4, color);

  // Colored dot
  tft.fillCircle(12, 10, 4, color);

  // Label text
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(color, TFT_BLACK);
  tft.setTextDatum(TL_DATUM);
  tft.drawString(label, 20, 5);
}

// ============================================================================
// HUD Corner Brackets — tactical frame decoration (Step 4)
// ============================================================================
void drawHUDCorners(int x, int y, int w, int h, int len, uint16_t color)
{
  // Top-left
  tft.drawFastHLine(x, y, len, color);
  tft.drawFastVLine(x, y, len, color);
  // Top-right
  tft.drawFastHLine(x + w - len, y, len, color);
  tft.drawFastVLine(x + w - 1, y, len, color);
  // Bottom-left
  tft.drawFastHLine(x, y + h - 1, len, color);
  tft.drawFastVLine(x, y + h - len, len, color);
  // Bottom-right
  tft.drawFastHLine(x + w - len, y + h - 1, len, color);
  tft.drawFastVLine(x + w - 1, y + h - len, len, color);
}

// ============================================================================
// Slideshow Functions (Step 15: now reachable from ConfigMenu long-press)
// ============================================================================
void StartSlideshow()
{
  Serial.println("Starting slideshow demo mode");
  slideshowActive = true;
  currentState = SLIDESHOW_MODE;
  currentSlide = 0;
  slideChanged = true;
  slideChangeTime = millis();
  DisplayCurrentSlide();
}

void StopSlideshow()
{
  Serial.println("Stopping slideshow demo mode");
  slideshowActive = false;
  slideChanged = false;
  if (currentState == SLIDESHOW_MODE)
  {
    currentState = CONFIG_MENU;
  }
}

void NextSlide()
{
  if (currentState == SLIDESHOW_MODE)
  {
    currentSlide = (currentSlide + 1) % totalSlides;
    slideChanged = true;
    slideChangeTime = millis();
    DisplayCurrentSlide();
  }
  else if (currentState == SOS_MENU)
  {
    currentService = static_cast<Service>((currentService + 1) % 4);
    ShowSlide(currentService);
  }
  Serial.printf("Next slide/service: %d\n",
                currentState == SLIDESHOW_MODE ? currentSlide : (int)currentService);
}

void DisplayCurrentSlide()
{
  if (currentState != SLIDESHOW_MODE)
    return;

  tft.fillScreen(TFT_BLACK);
  drawStateIndicator();

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.setTextSize(2);
  tft.setTextDatum(TL_DATUM);
  tft.setCursor(60, 10);
  tft.print("Demo Slide ");
  tft.print(currentSlide + 1);
  tft.print("/");
  tft.println(totalSlides);

  String slideTitle;
  uint16_t bgColor;
  switch (currentSlide)
  {
  case 0:
    slideTitle = "Medical Emergency";
    bgColor = TFT_RED;
    break;
  case 1:
    slideTitle = "Fire Emergency";
    bgColor = TFT_ORANGE;
    break;
  case 2:
    slideTitle = "Police Emergency";
    bgColor = TFT_BLUE;
    break;
  case 3:
    slideTitle = "General Emergency";
    bgColor = TFT_PURPLE;
    break;
  default:
    slideTitle = "Default";
    bgColor = TFT_WHITE;
    break;
  }

  tft.setTextSize(1);
  tft.setCursor(60, 40);
  tft.println(slideTitle);

  DrawServicePattern(currentSlide, 100, 80, bgColor);

  // HUD frame
  drawHUDCorners(5, 5, SCREEN_WIDTH - 10, SCREEN_HEIGHT - 10, 20, TFT_DARKGREY);

  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.setCursor(10, SCREEN_HEIGHT - 20);
  tft.println("BTN/Touch: Next slide  |  Auto: 3s");

  Serial.printf("Displayed slide: %d - %s\n", currentSlide + 1, slideTitle.c_str());
}

void DisplayScaledBitmap(const uint16_t *bitmap, int x, int y, int w, int h, int scale)
{
  for (int j = 0; j < h; j++)
  {
    for (int i = 0; i < w; i++)
    {
      uint16_t pixel = pgm_read_word(&bitmap[j * w + i]);
      for (int sy = 0; sy < scale; sy++)
      {
        for (int sx = 0; sx < scale; sx++)
        {
          tft.drawPixel(x + (i * scale) + sx, y + (j * scale) + sy, pixel);
        }
      }
    }
  }
}

void DrawServicePattern(int serviceIndex, int x, int y, uint16_t color)
{
  switch (serviceIndex)
  {
  case 0: // Ambulance — medical cross
    tft.fillRect(x + 44, y + 54, 40, 20, color);
    tft.fillRect(x + 54, y + 44, 20, 40, color);
    tft.drawRect(x + 42, y + 52, 44, 24, TFT_WHITE);
    tft.drawRect(x + 52, y + 42, 24, 44, TFT_WHITE);
    break;
  case 1: // Fire — flame pattern
    tft.fillTriangle(x + 64, y + 34, x + 44, y + 94, x + 84, y + 94, color);
    tft.drawTriangle(x + 64, y + 32, x + 42, y + 96, x + 86, y + 96, TFT_YELLOW);
    break;
  case 2: // Police — badge
    tft.fillCircle(x + 64, y + 64, 50, color);
    tft.drawCircle(x + 64, y + 64, 52, TFT_WHITE);
    tft.fillCircle(x + 64, y + 64, 30, TFT_BLACK);
    break;
  case 3: // Emergency — exclamation
    tft.fillRect(x + 59, y + 44, 10, 40, color);
    tft.fillCircle(x + 64, y + 94, 5, color);
    tft.drawRect(x + 57, y + 42, 14, 44, TFT_WHITE);
    break;
  }
}

void AutoAdvanceSlide()
{
  if (slideshowActive && currentState == SLIDESHOW_MODE)
  {
    if (millis() - slideChangeTime >= AUTO_SLIDE_DURATION)
    {
      NextSlide();
    }
  }
}

// ============================================================================
// SETUP — Enhanced boot sequence (Plan B: steps 9–14)
// ============================================================================
void setup()
{
  Serial.begin(115200);
  systemStartTime = millis();

  // Initialize EEPROM and RGB LED
  EEPROM.begin(EEPROM_SIZE);
  ledOff();
  pinMode(BOOT_BUTTON_PIN, INPUT_PULLUP);

  // Initialize display
  tft.init();
  tft.setRotation(1);

  // ---- Check BOOT button for touch calibration ----
  if (digitalRead(BOOT_BUTTON_PIN) == LOW)
  {
    Serial.println(">> BOOT button held — auto-calibrating touch...");
    autoCalibrate();
  }
  else
  {
    // Load threshold from EEPROM or use default
    if (loadThreshold(&TOUCH_THRESHOLD))
    {
      Serial.printf(">> Touch threshold loaded from EEPROM: %d\n", TOUCH_THRESHOLD);
    }
    else
    {
      Serial.printf(">> No EEPROM data, using default threshold: %d\n", TOUCH_THRESHOLD);
    }
  }

  // ---- Boot Screen ----
  tft.fillScreen(TFT_BLACK);
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextColor(TFT_CYAN);
  tft.drawString("> SYSTEM BOOT v2.0", 10, 10);
  tft.drawLine(0, 30, SCREEN_WIDTH, 30, TFT_CYAN);

  // HUD corners on boot screen
  drawHUDCorners(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, 15, TFT_DARKGREY);

  int yp = 50;
  bootPassed = 0;
  bootFailed = 0;

  // ---- Step 10: Segmented boot progress bar (6 segments) ----
  int totalBootSteps = 6;
  int segW = (SCREEN_WIDTH - 20) / totalBootSteps - 2;

  // Draw empty segment outlines
  for (int i = 0; i < totalBootSteps; i++)
  {
    tft.drawRect(10 + i * (segW + 2), SCREEN_HEIGHT - 16, segW, 12, TFT_DARKGREY);
  }

  // Helper: draw filled boot segment
  auto fillBootSeg = [&](int idx, bool ok)
  {
    uint16_t c = ok ? TFT_GREEN : TFT_RED;
    tft.fillRect(10 + idx * (segW + 2) + 1, SCREEN_HEIGHT - 15, segW - 2, 10, c);
  };

  auto bootStep = [&](const char *label, bool success)
  {
    tft.setTextColor(TFT_WHITE);
    tft.setTextFont(2);
    tft.setTextSize(1);
    tft.drawString(label, 20, yp);
    delay(120);
    if (success)
    {
      tft.setTextColor(TFT_GREEN);
      tft.drawString("[OK]", 260, yp);
      fillBootSeg(bootPassed + bootFailed, true);
      bootPassed++;
    }
    else
    {
      tft.setTextColor(TFT_RED);
      tft.drawString("[FAIL]", 252, yp);
      fillBootSeg(bootPassed + bootFailed, false);
      bootFailed++;
    }
    yp += 20;
  };

  // Step 1: Display init
  bootStep("Display init...", true);

  // Step 2: Hardware IO — real validation (Step 9)
  pinMode(NOTIFICATION_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  digitalWrite(NOTIFICATION_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  delay(50);
  bootStep("Hardware IO...", digitalRead(BUTTON_PIN) == HIGH);

  // Step 3: Self-test — brief buzzer + LED toggle (Step 13)
  digitalWrite(BUZZER_PIN, HIGH);
  delay(50);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(NOTIFICATION_PIN, HIGH);
  delay(50);
  digitalWrite(NOTIFICATION_PIN, LOW);
  bootStep("Self-test (Bzr+LED)...", true);

  // Step 4: Button input
  delay(100);
  bootStep("Button input...", true);

  // Step 5: Touch input (Z-pressure)
  {
    uint16_t testZ = tft.getTouchRawZ();
    Serial.printf("Touch Z test read: %d (threshold: %d)\n", testZ, TOUCH_THRESHOLD);
    bootStep("Touch input (Z)...", true);
  }

  // Step 6: Services
  delay(150);
  bootStep("Starting services...", true);

  // ---- Step 11: System info section ----
  yp += 5;
  tft.drawLine(10, yp, SCREEN_WIDTH - 10, yp, TFT_DARKGREY);
  yp += 5;
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(TFT_DARKGREY);

  char infoBuf[64];
  snprintf(infoBuf, sizeof(infoBuf), "Heap: %u KB", (unsigned)(ESP.getFreeHeap() / 1024));
  tft.drawString(infoBuf, 20, yp);
  yp += 12;
  snprintf(infoBuf, sizeof(infoBuf), "Chip: %s", ESP.getChipModel());
  tft.drawString(infoBuf, 20, yp);
  yp += 12;
  snprintf(infoBuf, sizeof(infoBuf), "CPU:  %u MHz", (unsigned)ESP.getCpuFreqMHz());
  tft.drawString(infoBuf, 20, yp);
  yp += 12;

  // ---- Step 14: Boot summary ----
  tft.setTextColor(bootFailed > 0 ? TFT_YELLOW : TFT_GREEN);
  snprintf(infoBuf, sizeof(infoBuf), "%d/%d checks passed", bootPassed, bootPassed + bootFailed);
  tft.drawString(infoBuf, 20, yp);
  yp += 15;

  // ---- Step 12: Animated "SYSTEM READY" ----
  uint16_t fadeColors[] = {0x0320, 0x0640, TFT_CYAN, TFT_WHITE};
  tft.setTextFont(4);
  tft.setTextDatum(TC_DATUM);
  for (int i = 0; i < 4; i++)
  {
    tft.setTextColor(fadeColors[i], TFT_BLACK);
    tft.drawCentreString("SYSTEM READY", SCREEN_WIDTH / 2, yp, 4);
    delay(120);
  }
  delay(800);

  // Show enhanced logo then main menu
  showLogo();

  // Start web server (if enabled)
  webserverSetup();

  ShowMainMenu();

  Serial.println(F("\n== SYSTEM READY v2.0 =="));
  Serial.printf("Init Time: %lu ms | Heap: %u bytes\n", millis() - systemStartTime, ESP.getFreeHeap());
  Serial.printf("Touch threshold: %d (Z < threshold = PRESSED)\n", TOUCH_THRESHOLD);
  if (WEBSERVER_ENABLED)
  {
    Serial.printf("Web UI: http://%s  (connect to WiFi '%s')\n",
                  WiFi.softAPIP().toString().c_str(), AP_SSID);
  }
}

// ============================================================================
// MAIN LOOP
// ============================================================================
void loop()
{
  if (slideshowActive)
    AutoAdvanceSlide();

  if (buzzerActive && (millis() - buzzerToggleTime >= BUZZER_TOGGLE_INTERVAL))
  {
    ToggleBuzzer();
    buzzerToggleTime = millis();
  }

  if (emergencyCallActive)
    handleEmergencyTimeout();

  handleButtonInput();
  handleTouchInput();

  // ---- Handle web commands (async server — no polling needed) ----

  if (webCmdNextService)
  {
    webCmdNextService = false;
    currentService = static_cast<Service>((currentService + 1) % 4);
    if (currentState == SOS_MENU || currentState == MAIN_MENU)
    {
      currentState = SOS_MENU;
      ShowSlide(currentService);
    }
  }
  if (webCmdCallEmergency)
  {
    webCmdCallEmergency = false;
    if (currentState != CALLING_SCREEN)
    {
      currentState = SOS_MENU;
      CallEmergencyService();
    }
  }
  if (webCmdMainMenu)
  {
    webCmdMainMenu = false;
    if (emergencyCallActive)
    {
      emergencyCallActive = false;
      buzzerActive = false;
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(NOTIFICATION_PIN, LOW);
    }
    StopSlideshow();
    currentState = MAIN_MENU;
    ShowMainMenu();
  }

  delay(10);
}

// ============================================================================
// Button Input — service cycling via single/double press (Step 17)
// Long press in CONFIG_MENU → slideshow (Step 15)
// ============================================================================
void handleButtonInput()
{
  bool currentButtonState = digitalRead(BUTTON_PIN);

  // Button pressed down
  if (currentButtonState == LOW && lastButtonState == HIGH)
  {
    buttonPressStartTime = millis();
    longPressDetected = false;
  }

  // Long press detection
  if (currentButtonState == LOW && !longPressDetected &&
      (millis() - buttonPressStartTime >= LONG_PRESS_DURATION))
  {
    longPressDetected = true;

    if (currentState == CONFIG_MENU)
    {
      // Long press in config → start slideshow (Step 15)
      Serial.println("Button: Long press in Config → Slideshow");
      StartSlideshow();
    }
    else
    {
      // Long press elsewhere → config menu
      Serial.println("Button: Long press → Config menu");
      StopSlideshow();
      currentState = CONFIG_MENU;
      ConfigMenu();
    }
  }

  // Button released (short press)
  if (currentButtonState == HIGH && lastButtonState == LOW &&
      (millis() - lastButtonPress > BUTTON_DEBOUNCE_TIME) && !longPressDetected)
  {

    lastButtonPress = millis();

    switch (currentState)
    {
    case MAIN_MENU:
      Serial.println("Button: → SOS menu");
      currentState = SOS_MENU;
      ShowSlide(currentService);
      break;

    case SOS_MENU:
      // Step 17: Single press = cycle service, double press = call
      if (awaitingSecondPress &&
          (millis() - lastShortPressTime <= DOUBLE_PRESS_WINDOW))
      {
        // Double press → call emergency
        awaitingSecondPress = false;
        Serial.println("Button: Double press → Calling emergency");
        CallEmergencyService();
      }
      else
      {
        // First press → cycle to next service
        awaitingSecondPress = true;
        lastShortPressTime = millis();
        Serial.println("Button: Single press → Next service");
        currentService = static_cast<Service>((currentService + 1) % 4);
        ShowSlide(currentService);
      }
      break;

    case CONFIG_MENU:
      Serial.println("Button: Exiting config → Main menu");
      StopSlideshow();
      currentState = MAIN_MENU;
      ShowMainMenu();
      break;

    case SLIDESHOW_MODE:
      Serial.println("Button: Next slide");
      NextSlide();
      break;

    case CALLING_SCREEN:
      Serial.println("Button: Cancelling emergency call");
      emergencyCallActive = false;
      buzzerActive = false;
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(NOTIFICATION_PIN, LOW); // Step 16: Fix LED leak
      currentState = SOS_MENU;
      ShowSlide(currentService);
      break;
    }
  }

  // Clear double-press window if expired
  if (awaitingSecondPress && (millis() - lastShortPressTime > DOUBLE_PRESS_WINDOW))
  {
    awaitingSecondPress = false;
  }

  lastButtonState = currentButtonState;
}

// ============================================================================
// Touch Input — Z-pressure whole-screen button (from code.txt touch API)
// Touch press acts like a short button press; double-tap = call in SOS_MENU.
// Provides RGB LED feedback: green flash on press.
// ============================================================================
void handleTouchInput()
{
  uint16_t z = tft.getTouchRawZ();
  touchPressed = (z < TOUCH_THRESHOLD);

  // Touch just pressed (rising edge)
  if (touchPressed && !prevTouchState)
  {
    if (millis() - lastTouchPress < TOUCH_DEBOUNCE_TIME)
    {
      prevTouchState = touchPressed;
      return; // Debounce — ignore rapid repeated touches
    }

    lastTouchPress = millis();
    ledGreen(); // Visual feedback via RGB LED
    Serial.printf("Touch PRESSED  Z:%d (threshold:%d)\n", z, TOUCH_THRESHOLD);

    switch (currentState)
    {
    case MAIN_MENU:
      Serial.println("Touch: → SOS menu");
      currentState = SOS_MENU;
      ShowSlide(currentService);
      break;

    case SOS_MENU:
      // Double-tap detection for calling
      if (touchAwaitingSecondPress &&
          (millis() - lastTouchShortPressTime <= DOUBLE_PRESS_WINDOW))
      {
        touchAwaitingSecondPress = false;
        Serial.println("Touch: Double-tap → Calling emergency");
        ledRed();
        CallEmergencyService();
      }
      else
      {
        touchAwaitingSecondPress = true;
        lastTouchShortPressTime = millis();
        Serial.println("Touch: Single tap → Next service");
        currentService = static_cast<Service>((currentService + 1) % 4);
        ShowSlide(currentService);
      }
      break;

    case CONFIG_MENU:
      Serial.println("Touch: Exiting config → Main menu");
      StopSlideshow();
      currentState = MAIN_MENU;
      ShowMainMenu();
      break;

    case SLIDESHOW_MODE:
      Serial.println("Touch: Next slide");
      NextSlide();
      break;

    case CALLING_SCREEN:
      Serial.println("Touch: Cancelling emergency call");
      emergencyCallActive = false;
      buzzerActive = false;
      digitalWrite(BUZZER_PIN, LOW);
      digitalWrite(NOTIFICATION_PIN, LOW);
      currentState = SOS_MENU;
      ShowSlide(currentService);
      break;
    }
  }

  // Touch just released (falling edge)
  if (!touchPressed && prevTouchState)
  {
    ledOff(); // Turn off RGB LED on release
    Serial.printf("Touch RELEASED Z:%d\n", z);
  }

  // Clear double-tap window if expired
  if (touchAwaitingSecondPress && (millis() - lastTouchShortPressTime > DOUBLE_PRESS_WINDOW))
  {
    touchAwaitingSecondPress = false;
  }

  prevTouchState = touchPressed;
}

// ============================================================================
// Emergency Timeout — global callStartTime (Step 18: fixes static var bug)
// ============================================================================
void handleEmergencyTimeout()
{
  if (millis() - callStartTime >= CALL_DURATION)
  {
    emergencyCallActive = false;
    buzzerActive = false;
    digitalWrite(BUZZER_PIN, LOW);
    digitalWrite(NOTIFICATION_PIN, LOW); // Step 16: Fix LED leak

    Serial.println("Emergency call completed");
    currentState = SOS_MENU;
    ShowSlide(currentService);
  }
}

// ============================================================================
// SOS_AI Logo / Splash Screen
// ============================================================================
void showLogo()
{
  tft.fillScreen(TFT_BLACK);
  int cx = SCREEN_WIDTH / 2;
  int cy = SCREEN_HEIGHT / 2;

  // Border frame
  tft.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, TFT_CYAN);

  // "SOS" title
  tft.setTextDatum(MC_DATUM);
  tft.setTextFont(4);
  tft.setTextSize(2);
  tft.setTextColor(TFT_WHITE);
  tft.drawString("SOS", cx - 40, cy - 20);

  // "_AI" suffix
  tft.setTextColor(TFT_CYAN);
  tft.drawString("_AI", cx + 70, cy - 20);

  // Subtitle
  tft.setTextSize(1);
  tft.setTextFont(2);
  tft.setTextColor(TFT_SILVER);
  tft.drawString("NEURAL EMERGENCY LINK", cx, cy + 30);

  // Progress bar
  tft.fillRect(40, cy + 50, SCREEN_WIDTH - 80, 4, TFT_DARKGREY);
  for (int i = 0; i <= SCREEN_WIDTH - 80; i += 4)
  {
    tft.fillRect(40, cy + 50, i, 4, TFT_CYAN);
    delay(5);
  }

  // Version info
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(TFT_DARKGREY);
  tft.drawString("v2.0 | ESP32-S3", cx, SCREEN_HEIGHT - 15);

  delay(800);
}

// ============================================================================
// MAIN MENU
// ============================================================================
void ShowMainMenu()
{
  Serial.println("Displaying main menu");

  tft.fillScreen(TFT_NAVY);

  // Header bar
  tft.fillRect(0, 0, SCREEN_WIDTH, 40, TFT_RED);
  tft.drawLine(0, 40, SCREEN_WIDTH, 40, TFT_WHITE);

  tft.setTextColor(TFT_WHITE);
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextDatum(TL_DATUM);
  tft.setCursor(70, 15);
  tft.println("SOS EMERGENCY SYSTEM");

  // State indicator (top-left, Step 19)
  drawStateIndicator();

  // System info
  tft.setTextFont(1);
  tft.setTextSize(1);

  tft.setTextColor(TFT_CYAN);
  tft.setCursor(20, 50);
  tft.printf("Uptime: %lu s", (millis() - systemStartTime) / 1000);

  tft.setCursor(20, 65);
  tft.setTextColor(TFT_WHITE);
  tft.print("Mode: ");
  tft.setTextColor(TFT_YELLOW);
  tft.print("OFFLINE - Local Alerts");

  tft.setCursor(20, 80);
  tft.setTextColor(TFT_WHITE);
  tft.print("Input: ");
  tft.setTextColor(TFT_GREEN);
  tft.print("Button + Touch");

  // Instructions (updated for touch + button controls)
  tft.setTextColor(TFT_YELLOW);
  tft.setCursor(20, 110);
  tft.println("READY FOR EMERGENCY");

  tft.setTextColor(TFT_WHITE);
  tft.setCursor(20, 130);
  tft.println("Press/Tap: Enter SOS menu");
  tft.setCursor(20, 145);
  tft.println("In SOS: tap=Cycle, x2=Call");
  tft.setCursor(20, 160);
  tft.println("Long press:  Configuration");
  tft.setCursor(20, 175);
  tft.println("BOOT+Reset: Recalibrate touch");

  // HUD decoration
  drawHUDCorners(2, 42, SCREEN_WIDTH - 4, SCREEN_HEIGHT - 44, 12, TFT_DARKGREY);

  buzzerActive = false;
  emergencyCallActive = false;
  digitalWrite(BUZZER_PIN, LOW);
}

// ============================================================================
// SOS MENU — Show Service Slide
// ============================================================================
void ShowSlide(Service service)
{
  Serial.printf("Showing service: %d\n", service);
  DrawServiceScreen(service);

  tft.fillRect(0, 180, SCREEN_WIDTH, 45, TFT_BLACK);
  tft.drawLine(0, 180, SCREEN_WIDTH, 180, TFT_WHITE);

  String serviceName;
  uint16_t serviceColor;
  switch (service)
  {
  case AMBULANCE:
    serviceName = "AMBULANCE";
    serviceColor = TFT_RED;
    break;
  case FIRE_ENGINE:
    serviceName = "FIRE DEPARTMENT";
    serviceColor = TFT_ORANGE;
    break;
  case POLICE:
    serviceName = "POLICE";
    serviceColor = TFT_BLUE;
    break;
  case EMERGENCY:
    serviceName = "EMERGENCY";
    serviceColor = TFT_PURPLE;
    break;
  }

  tft.setTextColor(serviceColor);
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextDatum(TL_DATUM);
  tft.setCursor(10, 190);
  tft.println(serviceName);

  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(TFT_YELLOW);
  tft.setCursor(10, 210);
  tft.println("BTN/Touch: Cycle | x2: Call | Hold: Config");

  buzzerActive = false;
  emergencyCallActive = false;
  digitalWrite(BUZZER_PIN, LOW);
}

// ============================================================================
// CONFIG MENU — with slideshow access via long-press (Step 15)
// ============================================================================
void ConfigMenu()
{
  Serial.println("Configuration menu");

  tft.fillScreen(TFT_BLUE);

  // Header
  tft.fillRect(0, 0, SCREEN_WIDTH, 40, TFT_WHITE);
  tft.drawLine(0, 40, SCREEN_WIDTH, 40, TFT_BLACK);
  tft.setTextColor(TFT_BLACK);
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextDatum(TL_DATUM);
  tft.setCursor(90, 15);
  tft.println("CONFIGURATION");

  // State indicator
  drawStateIndicator();

  // Config info box
  tft.drawRect(15, 60, 290, 55, TFT_WHITE);
  tft.setTextColor(TFT_WHITE);
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setCursor(25, 75);
  tft.print("Mode: ");
  tft.setTextColor(TFT_YELLOW);
  tft.println("OFFLINE");

  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(TFT_ORANGE);
  tft.setCursor(25, 95);
  tft.println("Local buzzer alerts only");

  // Instructions (updated for slideshow access)
  tft.setTextColor(TFT_YELLOW);
  tft.setCursor(25, 130);
  tft.println("Short press/Tap: Exit to Main");
  tft.setCursor(25, 145);
  tft.println("Long press: Start Slideshow Demo");
  tft.setCursor(25, 160);
  tft.println("BOOT+Reset: Recalibrate touch");

  // System diagnostics
  tft.setTextColor(TFT_DARKGREY);
  tft.setCursor(25, 175);
  tft.printf("Heap: %u B | CPU: %u MHz", ESP.getFreeHeap(), (unsigned)ESP.getCpuFreqMHz());
  tft.setCursor(25, 190);
  tft.printf("Boot: %d/%d passed | Up: %lu s",
             bootPassed, bootPassed + bootFailed,
             (millis() - systemStartTime) / 1000);
  tft.setCursor(25, 205);
  tft.printf("Touch Z threshold: %d", TOUCH_THRESHOLD);
}

// ============================================================================
// CALL EMERGENCY SERVICE
// ============================================================================
void CallEmergencyService()
{
  Serial.println("Emergency call initiated — OFFLINE MODE");

  currentState = CALLING_SCREEN;
  emergencyCallActive = true;
  callStartTime = millis(); // Step 18: global variable

  const char *serviceName;
  uint16_t serviceColor;
  switch (currentService)
  {
  case AMBULANCE:
    serviceName = "AMBULANCE";
    serviceColor = TFT_RED;
    break;
  case FIRE_ENGINE:
    serviceName = "FIRE DEPT";
    serviceColor = TFT_ORANGE;
    break;
  case POLICE:
    serviceName = "POLICE";
    serviceColor = TFT_BLUE;
    break;
  case EMERGENCY:
    serviceName = "EMERGENCY";
    serviceColor = TFT_PURPLE;
    break;
  }

  tft.fillScreen(serviceColor);

  // State indicator (top-left)
  drawStateIndicator();

  // Warning bar
  tft.fillRect(0, 20, SCREEN_WIDTH, 30, TFT_YELLOW);
  tft.setTextColor(TFT_BLACK);
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextDatum(TL_DATUM);
  tft.setCursor(40, 25);
  tft.println("OFFLINE - LOCAL ALERT ONLY");

  // Central calling circle
  int midX = SCREEN_WIDTH / 2;
  int midY = SCREEN_HEIGHT / 2;
  tft.fillCircle(midX, midY, 60, TFT_WHITE);
  tft.drawCircle(midX, midY, 65, TFT_BLACK);

  tft.setTextColor(TFT_BLACK);
  tft.setTextFont(4);
  tft.setTextSize(1);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("CALLING", midX, midY - 8);

  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.drawString(serviceName, midX, midY + 18);

  // Bottom bar
  tft.fillRect(0, SCREEN_HEIGHT - 30, SCREEN_WIDTH, 30, TFT_BLACK);
  tft.drawLine(0, SCREEN_HEIGHT - 30, SCREEN_WIDTH, SCREEN_HEIGHT - 30, TFT_WHITE);

  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(TFT_RED);
  tft.setTextDatum(TL_DATUM);
  tft.setCursor(10, SCREEN_HEIGHT - 20);
  tft.print("Local alarm only - BTN: Cancel");

  // Activate local buzzer + LED
  digitalWrite(NOTIFICATION_PIN, HIGH);
  buzzerActive = true;
  buzzerToggleTime = millis();

  Serial.printf("LOCAL ALERT: %s | Buzzer: ACTIVE\n", serviceName);
}

// ============================================================================
// BUZZER TOGGLE
// ============================================================================
void ToggleBuzzer()
{
  static bool buzzerState = false;
  buzzerState = !buzzerState;
  digitalWrite(BUZZER_PIN, buzzerState ? HIGH : LOW);
}

// ============================================================================
// DRAW SERVICE SCREEN — bitmap + pattern
// ============================================================================
void DrawServiceScreen(Service service)
{
  uint16_t backgroundColor;
  switch (service)
  {
  case AMBULANCE:
    backgroundColor = TFT_RED;
    break;
  case FIRE_ENGINE:
    backgroundColor = TFT_ORANGE;
    break;
  case POLICE:
    backgroundColor = TFT_BLUE;
    break;
  case EMERGENCY:
    backgroundColor = TFT_PURPLE;
    break;
  }

  tft.fillScreen(backgroundColor);
  DrawBitmapForService(service, backgroundColor);
}

// ============================================================================
// DRAW BITMAP FOR SERVICE — uses Service enum switch (Step 21, replaces strcmp)
// ============================================================================
void DrawBitmapForService(Service service, uint16_t bgColor)
{
  tft.fillScreen(bgColor);

  int centerX = SCREEN_WIDTH / 2;
  int centerY = 90;

  // State indicator (top-left)
  drawStateIndicator();

  // Draw bitmap via Service enum — no more strcmp!
  const unsigned char *bmp = nullptr;
  const char *label = "";
  switch (service)
  {
  case AMBULANCE:
    bmp = ambulanceBitmap;
    label = "AMBULANCE";
    break;
  case FIRE_ENGINE:
    bmp = fireEngineBitmap;
    label = "FIRE DEPT";
    break;
  case POLICE:
    bmp = policeBitmap;
    label = "POLICE";
    break;
  case EMERGENCY:
    bmp = emergencyBitmap;
    label = "EMERGENCY";
    break;
  }

  if (bmp)
  {
    tft.drawBitmap(centerX - 32, centerY - 32, bmp, 64, 64, TFT_WHITE);
  }

  // "SOS" header
  tft.setTextColor(TFT_WHITE);
  tft.setTextFont(4);
  tft.setTextSize(1);
  tft.setTextDatum(TC_DATUM);
  tft.drawString("SOS", centerX, 20);

  // Service name with drop-shadow
  tft.setTextFont(2);
  tft.setTextSize(1);
  tft.setTextDatum(TC_DATUM);
  tft.setTextColor(TFT_BLACK);
  tft.drawString(label, centerX + 1, 161);
  tft.setTextColor(TFT_WHITE);
  tft.drawString(label, centerX, 160);

  // Ready indicator
  tft.setTextFont(1);
  tft.setTextSize(1);
  tft.setTextColor(TFT_YELLOW);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("READY", centerX, centerY + 65);
}
