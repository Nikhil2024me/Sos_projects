#ifndef SOS_WEBSERVER_H
#define SOS_WEBSERVER_H

// ============================================================================
// SOS Web Control Panel (ESPAsyncWebServer)
// Provides a WiFi AP + web interface with 3 buttons to control the display.
// Toggle on/off with the WEBSERVER_ENABLED boolean.
// Non-blocking — no handleClient() needed in loop().
// ============================================================================

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>

// ---- Toggle: set to true to enable, false to disable ----
bool WEBSERVER_ENABLED = false;

// WiFi Access Point credentials
const char *AP_SSID = "SOS_EMERGENCY";
const char *AP_PASS = "sos";

// Async web server on port 80
AsyncWebServer server(80);

// Command flags — polled from loop()
volatile bool webCmdNextService = false;
volatile bool webCmdCallEmergency = false;
volatile bool webCmdMainMenu = false;

// ---- HTML Page ----
const char WEB_PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SOS Control Panel</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #0a0e17;
    color: #e0e0e0;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
  }
  .header {
    text-align: center;
    margin-bottom: 30px;
  }
  .header h1 {
    font-size: 28px;
    font-weight: 700;
    color: #00e5ff;
    letter-spacing: 3px;
  }
  .header h1 span { color: #ffffff; }
  .header p {
    color: #607d8b;
    font-size: 13px;
    margin-top: 6px;
    letter-spacing: 1px;
  }
  .status-bar {
    background: #111827;
    border: 1px solid #1e293b;
    border-radius: 10px;
    padding: 14px 24px;
    width: 100%;
    max-width: 380px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
  }
  .status-dot {
    width: 10px; height: 10px;
    border-radius: 50%;
    background: #22c55e;
    box-shadow: 0 0 8px #22c55e88;
    animation: pulse 2s infinite;
  }
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }
  .status-text { font-size: 13px; color: #94a3b8; }
  .btn-group {
    display: flex;
    flex-direction: column;
    gap: 16px;
    width: 100%;
    max-width: 380px;
  }
  .btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 18px 24px;
    border: 2px solid;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 1px;
    cursor: pointer;
    transition: all 0.2s;
    background: transparent;
    text-transform: uppercase;
  }
  .btn:active { transform: scale(0.97); }
  .btn-next {
    color: #00e5ff;
    border-color: #00e5ff;
  }
  .btn-next:hover { background: #00e5ff18; }
  .btn-call {
    color: #ff1744;
    border-color: #ff1744;
    background: #ff17440a;
  }
  .btn-call:hover { background: #ff174422; box-shadow: 0 0 20px #ff174433; }
  .btn-home {
    color: #66bb6a;
    border-color: #66bb6a;
  }
  .btn-home:hover { background: #66bb6a18; }
  .icon { font-size: 22px; }
  .toast {
    position: fixed;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%) translateY(80px);
    background: #1e293b;
    color: #e0e0e0;
    padding: 12px 28px;
    border-radius: 8px;
    font-size: 14px;
    border: 1px solid #334155;
    opacity: 0;
    transition: all 0.3s;
    pointer-events: none;
  }
  .toast.show {
    transform: translateX(-50%) translateY(0);
    opacity: 1;
  }
  .footer {
    margin-top: auto;
    padding-top: 30px;
    text-align: center;
    color: #334155;
    font-size: 11px;
    letter-spacing: 1px;
  }
</style>
</head>
<body>

<div class="header">
  <h1><span>SOS</span>_AI</h1>
  <p>EMERGENCY CONTROL PANEL</p>
</div>

<div class="status-bar">
  <div style="display:flex;align-items:center;gap:8px;">
    <div class="status-dot"></div>
    <span class="status-text">System Online</span>
  </div>
  <span class="status-text" id="uptime">--</span>
</div>

<div class="btn-group">
  <button class="btn btn-next" onclick="send('/cmd/next','Service cycled')">
    <span class="icon">&#9654;</span> Next Service
  </button>
  <button class="btn btn-call" onclick="send('/cmd/call','Emergency call triggered!')">
    <span class="icon">&#9888;</span> Call Emergency
  </button>
  <button class="btn btn-home" onclick="send('/cmd/home','Returned to Main Menu')">
    <span class="icon">&#8962;</span> Main Menu
  </button>
</div>

<div class="toast" id="toast"></div>

<div class="footer">SOS_AI v2.0 &middot; ESP32-S3</div>

<script>
function send(url, msg) {
  fetch(url).then(r => r.text()).then(() => showToast(msg)).catch(() => showToast('Connection error'));
}
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}
// Uptime counter
let start = Date.now();
setInterval(() => {
  let s = Math.floor((Date.now() - start) / 1000);
  let m = Math.floor(s / 60); s %= 60;
  document.getElementById('uptime').textContent = m + 'm ' + s + 's';
}, 1000);
</script>

</body>
</html>
)rawliteral";

// ---- Route Handlers (async) ----

void webserverSetup()
{
    if (!WEBSERVER_ENABLED)
    {
        Serial.println("[WEB] Web server DISABLED");
        return;
    }

    WiFi.softAP(AP_SSID, AP_PASS);
    IPAddress ip = WiFi.softAPIP();
    Serial.printf("[WEB] AP started — SSID: %s  IP: %s\n", AP_SSID, ip.toString().c_str());

    // Serve main page
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
              { request->send_P(200, "text/html", WEB_PAGE); });

    // Command endpoints
    server.on("/cmd/next", HTTP_GET, [](AsyncWebServerRequest *request)
              {
        webCmdNextService = true;
        request->send(200, "text/plain", "OK");
        Serial.println("[WEB] Next Service command received"); });

    server.on("/cmd/call", HTTP_GET, [](AsyncWebServerRequest *request)
              {
        webCmdCallEmergency = true;
        request->send(200, "text/plain", "OK");
        Serial.println("[WEB] Call Emergency command received"); });

    server.on("/cmd/home", HTTP_GET, [](AsyncWebServerRequest *request)
              {
        webCmdMainMenu = true;
        request->send(200, "text/plain", "OK");
        Serial.println("[WEB] Main Menu command received"); });

    server.begin();
    Serial.println("[WEB] Async HTTP server started on port 80");
}

// No webserverLoop() needed — ESPAsyncWebServer is non-blocking!

#endif // SOS_WEBSERVER_H
