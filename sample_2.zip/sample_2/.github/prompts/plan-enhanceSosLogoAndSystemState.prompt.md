## Plan: Enhance SOS Logo & System Boot

The current `showLogo()` and boot sequence are functional but minimal — the logo has a basic cyan progress bar with a flicker effect, and the boot screen is a linear checklist that can never report failures. Additionally, the state management has several bugs (unreachable states, stuck LED, no service cycling). Here's a comprehensive enhancement plan.

---

### A. Logo Enhancements (`showLogo()` at [sos.ino#L394-L422](sos/sos.ino#L394-L422))

**Current issues:** Single decorative triangle, no border animation, basic linear fill bar, "_AI" flicker is barely perceptible (20ms), no pulsing or fading effects.

**Steps**

1. **Add animated border frame** — draw an expanding rectangle border that "grows" from center outward before any text appears, using `drawRect()` in a loop with increasing dimensions and cyan/white color.

2. **Improve the "SOS" text entrance** — render each letter ("S", "O", "S") sequentially with a short delay between, giving a typewriter effect. Use `drawChar()` or individual `drawString()` calls.

3. **Add a pulsing glow ring** around the "SOS_AI" text — draw concentric circles at `(160, 100)` that expand and fade from cyan to dark, using `drawCircle()` in a timed loop.

4. **Replace the single grey triangle** with symmetric corner brackets (top-left + bottom-right), or a full "tech frame" made of short lines at all four corners — gives a HUD/military aesthetic.

5. **Enhance the progress bar** — replace the flat fill with a segmented bar (draw 24 small blocks of 10px each with 1px gaps). Each block lights up cyan, giving a more tactical look.

6. **Add a "scanning" line effect** — after the bar completes, sweep a single-pixel horizontal line from top to bottom using `drawFastHLine()` in a loop, simulating a system scan before transitioning.

7. **Extend the "_AI" flicker** — increase flicker visibility by alternating between cyan and bright white 3–4 times at the end with 150ms intervals instead of 20ms.

8. **Add version/build info** — display a small version string (e.g., `"v2.0 | ESP32-S3"`) at the bottom of the splash in dark grey, using Font 1.

---

### B. Boot Sequence Enhancements (`setup()` at [sos.ino#L217-L302](sos/sos.ino#L217-L302))

**Current issues:** `SFL` macro is defined but never used; boot steps are cosmetic (no real validation); progress bar is a plain green fill; no memory/hardware diagnostics shown.

**Steps**

9. **Add real hardware validation** — after `pinMode()` calls, read back `BUTTON_PIN` state and verify it's HIGH (pull-up). If not, use the `SFL` macro to display `[FAIL]` in red. This makes the failure path reachable.

10. **Replace the flat green progress bar** with a segmented/stepped bar — draw 5 discrete blocks (one per boot step), each lighting up green on success or red on failure, at y=230.

11. **Add a system info section after boot** — before "SYSTEM READY", display:
    - Free heap: `ESP.getFreeHeap()`
    - Chip model: `ESP.getChipModel()`
    - CPU freq: `ESP.getCpuFreqMHz()`
    This gives a real diagnostic feel.

12. **Animate the "SYSTEM READY" text** — instead of a static `drawCentreString()`, fade in by drawing in progressively lighter colors (dark green → green → cyan → white) with 100ms delays.

13. **Add a brief self-test** — toggle `BUZZER_PIN` HIGH for 50ms and `NOTIFICATION_PIN` HIGH for 50ms during boot to confirm hardware works, then report `[OK]`.

14. **Add a boot failure counter** — track how many steps passed vs failed in variables, and show a summary line like `"5/5 checks passed"` before "SYSTEM READY".

---

### C. State Management Fixes

**Current issues:** `SLIDESHOW_MODE` is unreachable, notification LED never turns off, no way to cycle services, `handleEmergencyTimeout()` has a static variable bug.

**Steps**

15. **Make `SLIDESHOW_MODE` reachable** — call `StartSlideshow()` from `ConfigMenu()` on a double-press or add it as an option. Alternatively, wire a long-press in `CONFIG_MENU` to launch the slideshow.

16. **Fix the notification LED leak** — add `digitalWrite(NOTIFICATION_PIN, LOW)` in both `handleEmergencyTimeout()` (at [sos.ino#L380](sos/sos.ino#L380)) and the `CALLING_SCREEN` cancel branch (at [sos.ino#L355](sos/sos.ino#L355)).

17. **Add service cycling** — change the `SOS_MENU` short-press behavior: first short press cycles to the next service (call `NextSlide()`), and a **double-press** (two presses within 500ms) triggers `CallEmergencyService()`. This makes all four services accessible.

18. **Fix `handleEmergencyTimeout()` static variable** — replace `static unsigned long callStartTime = 0` with a global variable set in `CallEmergencyService()`, eliminating the fragile `== 0` re-entry logic.

19. **Add a visual state indicator** — draw a small colored dot or icon in the top-right corner of every screen indicating the current `SystemState` (e.g., green=MAIN, red=SOS, blue=CONFIG, yellow=CALLING). Helps with debugging and user awareness.

---

### D. Code Cleanup (supporting changes)

20. **Use `SCREEN_WIDTH`/`SCREEN_HEIGHT` constants** — replace the ~20 hardcoded `320` and `240` values throughout the code with the defined constants at [sos.ino#L18-L20](sos/sos.ino#L18-L20).

21. **Replace `strcmp()` dispatch in `DrawBitmapWithTextUnderIt()`** ([sos.ino#L680](sos/sos.ino#L680)) — pass the `Service` enum directly and use a `switch` instead of string comparisons.

22. **Remove dead includes** — remove `#include <TJpg_Decoder.h>` at [sos.ino#L4](sos/sos.ino#L4) (unused) and `#include "calmap.h"` at [sos.ino#L14](sos/sos.ino#L14) (unreferenced).

23. **Fix or replace blank bitmaps** — [bitmap1.h](sos/bitmap1.h) is all zeros, and [bitmap2.h](sos/bitmap2.h), [bitmap3.h](sos/bitmap3.h), [bitmap4.h](sos/bitmap4.h) are stubs. Either generate proper 64x64 monochrome bitmaps for each service, or remove the `drawBitmap()` calls and rely on the `DrawServicePattern()` geometric shapes already implemented.

---

### Verification

- **Visual**: Flash to ESP32-S3, observe the boot sequence completes with segmented bar and system info, logo has animated border + typewriter + scanning effects.
- **State cycling**: Short press cycles through all 4 services in SOS menu; double-press triggers call.
- **LED fix**: After an emergency call times out or is cancelled, verify `NOTIFICATION_PIN` reads LOW.
- **Boot failure**: Disconnect button temporarily — verify `[FAIL]` appears for the button check step.
- **Serial monitor**: Confirm all state transitions log correctly, including slideshow entry/exit.

### Decisions

- **Service cycling via single/double press** over adding a second button — keeps the single-button hardware design.
- **Geometric patterns preferred over broken bitmaps** — `DrawServicePattern()` already works and looks clean; broken bitmap files should either be fixed with real data or removed.
- **Segmented progress bar over gradient** — matches the tactical/HUD aesthetic of the system.
