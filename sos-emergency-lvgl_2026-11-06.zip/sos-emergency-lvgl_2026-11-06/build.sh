#!/usr/bin/env bash
# ============================================================================
#  build.sh - build the SOS Emergency Transmitter firmware
# ============================================================================
#  Usage
#    ./build.sh                 compile the firmware (no board needed)
#    ./build.sh --clean         wipe the build directory first
#    ./build.sh --upload        compile, then upload (needs the board attached)
#    ./build.sh --monitor       open the serial monitor
#    ./build.sh --sim           build + run the headless UI verification
#    ./build.sh --size          print the memory summary after building
#    ./build.sh --doctor        check the toolchain, core and libraries
#    ./build.sh --tft-setup     install tft_setup.h over TFT_eSPI's User_Setup.h
#
#  Everything hardware-specific lives in config/build_env.sh - pin the FQBN,
#  the core version and the library versions there, never in memory.
# ============================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=config/build_env.sh
source "$ROOT/config/build_env.sh"

SKETCH="$ROOT/firmware/sos_emergency"
BUILD_DIR="${SOS_BUILD_DIR:-$ROOT/build}"
ARDUINO_CLI="${ARDUINO_CLI:-arduino-cli}"
ESP32_CORE_VERSION="${ESP32_CORE_VERSION:-3.3.12}"
LVGL_VERSION="${LVGL_VERSION:-9.6.0}"
TFT_ESPI_VERSION="${TFT_ESPI_VERSION:-2.5.43}"

log() { printf '\033[1m==>\033[0m %s\n' "$*"; }
die() { printf '\033[31merror:\033[0m %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# --doctor: prove the toolchain is the one this project was written against
# ---------------------------------------------------------------------------
doctor() {
    command -v "$ARDUINO_CLI" >/dev/null || die "arduino-cli not found"
    log "arduino-cli $("$ARDUINO_CLI" version | awk '{print $3}')"

    "$ARDUINO_CLI" core list 2>/dev/null | grep -q "esp32:esp32.*$ESP32_CORE_VERSION" \
        || die "esp32 core $ESP32_CORE_VERSION missing:
    arduino-cli core update-index
    arduino-cli core install esp32:esp32@$ESP32_CORE_VERSION"

    local libs
    libs="$("$ARDUINO_CLI" lib list 2>/dev/null)"
    grep -q "lvgl .*$LVGL_VERSION" <<<"$libs" || die "lvgl $LVGL_VERSION missing:
    arduino-cli lib install \"lvgl@$LVGL_VERSION\""
    grep -q "TFT_eSPI" <<<"$libs" || die "TFT_eSPI missing:
    arduino-cli lib install \"TFT_eSPI@$TFT_ESPI_VERSION\""

    log "core esp32:esp32@$ESP32_CORE_VERSION, lvgl $LVGL_VERSION, TFT_eSPI $TFT_ESPI_VERSION  OK"
    log "FQBN: $SOS_FQBN"
}

# ---------------------------------------------------------------------------
# --tft-setup: optional library-edit route
# ---------------------------------------------------------------------------
tft_setup() {
    local lib
    lib="$(find "$HOME/.arduino15" "$HOME/Arduino/libraries" -maxdepth 4 -type d -name TFT_eSPI 2>/dev/null | head -1)"
    [[ -n "$lib" ]] || die "TFT_eSPI library not found"
    cp "$SKETCH/tft_setup.h" "$lib/User_Setup.h"
    log "installed tft_setup.h over $lib/User_Setup.h"
    log "NOTE: the sketch-local tft_setup.h takes precedence anyway - keep them identical."
}

# ---------------------------------------------------------------------------
# Flags
# ---------------------------------------------------------------------------
CLEAN=0; DO_UPLOAD=0; DO_MONITOR=0; DO_SIM=0; DO_SIZE=0
for arg in "$@"; do
    case "$arg" in
        --clean)     CLEAN=1 ;;
        --upload)    DO_UPLOAD=1 ;;
        --monitor)   DO_MONITOR=1 ;;
        --sim)       DO_SIM=1 ;;
        --size)      DO_SIZE=1 ;;
        --doctor)    doctor; exit 0 ;;
        --tft-setup) tft_setup; exit 0 ;;
        -h|--help)   sed -n '2,20p' "$0"; exit 0 ;;
        *)           die "unknown option: $arg" ;;
    esac
done

doctor

if [[ $CLEAN -eq 1 ]]; then
    log "cleaning $BUILD_DIR"
    rm -rf "$BUILD_DIR"
fi
mkdir -p "$BUILD_DIR"

# ---------------------------------------------------------------------------
# Compile
# ---------------------------------------------------------------------------
log "compiling $SKETCH"
log "  FQBN: $SOS_FQBN"
log "  UI skin: $SOS_UI_DESIGN"
"$ARDUINO_CLI" compile \
    --fqbn "$SOS_FQBN" \
    --build-path "$BUILD_DIR" \
    --warnings more \
    --build-property "compiler.c.extra_flags=-DSOS_UI_DESIGN=$SOS_UI_DESIGN" \
    --build-property "compiler.cpp.extra_flags=-DSOS_UI_DESIGN=$SOS_UI_DESIGN" \
    --export-binaries \
    "$SKETCH"

log "firmware: $BUILD_DIR/sos_emergency.ino.bin"
ls -l "$BUILD_DIR"/*.bin 2>/dev/null | sed 's/^/  /' || true

if [[ $DO_SIZE -eq 1 ]]; then
    log "memory summary"
    "$ARDUINO_CLI" compile --fqbn "$SOS_FQBN" --build-path "$BUILD_DIR" \
        --build-property "compiler.c.extra_flags=-DSOS_UI_DESIGN=$SOS_UI_DESIGN" \
        --build-property "compiler.cpp.extra_flags=-DSOS_UI_DESIGN=$SOS_UI_DESIGN" \
        "$SKETCH" 2>&1 \
        | grep -Ei "sketch uses|global variables|flash|RAM" | sed 's/^/  /' || true
fi

# ---------------------------------------------------------------------------
# Upload (only meaningful with the board attached)
# ---------------------------------------------------------------------------
if [[ $DO_UPLOAD -eq 1 ]]; then
    log "uploading to $SOS_PORT"
    "$ARDUINO_CLI" upload -p "$SOS_PORT" --fqbn "$SOS_FQBN" \
        --input-dir "$BUILD_DIR" "$SKETCH"
fi

if [[ $DO_MONITOR -eq 1 ]]; then
    log "serial monitor on $SOS_PORT (115200)"
    "$ARDUINO_CLI" monitor -p "$SOS_PORT" -c baudrate=115200
fi

# ---------------------------------------------------------------------------
# Headless UI verification
# ---------------------------------------------------------------------------
if [[ $DO_SIM -eq 1 ]]; then
    log "headless UI verification"
    "$ROOT/tools/sim_build.sh" --run
fi

log "done"
