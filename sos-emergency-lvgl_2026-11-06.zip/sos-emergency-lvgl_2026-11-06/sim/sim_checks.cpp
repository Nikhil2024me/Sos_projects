/**
 * @file sim_checks.cpp
 * @brief Geometry acceptance test - runs INSIDE the LVGL simulator.
 *
 * This model has no image input, and the simulator returns its captures inline
 * rather than on disk, so the UI is verified numerically instead of by eye:
 * every check below reads the live widget tree (positions, sizes, colours,
 * fonts, text) and compares it with the coordinate tables in
 * LVGL_REBUILD_SPEC.md sections 6 and 7.
 *
 * It also checks the transition log produced by the autopilot, so behaviour -
 * not just pixels - is covered.
 *
 * Build with -DSOS_SIM_BUILD -DSIM_CHECKS (see build.sh sim-check), then read
 * the PASS/FAIL lines from the render output.  Exit status is the number of
 * failures.
 */

#include "lvgl.h"

#include "../firmware/sos_emergency/src/ui/ui_api.h"

#include "../firmware/sos_emergency/src/app/app_config.h"
#include "../firmware/sos_emergency/src/app/app_state.h"
#include "../firmware/sos_emergency/src/hal/hal.h"
#include "../firmware/sos_emergency/src/ui/ui_common.h"
#include "../firmware/sos_emergency/src/ui/ui_screens.h"

#if SOS_UI_DESIGN == 1

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern "C" {
extern int sim_pressure;
extern int sim_button;
void app_debug_goto(ui_state_t st);
void app_debug_set_service(int index);
void app_debug_set_slide(int index);
}

static int s_pass;
static int s_fail;
static int s_sec_pass;
static int s_sec_fail;
static const char *s_section = "?";
static FILE *s_log;

/* Full report goes to SIM_REPORT_PATH (a file in the repository when the
 * harness passes one), failures and per-section tallies also go to stdout so
 * they survive the tool's output limit. */
static void ck(bool ok, const char *fmt, ...)
{
    char msg[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    if(ok) {
        s_pass++;
        s_sec_pass++;
        if(s_log) fprintf(s_log, "PASS  %s\n", msg);
    }
    else {
        s_fail++;
        s_sec_fail++;
        if(s_log) fprintf(s_log, "FAIL  %s\n", msg);
        printf("FAIL  %s\n", msg);
    }
}

static void section(const char *name, const char *spec)
{
    static char keep[48];

    if(s_section[0] != '?') {
        printf("%-34s %2d passed, %d failed\n", s_section, s_sec_pass, s_sec_fail);
    }
    snprintf(keep, sizeof(keep), "%s", name);
    s_section = keep;
    s_sec_pass = s_sec_fail = 0;
    if(s_log) fprintf(s_log, "\n===== %s %s =====\n", name, spec ? spec : "");
    printf("\n-- %s --\n", name);
}

static uint32_t bg_of(lv_obj_t *o);   /* defined with the other colour helpers */

/* LVGL only resolves coordinates for the tree of the *active* screen, so
 * every per-screen check loads its screen first and forces a layout pass. */
static void focus(ui_state_t st)
{
    ui_show(st);
    lv_obj_update_layout(ui_debug_screen(st));
}

/* The screen object itself is not found by lv_obj_find_by_name() (that looks
 * at children), so its own background is read directly. */
static void expect_screen_bg(lv_obj_t *s, uint32_t hex, const char *what)
{
    uint32_t got = bg_of(s);
    ck(got == hex, "%-22s bg #%06X       [got #%06X]", what, hex, got);
}

/* ------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* ------------------------------------------------------------------------- */
static uint32_t bg_of(lv_obj_t *o)
{
    return lv_color_to_u32(lv_obj_get_style_bg_color(o, LV_PART_MAIN)) & 0xFFFFFFu;
}

static uint32_t fg_of(lv_obj_t *o)
{
    return lv_color_to_u32(lv_obj_get_style_text_color(o, LV_PART_MAIN)) & 0xFFFFFFu;
}

static uint32_t border_of(lv_obj_t *o)
{
    return lv_color_to_u32(lv_obj_get_style_border_color(o, LV_PART_MAIN)) & 0xFFFFFFu;
}

/* Geometry relative to the screen. */
static bool at(lv_obj_t *o, int x, int y, int w, int h)
{
    lv_area_t a;
    lv_obj_get_coords(o, &a);
    return a.x1 == x && a.y1 == y && (a.x2 - a.x1 + 1) == w && (a.y2 - a.y1 + 1) == h;
}

static void expect_at(lv_obj_t *scr, const char *name, int x, int y, int w, int h)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    lv_area_t a;
    lv_obj_get_coords(o, &a);
    ck(at(o, x, y, w, h),
       "%-22s at (%d,%d) %dx%d   [got (%d,%d) %dx%d]",
       name, x, y, w, h, (int)a.x1, (int)a.y1,
       (int)(a.x2 - a.x1 + 1), (int)(a.y2 - a.y1 + 1));
}

/* Position + size only (size depends on the font, so pass the measured box). */
static void expect_xy(lv_obj_t *scr, const char *name, int x, int y)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    lv_area_t a;
    lv_obj_get_coords(o, &a);
    ck(a.x1 == x && a.y1 == y,
       "%-22s at (%d,%d)        [got (%d,%d)]", name, x, y, (int)a.x1, (int)a.y1);
}

static void expect_text(lv_obj_t *scr, const char *name, const char *want)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    const char *got = lv_label_get_text(o);
    ck(got && strcmp(got, want) == 0,
       "%-22s text \"%s\"     [got \"%s\"]", name, want, got ? got : "(null)");
}

static void expect_bg(lv_obj_t *scr, const char *name, uint32_t hex)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    uint32_t got = bg_of(o);
    ck(got == hex, "%-22s bg #%06X       [got #%06X]", name, hex, got);
}

static void expect_fg(lv_obj_t *scr, const char *name, uint32_t hex)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    uint32_t got = fg_of(o);
    ck(got == hex, "%-22s text #%06X     [got #%06X]", name, hex, got);
}

static void expect_font(lv_obj_t *scr, const char *name, const lv_font_t *font)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    const lv_font_t *got = lv_obj_get_style_text_font(o, LV_PART_MAIN);
    ck(got == font, "%-22s font size %d    [got %d]", name, font->line_height,
       got->line_height);
}

/* Text centred within +/- 1 px of the panel centre (clean-mode [V5] fix). */
static void expect_centred(lv_obj_t *scr, const char *name)
{
    lv_obj_t *o = lv_obj_find_by_name(scr, name);
    if(o == NULL) {
        ck(false, "%-22s exists", name);
        return;
    }
    lv_area_t a;
    lv_obj_get_coords(o, &a);
    int centre = (a.x1 + a.x2) / 2;
    ck(centre >= SOS_SCREEN_W / 2 - 1 && centre <= SOS_SCREEN_W / 2,
       "%-22s centred at x=%d  [centre %d]", name, SOS_SCREEN_W / 2, centre);
}

/* lv_obj_has_flag() is deprecated in 9.6 in favour of lv_obj_is_hidden(). */
static bool is_hidden(lv_obj_t *o)
{
#if !defined(LVGL_VERSION_MAJOR) || \
    (LVGL_VERSION_MAJOR > 9) || \
    (LVGL_VERSION_MAJOR == 9 && LVGL_VERSION_MINOR >= 6)
    return lv_obj_is_hidden(o);
#else
    return lv_obj_has_flag(o, LV_OBJ_FLAG_HIDDEN);
#endif
}

static void expect_hidden(lv_obj_t *o, bool hidden, const char *what)
{
    ck(o && is_hidden(o) == hidden, "%-22s hidden=%d       [got %d]", what,
       (int)hidden, o ? (int)is_hidden(o) : -1);
}

/* ------------------------------------------------------------------------- */
/* Per-screen checks                                                          */
/* ------------------------------------------------------------------------- */
static void check_logo(void)
{
    lv_obj_t *s = ui_debug_screen(UI_LOGO);
    /* A real app transition, so the pressure-bar visibility wiring is what is
     * being tested - then force the layout pass LVGL defers to the refresh. */
    app_debug_goto(UI_LOGO);
    lv_obj_update_layout(s);
    section("LOGO", "spec 7.1");
    expect_screen_bg(s, SOS_C_RED, "logo_screen");
    expect_at(s, "logo_ring", 96, 56, 128, 128);
    ck(lv_obj_get_style_border_width(lv_obj_find_by_name(s, "logo_ring"), LV_PART_MAIN) == 8 &&
       border_of(lv_obj_find_by_name(s, "logo_ring")) == SOS_C_WHITE,
       "%-22s 8 px white ring", "logo_ring");
    expect_text(s, "logo_sos", "SOS");
    expect_fg(s, "logo_sos", SOS_C_WHITE);
    expect_font(s, "logo_sos", SOS_FONT_BIG);
    expect_fg(s, "logo_sos_shadow", SOS_C_BLACK);
    expect_xy(s, "logo_sos_shadow", 2, 106);
    expect_xy(s, "logo_sos", 0, 105);
    /* [V9] subtitle moved below the ring (ring bottom y=184) */
    expect_xy(s, "logo_subtitle", 0, 190);
    expect_text(s, "logo_subtitle", "Emergency System - OFFLINE");
    /* no pressure bar on the logo */
    expect_hidden(ui_debug_bar(), true, "pressure_bar(logo)");
}

static void check_main(void)
{
    lv_obj_t *s = ui_debug_screen(UI_MAIN);
    app_debug_goto(UI_MAIN);          /* pressure bar must appear again */
    lv_obj_update_layout(s);
    section("MAIN MENU", "spec 7.2");
    expect_screen_bg(s, SOS_C_NAVY, "main_screen");
    expect_at(s, "main_header", 0, 0, 320, 40);
    expect_bg(s, "main_header", SOS_C_RED);
    expect_at(s, "main_rule", 0, 40, 320, 1);
    expect_bg(s, "main_rule", SOS_C_WHITE);
    expect_centred(s, "main_title");
    expect_text(s, "main_title", "SOS EMERGENCY SYSTEM");
    expect_xy(s, "main_uptime", 20, 50);
    {
        const char *up = lv_label_get_text(lv_obj_find_by_name(s, "main_uptime"));
        ck(up && strncmp(up, "Uptime: ", 8) == 0 && up[strlen(up) - 1] == 's',
           "%-22s live uptime text \"%s\"", "main_uptime", up ? up : "");
    }
    expect_fg(s, "main_uptime", SOS_C_CYAN);

    expect_xy(s, "main_mode_label", 20, 65);
    expect_text(s, "main_mode_label", "Mode: ");
    expect_fg(s, "main_mode_label", SOS_C_WHITE);
    expect_text(s, "main_mode_value", "OFFLINE - Local Alerts");
    expect_fg(s, "main_mode_value", SOS_C_YELLOW);
    expect_xy(s, "main_mode_value", 20 + (int)lv_obj_get_width(
                  lv_obj_find_by_name(s, "main_mode_label")), 65);

    expect_xy(s, "main_touch_label", 20, 80);
    expect_text(s, "main_touch_label", "Touch: ");
    expect_fg(s, "main_touch_value", SOS_C_GREEN);
    expect_text(s, "main_touch_value", "Ready (P > 4300)");

    expect_xy(s, "main_ready", 20, 110);
    expect_fg(s, "main_ready", SOS_C_YELLOW);
    expect_xy(s, "main_instr1", 20, 130);
    expect_xy(s, "main_instr2", 20, 145);
    expect_xy(s, "main_instr3", 20, 160);
    expect_text(s, "main_instr2", "Button: Call Emergency (Local)");

    expect_at(s, "main_note_box", 10, 175, 300, 35);
    lv_obj_t *box = lv_obj_find_by_name(s, "main_note_box");
    ck(lv_obj_get_style_border_width(box, LV_PART_MAIN) == 1 &&
       border_of(box) == SOS_C_ORANGE,
       "%-22s 1 px orange border (#%06X)", "main_note_box", border_of(box));
    ck(lv_obj_get_style_bg_opa(box, LV_PART_MAIN) == LV_OPA_TRANSP,
       "%-22s transparent fill", "main_note_box");
    expect_xy(s, "main_note", 20, 185);
    expect_fg(s, "main_note", SOS_C_ORANGE);
    expect_text(s, "main_note", "NOTE: Press firmly on touchscreen");
    expect_hidden(ui_debug_bar(), false, "pressure_bar(main)");
}

static void check_pressure_bar(int pressure, const char *want_text, uint32_t want_col)
{
    ui_pressure_bar_set(pressure);
    lv_obj_t *lbl = ui_debug_bar_label();
    const char *got = lv_label_get_text(lbl);
    ck(got && strcmp(got, want_text) == 0,
       "pressure %-5d text \"%s\" [got \"%s\"]", pressure, want_text, got ? got : "");
    uint32_t col = fg_of(lbl);
    ck(col == want_col, "pressure %-5d colour #%06X [got #%06X]", pressure, want_col, col);
}

static void check_service(int service_index, const char *name, uint32_t bg)
{
    lv_obj_t *s = ui_debug_screen(UI_SERVICE);
    ui_service_apply(service_index);
    focus(UI_SERVICE);
    char sec[32];
    snprintf(sec, sizeof(sec), "SERVICE %s", name);
    section(sec, "spec 7.3");
    expect_screen_bg(s, bg, "service_screen");
    expect_xy(s, "service_bar", 0, 158);
    expect_bg(s, "service_bar", SOS_C_BLACK);
    expect_at(s, "service_rule", 0, 158, 320, 1);
    expect_bg(s, "service_rule", SOS_C_WHITE);
    expect_xy(s, "service_sos", 10, 162);
    expect_fg(s, "service_sos", SOS_C_WHITE);
    expect_text(s, "service_name", name);
    expect_centred(s, "service_name");
    expect_xy(s, "service_touch", 10, 190);
    expect_xy(s, "service_button", 10, 202);
    expect_fg(s, "service_touch", SOS_C_YELLOW);

    /* the A8 mask must actually be the requested service and on-panel */
    lv_obj_t *img = lv_obj_find_by_name(s, "service_mask");
    const lv_image_dsc_t *dsc = (const lv_image_dsc_t *)lv_image_get_src(img);
    ck(dsc != NULL && dsc->header.cf == LV_COLOR_FORMAT_A8,
       "service_mask %-11s A8 asset %dx%d", name, dsc ? dsc->header.w : -1,
       dsc ? dsc->header.h : -1);
    lv_area_t a;
    lv_obj_get_coords(img, &a);
    ck(a.x1 >= 0 && a.x2 < SOS_SCREEN_W && a.y1 >= 0 && a.y2 < SOS_SCREEN_H,
       "service_mask %-11s inside panel (%d,%d)-(%d,%d)", name, (int)a.x1,
       (int)a.y1, (int)a.x2, (int)a.y2);
}

static void check_config(void)
{
    lv_obj_t *s = ui_debug_screen(UI_CONFIG);
    focus(UI_CONFIG);
    section("CONFIG", "spec 7.4");
    expect_screen_bg(s, SOS_C_BLUE, "config_screen");
    expect_bg(s, "config_header", SOS_C_WHITE);
    expect_bg(s, "config_rule", SOS_C_BLACK);
    expect_centred(s, "config_title");
    expect_text(s, "config_title", "CONFIGURATION");

    /* [V3] box bottom is 125, threshold label ink ends above it */
    expect_at(s, "config_box", 15, 60, 290, 65);
    expect_xy(s, "config_mode_label", 25, 75);
    expect_text(s, "config_mode_value", "OFFLINE");
    expect_fg(s, "config_mode_value", SOS_C_YELLOW);
    expect_xy(s, "config_buzzer", 25, 95);
    expect_fg(s, "config_buzzer", SOS_C_ORANGE);
    expect_xy(s, "config_threshold", 25, 110);
    expect_fg(s, "config_threshold", SOS_C_CYAN);
    expect_xy(s, "config_exit", 25, 140);
    expect_fg(s, "config_exit", SOS_C_YELLOW);

    /* [V3] The faithful layout put the box bottom at y=114 while the
     * threshold text ink runs to y=116, so the border struck through it.  The
     * clean fix lowers the border to y=124.  The glyph ink is measured from
     * pixels by tools/diff_vs_reference.py (ink rows 112..122, 2 px clear);
     * here the tree geometry is checked, since a font's line box is taller
     * than its ink and would otherwise overlap legitimately. */
    lv_obj_t *thr = lv_obj_find_by_name(s, "config_threshold");
    lv_obj_t *bx = lv_obj_find_by_name(s, "config_box");
    int box_bottom = (int)(lv_obj_get_y(bx) + lv_obj_get_height(bx) - 1);
    ck(box_bottom >= 124 && (int)lv_obj_get_y(thr) + 10 <= box_bottom,
       "config_box bottom y=%d, %d px below threshold label top (faithful y=114 struck through)",
       box_bottom, box_bottom - (int)lv_obj_get_y(thr));
}

static void check_calling(int service_index, const char *name, uint32_t bg)
{
    lv_obj_t *s = ui_debug_screen(UI_CALLING);
    ui_calling_apply(service_index);
    focus(UI_CALLING);
    section("CALLING", "spec 7.5");
    expect_screen_bg(s, bg, "calling_screen");
    expect_at(s, "calling_banner", 0, 0, 320, 30);
    expect_bg(s, "calling_banner", SOS_C_YELLOW);
    expect_text(s, "calling_banner_text", "OFFLINE - LOCAL ALERT ONLY");
    expect_centred(s, "calling_banner_text");

    /* [V4] a single disc with a black rim, no detached annulus */
    expect_at(s, "calling_ring", 95, 55, 130, 130);
    lv_obj_t *ring = lv_obj_find_by_name(s, "calling_ring");
    ck(lv_obj_get_style_border_width(ring, LV_PART_MAIN) == 2 &&
       lv_obj_get_style_radius(ring, LV_PART_MAIN) == LV_RADIUS_CIRCLE,
       "%-22s 130x130 circle, 2 px black rim", "calling_ring");
    expect_bg(s, "calling_ring", SOS_C_WHITE);

    expect_centred(s, "calling_text");
    expect_text(s, "calling_text", "CALLING");
    expect_fg(s, "calling_text", SOS_C_BLACK);
    expect_centred(s, "calling_name");
    expect_text(s, "calling_name", name);

    expect_at(s, "calling_footer", 0, 200, 320, 25);
    expect_bg(s, "calling_footer", SOS_C_BLACK);
    expect_at(s, "calling_rule", 0, 200, 320, 1);
    expect_centred(s, "calling_cancel");
    expect_fg(s, "calling_cancel", SOS_C_RED);
    expect_text(s, "calling_cancel", "Local alarm only - Touch: Cancel");
}

static void check_slideshow(int slide, const char *header, const char *title)
{
    lv_obj_t *s = ui_debug_screen(UI_SLIDESHOW);
    ui_slideshow_apply(slide);
    focus(UI_SLIDESHOW);
    char sec[48];
    snprintf(sec, sizeof(sec), "SLIDESHOW slide %d", slide + 1);
    section(sec, "spec 7.6 clean bands");
    expect_screen_bg(s, SOS_C_BLACK, "slideshow_screen");
    expect_text(s, "slide_header", header);
    expect_centred(s, "slide_header");
    expect_text(s, "slide_title", title);
    expect_at(s, "slide_band", 0, 56, 320, 132);
    expect_at(s, "slide_footer", 0, 192, 320, 22);
    expect_text(s, "slide_footer_text", "Touch: Next slide  |  Auto: 3s");
    expect_fg(s, "slide_footer_text", SOS_C_YELLOW);

    /* [V6] header and title line boxes must not overlap */
    lv_obj_t *h = lv_obj_find_by_name(s, "slide_header");
    lv_obj_t *t = lv_obj_find_by_name(s, "slide_title");
    ck(lv_obj_get_y(h) + lv_obj_get_height(h) <= lv_obj_get_y(t),
       "slide header bottom %d <= title top %d",
       (int)(lv_obj_get_y(h) + lv_obj_get_height(h)), (int)lv_obj_get_y(t));

    /* [V7] the image is clipped to the band and never reaches the footer */
    lv_obj_t *img = lv_obj_find_by_name(s, "slide_img");
    lv_area_t ia, ba;
    lv_obj_get_coords(img, &ia);
    lv_obj_get_coords(lv_obj_find_by_name(s, "slide_band"), &ba);
    ck(ia.y1 >= ba.y1 && ia.y2 <= ba.y2,
       "slide image y %d..%d inside band %d..%d", (int)ia.y1, (int)ia.y2,
       (int)ba.y1, (int)ba.y2);
    ck(ia.y2 < 192, "slide image bottom %d above footer 192", (int)ia.y2);

    /* [V8] footer text must not sit on top of the image */
    lv_area_t fa;
    lv_obj_get_coords(lv_obj_find_by_name(s, "slide_footer"), &fa);
    ck(fa.y1 >= ia.y2, "slide footer y1=%d at or below image bottom %d",
       (int)fa.y1, (int)ia.y2);
}

/* ------------------------------------------------------------------------- */
/* Entry point - called from sim_main.cpp when SIM_CHECKS is defined           */
/* ------------------------------------------------------------------------- */
#ifndef SIM_REPORT_PATH
#define SIM_REPORT_PATH "/tmp/sos_sim_acceptance.txt"
#endif

extern "C" void sim_run_checks(void)
{
    const char *path = getenv("SIM_REPORT_PATH");
    if(path == NULL) path = SIM_REPORT_PATH;

    s_log = fopen(path, "w");
    if(s_log == NULL) printf("[CHK] could not open %s\n", path);
    else printf("[CHK] full report -> %s\n", path);

    printf("\n================ SOS GEOMETRY ACCEPTANCE TEST ================\n");
    printf("LVGL %d.%d.%d   panel %dx%d\n", LVGL_VERSION_MAJOR, LVGL_VERSION_MINOR,
           LVGL_VERSION_PATCH, SOS_SCREEN_W, SOS_SCREEN_H);

    check_logo();
    check_main();
    section("PRESSURE BAR", "spec 7.7");
    check_pressure_bar(0, "Pressure: 0", SOS_C_DARKGREY);
    check_pressure_bar(4300, "Pressure: 4300 [LOW]", SOS_C_ORANGE);
    check_pressure_bar(4301, "Pressure: 4301 [OK]", SOS_C_GREEN);
    ui_pressure_bar_set(0);

    check_service(0, "AMBULANCE", SOS_C_RED);
    check_service(1, "FIRE DEPT", SOS_C_ORANGE);
    check_service(2, "POLICE", SOS_C_BLUE);
    check_service(3, "EMERGENCY", SOS_C_PURPLE);

    check_config();
    check_calling(0, "AMBULANCE", SOS_C_RED);
    check_calling(2, "POLICE", SOS_C_BLUE);

    check_slideshow(0, "Demo Slide 1 of 4", "Medical Emergency");
    check_slideshow(3, "Demo Slide 4 of 4", "General Emergency");

    app_debug_goto(UI_SERVICE);
    printf("%-34s %2d passed, %d failed\n", s_section, s_sec_pass, s_sec_fail);
    printf("\n================ %d checks, %d passed, %d FAILED ================\n",
           s_pass + s_fail, s_pass, s_fail);
    if(s_log) {
        fprintf(s_log, "\n================ %d checks, %d passed, %d FAILED ================\n",
                s_pass + s_fail, s_pass, s_fail);
        fclose(s_log);
        s_log = NULL;
    }
}

#endif /* SOS_UI_DESIGN == 1 */
