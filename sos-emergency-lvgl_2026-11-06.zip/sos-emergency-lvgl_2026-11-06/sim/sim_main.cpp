/**
 * @file sim_main.cpp
 * @brief Headless verification harness for the SOS UI.
 *
 * The simulator calls ui_init().  This file
 *   1. starts the application exactly as the firmware does (app_init()), and
 *   2. optionally runs an "autopilot" that walks the panel through every state
 *      at fixed simulated times, so a single render can capture all of them
 *      via the simulator's `frames` parameter.
 *
 * The autopilot never touches the UI directly - it calls the same entry points
 * the hardware does (app_on_touch() for a valid panel press, and the simulated
 * button line for short/long presses).  Nothing in src/ knows this file exists.
 */

#include "lvgl.h"

#include "../firmware/sos_emergency/src/app/app_state.h"
#include "../firmware/sos_emergency/src/hal/hal.h"
#include "../firmware/sos_emergency/src/ui/ui_screens.h"
#include "../firmware/sos_emergency/src/ui/ui_api.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

extern "C" {
extern int sim_pressure;
extern int sim_button;
}

#if defined(SIM_CHECKS) && SOS_UI_DESIGN == 1
extern "C" void sim_run_checks(void);
#endif

/* ------------------------------------------------------------------------- */
/* Autopilot script                                                           */
/* ------------------------------------------------------------------------- */
enum { ACT_PRESSURE = 0, ACT_TOUCH = 1, ACT_BUTTON = 2 };

typedef struct {
    uint32_t at_ms;
    int      action;
    int      arg;
} sim_step_t;

#if defined(SIM_AUTOPILOT) && SOS_UI_DESIGN == 1
static const sim_step_t STEPS[] = {
    /* Timeline shared with sim/actions.json, which captures at the marked
     * times.  Every event below goes through the same entry point the hardware
     * uses: app_on_touch() for a valid panel press, and the simulated button
     * line for short and long presses. */
    /* t=0..2000: boot logo; the app leaves it by itself (2 s hold) */
    { 2500,  ACT_PRESSURE, 1200 },   /* light touch          -> [LOW]      */
    { 3200,  ACT_PRESSURE, 5200 },   /* firm touch           -> [OK]       */
    { 4200,  ACT_PRESSURE, 0 },      /* released             -> 0          */
    { 5200,  ACT_TOUCH,    0 },      /* MAIN            -> SERVICE ambulance */
    { 5600,  ACT_TOUCH,    0 },      /*                 -> fire dept       */
    { 6000,  ACT_TOUCH,    0 },      /*                 -> police          */
    { 6400,  ACT_TOUCH,    0 },      /*                 -> emergency       */
    { 6800,  ACT_BUTTON,   1 },      /* long press begins ...              */
    { 9000,  ACT_BUTTON,   0 },      /* ... released; CONFIG was entered   */
    { 9300,  ACT_BUTTON,   1 },      /* short press from CONFIG            */
    { 9500,  ACT_BUTTON,   0 },      /*                 -> SLIDESHOW       */
    { 13000, ACT_BUTTON,   1 },      /* long press exits the demo mode ... */
    { 15300, ACT_BUTTON,   0 },      /* ... -> MAIN                        */
    { 15500, ACT_TOUCH,    0 },      /*                 -> SERVICE         */
    { 16000, ACT_BUTTON,   1 },      /* short press     -> CALLING         */
    { 16200, ACT_BUTTON,   0 },
    /* the 5 s call times out by itself at ~21200 ms -> SERVICE */
    { 21700, ACT_BUTTON,   1 },      /* long press ...                     */
    { 23800, ACT_BUTTON,   0 },      /* ... -> CONFIG                      */
    { 24000, ACT_TOUCH,    0 },      /* touch exits CONFIG -> MAIN         */
    { 24100, ACT_BUTTON,   1 },      /* short press on MAIN (clean fix L1) */
    { 24300, ACT_BUTTON,   0 },      /*                 -> CALLING         */
    /* the second call times out at ~29300 ms -> SERVICE */
};

static const unsigned STEPS_N = sizeof(STEPS) / sizeof(STEPS[0]);
static unsigned s_next_step = 0;

static void autopilot_cb(lv_timer_t *t)
{
    LV_UNUSED(t);

    uint32_t now = lv_tick_get();
    while(s_next_step < STEPS_N && STEPS[s_next_step].at_ms <= now) {
        const sim_step_t *s = &STEPS[s_next_step++];
        switch(s->action) {
            case ACT_PRESSURE:
                sim_pressure = s->arg;
                break;
            case ACT_TOUCH:
                app_on_touch();
                break;
            case ACT_BUTTON:
                sim_button = s->arg;
                break;
            default:
                break;
        }
    }
}
#endif /* SIM_AUTOPILOT */

/* ------------------------------------------------------------------------- */
/* Entry point used by the simulator (default entry name: ui_init)             */
/* ------------------------------------------------------------------------- */
extern "C" void ui_init(void)
{
    app_init();

#if defined(SIM_AUTOPILOT) && SOS_UI_DESIGN == 1
    printf("[SIM] autopilot armed (%u steps)\n", STEPS_N);
    lv_timer_create(autopilot_cb, 10, NULL);
#endif

#if defined(SIM_CHECKS) && SOS_UI_DESIGN == 1
    /* One-shot geometry acceptance test.  When it runs is taken from the
     * environment so one binary serves both jobs:
     *   (unset)  no checks - used by the capture run, which stops at 21.5 s
     *   "1000"   run the checks 1 s in - used by the acceptance run
     * SIM_REPORT_PATH likewise selects where the full report is written. */
    const char *at = getenv("SIM_CHECKS_AT_MS");
    if(at != NULL) {
        lv_timer_t *t = lv_timer_create([](lv_timer_t *) { sim_run_checks(); },
                                        (uint32_t)strtoul(at, NULL, 10), NULL);
        lv_timer_set_repeat_count(t, 1);
        lv_timer_set_auto_delete(t, true);
        lv_timer_reset(t);
    }
#endif
}
