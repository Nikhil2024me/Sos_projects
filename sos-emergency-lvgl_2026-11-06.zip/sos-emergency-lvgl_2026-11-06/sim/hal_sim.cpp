/**
 * @file hal_sim.cpp
 * @brief Simulator stand-ins for the board HAL.
 *
 * Compiled INSTEAD of src/hal/hal_esp32.cpp + hal_display.cpp when the project
 * is rendered headlessly.  It implements exactly the same hal.h contract, so
 * app_state.c and the ui/ sources are byte-for-byte the ones that run on the
 * ESP32.
 *
 * Pressure is a settable global (sim_pressure) so the pressure bar's three
 * states can be captured without hardware.
 */

#include "../firmware/sos_emergency/src/hal/hal.h"

#include <stdarg.h>
#include <stdio.h>

int sim_pressure = 0;      /* driven by sim_main.cpp / the render actions */
int sim_button = 0;        /* 0 = released, 1 = pressed                    */

void hal_init(void) {}

void hal_notify_set(bool on)
{
    printf("[HAL] notification pin -> %s\n", on ? "HIGH" : "LOW");
}

void hal_buzzer_set(bool on)
{
    printf("[HAL] buzzer -> %s\n", on ? "ON" : "OFF");
}

bool hal_button_pressed(void)
{
    return sim_button != 0;
}

int hal_touch_pressure(void)
{
    return sim_pressure;
}

int hal_lora_probe(void)
{
    printf("[HAL] SX1278 probe skipped in the simulator\n");
    return -1;
}

void hal_logf(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    printf("[APP] ");
    vprintf(fmt, ap);
    printf("\n");
    va_end(ap);
}
