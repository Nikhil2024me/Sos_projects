# SOS Emergency Transmitter — LVGL 9.6 rebuild

A from-scratch LVGL rebuild of the v2 offline SOS panel, targeting an
**ESP32-S3-WROOM-1 N16R8** with an **ILI9341 2.4" 320×240** panel, an
**XPT2046** resistive touch controller and a **LoRa SX1278** module.

* Baseline: `bitmapwith_touch_beta1.txt` (v2), per `LVGL_REBUILD_SPEC.md`
* Mode: **clean** — visual bugs V1–V9 and logic bugs L1–L10 are fixed, not
  reproduced
* GUI: **LVGL 9.6.0**, 16-bit colour, one partial band draw buffer
* Slideshow: **wired up** (reachable, with the 3 s auto-advance the footer
  promises)

| | |
|---|---|
| Firmware build | `./build.sh` — compiles for `esp32:esp32:esp32s3` |
| Tagged toolchain | arduino-cli 1.5.1, esp32 core **3.3.12**, LVGL **9.6.0**, TFT_eSPI **2.5.43** |
| Headless verification | **185 / 185** geometry checks, **48 / 48** pixel checks |
| Firmware image | **1,112,480 bytes (35%)** of the 3 MB app partition; **115,140 bytes (35%)** of DRAM |
| Flashing | not performed — no board is attached |

---

## Two UI skins, one brain

`SOS_UI_DESIGN` selects the look; behaviour (call lifecycle, timers, buzzer,
notification pin, debounce) lives once in `src/app/app_state.c` and talks to a
skin through `src/ui/ui_api.h`.

| Skin | File | What it is |
|---|---|---|
| **2 (default)** | `src/ui2/ui_v2.c` | **SOS Console** — dark emergency console: gradient service cards with vehicle silhouettes, a hero "armed" screen, pulsing call rings with a 5 s countdown arc, per-widget hit testing, gradients/shadows/animations. |
| 1 | `src/ui/ui_screens.c` | The faithful-geometry rebuild (spec §7 layout, clean-mode fixes). Kept because it is fully verified; `SOS_UI_DESIGN=1` builds it. |

```bash
./build.sh                      # skin 2 (console)
SOS_UI_DESIGN=1 ./build.sh      # skin 1 (faithful rebuild)
SOS_UI_DESIGN=2 tools/sim_build.sh --run    # captures -> screens_v2/
SOS_UI_DESIGN=1 tools/sim_build.sh --run    # captures -> screens/ + 185 checks
```

## What is here

```
firmware/sos_emergency/          Arduino sketch (the whole device build)
├── sos_emergency.ino            setup()/loop(), LVGL tick, boot banner
├── lv_conf.h                    LVGL 9.6 config  (found automatically)
├── tft_setup.h                  TFT_eSPI config (found automatically)
└── src/
    ├── app/app_config.h         pin map, timing constants, palette, options
    ├── app/app_state.c          state machine, timers, input handling
    ├── hal/hal.h                the only boundary to the board
    ├── hal/hal_esp32.cpp        GPIO, buzzer, button, SX1278 probe
    ├── hal/hal_display.cpp      ILI9341 + XPT2046 + the LVGL display/indev
    ├── ui/ui_api.h              the skin contract (events in, screens out)
    ├── ui/ui_common.c           screen/label/rect helpers
    ├── ui/ui_screens.c          skin 1: faithful-geometry rebuild
    ├── ui2/ui_v2.c              skin 2: console redesign
    └── assets/svc_images.c      generated A8 masks (356 KiB)

sim/                             headless verification (never on the device)
├── sim_main.cpp                 ui_init() entry + the autopilot state tour
├── sim_checks.cpp               185-assertion geometry acceptance test
├── actions.json                 the capture schedule (named screenshots)
└── hal_sim.cpp                  stand-ins for the board HAL

tools/
├── sim_build.sh                 private LVGL simulator: build, capture, checks
├── png2lvgl_a8.py               handoff PNGs -> LVGL A8 masks
└── diff_vs_reference.py         pixel assertions against the v2 screenshots

config/build_env.sh              FQBN + toolchain pins (single source of truth)
docs/PINMAP.md                   full pin map, restricted-pin audit, wiring
docs/CLEAN_MODE_FIXES.md         V1–V9 / L1–L10, item by item, with evidence
docs/BUILD.md                    build, verify, flash, troubleshoot
docs/sim_acceptance_report.txt   the last geometry run, verbatim
```

The split that makes this verifiable: **`src/ui/` and `src/app/` include nothing
but LVGL.** No `Arduino.h`, no `TFT_eSPI.h`, no GPIO. Everything that touches
hardware is behind `hal.h`, which has two implementations — the real one for the
ESP32 and a stub for the simulator. The screens rendered by the simulator are
compiled from the same source files the firmware uses.

## Quick start

```bash
./build.sh --doctor      # check arduino-cli, the core and both libraries
./build.sh               # compile the firmware (no board needed)
./build.sh --sim         # compile + render/verify the UI headlessly
tools/sim_build.sh --run --diff    # the full verification, with pixel diffs
```

## Decisions taken (and what they cost)

| Decision | Chosen | Consequence |
|---|---|---|
| Resolution | 320×240, rotation 1 | the real panel. `SCREEN_HEIGHT 200` in v2 was only the touch-Y divisor, and that bug is fixed (L5) |
| LVGL | 9.6.0 | the newest release the Arduino library manager carries; the simulator runs the identical version |
| Mode | clean | V1–V9, L1–L10 fixed. Layout coordinates and all strings are unchanged |
| Slideshow | wired | entry = short button press on the config screen, exit = 2 s long press. A hint line was added so it is discoverable |
| Fonts | Montserrat 14/16/20/24/28 | not pixel-faithful to TFT_eSPI's GLCD/Font16/Font32rle. Spec §5.2 explains what exact fonts would need |
| Button pin | GPIO 1, kept | safe on the S3 (UART0 is 43/44 there), so the hardware does not have to change |
| Buzzer pin | GPIO 33 → **18** | GPIO 33 is an octal-PSRAM line on this module |
| Notification pin | GPIO 25 → **17** | the ESP32-S3 has no GPIO 25 at all |
| TFT pins | SPI2 IO_MUX 11/12/13/10 | see `docs/PINMAP.md`; keeps the bus off the 40 MHz GPIO-matrix ceiling |
| LoRa | pins configured, presence-probed | **no transmit/receive code**: spec feature O10 needs separate approval |

## Verification

Because this model has no image input, and because the `lvgl-simulator` MCP tool
returns captures inline rather than on disk, verification is **numerical**, not
visual — which turns out to be the stronger evidence anyway:

1. **Geometry, 185 checks** (`sim/sim_checks.cpp`, run by `tools/sim_build.sh`).
   Reads the live widget tree and asserts every coordinate, size, colour, font
   and string from spec §7, the pressure bar's three states, the V3/V4/V6/V7/V8
   invariants, and the state-machine log. **185/185 pass.**
2. **Pixels, 48 checks** (`tools/diff_vs_reference.py`). Each rendered screen is
   compared with the v2 handoff screenshot, and every clean-mode fix is asserted
   as a measurement *including proof that the bug is real in the reference*
   (e.g. "reference config border row y=114 carries 40 cyan px; rebuild's row
   y=124 carries 0"). **48/48 pass.**
3. **Similarity table.** Logo 95.1 % identical to v2, main 86.2 %, config
   91.5 % — and the service screens 30–49 %, because clean mode deliberately
   replaces the white plate with a service-coloured screen. Full table in
   `docs/CLEAN_MODE_FIXES.md`.

## Not done

* **Not flashed or run on hardware.** No board is attached. The firmware
  compiles, and the UI is verified in a headless LVGL 9.6 simulator; anything
  that depends on the panel itself (touch calibration, backlight polarity,
  SPI clock margin) can only be confirmed on the bench.
* **No optional features from spec §12** beyond the slideshow wiring and the
  live uptime / auto-advance that clean mode's L-list requires.
* **LoRa is configured, not used.** Pins, bus and a boot-time `RegVersion`
  probe exist. Transmit/receive (O10) requires explicit approval.
