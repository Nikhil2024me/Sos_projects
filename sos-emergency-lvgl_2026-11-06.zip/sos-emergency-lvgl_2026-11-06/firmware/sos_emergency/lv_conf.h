/**
 * @file lv_conf.h
 * @brief LVGL 9.6 configuration for the SOS rebuild.
 *
 * This file is picked up automatically: lv_conf_internal.h does
 * `#if __has_include("lv_conf.h")` and the Arduino sketch directory is on the
 * include path.  It lives in the sketch folder (not under src/) so the
 * headless simulator, which has its own configuration, never sees it.
 *
 * Only the values that actually matter for this panel are set here.  Widgets,
 * draw backends and filesystems are left at LVGL's defaults: the toolchain
 * compiles LVGL with -ffunction-sections/--gc-sections, so unreferenced
 * widgets cost flash only if something links them, and leaving the defaults on
 * keeps the device build identical to the simulator build.
 */

#ifndef LV_CONF_H
#define LV_CONF_H

#include <stdint.h>

/* -------------------------------------------------------------------------
 * Colour and memory
 * ------------------------------------------------------------------------- */
#define LV_COLOR_DEPTH 16

/* LVGL's own heap: widgets, styles, label text.  The draw buffer is owned by
 * the display driver, not by this pool.  The whole UI is ~40 objects, so 64 KB
 * is comfortable; the render reports the peak so it can be trimmed later. */
#define LV_MEM_SIZE (64U * 1024U)

#define LV_USE_OS LV_OS_NONE

/* Object names (lv_obj_set_name) are used by every widget in src/ui/: they make
 * the simulator's diagnostics and annotated captures readable, give the LVGL
 * logs real identifiers on the device, and let the geometry acceptance test in
 * sim/sim_checks.cpp address widgets by name.  Cost is one short allocation per
 * object, freed with the object. */
#define LV_USE_OBJ_NAME 1

/* -------------------------------------------------------------------------
 * Rendering - one partial band buffer, no full framebuffer
 * ------------------------------------------------------------------------- */
#define LV_DEF_REFR_PERIOD 16
#define LV_DPI_DEF 130

/* -------------------------------------------------------------------------
 * Fonts used by the screens
 *   montserrat_14 -> body text   (TFT_eSPI Font 1)
 *   montserrat_16 -> headers     (TFT_eSPI Font 2)
 *   montserrat_20 -> service name on the instruction bar
 *   montserrat_24 -> slideshow header (TFT_eSPI Font 2 @ size 2)
 *   montserrat_28 -> logo "SOS", "CALLING" (TFT_eSPI Font 4)
 * ------------------------------------------------------------------------- */
#define LV_FONT_MONTSERRAT_12 1
#define LV_FONT_MONTSERRAT_14 1
#define LV_FONT_MONTSERRAT_16 1
#define LV_FONT_MONTSERRAT_20 1
#define LV_FONT_MONTSERRAT_24 1
#define LV_FONT_MONTSERRAT_28 1
#define LV_FONT_MONTSERRAT_34 1
#define LV_FONT_DEFAULT &lv_font_montserrat_14

/* -------------------------------------------------------------------------
 * Diagnostics over serial
 * ------------------------------------------------------------------------- */
#define LV_USE_LOG 1
#define LV_LOG_LEVEL LV_LOG_LEVEL_WARN
#define LV_LOG_PRINTF 0

/* -------------------------------------------------------------------------
 * Theme
 * ------------------------------------------------------------------------- */
/* Every screen is created with lv_obj_remove_style_all(), so the default
 * theme's pressed "grow + recolour" transform is never applied: a press is a
 * plain fill with no extra intermediate layer draw.  The theme is kept only so
 * that any future standard widget still looks sane. */
#define LV_USE_THEME_DEFAULT 1
#define LV_THEME_DEFAULT_DARK 0
#define LV_THEME_DEFAULT_GROW 0
#define LV_THEME_DEFAULT_TRANSITION_TIME 0

#endif /* LV_CONF_H */
