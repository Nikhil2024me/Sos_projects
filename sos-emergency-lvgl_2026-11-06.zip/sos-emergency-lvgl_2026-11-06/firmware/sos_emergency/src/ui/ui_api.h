/**
 * @file ui_api.h
 * @brief The contract between the application core and a UI skin.
 *
 * The application (src/app/app_state.c) owns behaviour: the call lifecycle,
 * timers, buzzer, notification pin, debounce, the service list.  It knows
 * nothing about widgets.  A "skin" owns everything visual and implements the
 * functions below; it reports user intent back through the event callback.
 *
 * Two skins exist and are selected at compile time with SOS_UI_DESIGN:
 *
 *   1  src/ui/ui_screens.c   the faithful-geometry rebuild (spec §7 layout,
 *                            clean-mode fixes).  Whole-screen touch, as v2 had.
 *   2  src/ui2/ui_v2.c       the redesign: dark console UI, per-widget hit
 *                            testing, gradients, shadows, animation.
 *
 * Both are pure LVGL, so both render in the headless simulator.
 */

#ifndef SOS_UI_API_H
#define SOS_UI_API_H

#include <stdbool.h>
#include <stdint.h>

/* Application states, mirrored from the spec's SystemState plus the boot logo. */
typedef enum {
    UI_LOGO = 0,
    UI_MAIN,
    UI_SERVICE,
    UI_CONFIG,
    UI_CALLING,
    UI_SLIDESHOW
} ui_state_t;

/* What the user did. */
typedef enum {
    UI_EV_NONE = 0,
    UI_EV_ANY_TAP,      /**< skin 1: the whole screen is the button          */
    UI_EV_SERVICE,      /**< arg = service index: open that service           */
    UI_EV_CALL,         /**< arg = service index: place the call now          */
    UI_EV_CANCEL,       /**< abandon the call                                 */
    UI_EV_CONFIG,       /**< open settings                                    */
    UI_EV_BACK,         /**< back to the home screen                          */
    UI_EV_DEMO,         /**< enter the demo/slideshow                         */
    UI_EV_DEMO_NEXT,    /**< advance one demo slide                           */
    UI_EV_DEMO_EXIT     /**< leave the demo                                   */
} ui_event_t;

typedef void (*ui_event_cb_t)(ui_event_t ev, int arg);

/* ---------------------------------------------------------------------------
 * Implemented by the skin
 * ------------------------------------------------------------------------- */
void ui_build(ui_event_cb_t cb);            /* build every screen once       */
void ui_enter(int state);                   /* show a state, no transition   */
void ui_set_service(int index);             /* loaded service 0..3           */
void ui_set_calling(int index);             /* which service is being called */
void ui_set_slideshow(int index);           /* demo slide 0..3               */
void ui_set_uptime(unsigned long seconds);  /* live uptime label             */
void ui_set_pressure(int z);                /* raw XPT2046 pressure          */
void ui_set_call_progress(int ms_left);     /* 0..5000 while calling         */

/* ---------------------------------------------------------------------------
 * Which skin is compiled in
 * ------------------------------------------------------------------------- */
#ifndef SOS_UI_DESIGN
#define SOS_UI_DESIGN 2
#endif

#if SOS_UI_DESIGN == 1
#define SOS_DESIGN_NAME "v1 faithful-geometry rebuild"
#elif SOS_UI_DESIGN == 2
#define SOS_DESIGN_NAME "v2 console redesign"
#else
#error "SOS_UI_DESIGN must be 1 or 2"
#endif

#endif /* SOS_UI_API_H */