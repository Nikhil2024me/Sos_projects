/**
 * @file ui_common.h
 * @brief Small pure-LVGL helpers shared by every screen.
 *
 * This header and every file under src/ui/ include nothing but LVGL and the C
 * standard library, so the exact same screen code is compiled by the ESP32
 * firmware and by the headless LVGL simulator used for verification.
 */

#ifndef SOS_UI_COMMON_H
#define SOS_UI_COMMON_H

#include "lvgl.h"

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Font roles (spec section 5.2 quick mapping: TFT_eSPI Font 1/2/4 -> Montserrat).
 * "clean mode" keeps the geometry and colours of the original but uses the
 * regular LVGL fonts, so text is centred by measurement instead of by the old
 * fixed 6 px character cell. */
#define SOS_FONT_BODY  (&lv_font_montserrat_14)  /* was Font 1 */
#define SOS_FONT_HEAD  (&lv_font_montserrat_16)  /* was Font 2 */
#define SOS_FONT_NAME  (&lv_font_montserrat_20)
#define SOS_FONT_TITLE (&lv_font_montserrat_24)  /* was Font 2 at size 2 */
#define SOS_FONT_BIG   (&lv_font_montserrat_28)  /* was Font 4 */

/* LVGL 9.6 deprecated lv_obj_add_flag()/lv_obj_clear_flag() in favour of
 * per-flag setters such as lv_obj_set_scrollable().  Use the setters when the
 * headers offer them and fall back to the flag API on 9.5 and earlier, so the
 * sources stay buildable against both without deprecation noise. */
#if !defined(LVGL_VERSION_MAJOR) || \
    (LVGL_VERSION_MAJOR > 9) || \
    (LVGL_VERSION_MAJOR == 9 && LVGL_VERSION_MINOR >= 6)
#define SOS_SET_SCROLLABLE(o, en) lv_obj_set_scrollable((o), (en))
#define SOS_SET_CLICKABLE(o, en)  lv_obj_set_clickable((o), (en))
#define SOS_SET_HIDDEN(o, en)     lv_obj_set_hidden((o), (en))
#else
#define SOS_SET_SCROLLABLE(o, en)                                                    \
    do {                                                                             \
        if(en) lv_obj_add_flag((o), LV_OBJ_FLAG_SCROLLABLE);                         \
        else   lv_obj_clear_flag((o), LV_OBJ_FLAG_SCROLLABLE);                       \
    } while(0)
#define SOS_SET_CLICKABLE(o, en)                                                     \
    do {                                                                             \
        if(en) lv_obj_add_flag((o), LV_OBJ_FLAG_CLICKABLE);                          \
        else   lv_obj_clear_flag((o), LV_OBJ_FLAG_CLICKABLE);                        \
    } while(0)
#define SOS_SET_HIDDEN(o, en)                                                        \
    do {                                                                             \
        if(en) lv_obj_add_flag((o), LV_OBJ_FLAG_HIDDEN);                             \
        else   lv_obj_clear_flag((o), LV_OBJ_FLAG_HIDDEN);                           \
    } while(0)
#endif

/* Screens are opaque, unscrollable, style-free canvases. */
lv_obj_t *sos_screen_create(uint32_t bg_hex);
void sos_screen_set_bg(lv_obj_t *scr, uint32_t bg_hex);

/* Style-free child containers. */
lv_obj_t *sos_rect_create(lv_obj_t *parent, int x, int y, int w, int h,
                          uint32_t bg_hex);
lv_obj_t *sos_panel_create(lv_obj_t *parent, int x, int y, int w, int h,
                           uint32_t bg_hex, int opa);

/* Labels. _center() centres the text inside a full-width box. */
lv_obj_t *sos_label_create(lv_obj_t *parent, const char *text,
                           const lv_font_t *font, uint32_t color_hex,
                           int x, int y);
lv_obj_t *sos_label_center(lv_obj_t *parent, const char *text,
                           const lv_font_t *font, uint32_t color_hex, int y);
lv_obj_t *sos_label_center_in(lv_obj_t *parent, const char *text,
                              const lv_font_t *font, uint32_t color_hex,
                              int x, int y, int w);

/* A "Label: value" line in two colours, at the exact coordinates of the
 * original's two sequential print() calls.  The value is placed immediately
 * after the measured label width, which is what the spec asks for when a
 * proportional font replaces the original fixed-cell font. */
void sos_two_tone_line(lv_obj_t *parent,
                       const char *name_label, const char *name_value,
                       const char *label, uint32_t label_hex,
                       const char *value, uint32_t value_hex,
                       const lv_font_t *font, int x, int y);

/* 1 px separators / full width rules. */
lv_obj_t *sos_hline(lv_obj_t *parent, int y, uint32_t color_hex);

/* White A8 mask, recoloured (clean service/slideshow images). */
lv_obj_t *sos_mask_create(lv_obj_t *parent, const lv_image_dsc_t *dsc,
                          uint32_t color_hex);

#ifdef __cplusplus
}
#endif

#endif /* SOS_UI_COMMON_H */
