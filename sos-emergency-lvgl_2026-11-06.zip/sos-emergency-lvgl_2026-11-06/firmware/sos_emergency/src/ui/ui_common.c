#include "ui_common.h"

#include "../app/app_config.h"

#include <string.h>

lv_obj_t *sos_screen_create(uint32_t bg_hex)
{
    lv_obj_t *scr = lv_obj_create(NULL);
    lv_obj_remove_style_all(scr);
    lv_obj_set_style_bg_color(scr, lv_color_hex(bg_hex), 0);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, 0);
    SOS_SET_SCROLLABLE(scr, false);
    lv_obj_set_size(scr, SOS_SCREEN_W, SOS_SCREEN_H);
    return scr;
}

void sos_screen_set_bg(lv_obj_t *scr, uint32_t bg_hex)
{
    lv_obj_set_style_bg_color(scr, lv_color_hex(bg_hex), 0);
}

lv_obj_t *sos_rect_create(lv_obj_t *parent, int x, int y, int w, int h,
                          uint32_t bg_hex)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_remove_style_all(o);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg_hex), 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    SOS_SET_SCROLLABLE(o, false);
    return o;
}

lv_obj_t *sos_panel_create(lv_obj_t *parent, int x, int y, int w, int h,
                           uint32_t bg_hex, int opa)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_remove_style_all(o);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg_hex), 0);
    lv_obj_set_style_bg_opa(o, (lv_opa_t)opa, 0);
    SOS_SET_SCROLLABLE(o, false);
    return o;
}

lv_obj_t *sos_label_create(lv_obj_t *parent, const char *text,
                           const lv_font_t *font, uint32_t color_hex,
                           int x, int y)
{
    lv_obj_t *l = lv_label_create(parent);
    lv_obj_remove_style_all(l);
    lv_label_set_text(l, text);
    lv_obj_set_style_text_font(l, font, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(color_hex), 0);
    lv_obj_set_pos(l, x, y);
    return l;
}

lv_obj_t *sos_label_center_in(lv_obj_t *parent, const char *text,
                              const lv_font_t *font, uint32_t color_hex,
                              int x, int y, int w)
{
    lv_obj_t *l = sos_label_create(parent, text, font, color_hex, x, y);
    lv_obj_set_width(l, w);
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    return l;
}

lv_obj_t *sos_label_center(lv_obj_t *parent, const char *text,
                           const lv_font_t *font, uint32_t color_hex, int y)
{
    return sos_label_center_in(parent, text, font, color_hex, 0, y,
                               SOS_SCREEN_W);
}

void sos_two_tone_line(lv_obj_t *parent,
                       const char *name_label, const char *name_value,
                       const char *label, uint32_t label_hex,
                       const char *value, uint32_t value_hex,
                       const lv_font_t *font, int x, int y)
{
    lv_obj_t *l = sos_label_create(parent, label, font, label_hex, x, y);
    lv_obj_t *v = sos_label_create(parent, value, font, value_hex, x, y);
    lv_obj_set_name(l, name_label);
    lv_obj_set_name(v, name_value);

    /* Force a layout pass, then butt the value against the measured label.
     * This replaces the original's "chars * 6 px" assumption, which does not
     * hold for a proportional font (spec section 5.3). */
    lv_obj_update_layout(l);
    lv_obj_set_x(v, x + lv_obj_get_width(l));
}

lv_obj_t *sos_hline(lv_obj_t *parent, int y, uint32_t color_hex)
{
    return sos_rect_create(parent, 0, y, SOS_SCREEN_W, 1, color_hex);
}

lv_obj_t *sos_mask_create(lv_obj_t *parent, const lv_image_dsc_t *dsc,
                          uint32_t color_hex)
{
    lv_obj_t *img = lv_image_create(parent);
    lv_obj_remove_style_all(img);
    lv_image_set_src(img, dsc);
    /* An A8 image is pure coverage: paint it in one colour. */
    lv_obj_set_style_image_recolor(img, lv_color_hex(color_hex), 0);
    lv_obj_set_style_image_recolor_opa(img, LV_OPA_COVER, 0);
    return img;
}
