/**
 * @file ui_screens.c
 * @brief Screen construction for the SOS panel (clean mode).
 *
 * Geometry notes
 * --------------
 * Every coordinate the spec fixes (section 7 / appendix B) is kept:
 *   header 0..39, rule y=40, pressure bar 225..239, service instructions at
 *   y=190 and y=202, calling footer at y=200..224, slideshow footer band.
 *
 * Only the items the spec lists as *visual bugs* are moved, and each one is
 * marked [Vn] with the fix taken from spec section 11.1.
 *
 * Every object is named (lv_obj_set_name) so the simulator's diagnostics, its
 * annotated captures and the geometry acceptance test in sim/sim_checks.cpp
 * can address them.
 */

#include "ui_screens.h"

#if SOS_UI_DESIGN == 1

#include "../app/app_config.h"
#include "../assets/svc_images.h"
#include "ui_common.h"

#include <stdio.h>
#include <string.h>

/* ------------------------------------------------------------------------- */
/* Service table - spec section 7.3.  Colours are flat, never theme colours.  */
/* ------------------------------------------------------------------------- */
static const uint32_t SERVICE_BG[4] = {
    SOS_C_RED,      /* AMBULANCE */
    SOS_C_ORANGE,   /* FIRE DEPT */
    SOS_C_BLUE,     /* POLICE    */
    SOS_C_PURPLE,   /* EMERGENCY */
};
static const char *SERVICE_NAME[4] = {
    "AMBULANCE", "FIRE DEPT", "POLICE", "EMERGENCY",
};

/* ------------------------------------------------------------------------- */
/* Slideshow data - spec section 7.6                                          */
/* ------------------------------------------------------------------------- */
static const char *SLIDE_HEADER[4] = {
    "Demo Slide 1 of 4", "Demo Slide 2 of 4",
    "Demo Slide 3 of 4", "Demo Slide 4 of 4",
};
static const char *SLIDE_TITLE[4] = {
    "Medical Emergency", "Fire Emergency",
    "Police Emergency", "General Emergency",
};

/* ------------------------------------------------------------------------- */
/* Clean-mode layout constants                                                */
/* ------------------------------------------------------------------------- */
/* Service screen: the black instruction bar is raised from y=180 to y=158 so
 * the service name can live on a dark plate.  That hides the bitmaps'
 * baked-in labels (ambulance y159..172, police y191..213, fire y200..219) and
 * removes the duplicated / hollow-looking name [V2] without stacking a second
 * overlay on the first.  The spec's instruction coordinates y=190 / y=202 are
 * untouched. */
#define SVC_BAR_Y     158
#define SVC_NAME_Y    162
#define SVC_TOUCH_Y   190
#define SVC_BUTTON_Y  202

/* Calling screen: one white disc with a black border instead of the detached
 * white r=60 + black r=65 pair [V4]. */
#define CALL_RING_X   95
#define CALL_RING_Y   55
#define CALL_RING_W   130

/* Slideshow bands [V6][V7][V8]: header, title, image, footer - no overlap. */
#define SLIDE_HEADER_Y 4
#define SLIDE_TITLE_Y  34
#define SLIDE_IMG_Y    56
#define SLIDE_IMG_H    132
#define SLIDE_FOOT_Y   192
#define SLIDE_FOOT_H   22

/* Config box: bottom raised from 114 to 125 so it no longer strikes through
 * "Touch threshold: 4300" [V3] (spec's own suggested clean fix). */
#define CFG_BOX_H     65

static lv_obj_t *scr_logo;
static lv_obj_t *scr_main;
static lv_obj_t *scr_service;
static lv_obj_t *scr_config;
static lv_obj_t *scr_calling;
static lv_obj_t *scr_slideshow;

/* Widgets that are re-coloured / re-texted at run time. */
static lv_obj_t *srv_mask;
static lv_obj_t *srv_name;
static lv_obj_t *call_name;
static lv_obj_t *slide_header;
static lv_obj_t *slide_title;
static lv_obj_t *slide_img;
static lv_obj_t *main_uptime;
static lv_obj_t *bar;
static lv_obj_t *bar_label;

static ui_event_cb_t s_cb;

/* ------------------------------------------------------------------------- */
/* Helpers                                                                    */
/* ------------------------------------------------------------------------- */
static lv_obj_t *named(lv_obj_t *o, const char *name)
{
    lv_obj_set_name(o, name);
    return o;
}

/* Decorative objects must never swallow the "touch anywhere" gesture. */
static lv_obj_t *decor(lv_obj_t *o)
{
    SOS_SET_CLICKABLE(o, false);
    return o;
}

static lv_obj_t *label(lv_obj_t *parent, const char *name, const char *text,
                       const lv_font_t *font, uint32_t color, int x, int y)
{
    return decor(named(sos_label_create(parent, text, font, color, x, y), name));
}

static lv_obj_t *label_c(lv_obj_t *parent, const char *name, const char *text,
                         const lv_font_t *font, uint32_t color, int x, int y,
                         int w)
{
    return decor(named(sos_label_center_in(parent, text, font, color, x, y, w),
                       name));
}

static lv_obj_t *label_mid(lv_obj_t *parent, const char *name, const char *text,
                           const lv_font_t *font, uint32_t color, int y)
{
    return label_c(parent, name, text, font, color, 0, y, SOS_SCREEN_W);
}

static lv_obj_t *rect(lv_obj_t *parent, const char *name, int x, int y, int w,
                      int h, uint32_t color)
{
    return decor(named(sos_rect_create(parent, x, y, w, h, color), name));
}

/* v2 had no hit boxes: any valid touch means "act".  The handler is attached
 * to the screen object itself, so it fires no matter which input device
 * produced the press (the panel's XPT2046 indev on hardware, the simulator's
 * pointer device during verification). */
static void screen_pressed_cb(lv_event_t *e)
{
    LV_UNUSED(e);
    if(s_cb) s_cb(UI_EV_ANY_TAP, 0);
}

static lv_obj_t *scr(const char *name, uint32_t bg_hex)
{
    lv_obj_t *s = sos_screen_create(bg_hex);
    lv_obj_set_name(s, name);
    SOS_SET_CLICKABLE(s, true);
    lv_obj_add_event_cb(s, screen_pressed_cb, LV_EVENT_PRESSED, NULL);
    return s;
}

/* ------------------------------------------------------------------------- */
/* Boot logo - spec section 7.1                                               */
/* ------------------------------------------------------------------------- */
static void build_logo(void)
{
    scr_logo = scr("logo", SOS_C_RED);

    /* Ring: outer radius 64 / inner radius 56 at centre (160,120). */
    lv_obj_t *ring = rect(scr_logo, "logo_ring", 160 - 64, 120 - 64, 128, 128,
                          SOS_C_RED);
    lv_obj_set_style_radius(ring, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_opa(ring, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_color(ring, lv_color_hex(SOS_C_WHITE), 0);
    lv_obj_set_style_border_width(ring, 8, 0);
    lv_obj_set_style_border_opa(ring, LV_OPA_COVER, 0);

    /* "SOS" with the original 1 px black drop shadow, centred.  The shadow is
     * centred in a box one pixel to the right, so the offset survives without
     * pushing the label off the panel. */
    label_c(scr_logo, "logo_sos_shadow", "SOS", SOS_FONT_BIG, SOS_C_BLACK,
            2, 106, 318);
    label_c(scr_logo, "logo_sos", "SOS", SOS_FONT_BIG, SOS_C_WHITE, 0, 105, 320);

    /* Subtitle below the ring (ring bottom is y=184) instead of across it [V9]. */
    label_mid(scr_logo, "logo_subtitle", "Emergency System - OFFLINE",
              SOS_FONT_HEAD, SOS_C_WHITE, 190);
}

/* ------------------------------------------------------------------------- */
/* Main menu - spec section 7.2                                               */
/* ------------------------------------------------------------------------- */
static void build_main(void)
{
    scr_main = scr("main", SOS_C_NAVY);

    rect(scr_main, "main_header", 0, 0, 320, 40, SOS_C_RED);
    rect(scr_main, "main_rule", 0, 40, 320, 1, SOS_C_WHITE);

    /* Title centred on the panel rather than at the original's x=70 [V5]. */
    label_mid(scr_main, "main_title", "SOS EMERGENCY SYSTEM", SOS_FONT_HEAD,
              SOS_C_WHITE, 13);

    main_uptime = label(scr_main, "main_uptime", "Uptime: 0 s", SOS_FONT_BODY,
                        SOS_C_CYAN, 20, 50);

    sos_two_tone_line(scr_main, "main_mode_label", "main_mode_value",
                      "Mode: ", SOS_C_WHITE,
                      "OFFLINE - Local Alerts", SOS_C_YELLOW,
                      SOS_FONT_BODY, 20, 65);
    sos_two_tone_line(scr_main, "main_touch_label", "main_touch_value",
                      "Touch: ", SOS_C_WHITE,
                      "Ready (P > 4300)", SOS_C_GREEN,
                      SOS_FONT_BODY, 20, 80);

    label(scr_main, "main_ready", "READY FOR EMERGENCY", SOS_FONT_BODY,
          SOS_C_YELLOW, 20, 110);
    label(scr_main, "main_instr1", "Touch screen: Access SOS menu",
          SOS_FONT_BODY, SOS_C_WHITE, 20, 130);
    label(scr_main, "main_instr2", "Button: Call Emergency (Local)",
          SOS_FONT_BODY, SOS_C_WHITE, 20, 145);
    label(scr_main, "main_instr3", "Long press: Configuration",
          SOS_FONT_BODY, SOS_C_WHITE, 20, 160);

    /* NOTE box: orange 1 px outline, transparent fill, at (10,175) 300x35. */
    lv_obj_t *box = rect(scr_main, "main_note_box", 10, 175, 300, 35, SOS_C_WHITE);
    lv_obj_set_style_bg_opa(box, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_color(box, lv_color_hex(SOS_C_ORANGE), 0);
    lv_obj_set_style_border_width(box, 1, 0);

    label(scr_main, "main_note", "NOTE: Press firmly on touchscreen",
          SOS_FONT_BODY, SOS_C_ORANGE, 20, 185);
}

/* ------------------------------------------------------------------------- */
/* Service / SOS menu - spec section 7.3                                      */
/* ------------------------------------------------------------------------- */
static void build_service(void)
{
    scr_service = scr("service", SERVICE_BG[0]);

    /* "clean" image: white vehicle on the service colour.  The A8 mask is the
     * icon variant, cropped to the area the 1-bit source actually paints, so
     * no stray white band from the alpha inversion is dragged in. */
    srv_mask = decor(named(sos_mask_create(scr_service, &svc_mask_ambulance,
                                           SOS_C_WHITE), "service_mask"));
    lv_obj_align(srv_mask, LV_ALIGN_TOP_MID, 0, 0);

    /* Raised black instruction bar; carries the single authoritative name. */
    rect(scr_service, "service_bar", 0, SVC_BAR_Y, 320, SOS_SCREEN_H - SVC_BAR_Y,
         SOS_C_BLACK);
    rect(scr_service, "service_rule", 0, SVC_BAR_Y, 320, 1, SOS_C_WHITE);

    label(scr_service, "service_sos", "SOS", SOS_FONT_NAME, SOS_C_WHITE, 10,
          SVC_NAME_Y);
    srv_name = label_mid(scr_service, "service_name", SERVICE_NAME[0],
                         SOS_FONT_NAME, SOS_C_WHITE, SVC_NAME_Y);

    label(scr_service, "service_touch", "TOUCH: Next Service", SOS_FONT_BODY,
          SOS_C_YELLOW, 10, SVC_TOUCH_Y);
    label(scr_service, "service_button", "BUTTON: Call Emergency", SOS_FONT_BODY,
          SOS_C_YELLOW, 10, SVC_BUTTON_Y);
}

/* ------------------------------------------------------------------------- */
/* Configuration - spec section 7.4                                           */
/* ------------------------------------------------------------------------- */
static void build_config(void)
{
    scr_config = scr("config", SOS_C_BLUE);

    rect(scr_config, "config_header", 0, 0, 320, 40, SOS_C_WHITE);
    rect(scr_config, "config_rule", 0, 40, 320, 1, SOS_C_BLACK);

    /* Title centred rather than at the original's x=90 [V5]. */
    label_mid(scr_config, "config_title", "CONFIGURATION", SOS_FONT_HEAD,
              SOS_C_BLACK, 13);

    lv_obj_t *box = rect(scr_config, "config_box", 15, 60, 290, CFG_BOX_H,
                         SOS_C_WHITE);
    lv_obj_set_style_bg_opa(box, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_color(box, lv_color_hex(SOS_C_WHITE), 0);
    lv_obj_set_style_border_width(box, 1, 0);

    sos_two_tone_line(scr_config, "config_mode_label", "config_mode_value",
                      "Mode: ", SOS_C_WHITE, "OFFLINE", SOS_C_YELLOW,
                      SOS_FONT_HEAD, 25, 75);
    label(scr_config, "config_buzzer", "Local buzzer alerts only", SOS_FONT_BODY,
          SOS_C_ORANGE, 25, 95);
    label(scr_config, "config_threshold", "Touch threshold: 4300", SOS_FONT_BODY,
          SOS_C_CYAN, 25, 110);
    label(scr_config, "config_exit", "Touch anywhere to exit", SOS_FONT_BODY,
          SOS_C_YELLOW, 25, 140);

#if SOS_WIRE_SLIDESHOW && SOS_SLIDESHOW_HINT
    /* New in the rebuild: the slideshow was unreachable in v2 [L6].  Without a
     * hint there is no way for a user to discover the entry gesture. */
    label(scr_config, "config_hint", "Button: Demo slideshow", SOS_FONT_BODY,
          SOS_C_WHITE, 25, 155);
#endif
}

/* ------------------------------------------------------------------------- */
/* Calling - spec section 7.5                                                 */
/* ------------------------------------------------------------------------- */
static void build_calling(void)
{
    scr_calling = scr("calling", SERVICE_BG[0]);

    rect(scr_calling, "calling_banner", 0, 0, 320, 30, SOS_C_YELLOW);
    label_mid(scr_calling, "calling_banner_text", "OFFLINE - LOCAL ALERT ONLY",
              SOS_FONT_HEAD, SOS_C_BLACK, 7);

    /* One disc, black rim - the 4 px colour annulus of the original is gone [V4] */
    lv_obj_t *ring = rect(scr_calling, "calling_ring", CALL_RING_X, CALL_RING_Y,
                          CALL_RING_W, CALL_RING_W, SOS_C_WHITE);
    lv_obj_set_style_radius(ring, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_border_color(ring, lv_color_hex(SOS_C_BLACK), 0);
    lv_obj_set_style_border_width(ring, 2, 0);

    label_mid(scr_calling, "calling_text", "CALLING", SOS_FONT_BIG, SOS_C_BLACK,
              100);
    call_name = label_mid(scr_calling, "calling_name", SERVICE_NAME[0],
                          SOS_FONT_HEAD, SOS_C_BLACK, 138);

    rect(scr_calling, "calling_footer", 0, 200, 320, 25, SOS_C_BLACK);
    rect(scr_calling, "calling_rule", 0, 200, 320, 1, SOS_C_WHITE);
    label_mid(scr_calling, "calling_cancel", "Local alarm only - Touch: Cancel",
              SOS_FONT_BODY, SOS_C_RED, 206);
}

/* ------------------------------------------------------------------------- */
/* Slideshow - spec section 7.6 (clean band redesign)                          */
/* ------------------------------------------------------------------------- */
static void build_slideshow(void)
{
    scr_slideshow = scr("slideshow", SOS_C_BLACK);

    slide_header = label_mid(scr_slideshow, "slide_header", SLIDE_HEADER[0],
                             SOS_FONT_TITLE, SOS_C_WHITE, SLIDE_HEADER_Y);
    slide_title = label_mid(scr_slideshow, "slide_title", SLIDE_TITLE[0],
                            SOS_FONT_HEAD, SOS_C_WHITE, SLIDE_TITLE_Y);

    /* Image band.  Its own box clips the artwork, so nothing overlaps the
     * header or the footer [V6][V7]. */
    lv_obj_t *band = rect(scr_slideshow, "slide_band", 0, SLIDE_IMG_Y, 320,
                          SLIDE_IMG_H, SOS_C_BLACK);
    slide_img = decor(named(sos_mask_create(band, &slide_mask_ambulance,
                                            SOS_C_WHITE), "slide_img"));
    lv_obj_align(slide_img, LV_ALIGN_CENTER, 0, 0);

    /* Footer is a real band below the image, not a black character-cell strip
     * painted across it [V8]. */
    lv_obj_t *foot = rect(scr_slideshow, "slide_footer", 0, SLIDE_FOOT_Y, 320,
                          SLIDE_FOOT_H, 0x101010);
    label_c(foot, "slide_footer_text", "Touch: Next slide  |  Auto: 3s",
            SOS_FONT_BODY, SOS_C_YELLOW, 0, 4, 320);
}

/* ------------------------------------------------------------------------- */
/* Pressure bar - spec section 7.7 (persistent, on lv_layer_top)               */
/* ------------------------------------------------------------------------- */
static void build_pressure_bar(void)
{
    lv_obj_t *top = lv_layer_top();
    lv_obj_remove_style_all(top);
    lv_obj_set_name(top, "layer_top");
    SOS_SET_CLICKABLE(top, false);
    SOS_SET_SCROLLABLE(top, false);

    bar = rect(top, "pressure_bar", 0, 225, 320, 15, SOS_C_BLACK);
    /* The text sits on the layer, aligned to the bar, rather than inside it:
     * a 14 px font's line box is 16 px tall and a 15 px parent would clip it. */
    bar_label = label_c(top, "pressure_label", "Pressure: 0", SOS_FONT_BODY,
                        SOS_C_DARKGREY, 0, 0, 320);
    lv_obj_align_to(bar_label, bar, LV_ALIGN_CENTER, 0, 0);
}

/* ------------------------------------------------------------------------- */
/* Public API                                                                 */
/* ------------------------------------------------------------------------- */
void ui_screens_init(ui_event_cb_t cb)
{
    s_cb = cb;

    build_logo();
    build_main();
    build_service();
    build_config();
    build_calling();
    build_slideshow();
    build_pressure_bar();

    ui_service_apply(0);
    ui_calling_apply(0);
    ui_slideshow_apply(0);
    ui_pressure_bar_set(0);
}

void ui_enter(int st)
{
    ui_show((ui_state_t)st);
}

void ui_build(ui_event_cb_t cb)
{
    ui_screens_init(cb);
}

void ui_set_service(int index)     { ui_service_apply(index); }
void ui_set_calling(int index)     { ui_calling_apply(index); }
void ui_set_slideshow(int index)   { ui_slideshow_apply(index); }
void ui_set_uptime(unsigned long s){ ui_main_set_uptime(s); }
void ui_set_pressure(int z)        { ui_pressure_bar_set(z); }
void ui_set_call_progress(int ms)  { LV_UNUSED(ms); }   /* v1 has no countdown */

void ui_show(ui_state_t st)
{
    /* The faithful layout hides the pressure bar on the boot logo only. */
    ui_pressure_bar_visible(st != UI_LOGO);

    switch(st) {
        case UI_LOGO:      lv_screen_load(scr_logo);      break;
        case UI_MAIN:      lv_screen_load(scr_main);      break;
        case UI_SERVICE:   lv_screen_load(scr_service);   break;
        case UI_CONFIG:    lv_screen_load(scr_config);    break;
        case UI_CALLING:   lv_screen_load(scr_calling);   break;
        case UI_SLIDESHOW: lv_screen_load(scr_slideshow); break;
        default: break;
    }
}

void ui_service_apply(int service_index)
{
    if(service_index < 0 || service_index > 3) return;

    sos_screen_set_bg(scr_service, SERVICE_BG[service_index]);
    lv_image_set_src(srv_mask, sos_gfx[service_index].mask);
    lv_obj_align(srv_mask, LV_ALIGN_TOP_MID, 0, 0);
    lv_label_set_text(srv_name, SERVICE_NAME[service_index]);
}

void ui_calling_apply(int service_index)
{
    if(service_index < 0 || service_index > 3) return;

    sos_screen_set_bg(scr_calling, SERVICE_BG[service_index]);
    lv_label_set_text(call_name, SERVICE_NAME[service_index]);
}

void ui_slideshow_apply(int slide_index)
{
    if(slide_index < 0 || slide_index > 3) return;

    lv_label_set_text(slide_header, SLIDE_HEADER[slide_index]);
    lv_label_set_text(slide_title, SLIDE_TITLE[slide_index]);
    lv_image_set_src(slide_img, sos_gfx[slide_index].slide);
    lv_obj_align(slide_img, LV_ALIGN_CENTER, 0, 0);
}

void ui_main_set_uptime(unsigned long seconds)
{
    lv_label_set_text_fmt(main_uptime, "Uptime: %lu s", seconds);
}

void ui_pressure_bar_set(int pressure)
{
    uint32_t color;
    char text[40];

    if(pressure == 0) {
        color = SOS_C_DARKGREY;
        snprintf(text, sizeof(text), "Pressure: 0");
    }
    else if(pressure > SOS_TOUCH_Z_THRESHOLD) {
        color = SOS_C_GREEN;
        snprintf(text, sizeof(text), "Pressure: %d [OK]", pressure);
    }
    else {
        color = SOS_C_ORANGE;
        snprintf(text, sizeof(text), "Pressure: %d [LOW]", pressure);
    }

    lv_label_set_text(bar_label, text);
    lv_obj_set_style_text_color(bar_label, lv_color_hex(color), 0);
    /* Re-centre: a changing string changes the measured width. */
    lv_obj_align_to(bar_label, bar, LV_ALIGN_CENTER, 0, 0);
}

void ui_pressure_bar_visible(bool visible)
{
    SOS_SET_HIDDEN(bar, !visible);
    SOS_SET_HIDDEN(bar_label, !visible);
}

/* ------------------------------------------------------------------------- */
/* Verification accessors (simulator build only)                               */
/* ------------------------------------------------------------------------- */
#ifdef SOS_SIM_BUILD
lv_obj_t *ui_debug_screen(ui_state_t st)
{
    switch(st) {
        case UI_LOGO:      return scr_logo;
        case UI_MAIN:      return scr_main;
        case UI_SERVICE:   return scr_service;
        case UI_CONFIG:    return scr_config;
        case UI_CALLING:   return scr_calling;
        case UI_SLIDESHOW: return scr_slideshow;
        default:           return NULL;
    }
}

lv_obj_t *ui_debug_bar(void)       { return bar; }
lv_obj_t *ui_debug_bar_label(void) { return bar_label; }
#endif

#endif /* SOS_UI_DESIGN == 1 */
