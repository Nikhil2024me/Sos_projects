/**
 * @file ui_screens.h
 * @brief The six screens of the SOS panel. Pure LVGL - no Arduino, no timers.
 *
 * Screens are built once at start-up and only re-coloured / re-texted
 * afterwards, so navigating never allocates (spec section 10.10).
 */

#ifndef SOS_UI_SCREENS_H
#define SOS_UI_SCREENS_H

#include "lvgl.h"
#include "ui_api.h"

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ui_state_t and the event contract come from ui_api.h. */

/**
 * Build every screen.
 * @param on_touch callback invoked when the user presses anywhere on a screen
 *                 (v2 had no hit boxes - a valid touch means "act").
 */
void ui_screens_init(ui_event_cb_t cb);

/* Load a screen with no transition, exactly like the original's fillScreen(). */
void ui_show(ui_state_t st);

/* Re-colour / re-text the shared screens. */
void ui_service_apply(int service_index);
void ui_calling_apply(int service_index);
void ui_slideshow_apply(int slide_index);
void ui_main_set_uptime(unsigned long seconds);

/* Persistent pressure bar, living on lv_layer_top() so it survives screen
 * changes (spec section 7.7). Hidden on the boot logo. */
void ui_pressure_bar_set(int pressure);
void ui_pressure_bar_visible(bool visible);

/* ------------------------------------------------------------------------- */
/* Verification accessors - compiled only into the simulator harness          */
/* ------------------------------------------------------------------------- */
#ifdef SOS_SIM_BUILD
lv_obj_t *ui_debug_screen(ui_state_t st);
lv_obj_t *ui_debug_bar(void);
lv_obj_t *ui_debug_bar_label(void);
#endif

#ifdef __cplusplus
}
#endif

#endif /* SOS_UI_SCREENS_H */
