/**
 * @file hal_display.cpp
 * @brief ILI9341 + XPT2046 bring-up and the LVGL display/input drivers.
 *
 * Render mode: ONE partial band buffer (the fix that is known to work on this
 * panel).  In LV_DISPLAY_RENDER_MODE_PARTIAL LVGL hands the flush callback the
 * first pixel of the dirty rectangle, so the driver can push w*h pixels
 * contiguously - no stride, no second buffer, no offset bookkeeping.
 *
 * The default theme's pressed "grow + recolour" is not used anywhere: every
 * screen is built with lv_obj_remove_style_all(), so a press is never an extra
 * intermediate layer draw.
 */

#include "hal_display.h"

#include "../app/app_config.h"
#include "hal.h"

#include <Arduino.h>
#include <TFT_eSPI.h>

#include "lvgl.h"

TFT_eSPI tft = TFT_eSPI();

/* Last raw XPT2046 Z.  Read by hal_touch_pressure() on the pressure timer. */
static volatile int s_last_pressure = 0;

static lv_display_t *s_disp;
static lv_indev_t *s_indev;

/* Partial band buffer: 320 * 40 * 2 = 25,600 bytes. */
static uint8_t s_draw_buf[SOS_SCREEN_W * HAL_DRAW_BUF_LINES * 2]
    __attribute__((aligned(4)));

/* ------------------------------------------------------------------------- */
/* Flush                                                                      */
/* ------------------------------------------------------------------------- */
static void flush_cb(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map)
{
    const uint32_t w = (uint32_t)lv_area_get_width(area);
    const uint32_t h = (uint32_t)lv_area_get_height(area);

    /* PARTIAL mode: px_map points at the first pixel of the area and the
     * pixels are contiguous, so this is a straight window + burst write. */
    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, (int32_t)w, (int32_t)h);
    tft.pushPixels((const uint16_t *)px_map, w * h);
    tft.endWrite();

    lv_display_flush_ready(disp);
}

/* ------------------------------------------------------------------------- */
/* Touch                                                                      */
/* ------------------------------------------------------------------------- */
static bool touch_sample(int *x, int *y, int *z)
{
#if SOS_TOUCH_USE_IRQ
    /* T_IRQ is wired on this module (v2 used it too); when it is high the
     * panel is definitely untouched, so skip the SPI traffic entirely. */
    if(digitalRead(PIN_TOUCH_IRQ) == HIGH) {
        *z = 0;
        return false;
    }
#endif

    uint16_t raw_z = tft.getTouchRawZ();
    *z = (int)raw_z;

    if(raw_z <= SOS_TOUCH_Z_THRESHOLD) {
        return false;
    }

    uint16_t rx = 0, ry = 0;
    tft.getTouchRaw(&rx, &ry);
    /* Stock TFT_eSPI calibration + rotation.  Run TFT_eSPI's Touch_Calibrate
     * example if the axes ever look mirrored, then paste the numbers into
     * hal_display.cpp via tft.setTouch(). */
    tft.convertRawXY(&rx, &ry);

    *x = (int)rx;
    *y = (int)ry;
    return true;
}

static void indev_read_cb(lv_indev_t *indev, lv_indev_data_t *data)
{
    LV_UNUSED(indev);

    int x = 0, y = 0, z = 0;
    bool valid = touch_sample(&x, &y, &z);

    s_last_pressure = valid ? z : (z > 0 ? z : 0);

    if(valid) {
        data->point.x = (lv_coord_t)x;
        data->point.y = (lv_coord_t)y;
        data->state = LV_INDEV_STATE_PRESSED;
    }
    else {
        data->state = LV_INDEV_STATE_RELEASED;
    }
}

int hal_touch_pressure(void)
{
    return s_last_pressure;
}

/* ------------------------------------------------------------------------- */
/* Bring-up                                                                   */
/* ------------------------------------------------------------------------- */
void hal_display_init(void)
{
    /* Backlight first, so the panel is lit while it initialises. */
#if SOS_BL_PWM
    ledcAttach(PIN_TFT_BL, 5000, 8);
    ledcWrite(PIN_TFT_BL, SOS_BL_DUTY);
#else
    pinMode(PIN_TFT_BL, OUTPUT);
    digitalWrite(PIN_TFT_BL, HIGH);
#endif

    /* Touch IRQ is an input with a pull-up; the XPT2046 pulls it low. */
    pinMode(PIN_TOUCH_IRQ, INPUT_PULLUP);

    tft.init();
    tft.setRotation(1);              /* landscape 320x240, as the original */
    tft.fillScreen(TFT_BLACK);

    /* Byte order.  LVGL renders RGB565 in native (little-endian) order; the
     * panel wants the high byte first.  tft.setSwapBytes(true) makes
     * pushPixels() swap each pixel on the way out (TFT_eSPI's
     * pushSwapBytePixels path) - the standard TFT_eSPI + LVGL arrangement.
     *
     * The LVGL docs' alternative for external controllers is to make LVGL
     * render pre-swapped instead:
     *     lv_display_set_color_format(s_disp, LV_COLOR_FORMAT_RGB565_SWAPPED);
     * and then leave setSwapBytes(false).  That removes a per-pixel pass, at
     * the cost of a config that only some LVGL draw backends implement.  It is
     * deliberately NOT enabled here: it cannot be bench-tested without the
     * panel, and the two settings swap the image twice if one is changed
     * without the other. */
    tft.setSwapBytes(true);

    /* LVGL display: 320x240, RGB565, one partial band buffer. */
    s_disp = lv_display_create(SOS_SCREEN_W, SOS_SCREEN_H);
    lv_display_set_color_format(s_disp, LV_COLOR_FORMAT_RGB565);
    lv_display_set_flush_cb(s_disp, flush_cb);
    lv_display_set_buffers(s_disp, s_draw_buf, NULL, sizeof(s_draw_buf),
                           LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_default(s_disp);

    /* Pointer input for the resistive panel. */
    s_indev = lv_indev_create();
    lv_indev_set_type(s_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(s_indev, indev_read_cb);
    lv_indev_set_display(s_indev, s_disp);
}
