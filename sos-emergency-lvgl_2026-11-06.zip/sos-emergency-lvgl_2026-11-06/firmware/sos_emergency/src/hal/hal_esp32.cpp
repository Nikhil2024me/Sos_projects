/**
 * @file hal_esp32.cpp
 * @brief Board support for the ESP32-S3-WROOM-1 N16R8 build.
 *
 * Owns: notification output, buzzer, panel button, the SX1278 presence probe
 * and the serial log.  The panel + touch live in hal_display.cpp.
 *
 * The SX1278 sits on its OWN SPI bus (SPI3 / HSPI) so the radio never
 * arbitrates with the panel or the touch controller.  Nothing here transmits:
 * v2 has no LoRa code and the spec lists LoRa TX/RX as optional feature O10,
 * which needs explicit approval.
 */

#include "../app/app_config.h"
#include "hal.h"
#include "hal_display.h"

#include <Arduino.h>
#include <SPI.h>
#include <stdarg.h>

/* Dedicated SPI bus for the radio (ESP32-S3: HSPI == SPI3). */
static SPIClass s_lora_spi(HSPI);

/* ------------------------------------------------------------------------- */
/* Logging                                                                    */
/* ------------------------------------------------------------------------- */
void hal_logf(const char *fmt, ...)
{
    char buf[192];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    Serial.println(buf);
}

/* ------------------------------------------------------------------------- */
/* Notification + buzzer                                                      */
/* ------------------------------------------------------------------------- */
void hal_notify_set(bool on)
{
    digitalWrite(PIN_NOTIFICATION, on ? HIGH : LOW);
}

void hal_buzzer_set(bool on)
{
#if SOS_BUZZER_ACTIVE
    /* Active (self-driving) buzzer: plain on/off, exactly like v2's
     * digitalWrite() toggle every 500 ms. */
    digitalWrite(PIN_BUZZER, on ? HIGH : LOW);
#else
    /* Passive buzzer: switch a square wave on and off. */
    if(on) {
        ledcWriteTone(PIN_BUZZER, SOS_BUZZER_TONE_HZ);
    }
    else {
        ledcWriteTone(PIN_BUZZER, 0);
        digitalWrite(PIN_BUZZER, LOW);
    }
#endif
}

/* ------------------------------------------------------------------------- */
/* Button                                                                     */
/* ------------------------------------------------------------------------- */
bool hal_button_pressed(void)
{
    return digitalRead(PIN_BUTTON) == LOW;
}

/* ------------------------------------------------------------------------- */
/* SX1278 presence probe                                                      */
/* ------------------------------------------------------------------------- */
static uint8_t lora_reg_read(uint8_t addr)
{
    s_lora_spi.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0));
    digitalWrite(PIN_LORA_NSS, LOW);
    s_lora_spi.transfer(addr & 0x7F);       /* bit7 = 0 -> read */
    uint8_t v = s_lora_spi.transfer(0x00);
    digitalWrite(PIN_LORA_NSS, HIGH);
    s_lora_spi.endTransaction();
    return v;
}

int hal_lora_probe(void)
{
#if SOS_LORA_PROBE
    pinMode(PIN_LORA_NSS, OUTPUT);
    digitalWrite(PIN_LORA_NSS, HIGH);
    pinMode(PIN_LORA_RST, OUTPUT);

    /* Hardware reset pulse. */
    digitalWrite(PIN_LORA_RST, LOW);
    delay(2);
    digitalWrite(PIN_LORA_RST, HIGH);
    delay(10);

    const uint8_t version = lora_reg_read(0x42);   /* RegVersion */
    hal_logf("SX1278 RegVersion: 0x%02X (expect 0x12)", version);
    return (version == 0x12) ? 0x12 : -1;
#else
    return -1;
#endif
}

/* ------------------------------------------------------------------------- */
/* Init                                                                       */
/* ------------------------------------------------------------------------- */
void hal_init(void)
{
    /* Human interface pins - the v2 order (outputs first, then the button). */
    pinMode(PIN_NOTIFICATION, OUTPUT);
    pinMode(PIN_BUZZER, OUTPUT);
    pinMode(PIN_BUTTON, INPUT_PULLUP);
    digitalWrite(PIN_NOTIFICATION, LOW);
    digitalWrite(PIN_BUZZER, LOW);

#if !SOS_BUZZER_ACTIVE
    ledcAttach(PIN_BUZZER, SOS_BUZZER_TONE_HZ, 8);
    ledcWrite(PIN_BUZZER, 0);
#endif

    hal_display_init();

    /* Radio bus. */
    s_lora_spi.begin(PIN_LORA_SCLK, PIN_LORA_MISO, PIN_LORA_MOSI, PIN_LORA_NSS);
    pinMode(PIN_LORA_DIO0, INPUT);
}
