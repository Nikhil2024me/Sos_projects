/**
 * @file hal_display.h
 * @brief ESP32-S3 panel + touch bring-up (device only).
 */

#ifndef SOS_HAL_DISPLAY_H
#define SOS_HAL_DISPLAY_H

#ifdef __cplusplus
extern "C" {
#endif

/** tft.init(), rotation, backlight, LVGL display + XPT2046 pointer indev. */
void hal_display_init(void);

/**
 * LVGL flush buffer geometry.  One partial band buffer, exactly as the
 * "known good" fix describes: LVGL hands the flush callback the first pixel of
 * the dirty area, so the driver pushes w*h pixels contiguously.
 */
#define HAL_DRAW_BUF_LINES 40

#ifdef __cplusplus
}
#endif

#endif /* SOS_HAL_DISPLAY_H */
