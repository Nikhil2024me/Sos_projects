/**
 * @file hal.h
 * @brief The only boundary between the portable application code and the board.
 *
 * Two implementations exist:
 *   firmware/sos_emergency/src/hal/hal_esp32.cpp  - real GPIO / XPT2046 / SX1278
 *   sim/hal_sim.cpp                               - headless stand-ins, so the
 *                                                   very same ui/ + app/ sources
 *                                                   can be rendered and diffed
 *                                                   by the LVGL simulator.
 */

#ifndef SOS_HAL_H
#define SOS_HAL_H

#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Configure every pin / bus this module owns. Called once from setup(). */
void hal_init(void);

/** Notification output.  v2 never drove it LOW again (spec issue L2). */
void hal_notify_set(bool on);

/** Buzzer.  Active type: plain on/off.  Passive type: an LEDC tone. */
void hal_buzzer_set(bool on);

/** True while the panel button is held (INPUT_PULLUP, active LOW). */
bool hal_button_pressed(void);

/** Last raw XPT2046 Z reading; 0 when the panel is not touched. */
int hal_touch_pressure(void);

/**
 * Read the SX1278 version register (0x42).
 * @return 0x12 on a present SX1278, -1 if it did not answer.
 *
 * This is a *presence probe only*.  v2 has no LoRa code and the spec lists
 * LoRa transmit/receive as optional feature O10, which needs explicit
 * approval, so nothing here transmits or joins a network.
 */
int hal_lora_probe(void);

/** printf-style logging (Serial on hardware, stdout in the simulator). */
void hal_logf(const char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif /* SOS_HAL_H */
