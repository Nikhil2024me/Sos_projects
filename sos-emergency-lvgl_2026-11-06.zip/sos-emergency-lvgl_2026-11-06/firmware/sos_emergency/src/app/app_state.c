/**
 * @file app_state.c
 * @brief State machine, timers and input handling.
 *
 * Everything runs on LVGL timers and lv_tick_get(), so the identical logic is
 * exercised by the on-device firmware and by the headless simulator (spec
 * section 10.9 lists exactly these timers).
 *
 * Clean-mode behaviour changes are tagged [Ln] with the fix from spec 11.2.
 */

#include "app_state.h"

#include "app_config.h"
#include "../hal/hal.h"
#include "../ui/ui_api.h"

/* The core runs on LVGL timers and the tick, so it needs LVGL itself; the
 * ui_api.h contract stays LVGL-free so a skin can be swapped without it. */
#include "lvgl.h"

static void any_tap_dispatch(void);

#include <stdbool.h>
#include <string.h>

static ui_state_t state = UI_LOGO;
static int service_index = 0;   /* AMBULANCE */
static int slide_index = 0;

static bool call_active = false;
static bool buzzer_level = false;

static lv_timer_t *t_pressure;
static lv_timer_t *t_button;
static lv_timer_t *t_uptime;
static lv_timer_t *t_call;
static lv_timer_t *t_buzzer;
static lv_timer_t *t_slide;
static lv_timer_t *t_logo;
static lv_timer_t *t_progress;
static uint32_t call_start_ms;

static uint32_t last_touch_ms;
static uint32_t last_button_release_ms;
static uint32_t press_start_ms;
static bool long_press_done;
static bool button_was_down;
static int last_pressure = -1;

/* ------------------------------------------------------------------------- */
/* Forward declarations                                                       */
/* ------------------------------------------------------------------------- */
static void app_enter(ui_state_t next);
static void call_start(void);
static void call_end(void);
static void slideshow_start(void);
static void slideshow_stop(void);

/* ------------------------------------------------------------------------- */
/* Timers                                                                     */
/* ------------------------------------------------------------------------- */
static void pressure_cb(lv_timer_t *t)
{
    LV_UNUSED(t);

    int z = hal_touch_pressure();
    /* v2 only redrew when the value changed (spec 7.7). */
    if(z != last_pressure) {
        last_pressure = z;
        ui_set_pressure(z);
    }
}

static void uptime_cb(lv_timer_t *t)
{
    LV_UNUSED(t);
    /* [L8] the original drew the uptime once, so it stayed frozen until the
     * screen was re-entered.  This derives it from the tick, exactly like v2's
     * millis()/1000 did, so it cannot drift. */
    ui_set_uptime((unsigned long)(lv_tick_get() / 1000u));
}

static void buzzer_cb(lv_timer_t *t)
{
    LV_UNUSED(t);
    buzzer_level = !buzzer_level;         /* 500 ms square wave, as v2 */
    hal_buzzer_set(buzzer_level);
}

static void call_timeout_cb(lv_timer_t *t)
{
    LV_UNUSED(t);
    hal_logf("Emergency call completed");
    call_end();
    app_enter(UI_SERVICE);                /* [L3] a real one-shot, no statics */
}

/* Drives ui_set_call_progress() at 20 Hz only while a call is running, so the
 * countdown arc stays smooth without a per-frame cost when idle. */
static void call_progress_cb(lv_timer_t *t)
{
    LV_UNUSED(t);
    int32_t left = (int32_t)SOS_CALL_DURATION_MS -
                   (int32_t)((uint32_t)(lv_tick_get() - call_start_ms));
    ui_set_call_progress(left < 0 ? 0 : (int)left);
}

static void slideshow_auto_cb(lv_timer_t *t)
{
    LV_UNUSED(t);
    slide_index = (slide_index + 1) % 4;
    ui_set_slideshow(slide_index);
    hal_logf("Auto-advance to slide %d", slide_index + 1);   /* [L7] */
}

static void logo_hold_cb(lv_timer_t *t)
{
    LV_UNUSED(t);
    lv_timer_delete(t_logo);
    t_logo = NULL;
    app_enter(UI_MAIN);
    hal_logf("=== System Ready ===");
}

static void button_cb(lv_timer_t *t)
{
    LV_UNUSED(t);

    bool down = hal_button_pressed();
    uint32_t now = lv_tick_get();

    if(down && !button_was_down) {          /* HIGH -> LOW edge */
        press_start_ms = now;
        long_press_done = false;
    }

    if(down && !long_press_done &&
       (uint32_t)(now - press_start_ms) >= SOS_LONG_PRESS_MS) {
        long_press_done = true;
        /* [L6] The slideshow is a self-contained demo mode: it is entered from
         * the config screen and its long press returns straight to the main
         * menu, instead of dropping into the config screen and requiring a
         * second touch to get out.  Everywhere else the long press is the
         * documented route to the configuration screen.
         * [L4] app_enter() ends a call (buzzer + notification pin) on the way
         * out, whatever the target, so a long press can no longer leave a call
         * running in the background. */
        if(state == UI_SLIDESHOW) {
            hal_logf("Button: Long press - leaving slideshow");
            app_enter(UI_MAIN);
        }
        else {
            hal_logf("Button: Long press - Config menu");
            app_enter(UI_CONFIG);
        }
    }

    if(!down && button_was_down && !long_press_done &&
       (uint32_t)(now - last_button_release_ms) >= SOS_BUTTON_DEBOUNCE_MS) {
        last_button_release_ms = now;
        switch(state) {
            case UI_MAIN:
                /* [L1] the menu says "Button: Call Emergency (Local)" but v2
                 * did nothing here.  The text is part of the fixed string
                 * inventory, so the behaviour is what gets fixed. */
                hal_logf("Button: Calling emergency service from main menu");
                call_start();
                break;
            case UI_SERVICE:
                hal_logf("Button: Calling emergency service");
                call_start();
                break;
            case UI_CONFIG:
#if SOS_WIRE_SLIDESHOW
                /* [L6] the only route into the demo slideshow. */
                hal_logf("Button: Starting demo slideshow");
                slideshow_start();
#endif
                break;
            default:
                break;
        }
    }

    button_was_down = down;
}

/* ------------------------------------------------------------------------- */
/* Transitions                                                                */
/* ------------------------------------------------------------------------- */
static void slideshow_start(void)
{
    slide_index = 0;
    ui_set_slideshow(slide_index);
    app_enter(UI_SLIDESHOW);
}

static void slideshow_stop(void)
{
    if(t_slide) {
        lv_timer_delete(t_slide);
        t_slide = NULL;
    }
}

static void call_start(void)
{
    hal_logf("Starting local emergency call for service %d", service_index);

    call_active = true;
    buzzer_level = false;
    hal_buzzer_set(false);
    hal_notify_set(true);                 /* v2 held this HIGH for the call */

    ui_set_calling(service_index);
    app_enter(UI_CALLING);

    if(t_call == NULL) {
        t_call = lv_timer_create(call_timeout_cb, SOS_CALL_DURATION_MS, NULL);
    }
    lv_timer_reset(t_call);
    lv_timer_set_repeat_count(t_call, 1); /* true one-shot */

    if(t_buzzer == NULL) {
        t_buzzer = lv_timer_create(buzzer_cb, SOS_BUZZER_TOGGLE_MS, NULL);
    }
    lv_timer_reset(t_buzzer);

    call_start_ms = lv_tick_get();
    if(t_progress == NULL) {
        t_progress = lv_timer_create(call_progress_cb, 50, NULL);
    }
    lv_timer_reset(t_progress);
}

static void call_end(void)
{
    call_active = false;

    if(t_call)     { lv_timer_delete(t_call);     t_call = NULL; }
    if(t_buzzer)   { lv_timer_delete(t_buzzer);   t_buzzer = NULL; }
    if(t_progress) { lv_timer_delete(t_progress); t_progress = NULL; }

    buzzer_level = false;
    hal_buzzer_set(false);
    hal_notify_set(false);                /* [L2] v2 left the pin HIGH forever */
}

static void app_enter(ui_state_t next)
{
    /* [L4] leaving the calling state by any route always ends the call. */
    if(next != UI_CALLING && call_active) {
        call_end();
    }
    if(next != UI_SLIDESHOW) {
        slideshow_stop();
    }
    if(next != UI_MAIN && t_uptime) {
        lv_timer_delete(t_uptime);
        t_uptime = NULL;
    }

    state = next;
    ui_enter((int)next);

    switch(next) {
        case UI_LOGO:
            break;

        case UI_MAIN:
            ui_set_uptime((unsigned long)(lv_tick_get() / 1000u));
            if(t_uptime == NULL) {
                t_uptime = lv_timer_create(uptime_cb, 1000, NULL);
            }
            break;

        case UI_SERVICE:
            ui_set_service(service_index);
            break;

        case UI_CALLING:
            break;

        case UI_SLIDESHOW:
            if(t_slide == NULL) {
                t_slide = lv_timer_create(slideshow_auto_cb, SOS_AUTO_SLIDE_MS, NULL);
            }
            lv_timer_reset(t_slide);
            break;

        case UI_CONFIG:
        default:
            break;
    }

    /* v2 forced a pressure repaint on every screen change. */
    last_pressure = -1;
}

/* ------------------------------------------------------------------------- */
/* Touch                                                                      */
/* ------------------------------------------------------------------------- */
/* Skin 1 reports "the whole screen was tapped"; skin 2 reports what the user
 * actually pressed.  Both funnel into one behaviour table. */
void app_on_event(ui_event_t ev, int arg)
{
    uint32_t now = lv_tick_get();

    /* Only the whole-screen skin needs the 300 ms debounce: a widget press is
     * already a deliberate act, and the button scan has its own debounce. */
    if(ev == UI_EV_ANY_TAP) {
        if((uint32_t)(now - last_touch_ms) < SOS_TOUCH_DEBOUNCE_MS) return;
        last_touch_ms = now;
    }

    switch(ev) {
        case UI_EV_ANY_TAP:
            any_tap_dispatch();
            break;

        case UI_EV_SERVICE:
            if(arg >= 0 && arg < 4) service_index = arg;
            hal_logf("Touch: Going to SOS menu");
            app_enter(UI_SERVICE);
            break;

        case UI_EV_CALL:
            if(arg >= 0 && arg < 4) service_index = arg;
            hal_logf("Button: Calling emergency service");
            call_start();
            break;

        case UI_EV_CANCEL:
            if(state == UI_CALLING) {
                hal_logf("Touch: Cancelling emergency call");
                call_end();
                app_enter(UI_SERVICE);
            }
            break;

        case UI_EV_CONFIG:
            hal_logf("Touch: Opening configuration");
            app_enter(UI_CONFIG);
            break;

        case UI_EV_BACK:
            hal_logf("Touch: Back to main menu");
            app_enter(UI_MAIN);
            break;

        case UI_EV_DEMO:
            hal_logf("Touch: Starting demo slideshow");
            slideshow_start();
            break;

        case UI_EV_DEMO_NEXT:
            if(state == UI_SLIDESHOW) {
                slide_index = (slide_index + 1) % 4;
                ui_set_slideshow(slide_index);
                if(t_slide) lv_timer_reset(t_slide);
            }
            break;

        case UI_EV_DEMO_EXIT:
            app_enter(UI_MAIN);
            break;

        default:
            break;
    }
}

void app_on_touch(void)
{
    app_on_event(UI_EV_ANY_TAP, 0);
}

/* Skin 1's whole-screen semantics, kept exactly as verified. */
static void any_tap_dispatch(void)
{
    switch(state) {
        case UI_MAIN:
            hal_logf("Touch: Going to SOS menu");
            app_enter(UI_SERVICE);
            break;

        case UI_SERVICE:
            service_index = (service_index + 1) % 4;   /* [L10] no dead helpers */
            hal_logf("Touch: Next service");
            ui_set_service(service_index);
            break;

        case UI_CONFIG:
            hal_logf("Touch: Exiting config");
            app_enter(UI_MAIN);
            break;

        case UI_CALLING:
            hal_logf("Touch: Cancelling emergency call");
            call_end();
            app_enter(UI_SERVICE);
            break;

        case UI_SLIDESHOW:
            hal_logf("Touch: Next slide");
            slide_index = (slide_index + 1) % 4;
            ui_set_slideshow(slide_index);
            if(t_slide) lv_timer_reset(t_slide);       /* manual touch restarts */
            break;

        case UI_LOGO:
        default:
            break;
    }
}

ui_state_t app_state(void)
{
    return state;
}

#ifdef SOS_SIM_BUILD
/* Verification hooks.  Compiled only when the simulator harness builds this
 * file (-DSOS_SIM_BUILD); the firmware never sees them. */
void app_debug_goto(ui_state_t st)
{
    app_enter(st);
}

void app_debug_set_service(int index)
{
    if(index < 0 || index > 3) return;
    service_index = index;
    ui_set_service(service_index);
}

void app_debug_set_slide(int index)
{
    if(index < 0 || index > 3) return;
    slide_index = index;
    ui_set_slideshow(slide_index);
}
#endif

/* ------------------------------------------------------------------------- */
/* Start-up                                                                   */
/* ------------------------------------------------------------------------- */
void app_init(void)
{
    ui_build(app_on_event);

    /* Spec 10.9: pressure 1000 ms, button scan 10 ms.  Touch is event driven
     * (the screen's LV_EVENT_PRESSED) rather than polled at 50 ms - the same
     * 300 ms debounce applies, without the extra wake-ups. */
    t_pressure = lv_timer_create(pressure_cb, SOS_PRESSURE_MS, NULL);
    t_button   = lv_timer_create(button_cb, 10, NULL);

    app_enter(UI_LOGO);
    t_logo = lv_timer_create(logo_hold_cb, SOS_LOGO_HOLD_MS, NULL);
}
