/**
 * @file app_state.h
 * @brief Event table, state machine and timers (spec sections 6 and 10.7/10.9).
 */

#ifndef SOS_APP_STATE_H
#define SOS_APP_STATE_H

#include "../ui/ui_api.h"

#ifdef __cplusplus
extern "C" {
#endif

/** Build the UI, arm the periodic timers and enter the boot logo. */
void app_init(void);

/** Skin events: UI_EV_ANY_TAP for the whole-screen skin, or a specific
 *  widget press for the console skin. */
void app_on_event(ui_event_t ev, int arg);

/** v1 compatibility: same as app_on_event(UI_EV_ANY_TAP, 0). */
void app_on_touch(void);

/** Current state (used by the simulator harness and the boot banner). */
ui_state_t app_state(void);

#ifdef __cplusplus
}
#endif

#endif /* SOS_APP_STATE_H */
