/**
 * @file app_config.h
 * @brief Board pin map, timing constants and palette for the SOS LVGL rebuild.
 *
 * Target hardware (confirmed by the user):
 *   MCU    : ESP32-S3-WROOM-1 **N16R8** (16 MB quad flash + 8 MB *octal* PSRAM)
 *   Panel  : ILI9341 2.4" 320x240 SPI, rotation 1 (landscape)
 *   Touch  : XPT2046 resistive, shares the panel SPI bus
 *   Radio  : LoRa SX1278 (Ra-02 style: NSS/RST/DIO0 + SPI), own SPI bus
 *
 * ============================================================================
 * WHY THE v2 PIN MAP COULD NOT BE KEPT
 * ============================================================================
 * The v2 sketch (source/bitmapwith_touch_beta1.txt) was written for a classic
 * ESP32 and used BUTTON=1, NOTIFICATION=25, BUZZER=33, TOUCH_IRQ=16, TOUCH_CS=5.
 * On an ESP32-S3-WROOM-1 N16R8:
 *
 *   - GPIO 25 does not exist on the ESP32-S3 at all (the S3 has GPIO0-21 and
 *     GPIO26-48).  -> NOTIFICATION had to move.
 *   - GPIO 33 is one of the octal-PSRAM data lines (DQ4) on R8/R16V modules and
 *     is not usable.  -> BUZZER had to move.
 *   - GPIO 26..32 are the in-package flash/PSRAM SPI0/1 lines: never use.
 *   - GPIO 34..37 are also octal-PSRAM lines (DQ5/DQ6/DQ7/DQS); 33/34 are not
 *     even brought out on the WROOM-1 module.
 *   - GPIO 19/20 are USB_D-/USB_D+: reserved here so USB-Serial/JTAG keeps
 *     working for flashing and the serial monitor.
 *   - GPIO 0/3/45/46 are strapping pins: avoided.
 *   - GPIO 39..42 are the JTAG pins: left free for debugging.
 *   - GPIO 43/44 are UART0: left free so a plain UART bridge still works.
 *
 * BUTTON=1 and TOUCH_CS=5 and TOUCH_IRQ=16 *are* valid on the S3, so they are
 * kept exactly as v2 had them.  (Spec issue L9 - "GPIO 1 is UART0 TX" - is a
 * classic-ESP32 problem: UART0 on the S3 is GPIO43/44, so GPIO1 is safe here.)
 *
 * ============================================================================
 * SPI BUS LAYOUT
 * ============================================================================
 *   SPI2 (FSPI) - panel + touch, pins 11/12/13 are the S3's SPI2 IO_MUX pins
 *                 (MOSI/SCLK/MISO).  CS is on GPIO10, which is the SPI2 IO_MUX
 *                 CS0 pad, so the whole bus stays on IO_MUX and is not limited
 *                 to the ~40 MHz GPIO-matrix ceiling.
 *   SPI3 (HSPI) - SX1278 only, on its own pins, so the radio never has to
 *                 arbitrate the bus with the panel or the touch controller.
 *
 * See docs/PINMAP.md for the full table and the conflict audit.
 */

#ifndef SOS_APP_CONFIG_H
#define SOS_APP_CONFIG_H

/* ------------------------------------------------------------------------- */
/* Panel                                                                      */
/* ------------------------------------------------------------------------- */
#define SOS_SCREEN_W 320
#define SOS_SCREEN_H 240

/* ------------------------------------------------------------------------- */
/* Pin map - ESP32-S3-WROOM-1 N16R8                                           */
/* ------------------------------------------------------------------------- */

/* Panel, SPI2 (FSPI) - MOSI/SCLK/MISO/CS are the S3 SPI2 IO_MUX pins 11/12/13/10 */
#define PIN_TFT_DC        9    /* plain GPIO (output only)                    */
#define PIN_TFT_CS        10   /* FSPICS0 - IO_MUX chip select                */
#define PIN_TFT_MOSI      11   /* FSPID                                        */
#define PIN_TFT_SCLK      12   /* FSPICLK                                      */
#define PIN_TFT_MISO      13   /* FSPIQ                                        */
#define PIN_TFT_RST       14   /* plain GPIO                                   */
#define PIN_TFT_BL        21   /* backlight, LEDC-capable                      */

/* XPT2046 - same SPI2 bus, separate chip select, IRQ line */
#define PIN_TOUCH_CS      5    /* kept from v2 (valid + non-strapping on S3)   */
#define PIN_TOUCH_IRQ     16   /* kept from v2                                */

/* LoRa SX1278 - dedicated SPI3 (HSPI) bus */
#define PIN_LORA_NSS      4
#define PIN_LORA_SCLK     6
#define PIN_LORA_MISO     7
#define PIN_LORA_MOSI     8
#define PIN_LORA_RST      15
#define PIN_LORA_DIO0     2    /* interrupt-capable                           */

/* Human interface */
#define PIN_BUTTON        1    /* INPUT_PULLUP, active LOW (v2 pin, S3-safe)  */
#define PIN_NOTIFICATION  17   /* was 25 on v2 - no GPIO25 on the S3          */
#define PIN_BUZZER        18   /* was 33 on v2 - octal PSRAM line on R8       */

#if PIN_TFT_MOSI != 11 || PIN_TFT_SCLK != 12 || PIN_TFT_MISO != 13
#error "panel SPI must stay on the ESP32-S3 SPI2 IO_MUX pins (MOSI 11 / SCLK 12 / MISO 13)"
#endif

/* ------------------------------------------------------------------------- */
/* Timing (spec section 6.5) - identical to v2                                */
/* ------------------------------------------------------------------------- */
#define SOS_BUTTON_DEBOUNCE_MS 300u
#define SOS_LONG_PRESS_MS      2000u
#define SOS_BUZZER_TOGGLE_MS   500u
#define SOS_CALL_DURATION_MS   5000u
#define SOS_PRESSURE_MS        1000u
#define SOS_AUTO_SLIDE_MS      3000u   /* v2 declared it, never used (L7)     */
#define SOS_LOGO_HOLD_MS       2000u
#define SOS_TOUCH_DEBOUNCE_MS  300u

#define SOS_TOUCH_Z_THRESHOLD  4300    /* strict >, exactly as v2             */

/* Raw XPT2046 range -> screen.  v2 mapped Y to SCREEN_HEIGHT (200) which left
 * the bottom 40 px of a 240 px panel unreachable (spec issue L5). */
#define SOS_TOUCH_X_MIN   200
#define SOS_TOUCH_X_MAX   3700
#define SOS_TOUCH_Y_MIN   240
#define SOS_TOUCH_Y_MAX   3800

/* ------------------------------------------------------------------------- */
/* Palette - TFT_eSPI RGB565 expanded to RGB888 (spec section 4.3)            */
/* ------------------------------------------------------------------------- */
#define SOS_C_BLACK     0x000000u
#define SOS_C_NAVY      0x00007Bu
#define SOS_C_GREEN     0x00FF00u
#define SOS_C_RED       0xFF0000u
#define SOS_C_WHITE     0xFFFFFFu
#define SOS_C_ORANGE    0xFFB600u
#define SOS_C_BLUE      0x0000FFu
#define SOS_C_PURPLE    0x7B007Bu
#define SOS_C_YELLOW    0xFFFF00u
#define SOS_C_CYAN      0x00FFFFu
#define SOS_C_DARKGREY  0x7B7D7B

/* ------------------------------------------------------------------------- */
/* Build options                                                              */
/* ------------------------------------------------------------------------- */
/* Clean mode (user decision): fix V1-V9 / L1-L8 instead of reproducing them. */
#define SOS_CLEAN_MODE         1
/* v2 could never reach the slideshow; the user asked for it to be wired.    */
#define SOS_WIRE_SLIDESHOW     1
/* L7: make the footer's "Auto: 3s" true.                                     */
#define SOS_SLIDESHOW_AUTO     1
/* Discoverability hint on the config screen for the slideshow entry.         */
#define SOS_SLIDESHOW_HINT     1
/* Probe the SX1278 version register at boot (no TX/RX; that is spec O10).    */
#define SOS_LORA_PROBE         1
/* 1 = the fitted buzzer is an *active* (self-driving) type and is switched on
 * and off as v2 did.  0 = passive buzzer: an LEDC square wave is switched. */
#define SOS_BUZZER_ACTIVE      1
#define SOS_BUZZER_TONE_HZ     2700u
/* 1 = gate the XPT2046 read on T_IRQ (saves SPI traffic; correct on modules
 * that actually route T_IRQ - this one does, v2 used it).  Left at 0 by
 * default because an unrouted T_IRQ would silently kill touch input, and the
 * polled Z reading already reports "not touched" correctly. */
#define SOS_TOUCH_USE_IRQ      0
/* Backlight PWM duty, 0..255. Set SOS_BL_PWM 0 for a plain on/off backlight. */
#define SOS_BL_PWM             1
#define SOS_BL_DUTY            255

#endif /* SOS_APP_CONFIG_H */
