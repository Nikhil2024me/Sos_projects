/**
 * @file ui_v2.c
 * @brief SOS Console - redesign skin (SOS_UI_DESIGN == 2).
 *
 * Design brief: an emergency console, not a settings dialog.  Dark, high
 * contrast, one accent colour per service, big touch targets, and motion that
 * says something (armed / calling / counting down) instead of decorating.
 *
 * Panel reality: 320x240 ILI9341 on SPI at 40 MHz -> a full repaint costs
 * ~25-30 ms, so only small regions may animate.  Every animation here repaints
 * at most 210x210 px or a single card.
 *
 * Deliberately NO transform-based press effects.  A press is a flat fill
 * change: on this panel a scaled layer re-render costs more than the whole
 * card, which is exactly the "extra intermediate layer draw" that was removed
 * from the working upload.
 *
 * Grid: 8 px margins, 8 px gutters, 12-16 px radii.
 *   status strip  0..27
 *   content      28..231
 *   hint row    232..239
 */

#include "../ui/ui_api.h"

#include "../app/app_config.h"
#include "../assets/svc_images.h"
#include "../ui/ui_common.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#if SOS_UI_DESIGN == 2

/* ========================================================================== */
/* Palette                                                                    */
/* ========================================================================== */
#define C_BG        0x0B0E13u
#define C_STRIP     0x0F131Au
#define C_SURFACE   0x151A22u
#define C_SURFACE2  0x1D2430u
#define C_LINE      0x232C3Au
#define C_TEXT      0xF2F5F9u
#define C_MUTED     0x8A94A6u
#define C_DIM       0x74808Fu
#define C_GREEN     0x30D158u
#define C_AMBER     0xFFD60Au
#define C_RED       0xFF453Au
#define C_INK       0x0B0E13u   /* text on light surfaces */

typedef struct {
    uint32_t base;
    uint32_t light;
    uint32_t dark;
    const char *name;
} svc_style_t;

static const svc_style_t SVC[4] = {
    { 0xFF3B30u, 0xFF5A50u, 0xB3160Fu, "AMBULANCE" },
    { 0xFF9F0Au, 0xFFB84Du, 0xB26500u, "FIRE DEPT" },
    { 0x0A84FFu, 0x4FA8FFu, 0x0050A8u, "POLICE"    },
    { 0xBF5AF2u, 0xD08CFFu, 0x7A2BA8u, "EMERGENCY" },
};

#define F_MICRO (&lv_font_montserrat_12)
#define F_BODY  (&lv_font_montserrat_14)
#define F_SUB   (&lv_font_montserrat_16)
#define F_TITLE (&lv_font_montserrat_20)
#define F_DISP  (&lv_font_montserrat_28)
#define F_HERO  (&lv_font_montserrat_34)

/* ========================================================================== */
/* State                                                                      */
/* ========================================================================== */
static ui_event_cb_t s_cb;

static lv_obj_t *scr_splash, *scr_home, *scr_service, *scr_config;
static lv_obj_t *scr_calling, *scr_demo;

static lv_obj_t *home_uptime;
static lv_obj_t *home_tick[5];

static lv_obj_t *svc_glow[3];
static lv_obj_t *svc_icon;
static lv_obj_t *svc_name;
static lv_obj_t *svc_kicker;
static lv_obj_t *svc_call;

static lv_obj_t *call_ring[3];
static lv_obj_t *call_arc;
static lv_obj_t *call_name;
static lv_obj_t *call_tick[5];

static lv_obj_t *demo_img;
static lv_obj_t *demo_title;
static lv_obj_t *demo_count;
static lv_obj_t *demo_dot[4];

/* ========================================================================== */
/* Helpers                                                                    */
/* ========================================================================== */
static void emit(ui_event_t ev, int arg)
{
    if(s_cb) s_cb(ev, arg);
}

static lv_obj_t *box(lv_obj_t *parent, int x, int y, int w, int h, uint32_t bg)
{
    lv_obj_t *o = lv_obj_create(parent);
    lv_obj_remove_style_all(o);
    lv_obj_set_pos(o, x, y);
    lv_obj_set_size(o, w, h);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
    SOS_SET_SCROLLABLE(o, false);
    SOS_SET_CLICKABLE(o, false);
    return o;
}

static lv_obj_t *text(lv_obj_t *parent, const char *s, const lv_font_t *f,
                      uint32_t col, int x, int y)
{
    lv_obj_t *l = lv_label_create(parent);
    lv_obj_remove_style_all(l);
    lv_label_set_text(l, s);
    lv_obj_set_style_text_font(l, f, 0);
    lv_obj_set_style_text_color(l, lv_color_hex(col), 0);
    lv_obj_set_pos(l, x, y);
    SOS_SET_CLICKABLE(l, false);
    return l;
}

static lv_obj_t *text_mid(lv_obj_t *parent, const char *s, const lv_font_t *f,
                          uint32_t col, int y)
{
    lv_obj_t *l = text(parent, s, f, col, 0, y);
    lv_obj_set_width(l, SOS_SCREEN_W);
    lv_obj_set_style_text_align(l, LV_TEXT_ALIGN_CENTER, 0);
    return l;
}

static lv_obj_t *new_screen(const char *name, uint32_t bg, bool clickable)
{
    lv_obj_t *s = lv_obj_create(NULL);
    lv_obj_remove_style_all(s);
    lv_obj_set_name(s, name);
    lv_obj_set_style_bg_color(s, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(s, LV_OPA_COVER, 0);
    SOS_SET_SCROLLABLE(s, false);
    SOS_SET_CLICKABLE(s, clickable);
    return s;
}

static void rounded(lv_obj_t *o, int r, uint32_t bg)
{
    lv_obj_set_style_radius(o, r, 0);
    lv_obj_set_style_bg_color(o, lv_color_hex(bg), 0);
    lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
}

static void shadow(lv_obj_t *o, uint32_t col, int w, lv_opa_t opa, int dy)
{
    lv_obj_set_style_shadow_color(o, lv_color_hex(col), 0);
    lv_obj_set_style_shadow_width(o, w, 0);
    lv_obj_set_style_shadow_opa(o, opa, 0);
    lv_obj_set_style_shadow_ofs_y(o, dy, 0);
}

/* Press = flat fill change, no transform, no extra layer. */
static void press_fill(lv_obj_t *o, uint32_t normal, uint32_t pressed)
{
    lv_obj_set_style_bg_color(o, lv_color_hex(normal), 0);
    lv_obj_set_style_bg_grad_dir(o, LV_GRAD_DIR_VER, 0);
    lv_obj_set_style_bg_grad_color(o, lv_color_hex(normal), 0);
    lv_obj_set_style_bg_color(o, lv_color_hex(pressed), LV_STATE_PRESSED);
    lv_obj_set_style_bg_grad_color(o, lv_color_hex(pressed), LV_STATE_PRESSED);
}

static lv_obj_t *mask_img(lv_obj_t *parent, const lv_image_dsc_t *dsc,
                          uint32_t col, lv_opa_t opa)
{
    lv_obj_t *img = lv_image_create(parent);
    lv_obj_remove_style_all(img);
    lv_image_set_src(img, dsc);
    lv_obj_set_style_image_recolor(img, lv_color_hex(col), 0);
    lv_obj_set_style_image_recolor_opa(img, LV_OPA_COVER, 0);
    lv_obj_set_style_image_opa(img, opa, 0);
    SOS_SET_CLICKABLE(img, false);
    return img;
}

/* ========================================================================== */
/* Status strip                                                               */
/* ========================================================================== */
static void strip(lv_obj_t *scr, lv_obj_t **tick_arr, bool uptime)
{
    lv_obj_t *s = box(scr, 0, 0, 320, 28, C_STRIP);
    lv_obj_set_style_border_color(s, lv_color_hex(C_LINE), 0);
    lv_obj_set_style_border_width(s, 1, 0);
    lv_obj_set_style_border_side(s, LV_BORDER_SIDE_BOTTOM, 0);

    lv_obj_t *badge = box(scr, 10, 5, 34, 18, C_RED);
    lv_obj_set_style_radius(badge, 4, 0);
    lv_obj_t *bl = text(badge, "SOS", F_MICRO, C_TEXT, 0, 0);
    lv_obj_center(bl);

    lv_obj_t *dot = box(scr, 50, 12, 5, 5, C_AMBER);
    lv_obj_set_style_radius(dot, LV_RADIUS_CIRCLE, 0);
    text(scr, "OFFLINE", F_MICRO, C_MUTED, 59, 7);

    if(uptime) {
        home_uptime = text(scr, "0s", F_MICRO, C_DIM, 108, 8);
        lv_obj_set_width(home_uptime, 70);
        lv_obj_set_style_text_align(home_uptime, LV_TEXT_ALIGN_CENTER, 0);
    }

    if(tick_arr) {
        for(int i = 0; i < 5; i++) {
            tick_arr[i] = box(scr, 278 + i * 7, 9, 5, 10, C_SURFACE2);
            lv_obj_set_style_radius(tick_arr[i], 1, 0);
        }
    }
}

static void ticks_set(lv_obj_t **arr, int z)
{
    if(arr == NULL || arr[0] == NULL) return;

    int lit;
    uint32_t col;

    if(z <= 0)         { lit = 0; col = C_SURFACE2; }
    else if(z <= 4300) { lit = 1 + (z * 3) / 4301; col = C_AMBER; }
    else               { lit = 5; col = C_GREEN; }

    for(int i = 0; i < 5; i++) {
        lv_obj_set_style_bg_color(arr[i],
                                  lv_color_hex(i < lit ? col : C_SURFACE2), 0);
    }
}

/* ========================================================================== */
/* Buttons                                                                    */
/* ========================================================================== */
static lv_obj_t *pill(lv_obj_t *parent, const char *label, uint32_t bg,
                      uint32_t fg, int x, int y, int w, int h,
                      lv_event_cb_t cb, int arg)
{
    lv_obj_t *b = lv_obj_create(parent);
    lv_obj_remove_style_all(b);
    lv_obj_set_pos(b, x, y);
    lv_obj_set_size(b, w, h);
    rounded(b, h / 2, bg);
    press_fill(b, bg, C_SURFACE2);
    SOS_SET_SCROLLABLE(b, false);
    SOS_SET_CLICKABLE(b, true);
    lv_obj_add_event_cb(b, cb, LV_EVENT_CLICKED, (void *)(intptr_t)arg);

    lv_obj_t *l = text(b, label, F_BODY, fg, 0, 0);
    lv_obj_center(l);
    return b;
}

/* ========================================================================== */
/* 1. Splash                                                                  */
/* ========================================================================== */
static void fade_cb(void *var, int32_t v)
{
    lv_obj_set_style_opa((lv_obj_t *)var, (lv_opa_t)v, 0);
}

static void grow_cb(void *var, int32_t v)
{
    lv_obj_set_width((lv_obj_t *)var, v);
}

static void build_splash(void)
{
    scr_splash = new_screen("splash", C_BG, false);

    lv_obj_t *badge = box(scr_splash, 120, 58, 80, 80, C_RED);
    lv_obj_set_style_radius(badge, 22, 0);
    shadow(badge, C_RED, 30, LV_OPA_40, 0);
    lv_obj_t *bl = text(badge, "SOS", F_HERO, C_TEXT, 0, 0);
    lv_obj_center(bl);

    text_mid(scr_splash, "EMERGENCY CONSOLE", F_MICRO, C_MUTED, 154);
    text_mid(scr_splash, "OFFLINE  |  LOCAL ALERTS", F_MICRO, C_DIM, 170);

    box(scr_splash, 110, 204, 100, 2, C_SURFACE2);
    lv_obj_t *fill = box(scr_splash, 110, 204, 20, 2, C_RED);
    lv_obj_set_style_radius(fill, 1, 0);

    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, fill);
    lv_anim_set_values(&a, 20, 100);
    lv_anim_set_time(&a, 1500);
    lv_anim_set_exec_cb(&a, grow_cb);
    lv_anim_start(&a);

    lv_obj_set_style_opa(scr_splash, LV_OPA_TRANSP, 0);
    lv_anim_t f;
    lv_anim_init(&f);
    lv_anim_set_var(&f, scr_splash);
    lv_anim_set_values(&f, LV_OPA_TRANSP, LV_OPA_COVER);
    lv_anim_set_time(&f, 400);
    lv_anim_set_exec_cb(&f, fade_cb);
    lv_anim_start(&f);
}

/* ========================================================================== */
/* 2. Home                                                                    */
/* ========================================================================== */
static void on_card(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) {
        emit(UI_EV_SERVICE, (int)(intptr_t)lv_event_get_user_data(e));
    }
}

static void on_settings(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) emit(UI_EV_CONFIG, 0);
}

static void build_home(void)
{
    scr_home = new_screen("home", C_BG, true);
    strip(scr_home, home_tick, true);

    /* The strip is only 28 px tall, so this is the largest target that fits
     * without eating the content area: 60x24 px (~11x4.5 mm) instead of the
     * 30x20 px first draft. */
    pill(scr_home, "SET", C_SURFACE, C_MUTED, 250, 2, 62, 24, on_settings, 0);

    text(scr_home, "SELECT SERVICE", F_MICRO, C_DIM, 12, 33);

    for(int i = 0; i < 4; i++) {
        int x = (i & 1) ? 164 : 8;
        int y = (i >> 1) ? 144 : 54;

        lv_obj_t *c = lv_obj_create(scr_home);
        lv_obj_remove_style_all(c);
        lv_obj_set_pos(c, x, y);
        lv_obj_set_size(c, 148, 82);
        lv_obj_set_name(c, SVC[i].name);
        lv_obj_set_style_radius(c, 15, 0);
        lv_obj_set_style_bg_color(c, lv_color_hex(SVC[i].light), 0);
        lv_obj_set_style_bg_grad_color(c, lv_color_hex(SVC[i].dark), 0);
        lv_obj_set_style_bg_grad_dir(c, LV_GRAD_DIR_VER, 0);
        lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
        shadow(c, SVC[i].dark, 12, LV_OPA_50, 4);
        /* press: collapse the gradient, keep the deep tone */
        lv_obj_set_style_bg_color(c, lv_color_hex(SVC[i].dark), LV_STATE_PRESSED);
        lv_obj_set_style_bg_grad_color(c, lv_color_hex(SVC[i].dark),
                                       LV_STATE_PRESSED);
        SOS_SET_SCROLLABLE(c, false);
        SOS_SET_CLICKABLE(c, true);
        lv_obj_add_event_cb(c, on_card, LV_EVENT_CLICKED, (void *)(intptr_t)i);

        lv_obj_t *icon = mask_img(c, sos_gfx[i].card, C_TEXT, LV_OPA_80);
        lv_obj_align(icon, LV_ALIGN_RIGHT_MID, -8, -8);

        text(c, SVC[i].name, F_BODY, C_TEXT, 12, 54);
    }

    /* No bottom hint row: cards end at y=226 and a 12 px label needs 16 px of
     * line box, which would be clipped by the 240 px panel. */
}

/* ========================================================================== */
/* 3. Service (armed)                                                         */
/* ========================================================================== */
static void on_call(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) {
        emit(UI_EV_CALL, (int)(intptr_t)lv_event_get_user_data(e));
    }
}

static void on_back(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) emit(UI_EV_BACK, 0);
}

static void build_service(void)
{
    scr_service = new_screen("service", C_BG, true);
    strip(scr_service, NULL, false);

    /* Ambient glow behind the vehicle: three discs of falling opacity, which
     * gives a flat 16-bit panel some depth.  They live in a clipped container
     * so they never draw outside the 320x240 panel. */
    lv_obj_t *glow = box(scr_service, 0, 28, 320, 212, C_BG);
    lv_obj_set_style_bg_opa(glow, LV_OPA_TRANSP, 0);
    for(int i = 0; i < 3; i++) {
        int d = 120 - i * 20;
        lv_obj_t *g = box(glow, 160 - d / 2, 60 - d / 2, d, d, SVC[0].base);
        lv_obj_set_style_radius(g, LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_bg_opa(g, (lv_opa_t)(20 - i * 6), 0);
        svc_glow[i] = g;
    }

    svc_icon = mask_img(scr_service, sos_gfx[0].hero, C_TEXT, LV_OPA_COVER);
    lv_obj_align(svc_icon, LV_ALIGN_TOP_MID, 0, 32);

    svc_kicker = text_mid(scr_service, "ARMED", F_MICRO, C_MUTED, 122);
    svc_name = text_mid(scr_service, SVC[0].name, F_DISP, C_TEXT, 138);

    svc_call = pill(scr_service, "CALL NOW", C_TEXT, C_INK, 60, 174, 200, 40,
                    on_call, 0);
    lv_obj_set_style_radius(svc_call, 20, 0);
    shadow(svc_call, SVC[0].base, 18, LV_OPA_50, 4);
    lv_obj_t *cl = lv_obj_get_child(svc_call, 0);
    lv_obj_set_style_text_font(cl, F_TITLE, 0);
    lv_obj_center(cl);

    pill(scr_service, "< BACK", C_SURFACE, C_MUTED, 8, 32, 62, 24, on_back, 0);
    text_mid(scr_service, "Local alert only  |  no radio", F_MICRO, C_DIM, 218);
}

static void service_visuals(int idx)
{
    for(int i = 0; i < 3; i++) {
        lv_obj_set_style_bg_color(svc_glow[i], lv_color_hex(SVC[idx].base), 0);
    }
    lv_image_set_src(svc_icon, sos_gfx[idx].hero);
    lv_obj_align(svc_icon, LV_ALIGN_TOP_MID, 0, 32);
    lv_label_set_text(svc_name, SVC[idx].name);
    shadow(svc_call, SVC[idx].base, 18, LV_OPA_50, 4);
}

/* ========================================================================== */
/* 4. Calling                                                                 */
/* ========================================================================== */
static void on_cancel(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) emit(UI_EV_CANCEL, 0);
}

static void ring_fade_cb(void *var, int32_t v)
{
    lv_obj_set_style_border_opa((lv_obj_t *)var, (lv_opa_t)v, 0);
}

static void build_calling(void)
{
    scr_calling = new_screen("calling", C_BG, true);
    strip(scr_calling, call_tick, false);

    for(int i = 0; i < 3; i++) {
        int d = 112 + i * 30;
        lv_obj_t *r = box(scr_calling, 160 - d / 2, 112 - d / 2, d, d, C_BG);
        lv_obj_set_style_radius(r, LV_RADIUS_CIRCLE, 0);
        lv_obj_set_style_bg_opa(r, LV_OPA_TRANSP, 0);
        lv_obj_set_style_border_color(r, lv_color_hex(SVC[0].base), 0);
        lv_obj_set_style_border_width(r, 2, 0);
        lv_obj_set_style_border_opa(r, (lv_opa_t)(60 - i * 18), 0);
        call_ring[i] = r;

        lv_anim_t a;
        lv_anim_init(&a);
        lv_anim_set_var(&a, r);
        lv_anim_set_values(&a, 60 - i * 18, 0);
        lv_anim_set_time(&a, 1800);
        lv_anim_set_delay(&a, i * 320);
        lv_anim_set_repeat_count(&a, LV_ANIM_REPEAT_INFINITE);
        lv_anim_set_exec_cb(&a, ring_fade_cb);
        lv_anim_start(&a);
    }

    call_arc = lv_arc_create(scr_calling);
    lv_obj_remove_style_all(call_arc);
    lv_obj_set_size(call_arc, 148, 148);
    lv_obj_align(call_arc, LV_ALIGN_CENTER, 0, -4);
    lv_arc_set_bg_angles(call_arc, 135, 45);
    lv_arc_set_range(call_arc, 0, SOS_CALL_DURATION_MS);
    lv_arc_set_value(call_arc, SOS_CALL_DURATION_MS);
    SOS_SET_CLICKABLE(call_arc, false);

    lv_obj_set_style_arc_width(call_arc, 7, LV_PART_MAIN);
    lv_obj_set_style_arc_color(call_arc, lv_color_hex(C_SURFACE2), LV_PART_MAIN);
    lv_obj_set_style_arc_rounded(call_arc, true, LV_PART_MAIN);
    lv_obj_set_style_arc_width(call_arc, 7, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(call_arc, lv_color_hex(SVC[0].base),
                               LV_PART_INDICATOR);
    lv_obj_set_style_arc_rounded(call_arc, true, LV_PART_INDICATOR);

    text_mid(scr_calling, "CALLING", F_MICRO, C_MUTED, 92);
    call_name = text_mid(scr_calling, SVC[0].name, F_TITLE, C_TEXT, 106);

    lv_obj_t *cxl = pill(scr_calling, "CANCEL", C_SURFACE, C_RED, 90, 194, 140, 40,
                         on_cancel, 0);
    lv_obj_set_style_border_color(cxl, lv_color_hex(C_RED), 0);
    lv_obj_set_style_border_width(cxl, 1, 0);
    lv_obj_set_style_border_opa(cxl, LV_OPA_60, 0);
}

/* ========================================================================== */
/* 5. Config                                                                  */
/* ========================================================================== */
static void on_demo(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) emit(UI_EV_DEMO, 0);
}

static void build_config(void)
{
    scr_config = new_screen("config", C_BG, true);
    strip(scr_config, NULL, false);

    pill(scr_config, "<", C_SURFACE, C_MUTED, 8, 30, 44, 34, on_back, 0);
    text(scr_config, "SETTINGS", F_TITLE, C_TEXT, 62, 32);

    static const char *keys[3]   = { "Mode", "Alerts", "Touch threshold" };
    static const char *values[3] = { "OFFLINE", "buzzer + pin", "4300" };
    static const uint32_t vcol[3] = { C_AMBER, C_MUTED, C_MUTED };

    for(int i = 0; i < 3; i++) {
        lv_obj_t *r = box(scr_config, 8, 72 + i * 42, 304, 38, C_SURFACE);
        lv_obj_set_style_radius(r, 12, 0);
        lv_obj_set_style_border_color(r, lv_color_hex(C_LINE), 0);
        lv_obj_set_style_border_width(r, 1, 0);
        text(r, keys[i], F_BODY, C_TEXT, 14, 11);
        lv_obj_t *v = text(r, values[i], F_BODY, vcol[i], 0, 11);
        lv_obj_align(v, LV_ALIGN_RIGHT_MID, -14, 0);
    }

    pill(scr_config, "OPEN DEMO", C_SURFACE2, C_TEXT, 8, 194, 304, 40, on_demo, 0);
}

/* ========================================================================== */
/* 6. Demo                                                                    */
/* ========================================================================== */
static void on_demo_next(lv_event_t *e)
{
    if(lv_event_get_code(e) == LV_EVENT_CLICKED) emit(UI_EV_DEMO_NEXT, 0);
}

static void zoom_cb(void *var, int32_t v)
{
    lv_image_set_scale((lv_obj_t *)var, (uint32_t)v);
}

static void build_demo(void)
{
    scr_demo = new_screen("demo", 0x05070Au, true);
    lv_obj_add_event_cb(scr_demo, on_demo_next, LV_EVENT_CLICKED, NULL);

    text(scr_demo, "DEMO", F_MICRO, C_DIM, 12, 8);
    demo_count = text(scr_demo, "1 / 4", F_MICRO, C_MUTED, 0, 8);
    lv_obj_align(demo_count, LV_ALIGN_TOP_RIGHT, -12, 8);

    demo_img = mask_img(scr_demo, sos_gfx[0].slide, C_TEXT, LV_OPA_COVER);
    lv_obj_align(demo_img, LV_ALIGN_CENTER, 0, -14);

    /* slow breathing zoom: a still image reads as "live" */
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, demo_img);
    lv_anim_set_values(&a, LV_SCALE_NONE, LV_SCALE_NONE + 20);
    lv_anim_set_time(&a, 3000);
    lv_anim_set_playback_time(&a, 3000);
    lv_anim_set_repeat_count(&a, LV_ANIM_REPEAT_INFINITE);
    lv_anim_set_exec_cb(&a, zoom_cb);
    lv_anim_start(&a);

    demo_title = text_mid(scr_demo, "Medical Emergency", F_SUB, C_TEXT, 198);

    for(int i = 0; i < 4; i++) {
        demo_dot[i] = box(scr_demo, 137 + i * 12, 224, 8, 4, C_SURFACE2);
        lv_obj_set_style_radius(demo_dot[i], 2, 0);
    }
}

/* ========================================================================== */
/* API                                                                        */
/* ========================================================================== */
static lv_obj_t *screen_for(int st)
{
    switch(st) {
        case UI_LOGO:      return scr_splash;
        case UI_MAIN:      return scr_home;
        case UI_SERVICE:   return scr_service;
        case UI_CONFIG:    return scr_config;
        case UI_CALLING:   return scr_calling;
        case UI_SLIDESHOW: return scr_demo;
        default:           return scr_home;
    }
}

void ui_build(ui_event_cb_t cb)
{
    s_cb = cb;

    build_splash();
    build_home();
    build_service();
    build_calling();
    build_config();
    build_demo();

    ui_set_service(0);
    ui_set_calling(0);
    ui_set_slideshow(0);
    ui_set_pressure(0);
}

void ui_enter(int state)
{
    lv_obj_t *s = screen_for(state);
    if(s) lv_screen_load(s);
}

void ui_set_service(int index)
{
    if(index < 0 || index > 3) return;
    service_visuals(index);
}

void ui_set_calling(int index)
{
    if(index < 0 || index > 3) return;

    lv_label_set_text(call_name, SVC[index].name);
    lv_obj_set_style_arc_color(call_arc, lv_color_hex(SVC[index].base),
                               LV_PART_INDICATOR);
    for(int i = 0; i < 3; i++) {
        lv_obj_set_style_border_color(call_ring[i],
                                      lv_color_hex(SVC[index].base), 0);
    }
    lv_arc_set_value(call_arc, SOS_CALL_DURATION_MS);
}

void ui_set_slideshow(int index)
{
    if(index < 0 || index > 3) return;

    static const char *TITLE[4] = {
        "Medical Emergency", "Fire Emergency",
        "Police Emergency", "General Emergency",
    };

    lv_image_set_src(demo_img, sos_gfx[index].slide);
    lv_obj_align(demo_img, LV_ALIGN_CENTER, 0, -14);
    lv_label_set_text(demo_title, TITLE[index]);
    lv_label_set_text_fmt(demo_count, "%d / 4", index + 1);

    for(int i = 0; i < 4; i++) {
        lv_obj_set_style_bg_color(demo_dot[i],
                                  lv_color_hex(i == index ? C_TEXT : C_SURFACE2),
                                  0);
    }
}

void ui_set_uptime(unsigned long seconds)
{
    if(home_uptime) lv_label_set_text_fmt(home_uptime, "%lus", seconds);
}

void ui_set_pressure(int z)
{
    ticks_set(home_tick, z);
    ticks_set(call_tick, z);
}

void ui_set_call_progress(int ms_left)
{
    if(ms_left < 0) ms_left = 0;
    if(ms_left > SOS_CALL_DURATION_MS) ms_left = SOS_CALL_DURATION_MS;
    lv_arc_set_value(call_arc, ms_left);
}

#endif /* SOS_UI_DESIGN == 2 */