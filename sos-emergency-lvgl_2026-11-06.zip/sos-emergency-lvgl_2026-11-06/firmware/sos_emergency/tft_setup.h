// ============================================================================
//  tft_setup.h - TFT_eSPI configuration for the SOS rebuild
//  ESP32-S3-WROOM-1 N16R8 + ILI9341 2.4" 320x240 + XPT2046 resistive touch
// ============================================================================
//
//  HOW THIS FILE IS USED
//  ---------------------
//  TFT_eSPI.h looks for a header called tft_setup.h *in the sketch folder*
//  before it loads its own User_Setup_Select.h:
//
//      #if __has_include(<tft_setup.h>)
//        #include <tft_setup.h>
//        #define USER_SETUP_LOADED      // <- skips User_Setup_Select.h
//      #endif
//
//  So this file alone configures the library, the TFT_eSPI installation is
//  never modified, and the build is reproducible from a clean checkout.
//
//  If you would rather edit the library by hand, copy this file over
//      <Arduino>/libraries/TFT_eSPI/User_Setup.h
//  and delete the sketch copy.  Both routes produce the same binary.
//
//  PIN MAP (rationale in docs/PINMAP.md)
//  -------------------------------------
//  SPI2 / FSPI, deliberately on the ESP32-S3 SPI2 IO_MUX pads so the bus is
//  not capped at the ~40 MHz GPIO-matrix ceiling:
//      MOSI GPIO11 (FSPID)   SCLK GPIO12 (FSPICLK)   MISO GPIO13 (FSPIQ)
//      CS   GPIO10 (FSPICS0)
//  DC, RST, the touch chip-select and the backlight are ordinary GPIOs:
//      DC GPIO9    RST GPIO14    TOUCH_CS GPIO5    backlight GPIO21
//  GPIO21 is driven by the application (LEDC), not by TFT_eSPI.
// ============================================================================

#define USER_SETUP_INFO "SOS_ESP32S3_ILI9341_XPT2046"

// ---------------------------------------------------------------------------
// Driver
// ---------------------------------------------------------------------------
#define ILI9341_DRIVER

// TFT_WIDTH / TFT_HEIGHT are NOT set here on purpose: for ILI9341 the library
// supplies the panel's native portrait size (240x320) from
// TFT_Drivers/ILI9341_Defines.h.  Defining 320x240 here would be redefined by
// that header and the panel would be addressed in the wrong orientation.
// The UI is landscape because the driver calls tft.setRotation(1).

// ---------------------------------------------------------------------------
// Panel pins (SPI2 IO_MUX set)
// ---------------------------------------------------------------------------
#define TFT_MISO 13
#define TFT_MOSI 11
#define TFT_SCLK 12
#define TFT_CS   10   // FSPICS0
#define TFT_DC    9
#define TFT_RST  14

// ---------------------------------------------------------------------------
// Touch (same SPI bus, separate chip select)
// ---------------------------------------------------------------------------
#define TOUCH_CS 5

// ---------------------------------------------------------------------------
// Fonts.  LVGL draws the whole UI, so TFT_eSPI's own fonts only matter for its
// examples and for any leftover debug drawing.
// ---------------------------------------------------------------------------
#define LOAD_GLCD
#define LOAD_FONT2
#define LOAD_FONT4
#define SMOOTH_FONT

// ---------------------------------------------------------------------------
// SPI speeds.  40 MHz is the well-trodden ILI9341 write speed and is also the
// frequency at which ESP32-S3 GPIO-matrix routing behaves identically to
// IO_MUX.  The XPT2046 must stay slow.
// ---------------------------------------------------------------------------
#define SPI_FREQUENCY        40000000
#define SPI_READ_FREQUENCY   20000000
#define SPI_TOUCH_FREQUENCY   2500000

// TFT_eSPI uses the ESP32-S3's SPI2 (FSPI) host by default; stated here so the
// intent is explicit.  Do not enable USE_HSPI_PORT: SPI3 belongs to the radio.
//#define USE_HSPI_PORT
