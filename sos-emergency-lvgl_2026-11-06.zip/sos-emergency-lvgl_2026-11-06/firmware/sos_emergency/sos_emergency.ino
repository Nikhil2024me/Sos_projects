/**
 * SOS Emergency Transmitter - LVGL 9.6 rebuild (clean mode)
 * ========================================================
 * Target: ESP32-S3-WROOM-1 N16R8 + ILI9341 320x240 (XPT2046 touch)
 *         + LoRa SX1278 (pins configured, presence-probed, not used for TX).
 *
 * Baseline: v2 "bitmapwith touch beta1" per LVGL_REBUILD_SPEC.md.
 * Mode    : clean - the visual bugs V1..V9 and logic bugs L1..L8 are fixed.
 *           See docs/CLEAN_MODE_FIXES.md for the item-by-item record.
 *
 * This file only wires the pieces together:
 *   src/hal/   board support (TFT_eSPI panel, XPT2046, GPIO, SX1278 probe)
 *   src/app/   state machine + timers (portable, no Arduino)
 *   src/ui/    screens (portable LVGL, renders identically in the simulator)
 */

#include "src/app/app_config.h"
#include "src/app/app_state.h"
#include "src/hal/hal.h"

#include <Arduino.h>
#include <esp_timer.h>

#include "lvgl.h"

/* ------------------------------------------------------------------------- */
/* LVGL tick: 1 kHz hardware timer, independent of loop() jitter              */
/* ------------------------------------------------------------------------- */
static esp_timer_handle_t s_tick_timer;

static void lv_tick_cb(void *arg)
{
    LV_UNUSED(arg);
    lv_tick_inc(1);
}

void setup()
{
    Serial.begin(115200);

    /* lv_init() MUST come first: hal_init() ends up in hal_display_init(),
     * which calls lv_display_create() and lv_indev_create(). Creating a display
     * before the library is initialised leaves LVGL's display list unset. */
    lv_init();

    esp_timer_create_args_t tick_args;
    memset(&tick_args, 0, sizeof(tick_args));
    tick_args.callback = lv_tick_cb;
    tick_args.name = "lv_tick";
    esp_timer_create(&tick_args, &s_tick_timer);
    esp_timer_start_periodic(s_tick_timer, 1000);   /* 1000 us = 1 ms */

    /* Backlight, panel, touch, HMI pins, radio bus - and the LVGL display. */
    hal_init();

    Serial.println();
    Serial.println("=== SOS System - OFFLINE MODE (LVGL 9.6 rebuild) ===");
    Serial.printf("Build      : %s %s\n", __DATE__, __TIME__);
    Serial.printf("Panel      : ILI9341 %dx%d, SPI2 IO_MUX MOSI %d SCLK %d MISO %d CS %d\n",
                  SOS_SCREEN_W, SOS_SCREEN_H, PIN_TFT_MOSI, PIN_TFT_SCLK,
                  PIN_TFT_MISO, PIN_TFT_CS);
    Serial.printf("Touch      : XPT2046 CS %d IRQ %d, pressure threshold %d\n",
                  PIN_TOUCH_CS, PIN_TOUCH_IRQ, SOS_TOUCH_Z_THRESHOLD);
    Serial.printf("HMI pins   : button %d, notification %d, buzzer %d\n",
                  PIN_BUTTON, PIN_NOTIFICATION, PIN_BUZZER);
    Serial.printf("LoRa pins  : NSS %d SCK %d MISO %d MOSI %d RST %d DIO0 %d\n",
                  PIN_LORA_NSS, PIN_LORA_SCLK, PIN_LORA_MISO, PIN_LORA_MOSI,
                  PIN_LORA_RST, PIN_LORA_DIO0);
    Serial.printf("PSRAM      : found=%d size=%u free=%u\n",
                  (int)psramFound(), (unsigned)ESP.getPsramSize(),
                  (unsigned)ESP.getFreePsram());

    const int lora = hal_lora_probe();
    Serial.printf("SX1278     : %s\n",
                  lora == 0x12 ? "present (RegVersion 0x12)" : "NOT detected");

    /* Build the screens and enter the boot logo. */
    app_init();

    Serial.println("=== System Ready ===");
}

void loop()
{
    /* lv_timer_handler() drives every timer in the application: the logo hold,
     * the 1 s pressure refresh, the 10 ms button scan, the call timeout, the
     * buzzer toggle and the slideshow auto-advance. */
    lv_timer_handler();
    delay(5);
}
