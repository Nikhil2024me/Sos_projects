#!/usr/bin/env python3
"""Export the simulator captures as viewable, named PNGs plus a contact sheet.

Input : sim/out/capture-*-<label>.png   (written by tools/sim_build.sh --run)
Output: screens/NN_<label>.png          (one file per screen, in state order)
        screens/contact_sheet.png       (all screens, labelled, 4 columns)
        screens/contact_sheet_2x.png    (same, 2x nearest-neighbour)

The 2x sheet is the one to look at first: the panel is only 320x240, so the
text is unreadable at 1x on a normal display.

Usage: tools/export_screens.py [--out sim/out] [--dest screens]
"""

from __future__ import annotations

import argparse
import glob
import os
import re
import sys

from PIL import Image, ImageDraw

# Presentation order, matching the state machine's flow.  Anything captured but
# not listed here is appended at the end.
# Skin 2 (console redesign) in state-flow order.
ORDER_V2 = [
    "splash",
    "home",
    "service_ambulance",
    "service_fire",
    "service_police",
    "service_emergency",
    "calling",
    "calling_late",
    "back_on_service",
    "home_again",
    "config",
    "demo_slide1",
    "demo_slide2",
    "demo_slide3",
]

# Skin 1 (faithful rebuild) in state-flow order.
ORDER_V1 = [
    "logo",
    "main_menu",
    "main_pressure_low",
    "main_pressure_ok",
    "main_pressure_none",
    "service_ambulance",
    "service_fire",
    "service_police",
    "service_emergency",
    "config",
    "slideshow_1",
    "slideshow_2",
    "main_after_slideshow",
    "service_after_call",
    "config_again",
    "main_after_config",
    "calling_from_main",
    "service_after_second_call",
]

TITLES = {
    # skin 2 (console redesign)
    "splash": "splash / boot",
    "home": "home - service grid",
    "service_ambulance": "armed: ambulance",
    "service_fire": "armed: fire dept",
    "service_police": "armed: police",
    "service_emergency": "armed: emergency",
    "calling": "calling - countdown",
    "calling_late": "calling - 4 s in",
    "back_on_service": "back on service",
    "home_again": "home (return)",
    "demo_slide1": "demo 1/4",
    "demo_slide2": "demo 2/4",
    "demo_slide3": "demo 3/4",
    # skin 1 (faithful rebuild)
    "logo": "boot logo",
    "main_menu": "main menu",
    "main_pressure_low": "pressure [LOW]",
    "main_pressure_ok": "pressure [OK]",
    "main_pressure_none": "pressure idle",
    "service_ambulance": "service: ambulance",
    "service_fire": "service: fire dept",
    "service_police": "service: police",
    "service_emergency": "service: emergency",
    "config": "configuration",
    "slideshow_1": "slideshow 1/4",
    "slideshow_2": "slideshow 2/4",
    "main_after_slideshow": "main (after demo)",
    "service_after_call": "service (call ended)",
    "config_again": "configuration (2nd)",
    "main_after_config": "main (after config)",
    "calling_from_main": "calling (from main)",
    "service_after_second_call": "service (2nd call ended)",
}

COLS = 4
PAD = 8
HEADER = 18
BG = (24, 24, 28)
FG = (235, 235, 235)


def collect(out_dir):
    """label -> path, in the order that matches the skin being exported."""
    found = {}
    for path in glob.glob(os.path.join(out_dir, "capture-*.png")):
        m = re.match(r"capture-\d+-(.+)\.png$", os.path.basename(path))
        if m:
            found[m.group(1)] = path
    # The two skins share some labels (service_*, config), so the order must be
    # chosen from the label set actually present, not merged.
    order = ORDER_V2 if "splash" in found else ORDER_V1
    ordered = [(lbl, found.pop(lbl)) for lbl in order if lbl in found]
    ordered += sorted(found.items())
    return ordered


def contact_sheet(items, scale):
    cell_w, cell_h = 320 * scale, 240 * scale
    rows = (len(items) + COLS - 1) // COLS
    W = COLS * cell_w + (COLS + 1) * PAD
    H = rows * (cell_h + HEADER) + (rows + 1) * PAD
    sheet = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(sheet)

    for i, (label, path) in enumerate(items):
        r, c = divmod(i, COLS)
        x = PAD + c * (cell_w + PAD)
        y = PAD + r * (cell_h + HEADER + PAD)
        title = TITLES.get(label, label.replace("_", " "))
        d.text((x + 2, y + 4), f"{i + 1:02d}  {title}", fill=FG)
        im = Image.open(path).convert("RGB")
        if scale != 1:
            im = im.resize((cell_w, cell_h), Image.NEAREST)
        sheet.paste(im, (x, y + HEADER))
    return sheet


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sim/out")
    ap.add_argument("--dest", default="screens")
    args = ap.parse_args()

    items = collect(args.out)
    if not items:
        print(f"no captures in {args.out} - run tools/sim_build.sh --run first",
              file=sys.stderr)
        return 1

    os.makedirs(args.dest, exist_ok=True)
    # Remove only what this tool generates, so re-running after a rename does
    # not leave a mix of old and new screen images behind.
    for pat in ("[0-9][0-9]_*.png", "contact_sheet*.png", "final.png"):
        for stale in glob.glob(os.path.join(args.dest, pat)):
            os.remove(stale)

    print(f"{'file':<34}{'size':>10}  {'colours':>8}  content")
    for n, (label, path) in enumerate(items, 1):
        im = Image.open(path).convert("RGB")
        name = label if label[:1].isdigit() else f"{n:02d}_{label}"
        dst = os.path.join(args.dest, f"{name}.png")
        im.save(dst)
        colours = len(im.getcolors(maxcolors=1 << 20) or [])
        # a blank screen would be one flat colour
        flag = "" if colours > 8 else "  <-- SUSPICIOUS (nearly flat)"
        print(f"{os.path.basename(dst):<34}{im.size[0]}x{im.size[1]:<6}{colours:>8}{flag}")

    for scale, name in ((1, "contact_sheet.png"), (2, "contact_sheet_2x.png")):
        sheet = contact_sheet(items, scale)
        sheet.save(os.path.join(args.dest, name))
        print(f"{name:<34}{sheet.size[0]}x{sheet.size[1]:<6}"
              f"{'':>8}  {len(items)} screens")

    print(f"\n{len(items)} screens + 2 contact sheets -> {os.path.abspath(args.dest)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
