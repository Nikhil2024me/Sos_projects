#!/usr/bin/env python3
"""Pixel verification of the SOS rebuild against the v2 handoff screenshots.

The renders in sim/out/ come from the real LVGL 9.6 build (tools/sim_build.sh);
the references in the handoff's reference/320x240/ are the v2 TFT_eSPI drawing
simulation.  Two jobs:

1. Report how far each clean-mode screen is from the faithful reference, so the
   intentional differences are visible rather than surprising.
2. Assert the specific things clean mode is supposed to change - the visual
   bugs V1..V9 from LVGL_REBUILD_SPEC.md section 11.1 - as pixel measurements,
   because "the geometry test says the border is at y=124" is weaker evidence
   than "no cyan ink shares a row with the border".

Usage: tools/diff_vs_reference.py --out sim/out --handoff <lvgl_handoff dir>
"""

from __future__ import annotations

import argparse
import os
import sys

from PIL import Image

PASS = 0
FAIL = 0


def check(ok: bool, msg: str) -> None:
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"PASS  {msg}")
    else:
        FAIL += 1
        print(f"FAIL  {msg}")


def close(c, target, tol=14):
    return all(abs(a - b) <= tol for a, b in zip(c[:3], target[:3]))


def load(path):
    return Image.open(path).convert("RGB")


class Frame:
    def __init__(self, path):
        self.im = load(path)
        self.px = self.im.load()
        self.w, self.h = self.im.size

    def count(self, target, box=None, tol=14):
        x0, y0, x1, y1 = box or (0, 0, self.w, self.h)
        n = 0
        for y in range(y0, y1):
            for x in range(x0, x1):
                if close(self.px[x, y], target, tol):
                    n += 1
        return n

    def ink_bbox(self, target, box=None, tol=14):
        """Bounding box of pixels matching `target`."""
        x0, y0, x1, y1 = box or (0, 0, self.w, self.h)
        xs, ys = [], []
        for y in range(y0, y1):
            for x in range(x0, x1):
                if close(self.px[x, y], target, tol):
                    xs.append(x)
                    ys.append(y)
        if not xs:
            return None
        return (min(xs), min(ys), max(xs), max(ys))

    def row_counts(self, target, y, box=None, tol=14):
        x0, _, x1, _ = box or (0, 0, self.w, self.h)
        return sum(1 for x in range(x0, x1) if close(self.px[x, y], target, tol))

    def diff(self, other):
        """Exact-match percentage and mean absolute difference."""
        if (self.w, self.h) != (other.w, other.h):
            return None
        same = 0
        tot = 0
        mad = 0
        for y in range(self.h):
            for x in range(self.w):
                a = self.px[x, y]
                b = other.px[x, y]
                d = sum(abs(p - q) for p, q in zip(a, b)) / 3.0
                mad += d
                tot += 1
                if d == 0:
                    same += 1
        return 100.0 * same / tot, mad / tot


# ---------------------------------------------------------------------------
# Clean-mode visual fixes (spec 11.1)
# ---------------------------------------------------------------------------
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
CYAN = (0, 255, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 182, 0)
BLUE = (0, 0, 255)
PURPLE = (123, 0, 123)


def v3_config_box(ours, ref):
    """V3: the config box border used to strike through the threshold text."""
    # The bottom border is the LAST full-width white row in the box band.
    def border_row(f):
        for y in range(133, 57, -1):
            n = f.row_counts(WHITE, y, (15, 0, 305, 240))
            if n > 200:
                return y, n
        return None, 0

    ry, rn = border_row(ref)
    oy, on = border_row(ours)
    ref_cyan = ref.row_counts(CYAN, ry, (15, 0, 305, 240))
    our_cyan = ours.row_counts(CYAN, oy, (15, 0, 305, 240))
    check(ref_cyan > 0,
          f"V3 reference border row y={ry} strikes through the cyan text "
          f"({ref_cyan} cyan px) - the bug is real")
    check(our_cyan == 0,
          f"V3 rebuilt border row y={oy} has no cyan ink ({our_cyan} px)")
    # the text ink must still be fully drawn above the border
    ink = ours.ink_bbox(CYAN, (15, 62, 305, oy))
    check(ink is not None and ink[3] < oy,
          f"V3 threshold ink rows "
          f"{ink[1] if ink else '?'}..{ink[3] if ink else '?'} end above the "
          f"border y={oy}")


def v9_logo_subtitle(ours, ref):
    """V9: the logo subtitle used to be drawn across the ring."""
    # ring: white pixels near the horizontal centre, above the subtitle
    ring = ours.ink_bbox(WHITE, (140, 40, 181, 190))
    ring_bottom = ring[3] if ring else -1
    sub = ours.ink_bbox(WHITE, (40, ring_bottom + 1, 280, 215))
    check(sub is not None and sub[1] > ring_bottom,
          f"V9 subtitle ink starts y={sub[1] if sub else '?'} below ring bottom "
          f"y={ring_bottom}")
    r_ring = ref.ink_bbox(WHITE, (140, 40, 181, 190))
    r_sub = ref.ink_bbox(WHITE, (40, 165, 280, 200))
    check(r_sub is not None and r_ring is not None and r_sub[1] <= r_ring[3],
          f"V9 reference subtitle (y{r_sub[1]}) overlaps the ring "
          f"(bottom y{r_ring[3]}) - the bug is real")


def v5_centred(f, box, target, label, tol_px=2):
    """V5: text that used to sit at a fixed left x is now centred."""
    bb = f.ink_bbox(target, box)
    if bb is None:
        check(False, f"V5 {label}: no ink found in {box}")
        return
    centre = (bb[0] + bb[2]) / 2.0
    check(abs(centre - 160) <= tol_px,
          f"V5 {label} ink centre x={centre:.1f} (panel centre 160)")


def v1_v2_service(ours, ref, name):
    """V1/V2: no invisible SOS, no duplicated hollow name, no white plate."""
    # the instruction bar must be black across the full width
    bar_white = sum(ours.row_counts(WHITE, y, (0, 160, 320, 225)) for y in range(200, 220))
    check(bar_white == 0,
          f"V2 {name}: instruction bar rows 200..219 carry ink only on the bar "
          f"({bar_white} stray white px)")

    # V1: the SOS overlay is now visible on the black bar
    sos = ours.ink_bbox(WHITE, (5, 160, 60, 182))
    check(sos is not None, f"V1 {name}: 'SOS' ink present on the bar {sos}")

    # V2: the faithful screen painted an opaque white plate behind the
    # vehicle.  Point (5,60) is plate in the reference for every service (the
    # vehicles all start at x>=14), and must be the service colour now.
    service_rgb = {"ambulance": RED, "dept": ORANGE, "police": BLUE,
                   "emergency": PURPLE}[name]
    check(close(ref.px[5, 60], WHITE),
          f"V2 {name}: reference (5,60) is the white plate "
          f"{ref.px[5, 60]} - the plate is real")
    check(close(ours.px[5, 60], service_rgb),
          f"V2 {name}: rebuilt (5,60) is the service colour {ours.px[5, 60]} "
          f"(expected {service_rgb})")
    ref_white = ref.count(WHITE, (0, 44, 320, 156))
    our_white = ours.count(WHITE, (0, 44, 320, 156))
    print(f"      note: white px in rows 44..155: reference {ref_white}, "
          f"rebuild {our_white} (the rebuild's white is the vehicle itself)")

    # the service name is drawn once, centred, on the bar
    v5_centred(ours, (0, 158, 320, 182), WHITE, f"{name} service name")


def v4_calling_ring(ours, ref):
    """V4: the white fill (r=60) and black outline (r=65) left a 4 px gap."""
    def annulus_px(f):
        n = 0
        cx, cy = 160, 120
        for y in range(cy - 66, cy + 67):
            for x in range(cx - 66, cx + 67):
                if not (0 <= x < f.w and 0 <= y < f.h):
                    continue
                r = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                if 61 <= r <= 64 and close(f.px[x, y], RED):
                    n += 1
        return n

    r_ref = annulus_px(ref)
    r_our = annulus_px(ours)
    check(r_ref > 200, f"V4 reference shows {r_ref} service-coloured annulus px")
    check(r_our == 0, f"V4 rebuilt ring has no colour gap ({r_our} px)")


def v6_v7_v8_slideshow(ours, ref):
    """V6 overlap, V7 clipped image, V8 footer strip over the image."""
    white = ours.ink_bbox(WHITE, (0, 0, 320, 240))
    check(white is not None and white[3] < 192,
          f"V7 slideshow image ink ends y={white[3] if white else '?'} above the "
          f"footer band (192)")

    header = ours.ink_bbox(WHITE, (0, 0, 320, 34))
    title = ours.ink_bbox(WHITE, (0, 34, 320, 56))
    check(header and title and header[3] < title[1],
          f"V6 header ink ends y={header[3] if header else '?'} before title ink "
          f"starts y={title[1] if title else '?'}")

    def rows_with_both(f, band):
        n = 0
        for y in range(*band):
            if f.row_counts(WHITE, y) > 4 and f.row_counts(YELLOW, y) > 4:
                n += 1
        return n

    check(rows_with_both(ref, (198, 210)) > 0,
          "V8 reference draws footer text over the white image - the bug is real")
    check(rows_with_both(ours, (192, 215)) == 0,
          "V8 rebuilt footer text never shares a row with image ink")


# ---------------------------------------------------------------------------
# Behaviour (from the state-machine log the autopilot produced)
# ---------------------------------------------------------------------------
def behaviour(log):
    txt = open(log, errors="replace").read()

    def has(s):
        return s in txt

    check(has("Touch: Going to SOS menu"), "L: touch on the main menu opens the service screen")
    check(txt.count("Touch: Next service") == 3,
          f"L: touch cycles all four services ({txt.count('Touch: Next service')} advances)")
    check(has("Button: Long press - Config menu"), "L: 2 s long press opens the configuration")
    check(has("Button: Starting demo slideshow"),
          "L6: the config screen's button starts the slideshow (unreachable in v2)")
    check(has("Auto-advance to slide 2"), "L7: the 3 s auto-advance timer runs")
    check(has("Button: Calling emergency service from main menu"),
          "L1: the main menu's button now does what its label promises")
    check(has("Emergency call completed"), "L: the call times out after 5 s")
    check(has("Button: Long press - leaving slideshow"),
          "L6: the slideshow's long press leaves the demo mode")
    check(has("Touch: Exiting config"),
          "L: a touch on the config screen returns to the main menu")

    calls = txt.count("Starting local emergency call")
    highs = txt.count("notification pin -> HIGH")
    lows = txt.count("notification pin -> LOW")
    on = txt.count("buzzer -> ON")
    off = txt.count("buzzer -> OFF")

    check(calls == 2,
          f"L: two calls were placed - one from the service screen, one from "
          f"the main menu (L1) ({calls})")
    check(highs == calls and lows == calls,
          f"L2: notification pin HIGH {highs}x and LOW {lows}x across {calls} calls "
          f"(v2 raised it and never lowered it)")
    check(4 * calls <= on <= 5 * calls and 5 * calls <= off <= 7 * calls,
          f"L: buzzer {on} on / {off} off over {calls} five-second calls, "
          f"i.e. one toggle per 500 ms")
    check("SX1278" not in txt or "probe skipped" in txt,
          "O10: no LoRa transmit path was added (presence probe only)")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sim/out")
    ap.add_argument("--handoff", required=True)
    args = ap.parse_args()

    ref_dir = os.path.join(args.handoff, "reference", "320x240")
    out = args.out

    pairs = [
        ("logo", "01_logo.png", "LOGO"),
        ("main_menu", "02_main_menu.png", "MAIN"),
        ("service_ambulance", "03_ambulance.png", "SERVICE ambulance"),
        ("service_fire", "04_fire_engine.png", "SERVICE fire dept"),
        ("service_police", "05_police.png", "SERVICE police"),
        ("service_emergency", "06_emergency.png", "SERVICE emergency"),
        ("config", "07_config_menu.png", "CONFIG"),
        ("calling_from_main", "08_calling_ambulance.png", "CALLING ambulance"),
        ("slideshow_1", "12_slideshow_medical.png", "SLIDESHOW 1"),
    ]

    frames = {}
    print("=" * 78)
    print("PIXEL COMPARISON vs the v2 handoff (clean mode intentionally differs)")
    print("=" * 78)
    print(f"{'screen':<22}{'identical':>10}{'mean |d|':>10}   {'changed px':>12}")
    def find_capture(name):
        for f in sorted(os.listdir(out)):
            if f.startswith("capture-") and f.endswith(f"-{name}.png"):
                return os.path.join(out, f)
        return os.path.join(out, f"capture-?-{name}.png")

    for cap, ref, label in pairs:
        cpath, rpath = find_capture(cap), os.path.join(ref_dir, ref)
        if not (os.path.exists(cpath) and os.path.exists(rpath)):
            print(f"{label:<22}{'MISSING':>10}  {cpath if not os.path.exists(cpath) else rpath}")
            continue
        ours, ref_f = Frame(cpath), Frame(rpath)
        frames[label] = (ours, ref_f)
        d = ours.diff(ref_f)
        if d is None:
            print(f"{label:<22}{'size mismatch':>10}")
            continue
        same, mad = d
        print(f"{label:<22}{same:>9.1f}%{mad:>10.1f}   {100 - same:>11.1f}%")

    print()
    print("=" * 78)
    print("CLEAN-MODE FIXES, MEASURED FROM PIXELS (spec 11.1 V1..V9)")
    print("=" * 78)

    if "CONFIG" in frames:
        v3_config_box(*frames["CONFIG"])
    if "LOGO" in frames:
        v9_logo_subtitle(*frames["LOGO"])
        v5_centred(frames["LOGO"][0], (0, 185, 320, 212), WHITE, "logo subtitle")
    if "MAIN" in frames:
        ours, ref_f = frames["MAIN"]
        v5_centred(ours, (0, 0, 320, 40), WHITE, "main title")
        bb = ref_f.ink_bbox(WHITE, (0, 0, 320, 40))
        check(bb is not None and abs((bb[0] + bb[2]) / 2.0 - 160) > 5,
              f"V5 reference main title centre x={(bb[0] + bb[2]) / 2.0 if bb else '?'}"
              f" (off-centre at x=70 - the bug is real)")
    for label in ("SERVICE ambulance", "SERVICE fire dept", "SERVICE police", "SERVICE emergency"):
        if label in frames:
            v1_v2_service(frames[label][0], frames[label][1], label.split()[-1])
    if "CALLING ambulance" in frames:
        v4_calling_ring(*frames["CALLING ambulance"])
        v5_centred(frames["CALLING ambulance"][0], (0, 0, 320, 30), BLACK,
                   "calling banner text")
    if "SLIDESHOW 1" in frames:
        v6_v7_v8_slideshow(*frames["SLIDESHOW 1"])

    print()
    print("=" * 78)
    print("BEHAVIOUR (from the autopilot's state-machine log)")
    print("=" * 78)
    log = os.path.join(out, "run.log")
    if os.path.exists(log):
        behaviour(log)
    else:
        check(False, f"{log} missing - run tools/sim_build.sh --run first")

    print()
    print("=" * 78)
    print(f"{PASS} pixel checks passed, {FAIL} FAILED")
    print("=" * 78)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
