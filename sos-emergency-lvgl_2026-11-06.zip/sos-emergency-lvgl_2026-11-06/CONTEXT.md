# CONTEXT — SOS Emergency Transmitter, LVGL rebuild + console redesign

**Date:** 2026-11-06 · **Status:** firmware compiles, UI verified headlessly,
**nothing has been flashed** (no board was attached).

This file is the handoff: what was asked, what was decided, what was built, how
it was verified, what is still open. Read this first, then `README.md`, then
`docs/PINMAP.md`.

---

## 1. The request, in order

1. Build the project in `lvgl_handoff.zip` (a v2 Arduino/TFT_eSPI SOS panel and
   a 1909-line rebuild specification).
2. Answers given up front:
   * **clean mode** — fix the spec's visual bugs V1–V9 and logic bugs L1–L10
     instead of reproducing them;
   * **LVGL 9.6**;
   * **wire up the slideshow** (`StartSlideshow()` was never called in v2);
   * hardware is an **ESP32-S3‑WROOM‑1 N16R8** + ILI9341 2.4" + XPT2046 touch
     + **LoRa SX1278**, and every pin had to be chosen for *that* board using
     the official Espressif docs and Context7 rather than guessed;
   * "build" means **compile the firmware + verify the UI in a simulator**,
     because the board is not connected;
   * editing TFT_eSPI's `User_Setup.h` was permitted.
3. Then: *"I'm tired of this boring UI… push it to the limits, completely
   design a new UI which is good."*
4. Then: *render it, save the images, and zip the whole thing with the context.*

## 2. Hardware decisions (and why)

The v2 pin map **could not be carried over**. Confirmed against the Espressif
documentation via the `espressif-docs` MCP:

| v2 pin | Verdict on the S3‑WROOM‑1 N16R8 |
|---|---|
| `NOTIFICATION_PIN 25` | **The ESP32‑S3 has no GPIO 25 at all.** Moved to GPIO 17. |
| `BUZZER_PIN 33` | **GPIO 33 is an octal‑PSRAM data line** on an R8 module. Moved to 18. |
| `BUTTON_PIN 1`, `TOUCH_CS 5`, `TOUCH_IRQ 16` | Valid and non‑strapping on the S3 — **kept**. |

Also avoided: 26–32 (flash/PSRAM), 33–37 (octal PSRAM; 33/34 not even brought
out), 19/20 (USB‑Serial/JTAG), 0/3/45/46 (strapping), 39–42 (JTAG), 43/44
(UART0). Spare: 38, 47, 48.

**Panel bus on SPI2's IO_MUX pins** — MOSI 11, SCLK 12, MISO 13, CS 10. The
ESP-IDF SPI master docs state that once *any* SPI signal goes through the GPIO
matrix the whole bus is capped near 40 MHz instead of 80; staying on IO_MUX
keeps the headroom. DC 9, RST 14, backlight 21.

**Radio on its own bus** (SPI3): NSS 4, SCLK 6, MISO 7, MOSI 8, RST 15, DIO0 2 —
so the SX1278 never arbitrates with the panel or the touch controller.

Full table + conflict audit: `docs/PINMAP.md`.

## 3. Architecture

```
src/app/     behaviour only: state machine, timers, buzzer, notification pin,
             debounce, service list, call lifecycle.  Six LVGL timers.
src/ui/      ui_api.h  - the skin contract (events in, screens out)
             ui_screens.c - skin 1
src/ui2/     ui_v2.c  - skin 2
src/hal/     hal.h is the only board boundary. Two implementations:
             hal_esp32.cpp + hal_display.cpp (device)  |  sim/hal_sim.cpp
```

The point of the split: **`src/ui*/` and `src/app/` include only LVGL.** No
`Arduino.h`, no `TFT_eSPI.h`, no GPIO. That is what lets the simulator compile
the *same source files* the ESP32 does.

`SOS_UI_DESIGN` picks the skin (default **2**):

| Skin | What it is |
|---|---|
| **2 — "SOS Console"** | New design. Dark emergency console: gradient service cards with vehicle silhouettes, hero "armed" screen, pulsing call rings with a 5 s countdown arc, per‑widget hit testing, gradients/shadows/animations. |
| 1 — faithful rebuild | Spec §7 geometry with V1–V9 / L1–L10 fixed. Kept because it has a 185‑assertion acceptance suite. |

One state machine drives both; skins report user intent through
`ui_event_t` (`UI_EV_SERVICE`, `UI_EV_CALL`, `UI_EV_CANCEL`, `UI_EV_CONFIG`,
`UI_EV_BACK`, `UI_EV_DEMO`, `UI_EV_DEMO_NEXT`, plus `UI_EV_ANY_TAP` for skin 1's
whole‑screen touch).

## 4. Results

| | |
|---|---|
| Firmware (skin 2) | **1,206,992 B — 38 %** of the 3 MB app partition; **115,228 B — 35 %** of DRAM |
| Device target | `esp32:esp32:esp32s3`, core **3.3.12**, `FlashSize=16M,PSRAM=opi,FlashMode=qio`, `PartitionScheme=app3M_fat9M_16MB` |
| Library versions | LVGL **9.6.0**, TFT_eSPI **2.5.43** |
| A8 image assets | 356 KiB in flash (4 services × service/hero/card/slide masks) |
| LVGL heap peak | 33 KB (skin 1), 43–47 KB (skin 2) against a 64 KB pool |
| Source written | ~31,200 lines (2.6 MB of which is the generated asset table) |

**Verification, all headless:**

* Skin 1 geometry: **185/185** assertions (`docs/sim_acceptance_report.txt`).
* Skin 1 pixels vs the v2 handoff screenshots: **48/48** — including proofs that
  each bug is *real* in the reference (e.g. "reference config border row y=114
  carries 40 cyan px; rebuild's y=124 carries 0").
* Skin 2 diagnostics: **0 warnings, 0 errors** across all six screens.
* Skin 2 contrast (WCAG AA, measured from rendered pixels): card name 5.4:1,
  section label 5.0:1, `OFFLINE` 6.4:1, `CALL NOW` 18.4:1, `CANCEL` 5.2:1.
* Skin 2 motion: two captures 2.2 s apart differ in 2028 px confined to the
  arc/ring bounding box — the countdown really animates.
* State machine: driven through the full flow (splash → home → armed → calling
  → cancel → all four services → settings → demo) and the log is checked
  (`docs/sim_state_machine.log`).

## 5. Bugs found and fixed along the way

Worth recording because they would each have cost a debugging session:

1. **`lv_display_create()` was called before `lv_init()`** in `setup()`. No
   simulator can catch this — it would have bricked the first flash. Fixed by
   reordering; the comment in `sos_emergency.ino` explains why.
2. **The `lvgl-simulator` MCP server has one shared build directory.** A
   concurrent session reconfigured it mid‑run and one render silently came from
   a *different project* (wrong font, wrong widget count). Rather than trust it
   I built a private simulator instance from the same harness
   (`tools/sim_build.sh`) — which also made PNG captures possible.
3. **`tools/png2lvgl_a8.py` emitted a 3‑field initialiser for a 4‑field
   struct**, leaving `hero` NULL and the hero image 0×0. The simulator's
   `ZERO_SIZE` diagnostic caught it.
4. Deprecated LVGL 9.6 flag API (`lv_obj_add_flag`/`remove_flag`) — replaced
   with version‑guarded `SOS_SET_*` shims so the source also builds on 9.5.
5. `C_DIM` text was 3.2:1 on the page background — lightened until it measured
   above 4.5:1.

## 6. MCP usage — what was consulted and what it returned

| MCP | Used for | Outcome |
|---|---|---|
| **espressif-docs** | WROOM‑1 pin restrictions, strapping pins, octal‑PSRAM pin usage, SPI2 IO_MUX set and the GPIO‑matrix 40 MHz ceiling | Drove the entire pin map; the "GPIO 25 does not exist" and "GPIO 33 is PSRAM" findings came from here |
| **lvgl-simulator** | `lvgl_docs("esp32")`, `lvgl_check`, `lvgl_render_project`, `lvgl_inspect`, `lvgl://project-config` | Confirmed A8+recolor rendering, produced all diagnostics; revealed the shared‑build‑dir hazard |
| **context7** | `/websites/lvgl_io_open` — LVGL 9 display setup | Confirmed `lv_display_set_buffers(..., LV_DISPLAY_RENDER_MODE_PARTIAL)`; suggested `LV_COLOR_FORMAT_RGB565_SWAPPED` as the faster byte‑order route (documented as an alternative in `hal_display.cpp`, not enabled because it cannot be bench‑tested here) |
| **lvgl** (semantic search) | Display driver + touch bring‑up | Returned mostly **LVGL v8** forum code (`lv_disp_drv_t`, `lv_disp_flush_ready`) that conflicts with v9; reconciled against the installed 9.6 headers, which is what actually compiles |
| chrome-devtools / next-devtools | Enumerated only | Not applicable (no browser/Next.js work) |

## 7. Known trade-offs / open items

1. **Not flashed, not run on hardware.** Touch calibration, backlight polarity
   and the 40 MHz SPI margin can only be confirmed on the bench.
2. **Two touch targets are under 40×40 px**: the `SET` pill (62×24) and the
   armed screen's `BACK` (62×24). A 40 px‑tall control cannot fit the 28 px
   status strip without eating the content area. Everything else meets it.
3. **Fonts are Montserrat**, not TFT_eSPI's pixel fonts. Spec §5.2 explains what
   pixel‑faithful output would require (`lv_font_conv` at 1 bpp from the
   original glyph tables).
4. **LoRa is configured but unused** — pins, a dedicated bus and a boot‑time
   `RegVersion` probe. Transmit/receive is spec feature O10 and needs explicit
   approval; nothing in this build joins a network or transmits.
5. **No formal assertion suite for skin 2** — it is covered by the simulator's
   diagnostics, the contrast measurements and the click‑driven flow log. Skin 1
   keeps its 185‑check suite.

## 8. How to rebuild everything

```bash
./build.sh                                  # firmware, skin 2 (console)
SOS_UI_DESIGN=1 ./build.sh                  # firmware, skin 1 (faithful)
./build.sh --doctor                         # verify toolchain versions
./build.sh --upload                         # flash, when a board is attached

tools/sim_build.sh                          # build the headless simulator
SOS_UI_DESIGN=2 tools/sim_build.sh --run    # renders -> screens_v2/
SOS_UI_DESIGN=1 tools/sim_build.sh --run    # renders -> screens/ + 185 checks
SOS_PYTHON=.venv/bin/python tools/sim_build.sh --run --diff   # + pixel diffs
```

The simulator needs a C toolchain plus Pillow for the PNG export
(`python3 -m venv .venv && .venv/bin/pip install pillow`).

## 9. Archive contents

```
CONTEXT.md                  this file
PREVIEW.png                 all skin-2 screens on one sheet (start here)
README.md  docs/  config/    project documentation, pin map, build settings
firmware/                   Arduino sketch - the whole device build
sim/                        headless harness, action scripts, checkers
tools/                      sim_build.sh, png2lvgl_a8.py, diff_*
screens_v2/                 15 renders of the console UI + 2 contact sheets
screens/                    19 renders of the faithful rebuild + 2 contact sheets
build/                      compiled firmware: app / bootloader / partitions /
                            boot_app0 / a 16 MB merged full-flash image
MANIFEST.txt                every file, with sizes and SHA-256
```