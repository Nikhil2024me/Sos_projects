# Pin map and hardware configuration

**Board:** ESP32-S3-WROOM-1 **N16R8** (16 MB quad flash + 8 MB *octal* PSRAM)
**Panel:** ILI9341 2.4" 320×240 SPI, rotation 1 (landscape)
**Touch:** XPT2046 resistive
**Radio:** LoRa SX1278 (Ra-02 style: NSS / RST / DIO0 + SPI)

Everything below is defined once, in
[`src/app/app_config.h`](../firmware/sos_emergency/src/app/app_config.h) and
[`tft_setup.h`](../firmware/sos_emergency/tft_setup.h). Nothing is duplicated.

---

## 1. Which pins the ESP32-S3-WROOM-1 N16R8 does *not* have

This is the reason the v2 pin map could not be carried over unchanged.

| Pins | Status on this module | Source |
|---|---|---|
| GPIO 26–32 | In-package flash/PSRAM SPI0/1. **Never use.** | ESP-IDF *GPIO & RTC GPIO* for ESP32-S3 |
| GPIO 33–37 | Octal-PSRAM data lines (DQ4–DQ7 + DQS). Not available on R8/R16V modules. **GPIO 33 and 34 are not even brought out on the WROOM-1.** | WROOM-1 datasheet Table 3-1 note *b*; ESP-IDF GPIO notes |
| GPIO 19, 20 | `USB_D-` / `USB_D+` (USB-Serial/JTAG). Reserved here so flashing and the serial console keep working. | WROOM-1 datasheet pin table |
| GPIO 0, 3, 45, 46 | Strapping pins (boot mode, VDD_SPI, ROM print, JTAG source). Avoided. | WROOM-1 datasheet §4 *Boot Configurations* |
| GPIO 39–42 | JTAG (MTCK/MTDO/MTDI/MTMS). Left free for debugging. | ESP32-S3 datasheet §2.3.4 |
| GPIO 43, 44 | UART0 TX/RX. Left free so a plain UART bridge still works. | ESP32-S3 datasheet §2.3.4 |

Consequences for the v2 map:

* **`NOTIFICATION_PIN 25` cannot be kept** — the ESP32-S3 has no GPIO 25 at all.
  Moved to **GPIO 17**.
* **`BUZZER_PIN 33` cannot be kept** — GPIO 33 is an octal-PSRAM line on this
  module. Moved to **GPIO 18**.
* `BUTTON_PIN 1`, `TOUCH_CS 5` and `TOUCH_IRQ 16` **are** valid on the S3 and
  are kept exactly as v2 had them.
* Spec issue **L9** ("GPIO 1 is UART0 TX, move the button") does not apply here:
  on the ESP32-S3 UART0 is GPIO 43/44, so GPIO 1 is an ordinary pin
  (ADC1_CH0 / TOUCH1, neither of which this project uses).

## 2. SPI buses

Two independent buses, deliberately.

```
SPI2 (FSPI)  ─┬─ ILI9341   (CS 10)
              └─ XPT2046   (CS 5)
SPI3 (HSPI)  ─── SX1278    (NSS 4)
```

**Why SPI2 for the panel and touch.** The S3's SPI2 IO_MUX pads are
`CS0=10, MOSI=11, SCLK=12, MISO=13, WP=14, HD=9`. Putting the four *SPI* signals
(MOSI, SCLK, MISO, CS) on 11/12/13/10 keeps the whole bus on IO_MUX. That
matters: per the ESP-IDF SPI master documentation, once *any* SPI signal is
routed through the GPIO matrix the whole bus goes through it and the practical
clock ceiling drops from 80 MHz to about 40 MHz. DC, RST and the chip selects
are ordinary GPIOs and do not affect that rule.

**Why the radio gets its own bus.** The SX1278 is a 10 MHz-maximum, extremely
chatty peripheral, and the XPT2046 needs the panel bus left in a known state
after every read. Sharing one bus means every radio access has to arbitrate with
the panel and the touch controller. Three extra GPIOs buy complete isolation.

## 3. The map

| Function | GPIO | Notes |
|---|---:|---|
| `PIN_TFT_MOSI` | **11** | SPI2 `FSPID` (IO_MUX) |
| `PIN_TFT_SCLK` | **12** | SPI2 `FSPICLK` (IO_MUX) |
| `PIN_TFT_MISO` | **13** | SPI2 `FSPIQ` (IO_MUX) |
| `PIN_TFT_CS` | **10** | SPI2 `FSPICS0` (IO_MUX) |
| `PIN_TFT_DC` | **9** | plain output |
| `PIN_TFT_RST` | **14** | plain output |
| `PIN_TFT_BL` | **21** | backlight, LEDC PWM at 5 kHz, 8-bit |
| `PIN_TOUCH_CS` | **5** | kept from v2; **not** a strapping pin on the S3 |
| `PIN_TOUCH_IRQ` | **16** | kept from v2; XPT2046 `PENIRQ` |
| `PIN_LORA_NSS` | **4** | SPI3 |
| `PIN_LORA_SCLK` | **6** | SPI3 |
| `PIN_LORA_MISO` | **7** | SPI3 |
| `PIN_LORA_MOSI` | **8** | SPI3 |
| `PIN_LORA_RST` | **15** | active-low reset |
| `PIN_LORA_DIO0` | **2** | interrupt-capable |
| `PIN_BUTTON` | **1** | `INPUT_PULLUP`, active LOW |
| `PIN_NOTIFICATION` | **17** | was 25 on v2 |
| `PIN_BUZZER` | **18** | was 33 on v2 |

GPIOs left untouched on purpose: 0, 3, 19, 20, 26–37, 39–48.
Spare and usable if you need them: **38, 47, 48** (plus 39–42 if you give up
JTAG, and 43/44 if you give up the UART0 console).

## 4. Conflict audit

Every pin above was checked against the four restriction classes. The check is
also enforced at compile time for the one set that must not drift:

```c
#if PIN_TFT_MOSI != 11 || PIN_TFT_SCLK != 12 || PIN_TFT_MISO != 13
#error "panel SPI must stay on the ESP32-S3 SPI2 IO_MUX pins"
#endif
```

| Class | Pins | Collision with this map |
|---|---|---|
| Flash / PSRAM (SPI0-1) | 26–32 | none |
| Octal PSRAM (DQ4–DQ7, DQS) | 33–37 | none |
| USB-Serial/JTAG | 19, 20 | none |
| Strapping | 0, 3, 45, 46 | none |
| JTAG | 39–42 | none |
| UART0 | 43, 44 | none |
| Used by this map | 1, 2, 4–18, 21 | 18 pins of the 23 available |

No pin is used twice, and no pin appears in two peripheral groups.

## 5. Wiring notes

* **T_IRQ.** Wired to GPIO 16, as in v2. `SOS_TOUCH_USE_IRQ` in `app_config.h`
  is **0** by default: the driver polls the XPT2046's Z reading instead, which
  reports "not touched" correctly even on a module where T_IRQ is not routed.
  Set it to 1 to skip the SPI read entirely when the panel is untouched.
  It is left off because an unrouted T_IRQ would be a silent touch failure.
* **Backlight.** GPIO 21 drives the module's LED pin through whatever the module
  already has (usually a transistor). PWM is on by default; set
  `SOS_BL_PWM 0` for a plain on/off backlight.
* **Buzzer.** `SOS_BUZZER_ACTIVE 1` (default) reproduces v2's plain on/off
  toggle for a self-driving active buzzer. Set it to 0 for a passive buzzer and
  the code switches a 2.7 kHz LEDC tone instead.
* **Notification output.** GPIO 17, active high. Clean mode drives it LOW when
  the call ends (spec issue L2).
* **Touch calibration.** The build uses TFT_eSPI's stock calibration with
  `setRotation(1)`, i.e. the same path the known-good upload used. If the axes
  ever look mirrored on your panel, run TFT_eSPI's `Touch_Calibrate` example and
  paste its numbers in with `tft.setTouch(...)` in `hal_display.cpp`.
* **Shared-ground note.** The panel, the touch controller and the SX1278 must
  all be on the same ground as the module, and the SX1278 needs a proper
  supply: it draws ~120 mA peaks on transmit. Nothing in this build transmits.

## 6. Pin map for the *other* revision

The older `old_sos_tran_rev_ili9341_stable.ino` used button 25, notification 21,
buzzer 22, touch CS 33/IRQ 32, and LoRa on 14/12/13/5/26/27. Those belong to a
different hardware revision and conflict with both the v2 map and the S3's
restricted pins. **Do not copy them.** They are listed here only so that the
difference is unambiguous.
