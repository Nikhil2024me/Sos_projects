# Clean mode: what changed and why

Baseline: `source/bitmapwith_touch_beta1.txt` (v2), as specified in
`LVGL_REBUILD_SPEC.md`.

The user chose **clean mode**: fix the visual bugs **V1–V9** and the logic bugs
**L1–L10** from spec §11 instead of reproducing them. Geometry that the spec
pins down (header 0–39, rule y=40, pressure bar 225–239, service instructions
y=190/y=202, calling footer 200–224, colours, all strings) is kept exactly.

Every fix below is verified mechanically — see §4.

---

## 1. Visual fixes (spec §11.1)

| # | Faithful bug | What the rebuild does | Verified by |
|---|---|---|---|
| **V1** | Service `SOS` is white-on-white: drawn at y=30 *before* the bitmap, and the bitmap's white plate starts at y=34, so only 3 rows survive. | The `SOS` overlay moved onto the instruction bar, drawn **after** everything else, so it is legible white-on-black. | Pixel: white ink found in `x12..49, y166..179` |
| **V2** | The service name is white-on-white with a black shadow and duplicates a label already baked into the bitmap — it looks hollow, and the two labels nearly collide. | One authoritative name, drawn once, on the black instruction bar. The bitmaps' baked-in labels (ambulance y159–172, police y191–213, fire y200–219) all fall **inside** the raised bar and are covered. | Pixel: reference `(5,60)` is the white plate, rebuild `(5,60)` is the service colour; name ink centred at x=159.5 |
| **V3** | The config box bottom border is y=114 and the `Touch threshold: 4300` ink runs to y=116, so the border strikes through the text. | Box height 55 → **65** (bottom y=124). The spec's own suggested fix. | Pixel: reference border row y=114 has 40 cyan px (struck through); rebuild border row y=124 has 0, ink ends y=122 |
| **V4** | The calling screen fills white r=60 and outlines black r=65, leaving a 4 px annulus of service colour — the ring looks detached. | One 130×130 disc: white fill, 2 px black rim (outer r=65). | Pixel: reference shows 1184 service-coloured px at radius 61–64; rebuild shows 0 |
| **V5** | Headers and texts sit at fixed left x positions and are visibly off-centre (main title x=70 → centre 149.5; config title x=90 → centre 137.5; banner x=40; `CALLING` x=105). | All of those are centred on the 320 px panel. Two-colour lines still start at their spec x and the value is placed after the *measured* label width instead of the old fixed 6 px cell. | Pixel: main title centre x=159.0, logo subtitle 159.5, calling banner 160.0, service name 159.5 |
| **V6** | Slideshow header (32 px line box from y=10) and title (y=40) overlap. | Bands redesigned: header y=4, title y=34, image y=56–187, footer y=192–213. | Checker: header ink ends y=25, title ink starts y=37 |
| **V7** | Slideshow bitmap drawn at y=80 with height 200 → 40 px off-screen. | The artwork is pre-fitted to the 320×132 image band by `tools/png2lvgl_a8.py` and clipped by that band. Nothing is cut off. | Pixel: image ink ends y=165, above the footer band |
| **V8** | Slideshow footer uses `setTextColor(YELLOW, BLACK)`, painting black character cells across the white image. | Footer is its own band below the image; the text never shares a row with image ink. | Pixel: reference has rows with both white image and yellow text; rebuild has none |
| **V9** | Logo subtitle at y=170 is drawn across the ring (both white) so the letters disappear. | Subtitle moved to y=190, below the ring (ring bottom y=183). | Pixel: subtitle ink starts y=193, ring bottom y=183; reference subtitle y=165 overlaps |
| V10 | No pressure bar on the logo. | Kept — this one is intentional. | Checker: bar hidden in `UI_LOGO`, visible elsewhere |

## 2. Logic fixes (spec §11.2)

| # | Faithful bug | What the rebuild does |
|---|---|---|
| **L1** | The main menu says `Button: Call Emergency (Local)` but a short press does nothing — the handler only ran in `SOS_MENU`. | A short press on the main menu starts a call, which is what the text promises. (The alternative — changing the text — was rejected because spec §9 freezes the string inventory.) |
| **L2** | `NOTIFICATION_PIN` is never driven LOW, so it stays HIGH forever after the first call. | `call_end()` drives it LOW, and `app_enter()` calls `call_end()` on every exit from the calling state. Log: HIGH once, LOW once. |
| **L3** | `handleEmergencyTimeout()` uses a `static callStartTime` that a touch-cancel never resets, so the *second* call can end instantly. | A real one-shot `lv_timer` (`repeat_count = 1`) created on call start and deleted on call end. No statics. |
| **L4** | A 2 s long press during a call opens the config screen and leaves the call, buzzer and notification running; the timeout later jumps back to `SOS_MENU`. | `app_enter()` ends the call for any target state other than `UI_CALLING`. Last buzzer and notification states are always OFF. |
| **L5** | Touch Y is mapped to `SCREEN_HEIGHT` (200), so the bottom 40 px of a 240 px panel cannot be reached. | Touch coordinates come from TFT_eSPI's calibrated, rotation-aware conversion, i.e. the full 320×240. (`SOS_TOUCH_Y_MAX` is kept for reference.) |
| **L6** | `StartSlideshow()` is never called: the four-slide demo is unreachable dead code. | Wired up. **Entry:** a short button press on the configuration screen. **Exit:** a 2 s long press returns straight to the main menu — the demo mode is self-contained instead of dropping the user into the config screen, which would need a second touch to leave (v2's long press went to `CONFIG_MENU`). A new hint line `Button: Demo slideshow` was added to the config screen so the gesture is discoverable. |
| **L7** | The footer says `Auto: 3s` but `AUTO_SLIDE_DURATION` is never used — there is no auto-advance. | A 3 s `lv_timer` advances the slides; a manual touch also resets it. The footer text is now true. |
| **L8** | Uptime is drawn once and frozen until the screen is re-entered. | Live: a 1 s timer on the main menu updates the label in place (no full-screen redraw). |
| **L9** | Button on GPIO 1 is UART0 TX and can interfere with upload and boot. | **Resolved by the hardware, not by code.** On the ESP32-S3, UART0 is GPIO 43/44, so GPIO 1 is an ordinary GPIO and is safe. The v2 pin is kept. |
| **L10** | Dead code: `DrawServicePattern()`, `FONT_SIZE`, `slideshowActive`, `slideChanged`, the unused auto-slide constant. | All removed. |

## 3. Additions that are not fixes

* `Button: Demo slideshow` on the config screen (§2, L6) — needed for
  discoverability of the newly wired slideshow.
* A boot banner on the serial console with build date, panel/touch/HMI/LoRa pin
  summary, PSRAM status and the SX1278 probe result.
* An SX1278 **presence probe** at boot (reads `RegVersion` 0x42, expects 0x12)
  and its pins fully configured. **No transmit or receive code exists**: spec
  feature O10 needs separate approval and the v2 firmware has no LoRa code.

## 4. How each fix is verified

Two independent, repeatable checks, both runnable with no hardware:

```bash
tools/sim_build.sh --run            # 16 captures + the geometry test
tools/sim_build.sh --run --diff     # plus the pixel comparison
```

| Check | What it does | Result |
|---|---|---|
| Geometry acceptance test (`sim/sim_checks.cpp`) | Walks the live LVGL widget tree and asserts every coordinate, size, colour, font and string in spec §7, plus the [V3]/[V4]/[V6]/[V7]/[V8] invariants and the state-machine log. | **185 / 185 pass** |
| Pixel verification (`tools/diff_vs_reference.py`) | Compares each rendered screen with the corresponding v2 handoff screenshot and asserts the clean-mode changes as pixel measurements, including "the bug is real in the reference". | **48 / 48 pass** |

### Similarity to the v2 reference (lower = more intentionally changed)

| Screen | identical pixels | mean abs. difference |
|---|---:|---:|
| LOGO | 95.1 % | 5.8 |
| MAIN | 86.2 % | 17.8 |
| CONFIG | 91.5 % | 11.5 |
| SLIDESHOW 1 | 58.5 % | 94.4 |
| SERVICE ambulance | 48.7 % | 91.0 |
| SERVICE fire dept | 35.8 % | 80.3 |
| SERVICE police | 32.8 % | 118.8 |
| SERVICE emergency | 29.7 % | 118.5 |
| CALLING ambulance | 37.5 % | 57.0 |

The service screens differ the most because their whole premise changed: the
faithful screen is an opaque white plate with a coloured vehicle, the clean
screen is a service-coloured screen with a white vehicle. The logo and the two
menu screens, which clean mode barely touches, are 86–95 % identical.

## 5. Deliberately *not* done

* **No pixel-faithful TFT_eSPI fonts.** Spec §5.2: exact fonts need
  `Font16.c` / `Font32rle.c` / `glcdfont.c` extracted into a BDF and converted
  with `lv_font_conv` at 1 bpp. The rebuild uses Montserrat 14/16/20/24/28 and
  centres text by measurement instead of by the old fixed 6 px cell.
* **No optional features from spec §12** other than the slideshow wiring and the
  live uptime / auto-advance that the L-list requires. No NVS settings, no
  brightness menu, no cancel-confirmation dialog, no battery icon, no OTA, no
  LoRa status screen.
* **Nothing is uploaded** — no board is attached. The firmware is compiled and
  the UI is verified headlessly; flashing is `./build.sh --upload` once the
  board is connected.
