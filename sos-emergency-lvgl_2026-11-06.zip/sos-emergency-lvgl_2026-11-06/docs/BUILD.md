# Build, verify and flash

Everything hardware-specific is pinned in
[`config/build_env.sh`](../config/build_env.sh). Change it there, not in your
shell history.

---

## 1. Toolchain

| Thing | Version | Install |
|---|---|---|
| `arduino-cli` | 1.5.x | distro package |
| ESP32 core | **3.3.12** | `arduino-cli core install esp32:esp32@3.3.12` |
| LVGL | **9.6.0** | `arduino-cli lib install "lvgl@9.6.0"` |
| TFT_eSPI | **2.5.43** | `arduino-cli lib install "TFT_eSPI@2.5.43"` |

`./build.sh --doctor` checks all four and fails with the exact command to run if
one is missing.

## 2. Board options (FQBN)

```
esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,
  PartitionScheme=app3M_fat9M_16MB,CDCOnBoot=default,USBMode=hwcdc,
  UploadSpeed=921600,DebugLevel=none
```

Why each one, for an **N16R8** module:

| Option | Value | Reason |
|---|---|---|
| `FlashSize` | `16M` | the module has 16 MB of flash |
| `PSRAM` | `opi` | N16R8 is an **R8** die → *octal* PSRAM. `enabled` (QSPI) would report `psramFound()==false`. |
| `FlashMode` | `qio` | the flash is quad. **Do not** set `opi`: that is octal *flash* (WROOM-2) and bricks the boot here. |
| `PartitionScheme` | `app3M_fat9M_16MB` | 3 MB app partition; the UI + 356 KiB of A8 masks + LVGL fit with room to spare |
| `USBMode` | `hwcdc` | keeps the built-in USB-Serial/JTAG on GPIO 19/20 available |
| `CDCOnBoot` | `default` | logs come out on the hardware CDC / UART0 bridge |

`arduino-cli board details -b esp32:esp32:esp32s3` lists every option and its
legal values; use it instead of guessing.

## 3. Build

```bash
./build.sh                # compile (no board needed)
./build.sh --clean        # wipe the build directory first
./build.sh --size         # compile and print the memory summary
./build.sh --sim          # compile and run the headless UI verification
./build.sh --upload       # compile and flash (needs the board attached)
./build.sh --monitor      # serial monitor at 115200
```

Result on this toolchain:

```
Sketch uses 1112335 bytes (35%) of program storage space. Maximum is 3145728 bytes.
Global variables use 115140 bytes (35%) of dynamic memory, leaving 212540 bytes for local variables.
```

The 115 KB of globals is dominated by the 25,600-byte LVGL draw buffer, the
356 KiB of A8 masks live in flash, and LVGL's own heap (64 KB, `lv_conf.h`) is
allocated at runtime from DRAM.

The build is self-contained: no library file is edited. Two headers in the
sketch folder do all the configuration —

* `lv_conf.h` — LVGL 9.6 config. Found automatically because
  `lv_conf_internal.h` does `__has_include("lv_conf.h")` and the sketch folder
  is on the include path.
* `tft_setup.h` — TFT_eSPI config. Found automatically because `TFT_eSPI.h`
  does `__has_include(<tft_setup.h>)` and then defines `USER_SETUP_LOADED`, so
  TFT_eSPI's own `User_Setup_Select.h` / `User_Setup.h` are skipped entirely.

That last point is the answer to the "I edited `User_Setup.h` and nothing
changed" class of problem: there is only ever one setup file, and it is in the
repository. If you would rather edit the library, `./build.sh --tft-setup`
copies `tft_setup.h` over `libraries/TFT_eSPI/User_Setup.h` for you.

## 4. Verifying without hardware

The UI half of the firmware (`src/ui/`, `src/app/`) includes nothing but LVGL,
so it is compiled and rendered by the LVGL 9.6 simulator with the *same source
files* the ESP32 builds.

```bash
tools/sim_build.sh --run          # 16 screen captures + geometry acceptance test
tools/sim_build.sh --run --diff   # plus the pixel comparison with the v2 handoff
```

The pixel comparison needs Pillow (`python3 -m venv .venv && .venv/bin/pip
install pillow`, then `SOS_PYTHON=.venv/bin/python tools/sim_build.sh --run
--diff`). The build and the geometry test need nothing but a C toolchain.

What it produces:

| Artifact | Meaning |
|---|---|
| `sim/out/capture-*.png` | one PNG per screen, in the order shown in the state-machine log |
| `sim/out/run.log` | the autopilot's state-machine log (every transition, buzzer and notification change) |
| `docs/sim_acceptance_report.txt` | the full 185-check geometry report |
| `docs/sim_state_machine.log` | the last autopilot run, verbatim |
| stdout of `--diff` | 48 pixel assertions against the handoff's v2 screenshots |

`tools/sim_build.sh` uses a **private** build directory. The `lvgl-simulator`
MCP tool keeps one shared build tree, so two projects rendered at the same time
silently clobber each other; the private tree makes the result reproducible.

### What is checked

* **Geometry (185 checks).** Every widget's position, size, background colour,
  text colour, font and string from spec §7, read out of the live LVGL tree —
  plus the V3/V4/V6/V7/V8 invariants and the pressure bar's three states
  (`0` → dark grey, `4300` → orange `[LOW]`, `4301` → green `[OK]`).
* **Behaviour.** The autopilot drives the real state machine through
  logo → main → four services → config → slideshow → main → calling → timeout,
  using the same entry points the hardware uses, and the log is asserted against
  the spec's event table (including "notification HIGH exactly once and LOW
  exactly once").
* **Pixels (48 checks).** Each capture is compared with the corresponding v2
  reference screenshot, and each clean-mode fix is asserted as a measurement,
  including proof that the bug exists in the reference.

## 5. Flashing (when the board is attached)

```bash
./build.sh --upload            # uses SOS_PORT, default /dev/ttyACM0
SOS_PORT=/dev/ttyUSB0 ./build.sh --upload
```

Troubleshooting, in the order the problems actually occur:

| Symptom | Cause | Fix |
|---|---|---|
| port disappears | `brltty`/`ModemManager` grabbed a CH34x/CP210x | stop the service, replug |
| permission denied | another process holds the port | `fuser -v /dev/ttyACM0`, add yourself to `dialout` |
| `Failed to connect` | not in download mode | hold **BOOT**, tap **RESET**, release |
| upload fails only at 921600 | marginal USB or long wires | `UploadSpeed=115200` in the FQBN |
| uploads, no serial output | `CDCOnBoot` / port mismatch | the N16R8 has no USB bridge; use the native USB port with `USBMode=hwcdc` |
| boots but the panel is blank | backlight or wiring | check GPIO 21, then the boot banner for the pin summary |
| white screen, no UI | LVGL heap or the flush contract | the banner prints PSRAM status; the LVGL heap peak measured in simulation is 33 KB of the 64 KB pool |
| touch offset or mirrored | panel calibration | run TFT_eSPI's `Touch_Calibrate` and paste the values into `hal_display.cpp` with `tft.setTouch()` |

After flashing, the boot banner prints the build date/time, the panel and touch
pins, the HMI and LoRa pin map, PSRAM status and the SX1278 probe result. That
is the fastest way to confirm which binary is actually running.

## 6. Regenerating the image assets

`src/assets/svc_images.c` (356 KiB of A8 masks) is generated from the handoff's
PNGs and is checked in so a plain build needs no Python:

```bash
python3 tools/png2lvgl_a8.py \
    --assets <lvgl_handoff>/assets \
    --outdir firmware/sos_emergency/src/assets
```

It produces two masks per service: the `_icon` artwork cropped to the region the
1-bit source actually paints (used on the service screen), and the same artwork
fitted to the slideshow's image band. The header explains why cropping is
necessary — the handoff's `_icon` files are alpha inversions of the `_negative`
files, so they carry stray white bands wherever the original bitmap rows were
blank.
