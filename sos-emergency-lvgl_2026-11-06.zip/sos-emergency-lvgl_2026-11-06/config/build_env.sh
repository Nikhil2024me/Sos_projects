# Single source of truth for the firmware build.
# Sourced by ./build.sh - edit here, not in the script.
#
# Board: ESP32-S3-WROOM-1 N16R8  ->  16 MB flash, 8 MB *octal* PSRAM.
#   FlashSize=16M   the module has 16 MB
#   PSRAM=opi       N16R8 is an R8 die -> OCTAL PSRAM (NOT "enabled" = QSPI)
#   FlashMode=qio   the flash is QUAD.  Do NOT set FlashMode=opi: that is for
#                   WROOM-2 style octal *flash* and bricks the boot here.
#   PartitionScheme=app3M_fat9M_16MB  gives a 3 MB app partition; the UI plus
#                   354 KiB of A8 masks plus LVGL fits with room to spare.
SOS_FQBN="esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,PartitionScheme=app3M_fat9M_16MB,CDCOnBoot=default,USBMode=hwcdc,UploadSpeed=921600,DebugLevel=none"

# UI skin: 2 = console redesign (default), 1 = the faithful-geometry rebuild.
# Both share one state machine; only the visuals and the input model differ.
SOS_UI_DESIGN="${SOS_UI_DESIGN:-2}"

# Port used only by `arduino-cli upload`; the board is not attached right now.
SOS_PORT="${SOS_PORT:-/dev/ttyACM0}"

# TFT_eSPI is configured by firmware/sos_emergency/tft_setup.h, which the
# library picks up by itself (TFT_eSPI.h does __has_include(<tft_setup.h>) and
# then defines USER_SETUP_LOADED, so User_Setup_Select.h / User_Setup.h are
# skipped).  No library file is edited and no compiler flag is needed.
# To use the library-edit route instead, copy that file over
#     <Arduino>/libraries/TFT_eSPI/User_Setup.h
