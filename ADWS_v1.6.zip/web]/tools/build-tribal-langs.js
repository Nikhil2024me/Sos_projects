#!/usr/bin/env node
/**
 * ADWS — build generated beta language packs.
 *
 * Run:  node tools/build-tribal-langs.js
 *
 * What it does
 *   1. Reads the English dictionary from i18n.js.
 *   2. Keeps every key except the long "about" methodology block.
 *   3. Machine-translates the strings to Meitei (mni-Mtei) and Tulu (tcy).
 *   4. Masks placeholders, units, service names and numbers so the translation
 *      cannot break {count} style tokens or turn 112 into words.
 *   5. Writes i18n.tribal.js, which i18n.langs.js merges at load time.
 *
 * These packs are machine-assisted and unreviewed. The app labels them "Beta"
 * and shows the English original for live alert details. Do not remove that
 * notice without adding a human review step.
 */
"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const i18n = require(path.join(root, "i18n.js"));
const config = require(path.join(root, "config.js"));

const OUT_FILE = path.join(root, "i18n.tribal.js");
const REPORT_FILE = path.join(root, "test", "lang-generation-report.json");

const TARGETS = [
  {
    code: "mni",
    gt: "mni-Mtei",
    short: "ꯃꯤ",
    label: "ꯃꯤꯇꯩꯂꯣꯟ",
    english: "Meitei (Manipuri)",
    locale: "mni-Mtei-IN"
  },
  {
    code: "tcy",
    gt: "tcy",
    short: "ತುಳು",
    label: "ತುಳು",
    english: "Tulu",
    locale: "tcy-IN"
  }
];

const SKIP_TOP = new Set(["about"]);

/*
 * Tokens that must survive translation untouched: {placeholders}, URLs,
 * service names, units and numbers. The translator is called only on the
 * plain-language segments between them, so a placeholder can never be dropped
 * or renamed by the machine translation. (An earlier version masked tokens with
 * private-use characters; Google often stripped those, which silently deleted
 * placeholders. Splitting is boring but correct.)
 */
const PROTECT_PATTERN =
  "(\\{[a-zA-Z0-9_]+\\})" +
  "|(https?:\\/\\/[^\\s)]+)";
const PROTECT_SPLIT = new RegExp(PROTECT_PATTERN, "gi");
const PROTECT_EXACT = new RegExp("^(?:" + PROTECT_PATTERN + ")$", "i");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const FETCH_TIMEOUT_MS = 8000;
const translationCache = new Map();

function walkEnglish(value, key) {
  if (key != null && SKIP_TOP.has(key)) return undefined;
  if (Array.isArray(value)) {
    return value.map((item) => walkEnglish(item, null));
  }
  if (value && typeof value === "object") {
    const out = {};
    Object.keys(value).forEach((child) => {
      const result = walkEnglish(value[child], child);
      if (result !== undefined) out[child] = result;
    });
    return out;
  }
  return value;
}

async function translateOnce(gt, text) {
  const url =
    "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=" +
    encodeURIComponent(gt) +
    "&dt=t&q=" +
    encodeURIComponent(text);
  const response = await fetch(url, {
    headers: { "User-Agent": "ADWS-lang-builder/1.0" },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS)
  });
  if (!response.ok) throw new Error("HTTP " + response.status);
  const data = await response.json();
  if (!Array.isArray(data) || !Array.isArray(data[0])) throw new Error("bad payload");
  return data[0].map((part) => (Array.isArray(part) ? part[0] : "")).join("");
}

async function translateSegment(gt, text) {
  const cacheKey = gt + "\u0000" + text;
  if (translationCache.has(cacheKey)) {
    return { text: translationCache.get(cacheKey), fallback: false };
  }
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const result = await translateOnce(gt, text);
      translationCache.set(cacheKey, result);
      return { text: result, fallback: false };
    } catch (error) {
      lastError = error;
      await sleep(400 * (attempt + 1));
    }
  }
  return { text, fallback: true, error: lastError ? lastError.message : "unknown" };
}

async function translate(gt, text) {
  if (typeof text !== "string" || !text.trim()) return { text, fallback: false };
  const parts = text.split(PROTECT_SPLIT);
  let fallback = false;
  const out = [];
  for (const part of parts) {
    if (!part) continue;
    if (PROTECT_EXACT.test(part)) {
      out.push(part);
      continue;
    }
    if (!part.trim()) {
      out.push(part);
      continue;
    }
    const result = await translateSegment(gt, part);
    if (result.fallback) fallback = true;
    out.push(result.text);
  }
  const joined = out.join("");
  if (!joined.trim() || joined.trim() === text.trim()) return { text, fallback: true };
  return { text: joined, fallback };
}

function translateTree(value, gt, stats, pathParts, jobs) {
  if (Array.isArray(value)) {
    return value.map((item, index) => {
      const itemPath = pathParts.concat([String(index)]);
      if (typeof item === "string") {
        jobs.push({ pathParts: itemPath, source: item });
        return item;
      }
      return translateTree(item, gt, stats, itemPath, jobs);
    });
  }
  if (value && typeof value === "object") {
    const out = {};
    Object.keys(value).forEach((key) => {
      out[key] = translateTree(value[key], gt, stats, pathParts.concat([key]), jobs);
    });
    return out;
  }
  if (typeof value === "string") {
    jobs.push({ pathParts, source: value });
  }
  return value;
}

function setPath(object, parts, value) {
  let node = object;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const key = parts[i];
    if (Array.isArray(node)) {
      const index = Number(key);
      if (!node[index]) node[index] = {};
      node = node[index];
    } else {
      if (!node[key]) node[key] = {};
      node = node[key];
    }
  }
  const last = parts[parts.length - 1];
  if (Array.isArray(node)) node[Number(last)] = value;
  else node[last] = value;
}

async function buildPack(target) {
  const stats = { total: 0, fallback: 0, failed: 0 };
  const skeleton = walkEnglish(i18n.en, null);
  const jobs = [];
  translateTree(skeleton, target.gt, stats, [], jobs);

  const report = { code: target.code, gt: target.gt, total: jobs.length, fallback: 0, failed: 0 };

  let cursor = 0;
  async function worker() {
    while (cursor < jobs.length) {
      const job = jobs[cursor];
      cursor += 1;
      const result = await translate(target.gt, job.source);
      if (result.fallback) {
        report.fallback += 1;
        if (result.error) report.failed += 1;
      }
      setPath(skeleton, job.pathParts, result.text);
      if (cursor % 25 === 0) {
        process.stdout.write("  " + target.code + " " + cursor + "/" + jobs.length + "\r");
      }
    }
  }

  const workers = [];
  for (let i = 0; i < 10; i += 1) workers.push(worker());
  await Promise.all(workers);
  process.stdout.write("\n");

  // Fixed values that must not be machine-translated: the brand name and the
  // BCP-47 locale used for date/number formatting.
  skeleton.appName = "ADWS";
  skeleton.locale = target.locale;

  console.log(
    "  " + target.code + ": " + jobs.length + " strings, " +
    report.fallback + " English fallbacks, " + report.failed + " upstream errors"
  );
  return { skeleton, report };
}

async function translateNames(names) {
  const out = {};
  for (const name of names) {
    const result = await translate(targetForNames.gt, name);
    out[name] = result.fallback ? name : result.text;
  }
  return out;
}

let targetForNames = null;

async function main() {
  const packs = {};
  const reports = [];
  for (const target of TARGETS) {
    console.log("Building " + target.code + " (" + target.gt + ") ...");
    const built = await buildPack(target);
    targetForNames = target;
    const regions = config.regions || [];
    const regionNames = {};
    for (const region of regions) {
      const result = await translate(target.gt, region.name.en);
      regionNames[region.id] = result.fallback ? region.name.en : result.text;
    }
    const states = Array.from(new Set(regions.map((region) => region.state.en)));
    const stateNames = {};
    for (const state of states) {
      const result = await translate(target.gt, state);
      stateNames[state] = result.fallback ? state : result.text;
    }
    packs[target.code] = built.skeleton;
    reports.push(Object.assign({}, built.report, {
      districts: regionNames,
      states: stateNames
    }));
  }

  const data = {
    generatedAt: new Date().toISOString(),
    generator: "tools/build-tribal-langs.js",
    note: "Machine-assisted beta packs. English is authoritative. Do not remove the beta notice without native review.",
    packs,
    meta: TARGETS.map((target) => ({
      code: target.code,
      short: target.short,
      label: target.label,
      english: target.english,
      locale: target.locale,
      beta: true,
      reviewed: false,
      coverage: "core"
    })),
    regionNames: {},
    stateNames: {}
  };

  reports.forEach((report) => {
    data.regionNames[report.code] = report.districts;
    data.stateNames[report.code] = report.states;
    delete report.districts;
    delete report.states;
  });

  const body =
    "/*\n" +
    " * ADWS — generated beta language packs (Meitei, Tulu).\n" +
    " * Generated by tools/build-tribal-langs.js on " + data.generatedAt + ".\n" +
    " * Machine-assisted and unreviewed: the app shows a Beta notice and the\n" +
    " * English original for live alert details. Regenerate instead of editing.\n" +
    " */\n" +
    "(function (root) {\n" +
    "  \"use strict\";\n" +
    "  var DATA = " + JSON.stringify(data, null, 2) + ";\n" +
    "  root.APP_TRIBAL_LANGS = DATA;\n" +
    "  if (typeof module !== \"undefined\" && module.exports) module.exports = DATA;\n" +
    "})(typeof window !== \"undefined\" ? window : globalThis);\n";

  fs.writeFileSync(OUT_FILE, body, "utf8");
  fs.writeFileSync(REPORT_FILE, JSON.stringify(data, null, 2), "utf8");
  console.log("Wrote " + OUT_FILE);
  console.log("Wrote " + REPORT_FILE);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
