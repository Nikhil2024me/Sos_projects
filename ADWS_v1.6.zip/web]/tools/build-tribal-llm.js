#!/usr/bin/env node
/**
 * ADWS — build generated beta language packs with the Token Harbor LLM.
 *
 * Run:  node tools/build-tribal-llm.js
 *
 * Why this exists: the public Google Translate endpoint (used by
 * tools/build-tribal-langs.js) started answering 429 for this host, so the
 * packs are produced by the project's own LLM instead. Same output contract:
 * i18n.tribal.js + test/lang-generation-report.json, merged by i18n.langs.js.
 *
 * Safety rules, mirroring the Google builder:
 *   - {placeholders}, URLs, numbers and Latin acronyms must survive.
 *   - mni must be written in Meitei Mayek, tcy in Kannada script.
 *   - Hindi/Devanagari is never allowed in these packs.
 *   - Anything that fails validation falls back to the English string.
 */
"use strict";

const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const i18n = require(path.join(root, "i18n.js"));
const config = require(path.join(root, "config.js"));
const secrets = require(path.join(root, "server-secrets.js"));

const OUT_FILE = path.join(root, "i18n.tribal.js");
const REPORT_FILE = path.join(root, "test", "lang-generation-report.json");

const ENDPOINT = "https://tokenharbor.ai/v1/chat/completions";
const MODEL = "deepseek-v4.1-flash:free";
const BATCH_SIZE = 25;
const CONCURRENCY = 3;
const REQUEST_TIMEOUT_MS = 180000;
const MAX_ATTEMPTS = 3;

const SKIP_TOP = new Set(["about"]);

const TARGETS = [
  {
    code: "mni",
    langName: "Meitei/Manipuri (mni-Mtei)",
    scriptName: "Meitei Mayek",
    short: "ꯃꯤ",
    label: "ꯃꯤꯇꯩꯂꯣꯟ",
    english: "Meitei (Manipuri)",
    locale: "mni-Mtei-IN",
    native: /[\uABC0-\uABFF]/g
  },
  {
    code: "tcy",
    langName: "Tulu (tcy)",
    scriptName: "Kannada",
    short: "ತುಳು",
    label: "ತುಳು",
    english: "Tulu",
    locale: "tcy-IN",
    native: /[\u0C80-\u0CFF]/g
  }
];

const DEVANAGARI = /[\u0900-\u097F]/;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/* ------------------------------------------------------------------ */
/* Placeholder / token protection                                      */
/* ------------------------------------------------------------------ */

function placeholders(value) {
  if (typeof value !== "string") return [];
  return [...value.matchAll(/\{\w+\}/g)].map((m) => m[0]).sort();
}

function stripProtected(text) {
  return text.replace(/\{\w+\}/g, " ").replace(/https?:\/\/[^\s)]+/g, " ");
}

function countNative(text, re) {
  const matches = text.match(re);
  return matches ? matches.length : 0;
}

function countLatin(text) {
  const matches = text.match(/[A-Za-z]/g);
  return matches ? matches.length : 0;
}

/*
 * Short labels ("Live"), pure acronyms ("NASA FIRMS") and standalone numbers may
 * legitimately stay in Latin; everything long enough to carry meaning must come
 * back in the target script. Thresholds are deliberately lenient so a good
 * translation is never thrown away, but strict enough to catch a Latin echo.
 */
function needsNative(text) {
  const core = stripProtected(text).trim();
  if (core.length < 10) return false;
  if (countLatin(core) < 4) return false;
  if (/^[^a-z]*$/.test(core)) return false; // all-caps acronyms
  return true;
}

function validate(target, source, value) {
  if (typeof value !== "string" || !value.trim()) return "empty";
  const trimmed = value.trim();
  if (trimmed === source.trim()) return "untranslated";
  if (placeholders(source).join(",") !== placeholders(trimmed).join(",")) return "placeholder mismatch";
  if (DEVANAGARI.test(trimmed) && !DEVANAGARI.test(source)) return "devanagari";
  if (needsNative(source)) {
    const native = countNative(trimmed, target.native);
    if (native < 2) return "not in " + target.scriptName + " script";
    const latin = countLatin(trimmed);
    if (native * 3 < latin) return "mostly Latin";
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Token Harbor chat completions                                       */
/* ------------------------------------------------------------------ */

async function callModel(target, batch) {
  const payload = {};
  const ids = [];
  batch.forEach((item, index) => {
    const id = "s" + index;
    ids.push({ id, source: item });
    payload[id] = item;
  });
  const system =
    "You are a professional translator for an Indian disaster-warning web app. " +
    "Translate the English UI strings in the user's JSON object into " +
    target.langName + ", written exclusively in " + target.scriptName + " script " +
    "(never Devanagari, never Roman transliteration). " +
    "Rules: keep {placeholders} exactly as they are; keep URLs, numbers, units " +
    "(km, °C, µg/m³), and Latin acronyms/brands (ADWS, NASA, FIRMS, USGS, GDACS, PM2.5, AQI) unchanged; " +
    "keep the tone short and suitable for small buttons. " +
    "Reply with one strict JSON object mapping every input id to its translation " +
    "string. Do not add commentary, markdown fences or extra keys.";
  const body = JSON.stringify({
    model: MODEL,
    temperature: 0,
    messages: [
      { role: "system", content: system },
      { role: "user", content: JSON.stringify(payload) }
    ]
  });

  let lastError = null;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt += 1) {
    try {
      const response = await fetch(ENDPOINT, {
        method: "POST",
        headers: {
          Authorization: "Bearer " + secrets.tokenHarborKey,
          "Content-Type": "application/json"
        },
        body,
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
      });
      const text = await response.text();
      if (!response.ok) throw new Error("HTTP " + response.status + " " + text.slice(0, 160));
      const data = JSON.parse(text);
      const content = data && data.choices && data.choices[0] && data.choices[0].message
        ? data.choices[0].message.content
        : null;
      if (!content) throw new Error("empty completion");
      const jsonStart = content.indexOf("{");
      const jsonEnd = content.lastIndexOf("}");
      if (jsonStart < 0 || jsonEnd < jsonStart) throw new Error("no JSON object in reply");
      const parsed = JSON.parse(content.slice(jsonStart, jsonEnd + 1));
      const out = new Map();
      ids.forEach(({ id, source }) => {
        if (typeof parsed[id] === "string") out.set(source, parsed[id]);
      });
      if (!out.size) throw new Error("no usable translations in reply");
      return out;
    } catch (error) {
      lastError = error;
      if (attempt < MAX_ATTEMPTS) await sleep(1500 * attempt);
    }
  }
  throw lastError || new Error("unknown model error");
}

/* ------------------------------------------------------------------ */
/* English tree walking                                                */
/* ------------------------------------------------------------------ */

function walkEnglish(value, key) {
  if (key != null && SKIP_TOP.has(key)) return undefined;
  if (Array.isArray(value)) return value.map((item) => walkEnglish(item, null));
  if (value && typeof value === "object") {
    const out = {};
    Object.keys(value).forEach((child) => {
      const result = walkEnglish(value[child], child);
      if (result !== undefined) out[child] = result;
    });
    return out;
  }
  return value;
}

function setPath(object, parts, value) {
  let node = object;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const key = parts[i];
    if (Array.isArray(node)) {
      const index = Number(key);
      if (!node[index]) node[index] = {};
      node = node[index];
    } else {
      if (!node[key]) node[key] = {};
      node = node[key];
    }
  }
  const last = parts[parts.length - 1];
  if (Array.isArray(node)) node[Number(last)] = value;
  else node[last] = value;
}

/* ------------------------------------------------------------------ */
/* Batch translation with a small worker pool                          */
/* ------------------------------------------------------------------ */

async function translateTexts(target, texts, stats) {
  const cache = new Map();
  const unique = [...new Set(texts)].filter((text) => typeof text === "string" && text.trim());
  const batches = [];
  for (let i = 0; i < unique.length; i += BATCH_SIZE) {
    batches.push(unique.slice(i, i + BATCH_SIZE));
  }

  let cursor = 0;
  let done = 0;
  async function worker() {
    while (cursor < batches.length) {
      const batch = batches[cursor];
      cursor += 1;
      try {
        const result = await callModel(target, batch);
        result.forEach((value, source) => {
          const problem = validate(target, source, value);
          if (problem) {
            stats.rejected += 1;
            stats.reasons[problem] = (stats.reasons[problem] || 0) + 1;
          } else {
            cache.set(source, value.trim());
          }
        });
      } catch (error) {
        stats.requestErrors += 1;
        stats.lastError = error.message;
        console.error("  " + target.code + " batch failed: " + error.message);
      }
      done += 1;
      process.stdout.write("  " + target.code + " batch " + done + "/" + batches.length + "          \r");
    }
  }

  const workers = [];
  for (let i = 0; i < Math.min(CONCURRENCY, batches.length); i += 1) workers.push(worker());
  await Promise.all(workers);
  process.stdout.write("\n");
  return cache;
}

/* ------------------------------------------------------------------ */
/* Build one pack                                                      */
/* ------------------------------------------------------------------ */

async function buildPack(target) {
  const stats = { rejected: 0, requestErrors: 0, reasons: {}, lastError: null };

  const skeleton = walkEnglish(i18n.en, null);
  const jobs = [];
  (function collect(value, parts) {
    if (Array.isArray(value)) {
      value.forEach((item, index) => collect(item, parts.concat([String(index)])));
      return;
    }
    if (value && typeof value === "object") {
      Object.keys(value).forEach((key) => collect(value[key], parts.concat([key])));
      return;
    }
    if (typeof value === "string") jobs.push({ parts, source: value });
  })(skeleton, []);

  const cache = await translateTexts(target, jobs.map((job) => job.source), stats);

  let translated = 0;
  jobs.forEach((job) => {
    const hit = cache.get(job.source);
    if (hit) {
      translated += 1;
      setPath(skeleton, job.parts, hit);
    } else {
      setPath(skeleton, job.parts, job.source);
    }
  });

  /* District and state names go through the same pipeline. */
  const regions = config.regions || [];
  const stateList = [...new Set(regions.map((region) => region.state.en))];
  const nameCache = await translateTexts(
    target,
    regions.map((region) => region.name.en).concat(stateList),
    stats
  );
  const regionNames = {};
  const stateNames = {};
  regions.forEach((region) => {
    regionNames[region.id] = nameCache.get(region.name.en) || region.name.en;
  });
  stateList.forEach((state) => {
    stateNames[state] = nameCache.get(state) || state;
  });

  skeleton.appName = "ADWS";
  skeleton.locale = target.locale;

  const total = jobs.length;
  const report = {
    code: target.code,
    gt: "tokenharbor:" + MODEL,
    total,
    translated,
    fallback: total - translated,
    failed: stats.requestErrors,
    rejected: stats.rejected,
    rejectReasons: stats.reasons,
    lastError: stats.lastError
  };
  console.log(
    "  " + target.code + ": " + translated + "/" + total + " translated, " +
    (total - translated) + " English fallbacks, " + stats.rejected + " rejected, " +
    stats.requestErrors + " request errors"
  );
  return { skeleton, report, regionNames, stateNames };
}

/* ------------------------------------------------------------------ */

async function main() {
  if (!secrets.tokenHarborKey) {
    throw new Error("server-secrets.js has no tokenHarborKey");
  }
  const packs = {};
  const meta = [];
  const regionNames = {};
  const stateNames = {};
  const reports = [];

  for (const target of TARGETS) {
    console.log("Building " + target.code + " (" + target.langName + ") via " + MODEL + " ...");
    const built = await buildPack(target);
    packs[target.code] = built.skeleton;
    regionNames[target.code] = built.regionNames;
    stateNames[target.code] = built.stateNames;
    reports.push(built.report);
    meta.push({
      code: target.code,
      short: target.short,
      label: target.label,
      english: target.english,
      locale: target.locale,
      beta: true,
      reviewed: false,
      coverage: "core"
    });
  }

  const data = {
    generatedAt: new Date().toISOString(),
    generator: "tools/build-tribal-llm.js",
    note: "Machine-assisted beta packs. English is authoritative. Do not remove the beta notice without native review.",
    packs,
    meta,
    regionNames,
    stateNames
  };

  const body =
    "/*\n" +
    " * ADWS — generated beta language packs (Meitei, Tulu).\n" +
    " * Generated by tools/build-tribal-llm.js on " + data.generatedAt + ".\n" +
    " * Machine-assisted and unreviewed: the app shows a Beta notice and the\n" +
    " * English original for live alert details. Regenerate instead of editing.\n" +
    " */\n" +
    "(function (root) {\n" +
    "  \"use strict\";\n" +
    "  var DATA = " + JSON.stringify(data, null, 2) + ";\n" +
    "  root.APP_TRIBAL_LANGS = DATA;\n" +
    "  if (typeof module !== \"undefined\" && module.exports) module.exports = DATA;\n" +
    "})(typeof window !== \"undefined\" ? window : globalThis);\n";

  fs.writeFileSync(OUT_FILE, body, "utf8");
  fs.writeFileSync(REPORT_FILE, JSON.stringify(data, null, 2), "utf8");
  console.log("Wrote " + OUT_FILE);
  console.log("Wrote " + REPORT_FILE);
  console.log("Stats: " + JSON.stringify(reports));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
