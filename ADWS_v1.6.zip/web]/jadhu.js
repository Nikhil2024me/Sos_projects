/*
 * Jadhu — ADWS Intelligent Disaster Assistant (Beta)
 * ---------------------------------------------------
 * An AI assistant that knows everything about the ADWS disaster warning system:
 * - 30 tribal-majority districts + 526 monitored cities
 * - 7 hazard alarms (fire, rain, wind, heat, quake, landslide, tsunami) + Ambee AQI + NASA GPM rain
 * - Offline LoRa village broadcasts (ESP32, SX1276, AS3/AS4 packet formats)
 * - Emergency helplines (112, 1078, 108, 101, 100)
 * - Site controls: language switching (20 languages), satellite/street map layers,
 *   disaster filtering, district selection, live refresh, and navigation.
 *
 * Connected to Token Harbor using DeepSeek v4.1 Flash by default, with support
 * for Google Gemini Free API and an instant local intelligent fallback engine.
 */
(function (root) {
  "use strict";

  var STORAGE_TH_KEY = "adws_jadhu_tokenharbor_key";
  var STORAGE_MODEL_KEY = "adws_jadhu_model";
  var STORAGE_GEMINI_KEY = "adws_jadhu_gemini_key";

  var DEFAULT_TH_KEY = "thk_live_f3F4zLzvR3m6O2pCSKzT2yfOuUCyeHN6lg-01bHdHKUBxTW-ElWqOvp-9eeyfoR8";
  var DEFAULT_MODEL = "deepseek-v4.1-flash";

  var KNOWLEDGE = {
    appName: "ADWS (Advanced Disaster Warning System / Adivasi Suraksha)",
    version: "1.0.0 (Beta)",
    purpose: "Real-time multi-hazard surveillance and early warning platform designed primarily for 30 high-tribal-population districts across India, with supplementary coverage for 526 major cities.",
    helplines: [
      { name: "National Emergency Helpline", number: "112", desc: "Unified emergency service (Police, Fire, Ambulance)" },
      { name: "NDMA Disaster Management", number: "1078", desc: "National disaster helpline" },
      { name: "Medical Ambulance", number: "108", desc: "Emergency medical transport" },
      { name: "Fire Service", number: "101", desc: "Fire emergencies" },
      { name: "Police", number: "100", desc: "Police assistance" },
      { name: "Women Helpline", number: "1091", desc: "Women in distress" },
      { name: "State Disaster Management", number: "1070", desc: "State-level emergency operations" }
    ],
    hazards: {
      fire: "Monitored via NASA FIRMS (VIIRS 375m & MODIS 1km) thermal anomalies within 40 km of district centers.",
      rain: "Monitored via Open-Meteo 4-day forecast: Watch (40mm), Warning (80mm), Severe (120mm). Supplementary observed rain via NASA GPM IMERG.",
      heat: "Max temperature thresholds: Plains (Watch 40°C, Warning 43°C, Severe 46°C); Hills (Watch 30°C, Warning 33°C, Severe 36°C).",
      wind: "Sustained wind speeds: Watch (50 km/h), Warning (70 km/h), Severe (90 km/h).",
      quake: "USGS FDSN M4+ events in rolling 7 days: Watch (M5.0+ within 300km), Warning (M5.5+ within 300km), Severe (M6.5+ within 600km), Local small (M4.5+ within 150km).",
      landslide: "Rainfall-induced landslide hazard in steep terrain (elevation >= 600m combined with heavy rainfall >= 40mm).",
      tsunami: "High-magnitude offshore earthquake (M7.0+ within 400-1000km) in coastal/low-elevation areas (<= 250m).",
      air: "Real-time AQI and PM2.5/PM10 from Ambee API mapped to US EPA standards (Watch 101, Warning 151, Severe 201). Informational only."
    },
    lora: {
      purpose: "Transmits compact disaster codes over 433/868/915 MHz LoRa radio to village receivers with siren and LED indicators when cellular networks fail.",
      formats: "AS3,DD,OV,FRWHQLT,DDHHMM (7 hazards) or AS4,DD,OV,FRWHQLTA,DDHHMM (with air quality digit).",
      hardware: "ESP32 microcontrollers paired with Semtech SX1276/SX1278 transceivers, powered by solar + 18650 Li-ion battery."
    },
    apis: {
      firms: "NASA FIRMS (Fire Information for Resource Management System) — permanent free key.",
      bhuvan: "ISRO Bhuvan Shortest Path Routing API — token expires every 24 hours (1-day renewal required).",
      openmeteo: "Open-Meteo Weather API — open public service, no key needed.",
      usgs: "USGS FDSN Earthquake API — open GeoJSON service, no key needed.",
      ambee: "Ambee Air Quality API — trial evaluation key with 80-call daily guard.",
      gpm: "NASA GPM IMERG Early Run Precipitation — NASA Earthdata bearer token.",
      hazards: "GDACS RSS, NASA EONET v3, ReliefWeb v2 for regional situational awareness."
    },
    languages: [
      { code: "en", name: "English" },
      { code: "hi", name: "Hindi" },
      { code: "bn", name: "Bengali" },
      { code: "mr", name: "Marathi" },
      { code: "or", name: "Odia" },
      { code: "te", name: "Telugu" },
      { code: "ta", name: "Tamil" },
      { code: "gu", name: "Gujarati" },
      { code: "kn", name: "Kannada" },
      { code: "ml", name: "Malayalam" },
      { code: "as", name: "Assamese" },
      { code: "pa", name: "Punjabi" },
      { code: "sat", name: "Santali (Ol Chiki)" },
      { code: "gon", name: "Gondi (Devanagari)" },
      { code: "bhi", name: "Bhili (Devanagari)" },
      { code: "trp", name: "Kokborok (Tripura)" },
      { code: "lus", name: "Mizo (Mizoram)" },
      { code: "kha", name: "Khasi (Meghalaya)" },
      { code: "mni", name: "Meitei (Manipur, beta)" },
      { code: "tcy", name: "Tulu (Karnataka, beta)" }
    ]
  };

  function getTokenHarborKey() {
    try {
      return (window.localStorage.getItem(STORAGE_TH_KEY) || DEFAULT_TH_KEY).trim();
    } catch (e) {
      return DEFAULT_TH_KEY;
    }
  }

  function setTokenHarborKey(key) {
    try {
      if (key) {
        window.localStorage.setItem(STORAGE_TH_KEY, key.trim());
      } else {
        window.localStorage.removeItem(STORAGE_TH_KEY);
      }
    } catch (e) {}
  }

  function getModel() {
    try {
      return (window.localStorage.getItem(STORAGE_MODEL_KEY) || DEFAULT_MODEL).trim();
    } catch (e) {
      return DEFAULT_MODEL;
    }
  }

  function setModel(model) {
    try {
      if (model) {
        window.localStorage.setItem(STORAGE_MODEL_KEY, model.trim());
      } else {
        window.localStorage.removeItem(STORAGE_MODEL_KEY);
      }
    } catch (e) {}
  }

  function getGeminiKey() {
    try {
      return (window.localStorage.getItem(STORAGE_GEMINI_KEY) || "").trim();
    } catch (e) {
      return "";
    }
  }

  function setGeminiKey(key) {
    try {
      if (key) {
        window.localStorage.setItem(STORAGE_GEMINI_KEY, key.trim());
      } else {
        window.localStorage.removeItem(STORAGE_GEMINI_KEY);
      }
    } catch (e) {}
  }

  /* -------------------------------------------------------------
   * Settings & Site Control Executor
   * ------------------------------------------------------------- */
  function executeSiteAction(action, value) {
    var ctrl = window.ADWS_CONTROL;
    if (!ctrl) return { success: false, message: "ADWS control system not yet initialized." };

    switch (action) {
      case "setLanguage":
        var lang = String(value).toLowerCase().trim();
        ctrl.setLanguage(lang);
        return { success: true, message: "Switched website language to " + lang.toUpperCase() + "." };

      case "setBaseLayer":
        var layer = value === "satellite" ? "satellite" : "street";
        ctrl.setBaseLayer(layer);
        return { success: true, message: "Map basemap set to " + (layer === "satellite" ? "Satellite Imagery" : "Street Map") + "." };

      case "selectRegion":
        ctrl.selectRegion(value, "card");
        var el = document.getElementById("detailPanel") || document.getElementById("map");
        if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
        return { success: true, message: "Selected region: " + value + "." };

      case "setMapDisaster":
        var dis = String(value).toLowerCase().trim();
        ctrl.setMapDisaster(dis);
        return { success: true, message: "Filtered map disaster view to: " + dis + "." };

      case "refresh":
        ctrl.refresh();
        return { success: true, message: "Refreshing all live feeds and disaster data." };

      case "navigate":
        var target = document.querySelector(value);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          return { success: true, message: "Navigated to " + value + "." };
        }
        return { success: false, message: "Section " + value + " not found." };

      case "toggleGoogleTranslate":
        var gt = document.getElementById("google_translate_element");
        if (gt) {
          var isHidden = gt.style.display === "none" || !gt.style.display;
          gt.style.display = isHidden ? "block" : "none";
          return { success: true, message: isHidden ? "Opened Google Translate widget." : "Closed Google Translate widget." };
        }
        return { success: false, message: "Google translate widget not available." };

      case "locateMe":
        var locBtn = document.getElementById("locateBtn");
        if (locBtn) {
          locBtn.click();
          return { success: true, message: "Finding your location and nearest district via GPS..." };
        }
        return { success: false, message: "Locate button not available." };

      default:
        return { success: false, message: "Unknown action: " + action };
    }
  }

  /* -------------------------------------------------------------
   * Intent Parsing for Settings & Site Actions
   * ------------------------------------------------------------- */
  function detectActionIntent(query) {
    var q = query.toLowerCase().trim();

    // Locate action
    if (/find\s*(?:my\s*)?district|where\s*am\s*i|locate\s*me|my\s*location/i.test(q)) {
      return { action: "locateMe", value: true, desc: "Locate user via GPS" };
    }

    // Map layer actions
    if (/satellite\s*(view|map|layer|mode)?|switch\s*to\s*satellite/i.test(q)) {
      return { action: "setBaseLayer", value: "satellite", desc: "Switch map to Satellite view" };
    }
    if (/street\s*(view|map|layer|mode)?|normal\s*map|standard\s*map/i.test(q)) {
      return { action: "setBaseLayer", value: "street", desc: "Switch map to Street view" };
    }

    // Refresh action
    if (/^(refresh|reload|update|fetch)(\s*(live|data|alerts|feeds))?$/i.test(q) || /refresh\s*data/i.test(q)) {
      return { action: "refresh", value: true, desc: "Refresh live data" };
    }

    // Language actions
    var langMatch = q.match(/(?:change|switch|set)\s*(?:the\s*)?(?:language|lang)\s*(?:to\s*)?([a-z\s]+)/i) ||
                    q.match(/(?:in|to)\s*(hindi|english|bengali|marathi|odia|telugu|tamil|gujarati|kannada|malayalam|assamese|punjabi|santali|gondi|bhili|kokborok|mizo|khasi|meitei|manipuri|tulu)/i);
    if (langMatch) {
      var name = langMatch[1].trim();
      var langMap = {
        "english": "en", "en": "en",
        "hindi": "hi", "hi": "hi",
        "bengali": "bn", "bangla": "bn", "bn": "bn",
        "marathi": "mr", "mr": "mr",
        "odia": "or", "oriya": "or", "or": "or",
        "telugu": "te", "te": "te",
        "tamil": "ta", "ta": "ta",
        "gujarati": "gu", "gu": "gu",
        "kannada": "kn", "kn": "kn",
        "malayalam": "ml", "ml": "ml",
        "assamese": "as", "as": "as",
        "punjabi": "pa", "pa": "pa",
        "santali": "sat", "sat": "sat",
        "gondi": "gon", "gon": "gon",
        "bhili": "bhi", "bhi": "bhi",
        "kokborok": "trp", "trp": "trp",
        "mizo": "lus", "lus": "lus",
        "khasi": "kha", "kha": "kha",
        "meitei": "mni", "manipuri": "mni", "mni": "mni",
        "tulu": "tcy", "tcy": "tcy"
      };
      if (langMap[name]) {
        return { action: "setLanguage", value: langMap[name], desc: "Change language to " + name };
      }
    }

    // Disaster filter actions
    if (/show\s*fires?|filter\s*fires?|wildfires?/i.test(q)) {
      return { action: "setMapDisaster", value: "fire", desc: "Filter map for Fire alerts" };
    }
    if (/show\s*rain|filter\s*rain|floods?/i.test(q)) {
      return { action: "setMapDisaster", value: "rain", desc: "Filter map for Rain alerts" };
    }
    if (/show\s*quakes?|earthquakes?|filter\s*quakes?/i.test(q)) {
      return { action: "setMapDisaster", value: "quake", desc: "Filter map for Earthquakes" };
    }
    if (/show\s*wind|extreme\s*wind|cyclones?/i.test(q)) {
      return { action: "setMapDisaster", value: "wind", desc: "Filter map for High Winds" };
    }
    if (/show\s*heat|heatwaves?/i.test(q)) {
      return { action: "setMapDisaster", value: "heat", desc: "Filter map for Heatwaves" };
    }
    if (/show\s*all\s*disasters|all\s*hazards|reset\s*filter/i.test(q)) {
      return { action: "setMapDisaster", value: "all", desc: "Show all disasters on map" };
    }

    // Navigation actions
    if (/go\s*to\s*map|show\s*map/i.test(q)) {
      return { action: "navigate", value: "#map", desc: "Scroll to Live Map" };
    }
    if (/go\s*to\s*routing|evacuation|shortest\s*path|bhuvan/i.test(q)) {
      return { action: "navigate", value: "#routing", desc: "Scroll to Evacuation Route Planner" };
    }
    if (/show\s*cities|view\s*cities/i.test(q)) {
      return { action: "navigate", value: "#cities", desc: "Scroll to Cities Monitor" };
    }
    if (/show\s*districts|tribal\s*districts/i.test(q)) {
      return { action: "navigate", value: "#districts", desc: "Scroll to 30 Tribal Districts" };
    }
    if (/open\s*translate|google\s*translate/i.test(q)) {
      return { action: "toggleGoogleTranslate", value: true, desc: "Toggle Google Translate Widget" };
    }

    // District / City selection
    var ctrl = window.ADWS_CONTROL;
    if (ctrl && ctrl.getConfig) {
      var config = ctrl.getConfig();
      if (config && config.places) {
        for (var i = 0; i < config.places.length; i++) {
          var p = config.places[i];
          var enName = (p.name && p.name.en ? p.name.en : p.id).toLowerCase();
          var hiName = (p.name && p.name.hi ? p.name.hi : "");
          var regex = new RegExp("\\b(?:show|select|check|inspect|open|go to)\\s+" + p.id + "\\b", "i");
          var nameRegex = new RegExp("\\b(?:show|select|check|inspect|open|go to)\\s+" + enName + "\\b", "i");
          if (regex.test(q) || nameRegex.test(q) || (hiName && q.indexOf(hiName) !== -1)) {
            return { action: "selectRegion", value: p.id, desc: "Select " + (p.name.en || p.id) };
          }
        }
      }
    }

    return null;
  }

  /* -------------------------------------------------------------
   * Real-time State & Live Stats Summarizer
   * ------------------------------------------------------------- */
  function getLiveStateContext() {
    var ctrl = window.ADWS_CONTROL;
    if (!ctrl || !ctrl.getState) return "Live state loading...";
    var state = ctrl.getState();
    var firesCount = state.fires ? state.fires.length : 0;
    var quakesCount = state.quakes ? state.quakes.length : 0;
    var selected = state.selectedId || "bastar";
    var lang = state.lang || "en";
    var baseLayer = state.baseLayer || "street";

    var topRisk = "None";
    if (state.snapshot) {
      var keys = Object.keys(state.snapshot);
      var highestSev = -1;
      keys.forEach(function (k) {
        var snap = state.snapshot[k];
        if (snap && snap.severity > highestSev) {
          highestSev = snap.severity;
          topRisk = (snap.name && snap.name.en ? snap.name.en : k) + " (Level " + highestSev + ")";
        }
      });
    }

    return {
      firesCount: firesCount,
      quakesCount: quakesCount,
      selectedId: selected,
      lang: lang,
      baseLayer: baseLayer,
      topRisk: topRisk,
      disasterFilter: state.mapDisaster || "all"
    };
  }

  /* -------------------------------------------------------------
   * Instant Local Intelligence Engine (Fallback / Offline)
   * ------------------------------------------------------------- */
  function generateLocalResponse(query) {
    var q = query.toLowerCase().trim();
    var live = getLiveStateContext();

    // Check if there is an explicit settings action
    var intent = detectActionIntent(query);
    var actionNote = "";
    if (intent) {
      var res = executeSiteAction(intent.action, intent.value);
      actionNote = "\n\n⚡ **Action Applied:** " + res.message;
    }

    // 1. Live status questions
    if (/active\s*disasters?|what\s*(is|are)\s*(happening|active|detected)|status|live\s*summary/i.test(q)) {
      return "📊 **Current ADWS Live Status:**\n\n" +
        "• **Satellite Fire Detections:** " + live.firesCount + " active thermal anomalies (NASA FIRMS)\n" +
        "• **Earthquakes (Past 7 Days):** " + live.quakesCount + " M4+ events recorded (USGS FDSN)\n" +
        "• **Highest Alert Region:** " + live.topRisk + "\n" +
        "• **Active Basemap:** " + (live.baseLayer === "satellite" ? "Satellite Imagery" : "Street Basemap") + "\n" +
        "• **Current Language:** " + live.lang.toUpperCase() + "\n" +
        "• **Monitored Areas:** 30 high-tribal districts + 526 major Indian cities.\n\n" +
        "Would you like me to focus on a particular district or switch to satellite view?" + actionNote;
    }

    // 2. Fire questions
    if (/fire|thermal|modis|viirs|nasa firms/i.test(q)) {
      return "🔥 **Fire & Thermal Anomaly Monitoring:**\n\n" +
        "ADWS tracks wildfires and agricultural burns using NASA FIRMS satellites:\n" +
        "• **Sensors:** VIIRS (NOAA-20 & Suomi NPP at 375m resolution) and MODIS (Terra & Aqua at 1km).\n" +
        "• **Coverage Radius:** 40 km radius around each district headquarters.\n" +
        "• **Thresholds:** Watch (1+ fires), Warning (5+ fires), Severe (12+ fires).\n" +
        "• **Current Live Fires:** " + live.firesCount + " spots detected across India right now." + actionNote;
    }

    // 3. Earthquake questions
    if (/earthquake|quake|tremor|richter|usgs/i.test(q)) {
      return "🌍 **Earthquake Hazard System:**\n\n" +
        "ADWS streams live earthquake data directly from the USGS FDSN API:\n" +
        "• **Filter:** M4.0+ events within India and surrounding South Asia (6°N–37°N, 68°E–98°E).\n" +
        "• **Alarms:** M5.0+ (Watch within 300km), M5.5+ (Warning within 300km), M6.5+ (Severe within 600km).\n" +
        "• **Local Proximity Watch:** M4.5+ within 150 km of any monitored place.\n" +
        "• **Active Quakes:** " + live.quakesCount + " events logged in the rolling 7-day window." + actionNote;
    }

    // 4. LoRa & Offline broadcasts
    if (/lora|offline|radio|packet|esp32|village|hardware/i.test(q)) {
      return "📡 **LoRa Village Warning & Hardware Architecture:**\n\n" +
        "When cellular networks collapse during cyclones or floods, ADWS broadcasts over off-grid LoRa radio:\n" +
        "• **Frequencies:** 433 MHz, 868 MHz, or 915 MHz (Semtech SX1276/SX1278 transceiver).\n" +
        "• **Gateways:** ESP32 solar-powered microcontrollers in remote tribal villages.\n" +
        "• **Packet Format:** `" + KNOWLEDGE.lora.formats + "`\n" +
        "• **Coverage:** Exclusively covers the 30 tribal districts (indexes 01–30) to preserve emergency bandwidth.\n" +
        "• **Local Alerts:** Village receivers sound sirens and activate LED severity indicators (Green=Safe, Yellow=Watch, Orange=Warning, Red=Severe)." + actionNote;
    }

    // 5. Emergency helplines
    if (/helpline|emergency|phone|call|police|ambulance|hospital|112|contact/i.test(q)) {
      var lines = KNOWLEDGE.helplines.map(function (h) {
        return "• **" + h.number + "** — " + h.name + " (" + h.desc + ")";
      }).join("\n");
      return "🚨 **Emergency Helplines (24x7 India):**\n\n" + lines + "\n\nAll numbers are toll-free and accessible from any landline or mobile." + actionNote;
    }

    // 6. Language support
    if (/language|tribal language|languages|translate|santali|gondi|bhili|kokborok|mizo|khasi/i.test(q)) {
      var langNames = KNOWLEDGE.languages.map(function (l) { return l.name + " (`" + l.code + "`)"; }).join(", ");
      return "🌐 **Multilingual & Tribal Language Support:**\n\n" +
        "ADWS supports 20 native languages built into the client, including 8 tribal languages:\n" +
        langNames + ".\n\n" +
        "• In addition, Google Translate is embedded for over 130+ world languages!\n" +
        "• You can ask me anytime: *'Switch to Hindi'*, *'Change language to Santali'*, or *'Switch to English'*." + actionNote;
    }

    // 7. ISRO Bhuvan & Routing
    if (/bhuvan|route|routing|evacuation|shortest path|isro/i.test(q)) {
      return "🗺️ **ISRO Bhuvan Shortest Path Evacuation:**\n\n" +
        "ADWS uses ISRO's NRSC Bhuvan road network API to calculate the safest and shortest route from your live coordinates to district headquarters or relief shelters.\n" +
        "• ⚠️ **Note:** The Bhuvan API token expires every 24 hours (1-day validity) and requires same-state routing." + actionNote;
    }

    // 8. General ADWS summary or settings command
    if (intent) {
      return "✓ **Done!** I have executed your request:\n" + actionNote + "\n\nCan I help you with anything else on ADWS?";
    }

    return "Hello! I am **Jadhu**, your ADWS AI Assistant powered by **DeepSeek v4.1 Flash** (Token Harbor).\n\n" +
      "I know everything about this disaster monitoring platform:\n" +
      "• **7 Hazard Alarms:** Fire (NASA FIRMS), Rain & Heat (Open-Meteo), Quakes (USGS), Landslides, Tsunamis, and Air Quality (Ambee).\n" +
      "• **Locations:** 30 high-tribal districts + 526 Indian cities.\n" +
      "• **Offline Resilience:** ESP32 LoRa radio broadcasts (`AS3`/`AS4` packets).\n" +
      "• **18 Languages:** Including Santali, Gondi, Bhili, Kokborok, Mizo, and Khasi.\n\n" +
      "You can ask me questions or command site settings like:\n" +
      "👉 *'Switch to Satellite view'*\n" +
      "👉 *'Change language to Hindi'*\n" +
      "👉 *'Show Bastar district'*\n" +
      "👉 *'What disasters are active right now?'*";
  }

  /* -------------------------------------------------------------
   * AI Query Engine (Token Harbor DeepSeek v4.1 Flash + Gemini + Local)
   * ------------------------------------------------------------- */
  async function queryAI(promptText, history) {
    var thKey = getTokenHarborKey();
    var currentModel = getModel();
    var geminiKey = getGeminiKey();
    var live = getLiveStateContext();

    var systemInstructionText =
      "You are Jadhu, the intelligent disaster management assistant for ADWS (Advanced Disaster Warning System / Adivasi Suraksha).\n" +
      "ADWS monitors real-time natural hazards for 30 high-tribal districts and 526 cities across India.\n" +
      "Hazards tracked: NASA FIRMS (wildfires, 40km radius), Open-Meteo (rain forecast, extreme heat, wind), USGS (earthquakes M4+), Landslides (hills >600m + rain), Tsunamis (<250m elevation + offshore M7+ quake), Ambee AQI, NASA GPM rain, ISRO Bhuvan evacuation routes, and off-grid LoRa village radio broadcasts (ESP32, AS3/AS4 packets).\n" +
      "Languages supported: 20 (English, Hindi, Bengali, Marathi, Odia, Telugu, Tamil, Gujarati, Kannada, Malayalam, Assamese, Punjabi, and tribal languages: Santali, Gondi, Bhili, Kokborok, Mizo, Khasi, plus beta Meitei and Tulu) + Google Translate.\n" +
      "Current Live State: " + JSON.stringify(live) + ".\n" +
      "Capabilities: You can control site settings. If the user asks to switch language, toggle satellite/street view, select a district/city, filter map disasters, or refresh data, include an action block at the very end of your response in this exact format:\n" +
      "```action\n{\"action\": \"setLanguage\"|\"setBaseLayer\"|\"selectRegion\"|\"setMapDisaster\"|\"refresh\"|\"navigate\", \"value\": \"...\"}\n```\n" +
      "Keep answers helpful, accurate, and concise. Be courteous and protective of citizen safety. Emergency numbers: 112 (National), 1078 (Disaster), 108 (Ambulance), 101 (Fire).";

    // 1. First attempt: Call /api/jadhu server endpoint (Token Harbor / DeepSeek v4.1 Flash)
    try {
      var serverRes = await fetch("/api/jadhu", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-tokenharbor-key": thKey,
          "x-gemini-key": geminiKey
        },
        body: JSON.stringify({
          prompt: promptText,
          model: currentModel,
          tokenHarborKey: thKey,
          geminiKey: geminiKey,
          systemInstruction: { parts: [{ text: systemInstructionText }] }
        })
      });

      if (serverRes.ok) {
        var resData = await serverRes.json();
        if (resData.status === "success" && resData.text) {
          return resData.text;
        }
        if (resData.status === "tokenharbor_error") {
          // If Token Harbor returned a plan or free model notice, return local answer + notice
          var local = generateLocalResponse(promptText);
          var hint = resData.message.indexOf("Free models are turned off") !== -1
            ? "\n\n*(ℹ️ Token Harbor: Free models are currently disabled on your key. To enable DeepSeek Flash, toggle 'Free models' ON in your dashboard at https://tokenharbor.ai/dashboard)*"
            : (resData.message.indexOf("balance") !== -1
              ? "\n\n*(ℹ️ Token Harbor: " + resData.message + ")*"
              : "");
          return local + hint;
        }
      }
    } catch (e) {
      // Server not reachable or static-only deployment, continue to direct client call
    }

    // 2. Second attempt: Direct client-side call to Token Harbor OpenAI-compatible endpoint
    if (thKey) {
      try {
        var candidateModels = [currentModel];
        if (!currentModel.endsWith(":free")) candidateModels.push(currentModel + ":free");
        else candidateModels.push(currentModel.replace(":free", ""));

        for (var i = 0; i < candidateModels.length; i++) {
          var mod = candidateModels[i];
          var thRes = await fetch("https://tokenharbor.ai/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer " + thKey
            },
            body: JSON.stringify({
              model: mod,
              messages: [
                { role: "system", content: systemInstructionText },
                { role: "user", content: promptText }
              ],
              temperature: 0.4,
              max_tokens: 1000
            })
          });

          if (thRes.ok) {
            var thData = await thRes.json();
            if (thData && thData.choices && thData.choices[0] && thData.choices[0].message) {
              return thData.choices[0].message.content;
            }
          }
        }
      } catch (err) {
        console.warn("Direct Token Harbor call error:", err);
      }
    }

    // 3. Third attempt: Google Gemini direct call (if key present)
    if (geminiKey) {
      try {
        var directUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + encodeURIComponent(geminiKey);
        var directRes = await fetch(directUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                role: "user",
                parts: [{ text: systemInstructionText + "\n\nUser Question: " + promptText }]
              }
            ],
            generationConfig: { temperature: 0.4, maxOutputTokens: 800 }
          })
        });

        if (directRes.ok) {
          var dData = await directRes.json();
          var directCand = dData.candidates && dData.candidates[0];
          if (directCand && directCand.content && directCand.content.parts && directCand.content.parts[0]) {
            return directCand.content.parts[0].text;
          }
        }
      } catch (gErr) {}
    }

    // 4. Fallback to instant local intelligence engine
    return generateLocalResponse(promptText);
  }

  /* -------------------------------------------------------------
   * UI & Modal Creation
   * ------------------------------------------------------------- */
  function injectJadhuUI() {
    if (document.getElementById("jadhuContainer")) return;

    // 1. Star Trigger Button (compact icon overlay)
    var triggerBtn = document.createElement("button");
    triggerBtn.id = "jadhuTrigger";
    triggerBtn.className = "jadhu-fab";
    triggerBtn.setAttribute("type", "button");
    triggerBtn.setAttribute("aria-label", "Ask Jadhu AI");
    triggerBtn.setAttribute("title", "Ask Jadhu AI (DeepSeek v4.1 Flash)");
    triggerBtn.innerHTML = '<span class="jadhu-fab-star" aria-hidden="true">★</span>';

    // 2. Backdrop Overlay (for mobile bottom-sheet dismissal)
    var backdrop = document.createElement("div");
    backdrop.id = "jadhuBackdrop";
    backdrop.className = "jadhu-backdrop";
    backdrop.setAttribute("aria-hidden", "true");

    // 3. Jadhu Modal / Drawer Panel
    var container = document.createElement("div");
    container.id = "jadhuContainer";
    container.className = "jadhu-modal-container";
    container.setAttribute("aria-hidden", "true");
    container.innerHTML =
      '<div class="jadhu-modal" role="dialog" aria-labelledby="jadhuTitle">' +
      '  <div class="jadhu-sheet-handle" aria-hidden="true"></div>' +
      '  <div class="jadhu-header">' +
      '    <div class="jadhu-header-info">' +
      '      <span class="jadhu-header-star">★</span>' +
      '      <div>' +
      '        <h3 id="jadhuTitle" class="jadhu-title">Jadhu <span class="jadhu-pill">DeepSeek Flash</span></h3>' +
      '        <p class="jadhu-subtitle">ADWS Disaster Intelligence & Control</p>' +
      '      </div>' +
      '    </div>' +
      '    <div class="jadhu-header-actions">' +
      '      <button type="button" class="jadhu-icon-btn" id="jadhuSettingsBtn" title="AI Model & Key Settings" aria-label="API Settings">⚙️</button>' +
      '      <button type="button" class="jadhu-icon-btn" id="jadhuClearBtn" title="Clear Conversation" aria-label="Clear chat">🗑️</button>' +
      '      <button type="button" class="jadhu-icon-btn jadhu-close-btn" id="jadhuCloseBtn" title="Close Jadhu" aria-label="Close">✕</button>' +
      '    </div>' +
      '  </div>' +

      // Settings dropdown drawer
      '  <div class="jadhu-settings-drawer" id="jadhuSettingsDrawer" hidden>' +
      '    <div class="jadhu-settings-box">' +
      '      <label for="jadhuThKeyInput" class="jadhu-settings-label">Token Harbor API Key:</label>' +
      '      <div class="jadhu-settings-row">' +
      '        <input type="password" id="jadhuThKeyInput" class="jadhu-input" placeholder="thk_live_..." />' +
      '      </div>' +
      '      <label for="jadhuModelSelect" class="jadhu-settings-label" style="margin-top:0.35rem">Default AI Model:</label>' +
      '      <div class="jadhu-settings-row">' +
      '        <select id="jadhuModelSelect" class="jadhu-input" style="flex:1">' +
      '          <option value="deepseek-v4.1-flash" selected>DeepSeek V4.1 Flash (Token Harbor)</option>' +
      '          <option value="deepseek-v4.1-flash:free">DeepSeek V4.1 Flash (Free Tier)</option>' +
      '          <option value="deepseek-v4-flash:free">DeepSeek V4 Flash (Free Tier)</option>' +
      '          <option value="mimo-v2.6-flash:free">MiMo V2.6 Flash (Free Tier)</option>' +
      '          <option value="gemini-1.5-flash">Google Gemini 1.5 Flash</option>' +
      '        </select>' +
      '        <button type="button" class="btn btn-small" id="jadhuSaveSettingsBtn">Save</button>' +
      '      </div>' +
      '      <p class="jadhu-settings-hint">Connected to Token Harbor with DeepSeek v4.1 Flash. Manage keys at <a href="https://tokenharbor.ai/dashboard" target="_blank" rel="noopener">tokenharbor.ai</a>.</p>' +
      '    </div>' +
      '  </div>' +

      // Chat Messages List
      '  <div class="jadhu-body" id="jadhuMessages" role="log" aria-live="polite"></div>' +

      // Suggestion quick chips
      '  <div class="jadhu-chips" id="jadhuChips">' +
      '    <button type="button" class="jadhu-chip" data-prompt="What disasters are active right now?">⚡ Active Disasters</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="Switch map to Satellite view">🛰️ Satellite Map</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="Change website language to Hindi">🌐 Hindi</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="Show Bastar district details">📍 Bastar</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="How does LoRa village warning work?">📡 LoRa Broadcast</button>' +
      '    <button type="button" class="jadhu-chip" data-prompt="What are the emergency helpline numbers?">🚨 Helplines</button>' +
      '  </div>' +

      // Input Form
      '  <form class="jadhu-footer" id="jadhuForm">' +
      '    <input type="text" id="jadhuInput" class="jadhu-text-input" placeholder="Ask Jadhu or say \'switch to satellite\'..." autocomplete="off" />' +
      '    <button type="button" class="jadhu-mic-btn" id="jadhuMicBtn" title="Voice Input" aria-label="Voice input">🎙️</button>' +
      '    <button type="submit" class="jadhu-send-btn" id="jadhuSendBtn" aria-label="Send message">➤</button>' +
      '  </form>' +
      '</div>';

    document.body.appendChild(triggerBtn);
    document.body.appendChild(backdrop);
    document.body.appendChild(container);

    attachJadhuEvents();
    renderWelcomeMessage();
  }

  function renderWelcomeMessage() {
    var messagesEl = document.getElementById("jadhuMessages");
    if (!messagesEl) return;
    messagesEl.innerHTML = "";

    appendMessage("bot",
      "Namaste! I am **Jadhu**, your AI disaster & site assistant for ADWS, powered by **DeepSeek v4.1 Flash**.\n\n" +
      "I have full knowledge of our 30 tribal districts, 526 monitored cities, live satellite fires, USGS earthquakes, and off-grid LoRa village alerts.\n\n" +
      "I can also control the site for you — try asking me to **switch to satellite view**, **change language to Hindi**, or **check active disasters**!"
    );
  }

  function appendMessage(sender, text, isAction) {
    var messagesEl = document.getElementById("jadhuMessages");
    if (!messagesEl) return;

    var msgDiv = document.createElement("div");
    msgDiv.className = "jadhu-msg jadhu-msg-" + sender + (isAction ? " jadhu-msg-action" : "");

    // Simple markdown renderer for bold, lists, and code
    var formatted = escapeHtml(text)
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\n\n/g, "<br><br>")
      .replace(/\n•/g, "<br>•");

    msgDiv.innerHTML = formatted;
    messagesEl.appendChild(msgDiv);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function attachJadhuEvents() {
    var triggerBtn = document.getElementById("jadhuTrigger");
    var container = document.getElementById("jadhuContainer");
    var backdrop = document.getElementById("jadhuBackdrop");
    var closeBtn = document.getElementById("jadhuCloseBtn");
    var form = document.getElementById("jadhuForm");
    var input = document.getElementById("jadhuInput");
    var clearBtn = document.getElementById("jadhuClearBtn");
    var settingsBtn = document.getElementById("jadhuSettingsBtn");
    var settingsDrawer = document.getElementById("jadhuSettingsDrawer");
    var thKeyInput = document.getElementById("jadhuThKeyInput");
    var modelSelect = document.getElementById("jadhuModelSelect");
    var saveSettingsBtn = document.getElementById("jadhuSaveSettingsBtn");
    var micBtn = document.getElementById("jadhuMicBtn");
    var chipsContainer = document.getElementById("jadhuChips");

    function openModal() {
      container.classList.add("is-open");
      container.setAttribute("aria-hidden", "false");
      if (backdrop) {
        backdrop.classList.add("is-open");
        backdrop.setAttribute("aria-hidden", "false");
      }
      input.focus();
    }

    function closeModal() {
      container.classList.remove("is-open");
      container.setAttribute("aria-hidden", "true");
      if (backdrop) {
        backdrop.classList.remove("is-open");
        backdrop.setAttribute("aria-hidden", "true");
      }
    }

    triggerBtn.addEventListener("click", function () {
      if (container.classList.contains("is-open")) {
        closeModal();
      } else {
        openModal();
      }
    });

    closeBtn.addEventListener("click", closeModal);
    if (backdrop) backdrop.addEventListener("click", closeModal);

    clearBtn.addEventListener("click", function () {
      renderWelcomeMessage();
    });

    settingsBtn.addEventListener("click", function () {
      var isHidden = settingsDrawer.hasAttribute("hidden");
      if (isHidden) {
        settingsDrawer.removeAttribute("hidden");
        thKeyInput.value = getTokenHarborKey();
        modelSelect.value = getModel();
        thKeyInput.focus();
      } else {
        settingsDrawer.setAttribute("hidden", "true");
      }
    });

    saveSettingsBtn.addEventListener("click", function () {
      setTokenHarborKey(thKeyInput.value);
      setModel(modelSelect.value);
      settingsDrawer.setAttribute("hidden", "true");
      appendMessage("bot", "✓ Settings saved! Model set to: **" + modelSelect.value + "**.");
    });

    // Voice recognition (Speech to text)
    var isListening = false;
    var currentRecognition = null;

    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

      function stopListening() {
        if (currentRecognition) {
          try {
            currentRecognition.abort();
          } catch (e) {}
          currentRecognition = null;
        }
        isListening = false;
        micBtn.classList.remove("is-listening");
        micBtn.textContent = "🎙️";
        micBtn.setAttribute("aria-label", "Start voice input");
        input.placeholder = "Ask Jadhu or say 'switch to satellite'...";
      }

      async function startListening() {
        if (isListening) {
          stopListening();
          return;
        }

        // 1. Explicitly request & verify microphone permission first via getUserMedia.
        // This solves the permission prompt timeout bug in Chrome & WebKit!
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          try {
            micBtn.textContent = "⏳";
            var stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            // Release the tracks right away so the audio hardware is freed for SpeechRecognition
            stream.getTracks().forEach(function (track) { track.stop(); });
          } catch (permErr) {
            micBtn.textContent = "🎙️";
            if (permErr.name === "NotAllowedError" || permErr.name === "PermissionDeniedError") {
              appendMessage("bot", "⚠️ Microphone permission was denied. Please allow microphone access in your browser site settings (click the lock or tune icon in the address bar) to use voice input.");
              return;
            }
          }
        }

        // 2. Instantiate a fresh SpeechRecognition instance for this session
        var rec;
        try {
          rec = new SpeechRecognition();
        } catch (e) {
          appendMessage("bot", "Speech recognition could not be started on this browser.");
          return;
        }

        rec.continuous = false;
        rec.interimResults = true;
        var currentLang = (window.adws && window.adws.state && window.adws.state.lang) || "en";
        rec.lang = currentLang === "hi" ? "hi-IN" : "en-IN";

        rec.onstart = function () {
          isListening = true;
          micBtn.classList.add("is-listening");
          micBtn.textContent = "🔴";
          micBtn.setAttribute("aria-label", "Listening… Tap to stop");
          input.placeholder = "Listening… speak now";
        };

        rec.onresult = function (event) {
          var transcript = "";
          for (var i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
          }
          if (transcript) {
            input.value = transcript;
          }
          if (event.results[0] && event.results[0].isFinal) {
            stopListening();
            if (transcript.trim()) {
              handleUserMessage(transcript.trim());
            }
          }
        };

        rec.onerror = function (event) {
          console.warn("SpeechRecognition error:", event.error);
          stopListening();
          if (event.error === "not-allowed" || event.error === "service-not-allowed") {
            appendMessage("bot", "⚠️ Microphone access was not allowed. Please click the lock or site settings icon in the address bar to allow microphone.");
          }
        };

        rec.onend = function () {
          stopListening();
        };

        try {
          rec.start();
          currentRecognition = rec;
        } catch (err) {
          console.warn("Could not start recognition:", err);
          stopListening();
        }
      }

      micBtn.addEventListener("click", function () {
        startListening();
      });
    } else {
      micBtn.style.display = "none";
    }

    // Chips click handler
    chipsContainer.addEventListener("click", function (e) {
      var btn = e.target.closest(".jadhu-chip");
      if (btn) {
        var p = btn.getAttribute("data-prompt");
        if (p) {
          input.value = p;
          handleUserMessage(p);
        }
      }
    });

    // Form submit handler
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var text = input.value.trim();
      if (!text) return;
      handleUserMessage(text);
      input.value = "";
    });

    // Keyboard shortcut (Escape to close)
    window.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && container.classList.contains("is-open")) {
        closeModal();
      }
    });
  }

  async function handleUserMessage(userText) {
    var input = document.getElementById("jadhuInput");
    var sendBtn = document.getElementById("jadhuSendBtn");
    appendMessage("user", userText);

    if (input) input.disabled = true;
    if (sendBtn) sendBtn.disabled = true;

    // Show temporary typing indicator
    var messagesEl = document.getElementById("jadhuMessages");
    var typingDiv = document.createElement("div");
    typingDiv.className = "jadhu-msg jadhu-msg-bot jadhu-typing";
    typingDiv.innerHTML = "<span></span><span></span><span></span>";
    messagesEl.appendChild(typingDiv);
    messagesEl.scrollTop = messagesEl.scrollHeight;

    try {
      var response = await queryAI(userText);

      // Check if response contains an action code block
      var actionBlockMatch = response.match(/```action\s*([\s\S]*?)\s*```/);
      var cleanResponse = response.replace(/```action[\s\S]*?```/g, "").trim();

      if (typingDiv.parentNode) typingDiv.parentNode.removeChild(typingDiv);

      appendMessage("bot", cleanResponse);

      if (actionBlockMatch) {
        try {
          var actObj = JSON.parse(actionBlockMatch[1]);
          if (actObj && actObj.action) {
            var actionResult = executeSiteAction(actObj.action, actObj.value);
            appendMessage("bot", "⚡ " + actionResult.message, true);
          }
        } catch (err) {
          console.warn("Failed to parse AI action payload:", err);
        }
      }
    } catch (err) {
      if (typingDiv.parentNode) typingDiv.parentNode.removeChild(typingDiv);
      var fallback = generateLocalResponse(userText);
      appendMessage("bot", fallback);
    } finally {
      if (input) {
        input.disabled = false;
        input.focus();
      }
      if (sendBtn) sendBtn.disabled = false;
    }
  }

  // Initialize once DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectJadhuUI);
  } else {
    injectJadhuUI();
  }

  root.JadhuAI = {
    open: function () {
      var container = document.getElementById("jadhuContainer");
      var backdrop = document.getElementById("jadhuBackdrop");
      if (container) {
        container.classList.add("is-open");
        container.setAttribute("aria-hidden", "false");
      }
      if (backdrop) {
        backdrop.classList.add("is-open");
        backdrop.setAttribute("aria-hidden", "false");
      }
    },
    close: function () {
      var container = document.getElementById("jadhuContainer");
      var backdrop = document.getElementById("jadhuBackdrop");
      if (container) {
        container.classList.remove("is-open");
        container.setAttribute("aria-hidden", "true");
      }
      if (backdrop) {
        backdrop.classList.remove("is-open");
        backdrop.setAttribute("aria-hidden", "true");
      }
    },
    ask: handleUserMessage,
    execute: executeSiteAction
  };
})(typeof window !== "undefined" ? window : globalThis);
