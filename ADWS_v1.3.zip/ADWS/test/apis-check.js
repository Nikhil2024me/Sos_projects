#!/usr/bin/env node
/**
 * One-shot live check for every API the project uses.
 * Requires: node serve.js 5173
 * Run: node test/apis-check.js
 *
 * PASS = the provider answered and the data is usable.
 * WARN = the code is fine but an external setup step is missing (GPM EULA,
 *        ReliefWeb appname, expired one-day Bhuvan token) or a trial quota ran
 *        out. Warnings do not fail the command.
 * FAIL = the provider should work but did not.
 *
 * The report never writes API keys or tokens. It contains provider names,
 * HTTP statuses and counts only.
 */
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const CONFIG = require("../config");
const Logic = require("../logic");

const BASE = (process.env.API_BASE || "http://127.0.0.1:5173").replace(/\/+$/, "");
const OUT = path.join(__dirname, "apis-report.json");
const checks = [];
const notes = [];

function record(level, name, detail) {
  checks.push({ level, name, detail: detail || "" });
  const tag = level === "pass" ? "PASS" : level === "warn" ? "WARN" : "FAIL";
  console.log(tag + "  " + name + (detail ? " — " + detail : ""));
}
function pass(name, detail) { record("pass", name, detail); }
function warn(name, detail) { record("warn", name, detail); }
function fail(name, detail) { record("fail", name, detail); }
function note(message) {
  notes.push(message);
  console.log("note  " + message);
}

async function request(pathname, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || 90000);
  try {
    const response = await fetch(BASE + pathname, { signal: controller.signal });
    const text = await response.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* not JSON */ }
    return { status: response.status, text, json };
  } finally {
    clearTimeout(timer);
  }
}

async function direct(url, timeoutMs, headers) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs || 30000);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: headers || {} });
    const text = await response.text();
    return { status: response.status, ok: response.ok, text };
  } finally {
    clearTimeout(timer);
  }
}

function countRows(csv) {
  const lines = String(csv || "").trim().split(/\r?\n/);
  return Math.max(0, lines.length - 1);
}

(async () => {
  console.log("Checking " + BASE + "\n");

  /* ---- Local server and primary five-hazard feed ------------------- */
  let health = null;
  try {
    const reply = await request("/api/health", 15000);
    health = reply.json;
    if (reply.status === 200 && health && health.ok) {
      pass("Local server", "/api/health is up");
    } else {
      fail("Local server", "HTTP " + reply.status);
    }
  } catch (error) {
    fail("Local server", "not running (" + error.message + "). Start node serve.js first.");
  }

  if (!health) {
    printSummary();
    return;
  }

  try {
    const reply = await request("/api/alerts", 120000);
    const body = reply.json;
    if (reply.status === 200 && body && body.sources) {
      const sources = body.sources;
      const live = Object.keys(sources).filter((key) => sources[key] === "live");
      if (live.length === 3) pass("Primary feed", "FIRMS + Open-Meteo + USGS are live");
      else warn("Primary feed", "partial: " + JSON.stringify(sources));
      note(body.totalFires + " fire detections in the current snapshot");
    } else {
      fail("Primary feed", "HTTP " + reply.status);
    }
  } catch (error) {
    fail("Primary feed", error.message);
  }

  /* ---- NASA FIRMS: all three satellite sources --------------------- */
  const firmsResults = await Promise.all(CONFIG.firms.sources.map(async (source) => {
    try {
      const url = CONFIG.firms.baseUrl + "/" + CONFIG.firms.key + "/" + source + "/" +
        CONFIG.firms.bbox + "/" + CONFIG.firms.days;
      const reply = await direct(url, 45000);
      return { source, status: reply.status, ok: reply.ok, rows: countRows(reply.text) };
    } catch (error) {
      return { source, status: 0, ok: false, rows: 0, error: error.message };
    }
  }));
  firmsResults.forEach((item) => {
    if (!item.ok) fail("NASA FIRMS " + item.source, "HTTP " + item.status);
    else if (item.rows > 0) pass("NASA FIRMS " + item.source, item.rows + " detections");
    else pass("NASA FIRMS " + item.source, "reachable; no new detections in the 2-day window");
  });

  /* ---- Open-Meteo -------------------------------------------------- */
  try {
    const places = CONFIG.regions.slice(0, 30);
    const params = new URLSearchParams();
    params.set("latitude", places.map((r) => r.lat).join(","));
    params.set("longitude", places.map((r) => r.lon).join(","));
    params.set("current", "temperature_2m");
    params.set("timezone", CONFIG.weather.timezone || "Asia/Kolkata");
    const reply = await direct(CONFIG.weather.baseUrl + "?" + params.toString(), 30000);
    if (reply.ok) {
      const json = JSON.parse(reply.text);
      const count = Array.isArray(json) ? json.length : 1;
      pass("Open-Meteo", count + "/" + places.length + " districts returned weather");
    } else {
      fail("Open-Meteo", "HTTP " + reply.status);
    }
  } catch (error) {
    fail("Open-Meteo", error.message);
  }

  /* ---- USGS FDSN --------------------------------------------------- */
  try {
    const url = Logic.quakeFeedUrl(CONFIG);
    const reply = await direct(url, 30000);
    if (reply.ok) {
      const json = JSON.parse(reply.text);
      const count = (json.features || []).length;
      pass("USGS FDSN", count + " earthquakes in the 7-day India bbox");
    } else {
      fail("USGS FDSN", "HTTP " + reply.status);
    }
  } catch (error) {
    fail("USGS FDSN", error.message);
  }

  /* ---- Ambee ------------------------------------------------------- */
  try {
    const reply = await request("/api/air?district=bastar", 40000);
    const body = reply.json;
    if (reply.status === 200 && body && body.available) {
      pass("Ambee air quality", "AQI " + body.aqi + " (" + body.category + ")");
    } else if (reply.status === 200 && body) {
      warn("Ambee air quality", body.message || "no station reading");
    } else if (body && body.error === "quota_exceeded") {
      warn("Ambee air quality", "daily trial quota reached; AS1 packets still work");
    } else {
      warn("Ambee air quality", (body && body.error) || ("HTTP " + reply.status));
    }
  } catch (error) {
    warn("Ambee air quality", error.message);
  }

  /* ---- NASA GPM ---------------------------------------------------- */
  try {
    const reply = await request("/api/gpm?district=bastar", 60000);
    const body = reply.json;
    if (reply.status === 200 && body && body.available) {
      pass("NASA GPM IMERG", body.rainfallMm + " mm/day (" + body.date + ")");
    } else if (body && body.error === "eula_required") {
      warn("NASA GPM IMERG", "blocked: approve the GES DISC EULA once, then re-run");
    } else if (body && (body.error === "no_data" || body.available === false)) {
      warn("NASA GPM IMERG", "reachable, but no valid cells for this sample");
    } else {
      warn("NASA GPM IMERG", (body && body.error) || ("HTTP " + reply.status));
    }
  } catch (error) {
    warn("NASA GPM IMERG", error.message);
  }

  /* ---- GDACS / EONET / ReliefWeb ----------------------------------- */
  try {
    const reply = await request("/api/hazards?district=bastar", 45000);
    const body = reply.json;
    if (reply.status === 200 && body && body.sources) {
      const sources = body.sources;
      const statusOf = (key) => (sources[key] && sources[key].status) || "unknown";
      const usable = (key) => ["live", "saved", "cached"].indexOf(statusOf(key)) !== -1;

      if (usable("gdacs")) pass("GDACS", statusOf("gdacs") + ", " + sources.gdacs.count + " items");
      else fail("GDACS", statusOf("gdacs"));

      if (usable("eonet")) pass("NASA EONET", statusOf("eonet") + ", " + sources.eonet.count + " items");
      else fail("NASA EONET", statusOf("eonet"));

      if (usable("reliefweb")) pass("ReliefWeb", statusOf("reliefweb") + ", " + sources.reliefweb.count + " items");
      else if (statusOf("reliefweb") === "not_configured") {
        warn("ReliefWeb", "blocked: add an approved appname to server-secrets.js");
      } else {
        warn("ReliefWeb", statusOf("reliefweb"));
      }
    } else {
      fail("Wider hazards", "HTTP " + reply.status);
    }
  } catch (error) {
    fail("Wider hazards", error.message);
  }

  /* ---- Bhuvan routing ---------------------------------------------- */
  try {
    const reply = await request("/api/route?fromLat=17.385&fromLon=78.487&to=bhadrachalam", 60000);
    const body = reply.json;
    if (reply.status === 200 && body && body.distanceKm) {
      pass("Bhuvan routing", body.distanceKm + " km, " + body.points + " points");
    } else if (body && body.error === "invalid_token") {
      warn("Bhuvan routing", "blocked: the one-day token expired; generate a new Routing token");
    } else if (body && body.error === "same_state") {
      warn("Bhuvan routing", "reachable, but this state has no same-state road route");
    } else {
      warn("Bhuvan routing", (body && body.error) || ("HTTP " + reply.status));
    }
  } catch (error) {
    warn("Bhuvan routing", error.message);
  }

  /* ---- Map tiles ---------------------------------------------------- */
  const streetProviders = CONFIG.map.tileProviders || [];
  const satelliteProviders = CONFIG.map.satelliteProviders || [];
  const tileChecks = [
    ["Esri street", streetProviders[0] && streetProviders[0].url
      .replace("{z}", "5").replace("{y}", "12").replace("{x}", "20")],
    ["Esri imagery", satelliteProviders[0] && satelliteProviders[0].url
      .replace("{z}", "5").replace("{y}", "12").replace("{x}", "20")],
    ["OSM France fallback", streetProviders[1] && streetProviders[1].url
      .replace("{s}", "a").replace("{z}", "5").replace("{x}", "20").replace("{y}", "12")]
  ].filter((entry) => Boolean(entry[1]));
  const tileResults = await Promise.all(tileChecks.map(async ([name, url]) => {
    try {
      const reply = await direct(url, 20000);
      return { name, ok: reply.ok, status: reply.status };
    } catch (error) {
      return { name, ok: false, status: 0, error: error.message };
    }
  }));
  const goodTiles = tileResults.filter((item) => item.ok).length;
  tileResults.forEach((item) => {
    if (item.ok) pass("Map tile " + item.name, "HTTP 200");
    else warn("Map tile " + item.name, "HTTP " + item.status);
  });
  if (goodTiles === tileResults.length) note("Street, satellite and fallback tiles all render.");

  printSummary();

  function printSummary() {
    const failures = checks.filter((item) => item.level === "fail").length;
    const warnings = checks.filter((item) => item.level === "warn").length;
    const passed = checks.filter((item) => item.level === "pass").length;

    console.log("\n" + (failures ? "FAILED" : "PASSED") +
      " — " + passed + " passed, " + warnings + " warning(s), " + failures + " failure(s).");

    if (warnings) {
      console.log("\nWarnings need an external action, not a code change:");
      checks.filter((item) => item.level === "warn")
        .forEach((item) => console.log("  - " + item.name + ": " + item.detail));
    }
    if (notes.length) {
      console.log("\nNotes:");
      notes.forEach((message) => console.log("  - " + message));
    }
    if (!failures) {
      console.log("\nThe dashboard and the LoRa feed can run now." +
        (warnings ? " The warnings above stay disabled until fixed." : ""));
    }

    fs.writeFileSync(OUT, JSON.stringify({
      generatedAt: new Date().toISOString(),
      base: BASE,
      passed,
      warnings,
      failures,
      checks,
      notes
    }, null, 2) + "\n");
    console.log("Report: " + path.relative(process.cwd(), OUT));
    process.exitCode = failures ? 1 : 0;
  }
})().catch((error) => {
  console.error("Unexpected failure:", error);
  process.exitCode = 1;
});
