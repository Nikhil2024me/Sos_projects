#include "src/ui/ui_common.h"

// ---------------------------------------------------------------------------
// V4 Split-Pane Android Tablet Settings Screen (320x240)
// + Popup Dropdown Menus + Full-Screen QWERTY City Keyboard
// ---------------------------------------------------------------------------

typedef enum {
    CFG_CAT_LORA = 0,
    CFG_CAT_WEATHER,
    CFG_CAT_BAR,
    CFG_CAT_DISPLAY,
    CFG_CAT_SOUND,
    CFG_CAT_SYSTEM,
    CFG_CAT_COUNT
} cfg_cat_t;

typedef enum {
    DD_NONE = 0,
    DD_NODE_ID,
    DD_TX_PWR_SF,
    DD_LOCATION,
    DD_TEMP_UNIT,
    DD_POLL_INT,
    DD_BRIGHTNESS,
    DD_RGB_MODE
} dd_kind_t;

typedef enum {
    ROW_MODE_VALUE = 0,
    ROW_MODE_SWITCH,
    ROW_MODE_DROPDOWN
} row_mode_t;

static cfg_cat_t s_cat = CFG_CAT_LORA;
static dd_kind_t s_dd_kind = DD_NONE;

static lv_obj_t *s_cat_rows[CFG_CAT_COUNT];
static lv_obj_t *s_cat_lbls[CFG_CAT_COUNT];
static lv_obj_t *s_right_title = NULL;

// Right-pane interactive rows (4 rows inside the detail pane)
static lv_obj_t *s_r_rows[4];
static lv_obj_t *s_r_titles[4];
static lv_obj_t *s_r_subs[4];
static lv_obj_t *s_r_vals[4];
static lv_obj_t *s_r_dd_boxes[4];
static lv_obj_t *s_r_dd_lbls[4];
static lv_obj_t *s_r_sw_tracks[4];
static lv_obj_t *s_r_sw_knobs[4];

// Floating Dropdown Menu overlay widgets
#define DD_MAX_OPTS 6
static lv_obj_t *s_dd_backdrop = NULL;
static lv_obj_t *s_dd_panel = NULL;
static lv_obj_t *s_dd_title = NULL;
static lv_obj_t *s_dd_opts[DD_MAX_OPTS];
static lv_obj_t *s_dd_opt_lbls[DD_MAX_OPTS];
static lv_obj_t *s_dd_opt_chks[DD_MAX_OPTS];

// On-screen QWERTY City Keyboard state
static lv_obj_t *s_kb_input_lbl = NULL;
static char s_kb_buf[20] = "Coimbatore";
static uint8_t s_kb_len = 10;

static uint32_t s_ping_flash_until = 0;
static uint32_t s_sync_flash_until = 0;

#define AND_BG        lv_color_hex(0x000000)
#define AND_CARD      lv_color_hex(0x1C1D22)
#define AND_CARD_SEL  lv_color_hex(0x2E323B)
#define AND_DIV       lv_color_hex(0x2A2C34)
#define AND_BLUE      lv_color_hex(0x2B6FF7)
#define AND_SW_OFF    lv_color_hex(0x484C56)
#define AND_SUB       lv_color_hex(0x8C919E)
#define AND_DD_BG     lv_color_hex(0x252830)
#define AND_DD_BDR    lv_color_hex(0x3B404E)
#define AND_POPUP_BG  lv_color_hex(0x22252E)
#define AND_POPUP_BDR lv_color_hex(0x3E4556)
#define AND_OPT_SEL   lv_color_hex(0x1B315E)

// RF Power + Spreading Factor preset table (6 combinations)
typedef struct {
    uint8_t dbm;
    uint8_t sf;
    const char *short_lbl;
    const char *menu_lbl;
} rf_preset_t;

static const rf_preset_t k_rf_presets[6] = {
    { 11,  7, "11dBm SF7",  "11 dBm | SF7 (Short)"   },
    { 14,  7, "14dBm SF7",  "14 dBm | SF7 (Normal)"  },
    { 17,  7, "17dBm SF7",  "17 dBm | SF7 (Default)" },
    { 20,  7, "20dBm SF7",  "20 dBm | SF7 (Max Pwr)" },
    { 20,  9, "20dBm SF9",  "20 dBm | SF9 (Long Rng)"},
    { 20, 10, "20dBm SF10", "20 dBm | SF10 (Extreme)"},
};

static int find_rf_preset_idx(uint8_t dbm, uint8_t sf)
{
    for (int i = 0; i < 6; i++) {
        if (k_rf_presets[i].dbm == dbm && k_rf_presets[i].sf == sf) return i;
    }
    return 2; // default 17dBm SF7
}

static void show_city_keyboard(void);

void ui_config_reset(void)
{
    s_dd_kind = DD_NONE;
    s_kb_input_lbl = NULL;
    for (int i = 0; i < CFG_CAT_COUNT; i++) {
        s_cat_rows[i] = NULL;
        s_cat_lbls[i] = NULL;
    }
    s_right_title = NULL;
    for (int i = 0; i < 4; i++) {
        s_r_rows[i] = NULL;
        s_r_titles[i] = NULL;
        s_r_subs[i] = NULL;
        s_r_vals[i] = NULL;
        s_r_dd_boxes[i] = NULL;
        s_r_dd_lbls[i] = NULL;
        s_r_sw_tracks[i] = NULL;
        s_r_sw_knobs[i] = NULL;
    }
    s_dd_backdrop = NULL;
    s_dd_panel = NULL;
    s_dd_title = NULL;
    for (int i = 0; i < DD_MAX_OPTS; i++) {
        s_dd_opts[i] = NULL;
        s_dd_opt_lbls[i] = NULL;
        s_dd_opt_chks[i] = NULL;
    }
}

static void setup_right_row(int idx, const char *title, const char *sub,
                            row_mode_t mode, bool sw_on,
                            const char *val_text, lv_color_t title_color,
                            lv_color_t val_color)
{
    if (idx < 0 || idx >= 4 || s_r_rows[idx] == NULL) return;

    lv_label_set_text(s_r_titles[idx], title);
    lv_obj_set_style_text_color(s_r_titles[idx], title_color, 0);

    if (sub != NULL && sub[0] != '\0') {
        lv_label_set_text(s_r_subs[idx], sub);
        lv_obj_set_hidden(s_r_subs[idx], false);
        lv_obj_set_y(s_r_titles[idx], (idx == 0) ? 3 : 6);
    } else {
        lv_label_set_text(s_r_subs[idx], "");
        lv_obj_set_hidden(s_r_subs[idx], true);
        lv_obj_set_y(s_r_titles[idx], (idx == 0) ? 11 : 13);
    }

    if (mode == ROW_MODE_SWITCH) {
        lv_obj_set_width(s_r_titles[idx], 134);
        lv_obj_set_hidden(s_r_sw_tracks[idx], false);
        lv_obj_set_hidden(s_r_vals[idx], true);
        lv_obj_set_hidden(s_r_dd_boxes[idx], true);
        lv_obj_set_style_bg_color(s_r_sw_tracks[idx],
                                  sw_on ? AND_BLUE : AND_SW_OFF, 0);
        lv_obj_set_style_border_color(s_r_sw_tracks[idx],
                                      sw_on ? AND_BLUE : AND_SW_OFF, 0);
        lv_obj_set_x(s_r_sw_knobs[idx], sw_on ? 17 : 2);
    } else if (mode == ROW_MODE_DROPDOWN) {
        lv_obj_set_width(s_r_titles[idx], 84);
        lv_obj_set_hidden(s_r_sw_tracks[idx], true);
        lv_obj_set_hidden(s_r_vals[idx], true);
        lv_obj_set_hidden(s_r_dd_boxes[idx], false);
        lv_label_set_text_fmt(s_r_dd_lbls[idx], "%s " LV_SYMBOL_DOWN,
                              val_text != NULL ? val_text : "");
        lv_obj_set_style_text_color(s_r_dd_lbls[idx], val_color, 0);
    } else {
        lv_obj_set_width(s_r_titles[idx], 124);
        lv_obj_set_hidden(s_r_sw_tracks[idx], true);
        lv_obj_set_hidden(s_r_dd_boxes[idx], true);
        lv_obj_set_hidden(s_r_vals[idx], false);
        lv_label_set_text(s_r_vals[idx], val_text != NULL ? val_text : "");
        lv_obj_set_style_text_color(s_r_vals[idx], val_color, 0);
    }
}

static void refresh_dropdown_overlay(void)
{
    if (s_dd_panel == NULL || s_dd_backdrop == NULL) return;

    if (s_dd_kind == DD_NONE) {
        lv_obj_set_hidden(s_dd_backdrop, true);
        lv_obj_set_hidden(s_dd_panel, true);
        return;
    }

    const ui_settings_t *cfg = ui_get_settings();
    const char *hdr = "Select Option";
    const char *opts[DD_MAX_OPTS] = {0};
    char custom_opt_buf[36];
    int count = 0;
    int selected = 0;

    switch (s_dd_kind) {
    case DD_TX_PWR_SF:
        hdr = "Select TX Power & SF";
        count = 6;
        selected = find_rf_preset_idx(cfg->lora_tx_dbm, cfg->lora_sf);
        for (int i = 0; i < 6; i++) opts[i] = k_rf_presets[i].menu_lbl;
        break;
    case DD_NODE_ID:
        hdr = "Select Station Node ID";
        opts[0] = "Node 01 (Primary)";
        opts[1] = "Node 02 (Sector B)";
        opts[2] = "Node 03 (Sector C)";
        opts[3] = "Node 04 (Mobile)";
        count = 4;
        selected = (cfg->node_id >= 1 && cfg->node_id <= 4) ? (cfg->node_id - 1) : 0;
        break;
    case DD_LOCATION:
        hdr = "Select or Type City";
        opts[0] = "Chennai (13.1N, 80.3E)";
        opts[1] = "Bengaluru (13.0N, 77.6E)";
        opts[2] = "Mumbai (19.1N, 72.9E)";
        opts[3] = "Delhi (28.6N, 77.2E)";
        opts[4] = "London (51.5N, 0.1W)";
        if (cfg->custom_city[0] != '\0') {
            lv_snprintf(custom_opt_buf, sizeof(custom_opt_buf),
                        "+ Type (%s)...", cfg->custom_city);
        } else {
            lv_snprintf(custom_opt_buf, sizeof(custom_opt_buf),
                        "%s", "+ Type Custom City...");
        }
        opts[5] = custom_opt_buf;
        count = 6;
        selected = (cfg->city_index <= 5) ? cfg->city_index : 0;
        break;
    case DD_TEMP_UNIT:
        hdr = "Temperature Unit";
        opts[0] = "Celsius (C) - Metric";
        opts[1] = "Fahrenheit (F) - Imperial";
        count = 2;
        selected = cfg->temp_fahrenheit ? 1 : 0;
        break;
    case DD_POLL_INT:
        hdr = "OWM Auto-Poll Interval";
        opts[0] = "Every 5 minutes";
        opts[1] = "Every 15 minutes";
        opts[2] = "Every 30 minutes";
        opts[3] = "Manual sync only";
        count = 4;
        selected = (cfg->owm_interval_min == 5)  ? 0 :
                   (cfg->owm_interval_min == 15) ? 1 :
                   (cfg->owm_interval_min == 30) ? 2 : 3;
        break;
    case DD_BRIGHTNESS:
        hdr = "Display Brightness";
        opts[0] = "100% (Maximum)";
        opts[1] = "75% (High)";
        opts[2] = "50% (Medium)";
        opts[3] = "25% (Dim / Night)";
        count = 4;
        selected = (cfg->brightness_pct >= 90) ? 0 :
                   (cfg->brightness_pct >= 65) ? 1 :
                   (cfg->brightness_pct >= 40) ? 2 : 3;
        break;
    case DD_RGB_MODE:
        hdr = "ESP32-S3 RGB LED Mode";
        opts[0] = "Auto (Service Color)";
        opts[1] = "Police Strobe (R/B)";
        opts[2] = "Crimson Alert (Red)";
        opts[3] = "Cyber Cyan";
        opts[4] = "Emerald Green";
        opts[5] = "Warm Amber";
        count = 6;
        selected = (cfg->rgb_mode < 6) ? cfg->rgb_mode : 0;
        break;
    default:
        break;
    }

    lv_label_set_text(s_dd_title, hdr);
    int32_t panel_h = 28 + count * 26 + 4;
    lv_obj_set_height(s_dd_panel, panel_h);
    lv_obj_set_y(s_dd_panel, 28 + (188 - panel_h) / 2);

    for (int i = 0; i < DD_MAX_OPTS; i++) {
        if (i < count) {
            bool act = (i == selected);
            lv_obj_set_hidden(s_dd_opts[i], false);
            lv_obj_set_style_bg_color(s_dd_opts[i],
                                      act ? AND_OPT_SEL : AND_POPUP_BG, 0);
            lv_label_set_text(s_dd_opt_lbls[i], opts[i]);
            lv_color_t tc = act ? UI_WHITE :
                            ((s_dd_kind == DD_LOCATION && i == 5) ? UI_CYAN : lv_color_hex(0xD1D5DB));
            lv_obj_set_style_text_color(s_dd_opt_lbls[i], tc, 0);
            lv_obj_set_hidden(s_dd_opt_chks[i], !act);
        } else {
            lv_obj_set_hidden(s_dd_opts[i], true);
        }
    }

    lv_obj_set_hidden(s_dd_backdrop, false);
    lv_obj_set_hidden(s_dd_panel, false);
}

void ui_config_refresh_live(void)
{
    if (s_r_rows[0] == NULL) return;

    const ui_settings_t *cfg = ui_get_settings();
    const ui_status_t *st = ui_get_status();

    // Update Left Sidebar selection highlight
    for (int i = 0; i < CFG_CAT_COUNT; i++) {
        if (s_cat_rows[i] == NULL) continue;
        const bool sel = ((int)s_cat == i);
        lv_obj_set_style_bg_color(s_cat_rows[i], sel ? AND_CARD_SEL : AND_CARD, 0);
        lv_obj_set_style_bg_opa(s_cat_rows[i], sel ? LV_OPA_COVER : LV_OPA_TRANSP, 0);
        lv_obj_set_style_text_color(s_cat_lbls[i],
                                    sel ? UI_WHITE : lv_color_hex(0xD1D5DB), 0);
    }

    char sub_buf[44];
    char val_buf[24];

    if (s_cat == CFG_CAT_LORA) {
        lv_label_set_text(s_right_title, "LoRa 433MHz");

        lv_snprintf(sub_buf, sizeof(sub_buf), "SX1278 SPI | %lu pkts",
                    (unsigned long)st->lora_tx_count);
        setup_right_row(0, "LoRa Radio", sub_buf,
                        ROW_MODE_SWITCH, st->lora_ok, NULL, UI_WHITE, UI_WHITE);

        bool ping_ok = (s_ping_flash_until > 0 && lv_tick_get() < s_ping_flash_until);
        lv_snprintf(sub_buf, sizeof(sub_buf), "Send NODE:%02u ping",
                    (unsigned)cfg->node_id);
        setup_right_row(1, ping_ok ? LV_SYMBOL_OK " Ping Sent" : "Test Ping",
                        sub_buf, ROW_MODE_VALUE, false,
                        ping_ok ? "OK >" : "SEND >",
                        ping_ok ? AND_BLUE : UI_WHITE,
                        ping_ok ? AND_BLUE : AND_SUB);

        lv_snprintf(val_buf, sizeof(val_buf), "Node %02u", (unsigned)cfg->node_id);
        setup_right_row(2, "Station ID", NULL, ROW_MODE_DROPDOWN, false,
                        val_buf, UI_WHITE, UI_WHITE);

        int rf_idx = find_rf_preset_idx(cfg->lora_tx_dbm, cfg->lora_sf);
        setup_right_row(3, "Power & SF", NULL, ROW_MODE_DROPDOWN, false,
                        k_rf_presets[rf_idx].short_lbl, UI_WHITE, UI_WHITE);

    } else if (s_cat == CFG_CAT_WEATHER) {
        lv_label_set_text(s_right_title, "Weather & OWM");

        setup_right_row(0, "Wi-Fi & OWM Sync", "Live OWM API sync",
                        ROW_MODE_SWITCH, cfg->wifi_enabled, NULL, UI_WHITE, UI_WHITE);

        int t_disp = (int)st->temp_c;
        char unit = 'C';
        if (cfg->temp_fahrenheit) {
            t_disp = (t_disp * 9) / 5 + 32;
            unit = 'F';
        }
        bool synced = (s_sync_flash_until > 0 && lv_tick_get() < s_sync_flash_until);
        lv_snprintf(sub_buf, sizeof(sub_buf), "%d%c %s | %u%% RH",
                    t_disp, unit,
                    st->condition[0] ? st->condition : "CLEAR",
                    (unsigned)st->humidity);
        setup_right_row(1, synced ? LV_SYMBOL_OK " Synced OWM" : "Sync Weather Now",
                        sub_buf, ROW_MODE_VALUE, false,
                        "SYNC >",
                        synced ? AND_BLUE : UI_WHITE, AND_BLUE);

        setup_right_row(2, "Location", NULL, ROW_MODE_DROPDOWN, false,
                        ui_city_name(cfg->city_index), UI_WHITE, UI_WHITE);

        setup_right_row(3, "Temp Unit", NULL, ROW_MODE_DROPDOWN, false,
                        cfg->temp_fahrenheit ? "Fahrenheit" : "Celsius",
                        UI_WHITE, UI_WHITE);

    } else if (s_cat == CFG_CAT_BAR) {
        lv_label_set_text(s_right_title, "AQI & Status Bar");

        setup_right_row(0, "Bottom Status Bar", "Weather, AQI & LoRa",
                        ROW_MODE_SWITCH, cfg->show_bottom_bar, NULL, UI_WHITE, UI_WHITE);

        const char *tier = (st->aqi > 150) ? "Poor" :
                           (st->aqi > 100) ? "Mod" :
                           (st->aqi > 50)  ? "Fair" : "Good";
        lv_snprintf(sub_buf, sizeof(sub_buf), "OWM Air: %s", tier);
        lv_snprintf(val_buf, sizeof(val_buf), "AQI %u >", (unsigned)st->aqi);
        setup_right_row(1, LV_SYMBOL_OK " Live Air Quality", sub_buf,
                        ROW_MODE_VALUE, false, val_buf, AND_BLUE, UI_GREEN);

        if (cfg->owm_interval_min == 0) {
            lv_snprintf(val_buf, sizeof(val_buf), "Manual");
        } else {
            lv_snprintf(val_buf, sizeof(val_buf), "%u min",
                        (unsigned)cfg->owm_interval_min);
        }
        setup_right_row(2, "Poll Interval", NULL, ROW_MODE_DROPDOWN, false,
                        val_buf, UI_WHITE, UI_WHITE);

        setup_right_row(3, "Link Display", NULL, ROW_MODE_VALUE, false,
                        st->lora_ok ? "LoRa OK >" : "Offline >",
                        UI_WHITE, st->lora_ok ? UI_GREEN : UI_AMBER);

    } else if (s_cat == CFG_CAT_DISPLAY) {
        lv_label_set_text(s_right_title, "Display & Touch");

        setup_right_row(0, "Backlight ON", "GPIO 21 panel power",
                        ROW_MODE_SWITCH, cfg->brightness_pct > 25, NULL, UI_WHITE, UI_WHITE);

        lv_snprintf(val_buf, sizeof(val_buf), "%u%%", (unsigned)cfg->brightness_pct);
        setup_right_row(1, "Brightness", "Backlight PWM level",
                        ROW_MODE_DROPDOWN, false, val_buf, UI_WHITE, UI_WHITE);

        setup_right_row(2, LV_SYMBOL_OK " Touch Calibrate",
                        NULL, ROW_MODE_VALUE, false,
                        "RUN >", AND_BLUE, AND_BLUE);

        setup_right_row(3, "Panel Format", NULL, ROW_MODE_VALUE, false,
                        "320x240 >", UI_WHITE, AND_SUB);

    } else if (s_cat == CFG_CAT_SOUND) {
        static const char *const k_rgb_short[6] = {
            "Auto Svc", "Strobe RB", "Red Alert", "Cyber Cyan", "Emerald", "Amber"
        };
        uint8_t rmode = (cfg->rgb_mode < 6) ? cfg->rgb_mode : 0;

        lv_label_set_text(s_right_title, "Sound & S3 RGB");

        setup_right_row(0, "Buzzer Sound", "GPIO 18 alarm on SOS",
                        ROW_MODE_SWITCH, cfg->buzzer_enabled, NULL, UI_WHITE, UI_WHITE);

        setup_right_row(1, "ESP32-S3 RGB LED", "WS2812 GPIO 48",
                        ROW_MODE_SWITCH, cfg->led_enabled, NULL, UI_WHITE, UI_WHITE);

        setup_right_row(2, "RGB Mode", NULL, ROW_MODE_DROPDOWN, false,
                        k_rgb_short[rmode], UI_WHITE, UI_WHITE);

        setup_right_row(3, LV_SYMBOL_OK " Test Sound/RGB", NULL,
                        ROW_MODE_VALUE, false, "PULSE >", AND_BLUE, AND_BLUE);

    } else {
        // CFG_CAT_SYSTEM
        lv_label_set_text(s_right_title, "System Info");

        uint32_t up = ui_uptime_get();
        lv_snprintf(val_buf, sizeof(val_buf), "%02lu:%02lu",
                    (unsigned long)(up / 60u), (unsigned long)(up % 60u));
        setup_right_row(0, "System Uptime", "ESP32-S3 + LVGL 9.6",
                        ROW_MODE_VALUE, false, val_buf, UI_WHITE, AND_SUB);

        lv_snprintf(val_buf, sizeof(val_buf), "%lu sent",
                    (unsigned long)st->lora_tx_count);
        setup_right_row(1, "LoRa Packets", "433.0 MHz SX1278",
                        ROW_MODE_VALUE, false, val_buf, UI_WHITE, AND_SUB);

        setup_right_row(2, "Touch Calibration", NULL,
                        ROW_MODE_VALUE, false, "CAL >", UI_WHITE, AND_BLUE);

        setup_right_row(3, "Reset Defaults", NULL,
                        ROW_MODE_VALUE, false, "RESET >", UI_RED, UI_RED);
    }

    refresh_dropdown_overlay();
}

void ui_config_update_pressure(uint16_t z)
{
    (void)z;
}

void ui_config_update_uptime(uint32_t seconds)
{
    (void)seconds;
    if (s_r_rows[0] != NULL && s_cat == CFG_CAT_SYSTEM && s_dd_kind == DD_NONE) {
        ui_config_refresh_live();
    }
}

static void notify_settings_changed(const ui_settings_t *next)
{
    ui_set_settings(next);
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_settings_change != NULL) {
        cbs->on_settings_change(ui_get_settings());
    }
}

static void open_dropdown(dd_kind_t kind)
{
    s_dd_kind = kind;
    refresh_dropdown_overlay();
}

static void dd_close_cb(lv_event_t *e)
{
    (void)e;
    s_dd_kind = DD_NONE;
    refresh_dropdown_overlay();
}

static void dd_opt_clicked_cb(lv_event_t *e)
{
    intptr_t idx = (intptr_t)lv_event_get_user_data(e);
    ui_settings_t next = *ui_get_settings();
    const ui_callbacks_t *cbs = ui_get_callbacks();
    dd_kind_t kind = s_dd_kind;
    s_dd_kind = DD_NONE;

    switch (kind) {
    case DD_TX_PWR_SF:
        if (idx >= 0 && idx < 6) {
            next.lora_tx_dbm = k_rf_presets[idx].dbm;
            next.lora_sf     = k_rf_presets[idx].sf;
        }
        break;
    case DD_NODE_ID:
        if (idx >= 0 && idx < 4) {
            next.node_id = (uint8_t)(idx + 1);
        }
        break;
    case DD_LOCATION:
        if (idx >= 0 && idx < 5) {
            next.city_index = (uint8_t)idx;
            notify_settings_changed(&next);
            if (cbs->on_weather_sync != NULL) cbs->on_weather_sync();
            return;
        } else if (idx == 5) {
            show_city_keyboard();
            return;
        }
        break;
    case DD_TEMP_UNIT:
        next.temp_fahrenheit = (idx == 1);
        break;
    case DD_POLL_INT:
        if (idx == 0) next.owm_interval_min = 5;
        else if (idx == 1) next.owm_interval_min = 15;
        else if (idx == 2) next.owm_interval_min = 30;
        else next.owm_interval_min = 0;
        break;
    case DD_BRIGHTNESS:
        if (idx == 0) next.brightness_pct = 100;
        else if (idx == 1) next.brightness_pct = 75;
        else if (idx == 2) next.brightness_pct = 50;
        else next.brightness_pct = 25;
        break;
    case DD_RGB_MODE:
        if (idx >= 0 && idx < 6) {
            next.rgb_mode = (uint8_t)idx;
        }
        break;
    default:
        break;
    }

    notify_settings_changed(&next);
}

static void back_clicked_cb(lv_event_t *e)
{
    (void)e;
    if (s_dd_kind != DD_NONE) {
        s_dd_kind = DD_NONE;
        refresh_dropdown_overlay();
        return;
    }
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_close_config != NULL) {
        cbs->on_close_config();
    }
}

static void cat_clicked_cb(lv_event_t *e)
{
    intptr_t idx = (intptr_t)lv_event_get_user_data(e);
    if (idx >= 0 && idx < CFG_CAT_COUNT) {
        s_dd_kind = DD_NONE;
        s_cat = (cfg_cat_t)idx;
        ui_config_refresh_live();
    }
}

static void right_row_clicked_cb(lv_event_t *e)
{
    intptr_t row = (intptr_t)lv_event_get_user_data(e);
    ui_settings_t next = *ui_get_settings();
    const ui_callbacks_t *cbs = ui_get_callbacks();

    if (s_cat == CFG_CAT_LORA) {
        if (row == 0) {
            if (cbs->on_lora_reinit != NULL) cbs->on_lora_reinit();
            ui_config_refresh_live();
            return;
        } else if (row == 1) {
            s_ping_flash_until = lv_tick_get() + 1500;
            if (cbs->on_lora_ping != NULL) cbs->on_lora_ping();
            ui_config_refresh_live();
            return;
        } else if (row == 2) {
            open_dropdown(DD_NODE_ID);
            return;
        } else if (row == 3) {
            open_dropdown(DD_TX_PWR_SF);
            return;
        }
    } else if (s_cat == CFG_CAT_WEATHER) {
        if (row == 0) {
            next.wifi_enabled = !next.wifi_enabled;
        } else if (row == 1) {
            s_sync_flash_until = lv_tick_get() + 1500;
            if (cbs->on_weather_sync != NULL) cbs->on_weather_sync();
            ui_config_refresh_live();
            return;
        } else if (row == 2) {
            open_dropdown(DD_LOCATION);
            return;
        } else if (row == 3) {
            open_dropdown(DD_TEMP_UNIT);
            return;
        }
    } else if (s_cat == CFG_CAT_BAR) {
        if (row == 0) {
            next.show_bottom_bar = !next.show_bottom_bar;
        } else if (row == 1) {
            s_sync_flash_until = lv_tick_get() + 1500;
            if (cbs->on_weather_sync != NULL) cbs->on_weather_sync();
            ui_config_refresh_live();
            return;
        } else if (row == 2) {
            open_dropdown(DD_POLL_INT);
            return;
        } else if (row == 3) {
            if (cbs->on_lora_reinit != NULL) cbs->on_lora_reinit();
            ui_config_refresh_live();
            return;
        }
    } else if (s_cat == CFG_CAT_DISPLAY) {
        if (row == 0) {
            next.brightness_pct = (next.brightness_pct > 25) ? 25 : 100;
        } else if (row == 1) {
            open_dropdown(DD_BRIGHTNESS);
            return;
        } else if (row == 2) {
            if (cbs->on_calibrate != NULL) cbs->on_calibrate();
            return;
        } else {
            return;
        }
    } else if (s_cat == CFG_CAT_SOUND) {
        if (row == 0) {
            next.buzzer_enabled = !next.buzzer_enabled;
        } else if (row == 1) {
            next.led_enabled = !next.led_enabled;
        } else if (row == 2) {
            open_dropdown(DD_RGB_MODE);
            return;
        } else if (row == 3) {
            if (cbs->on_test_io != NULL) cbs->on_test_io();
            return;
        }
    } else {
        // CFG_CAT_SYSTEM
        if (row == 1) {
            if (cbs->on_lora_ping != NULL) cbs->on_lora_ping();
            ui_config_refresh_live();
            return;
        } else if (row == 2) {
            if (cbs->on_calibrate != NULL) cbs->on_calibrate();
            return;
        } else if (row == 3) {
            ui_settings_defaults(&next);
        } else {
            return;
        }
    }

    notify_settings_changed(&next);
}

// ===========================================================================
// Full-Screen Touch QWERTY Keyboard for Typing Custom City Name
// ===========================================================================
static void kb_refresh_label(void)
{
    if (s_kb_input_lbl == NULL) return;
    lv_label_set_text_fmt(s_kb_input_lbl, "%s_", s_kb_buf);
}

static void kb_key_cb(lv_event_t *e)
{
    char ch = (char)(intptr_t)lv_event_get_user_data(e);
    if ((size_t)(s_kb_len + 1) >= sizeof(s_kb_buf)) return;

    // Auto-capitalize first letter of each word, lowercase subsequent letters
    bool word_start = (s_kb_len == 0 || s_kb_buf[s_kb_len - 1] == ' ' ||
                       s_kb_buf[s_kb_len - 1] == '-');
    if (ch >= 'A' && ch <= 'Z' && !word_start) {
        ch = (char)(ch - 'A' + 'a');
    }
    s_kb_buf[s_kb_len++] = ch;
    s_kb_buf[s_kb_len] = '\0';
    kb_refresh_label();
}

static void kb_bksp_cb(lv_event_t *e)
{
    (void)e;
    if (s_kb_len > 0) {
        s_kb_buf[--s_kb_len] = '\0';
        kb_refresh_label();
    }
}

static void kb_clear_cb(lv_event_t *e)
{
    (void)e;
    s_kb_len = 0;
    s_kb_buf[0] = '\0';
    kb_refresh_label();
}

static void kb_cancel_cb(lv_event_t *e)
{
    (void)e;
    ui_show_config();
}

static void kb_save_cb(lv_event_t *e)
{
    (void)e;
    if (s_kb_len > 0) {
        ui_settings_t next = *ui_get_settings();
        lv_snprintf(next.custom_city, sizeof(next.custom_city), "%s", s_kb_buf);
        next.city_index = 5;
        notify_settings_changed(&next);
        const ui_callbacks_t *cbs = ui_get_callbacks();
        if (cbs->on_weather_sync != NULL) cbs->on_weather_sync();
    }
    ui_show_config();
}

static void show_city_keyboard(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    if (cfg->custom_city[0] != '\0') {
        lv_snprintf(s_kb_buf, sizeof(s_kb_buf), "%s", cfg->custom_city);
    } else {
        lv_snprintf(s_kb_buf, sizeof(s_kb_buf), "%s", "Madurai");
    }
    s_kb_len = 0;
    while (s_kb_buf[s_kb_len] != '\0' && s_kb_len < 19) s_kb_len++;

    lv_obj_t *scr = ui_screen_begin(AND_BG, AND_BG);
    ui_telemetry_set_visible(true);

    // Top Input Bar (y = 3..29)
    lv_obj_t *cancel_btn = ui_card(scr, 6, 3, 56, 26, AND_CARD, AND_DD_BDR, 1, 6);
    ui_make_clickable(cancel_btn, AND_CARD_SEL, LV_OPA_COVER);
    ui_name(cancel_btn, "kb_cancel_btn");
    ui_label(cancel_btn, LV_SYMBOL_LEFT " ESC", &lv_font_montserrat_12, UI_WHITE,
             0, 5, 54, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(cancel_btn);
    lv_obj_add_event_cb(cancel_btn, kb_cancel_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *ibox = ui_card(scr, 66, 3, 184, 26, lv_color_hex(0x14171F),
                             AND_BLUE, 1, 6);
    ui_name(ibox, "kb_input_box");
    s_kb_input_lbl = ui_label(ibox, "", &lv_font_montserrat_14, UI_WHITE,
                              8, 4, 168, LV_TEXT_ALIGN_LEFT);
    kb_refresh_label();

    lv_obj_t *save_btn = ui_card(scr, 254, 3, 60, 26, AND_BLUE, AND_BLUE, 1, 6);
    ui_make_clickable(save_btn, lv_color_hex(0x1D4ED8), LV_OPA_COVER);
    ui_name(save_btn, "kb_save_btn");
    ui_label(save_btn, LV_SYMBOL_OK " SAVE", &lv_font_montserrat_12, UI_WHITE,
             0, 5, 58, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(save_btn);
    lv_obj_add_event_cb(save_btn, kb_save_cb, LV_EVENT_CLICKED, NULL);

    // QWERTY Row 1: Q W E R T Y U I O P (10 keys, y = 34, h = 40)
    static const char r1[10] = {'Q','W','E','R','T','Y','U','I','O','P'};
    for (int i = 0; i < 10; i++) {
        char kstr[2] = { r1[i], '\0' };
        char kname[12];
        lv_snprintf(kname, sizeof(kname), "kb_key_%c", r1[i]);
        lv_obj_t *k = ui_card(scr, 6 + i * 31, 34, 29, 40, AND_CARD, AND_DD_BDR, 1, 6);
        ui_make_clickable(k, AND_BLUE, LV_OPA_COVER);
        ui_name(k, kname);
        ui_label(k, kstr, &lv_font_montserrat_14, UI_WHITE, 0, 11, 27, LV_TEXT_ALIGN_CENTER);
        ui_bubble_children(k);
        lv_obj_add_event_cb(k, kb_key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)r1[i]);
    }

    // QWERTY Row 2: A S D F G H J K L (9 keys, y = 78, h = 40)
    static const char r2[9] = {'A','S','D','F','G','H','J','K','L'};
    for (int i = 0; i < 9; i++) {
        char kstr[2] = { r2[i], '\0' };
        char kname[12];
        lv_snprintf(kname, sizeof(kname), "kb_key_%c", r2[i]);
        lv_obj_t *k = ui_card(scr, 21 + i * 31, 78, 29, 40, AND_CARD, AND_DD_BDR, 1, 6);
        ui_make_clickable(k, AND_BLUE, LV_OPA_COVER);
        ui_name(k, kname);
        ui_label(k, kstr, &lv_font_montserrat_14, UI_WHITE, 0, 11, 27, LV_TEXT_ALIGN_CENTER);
        ui_bubble_children(k);
        lv_obj_add_event_cb(k, kb_key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)r2[i]);
    }

    // QWERTY Row 3: Z X C V B N M (7 keys) +CLEAR +BKSP (y = 122, h = 40)
    static const char r3[7] = {'Z','X','C','V','B','N','M'};
    for (int i = 0; i < 7; i++) {
        char kstr[2] = { r3[i], '\0' };
        char kname[12];
        lv_snprintf(kname, sizeof(kname), "kb_key_%c", r3[i]);
        lv_obj_t *k = ui_card(scr, 52 + i * 31, 122, 29, 40, AND_CARD, AND_DD_BDR, 1, 6);
        ui_make_clickable(k, AND_BLUE, LV_OPA_COVER);
        ui_name(k, kname);
        ui_label(k, kstr, &lv_font_montserrat_14, UI_WHITE, 0, 11, 27, LV_TEXT_ALIGN_CENTER);
        ui_bubble_children(k);
        lv_obj_add_event_cb(k, kb_key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)r3[i]);
    }

    // Row 4: [CLEAR] [   SPACE   ] [BKSP] (y = 166, h = 42)
    lv_obj_t *clr = ui_card(scr, 6, 166, 72, 42, lv_color_hex(0x281117), UI_RED, 1, 6);
    ui_make_clickable(clr, UI_RED, LV_OPA_COVER);
    ui_name(clr, "kb_clear_btn");
    ui_label(clr, "CLEAR", &lv_font_montserrat_12, UI_WHITE, 0, 13, 70, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(clr);
    lv_obj_add_event_cb(clr, kb_clear_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *spc = ui_card(scr, 84, 166, 152, 42, AND_CARD, AND_DD_BDR, 1, 6);
    ui_make_clickable(spc, AND_CARD_SEL, LV_OPA_COVER);
    ui_name(spc, "kb_space_btn");
    ui_label(spc, "SPACE", &lv_font_montserrat_12, UI_MUTED, 0, 13, 150, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(spc);
    lv_obj_add_event_cb(spc, kb_key_cb, LV_EVENT_CLICKED, (void *)(intptr_t)' ');

    lv_obj_t *bks = ui_card(scr, 242, 166, 72, 42, AND_DD_BG, AND_DD_BDR, 1, 6);
    ui_make_clickable(bks, AND_CARD_SEL, LV_OPA_COVER);
    ui_name(bks, "kb_bksp_btn");
    ui_label(bks, LV_SYMBOL_BACKSPACE " DEL", &lv_font_montserrat_12, UI_WHITE,
             0, 13, 70, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(bks);
    lv_obj_add_event_cb(bks, kb_bksp_cb, LV_EVENT_CLICKED, NULL);
}

void ui_show_config(void)
{
    lv_obj_t *scr = ui_screen_begin(AND_BG, AND_BG);
    ui_telemetry_set_visible(true);

    // Subtle vertical split-pane divider at x = 114
    ui_box(scr, 114, 0, 1, 220, lv_color_hex(0x16181E), LV_OPA_COVER,
           lv_color_hex(0x16181E), 0);

    // ==================================================================
    // LEFT PANE (x = 0..113): Android Settings Sidebar
    // ==================================================================
    lv_obj_t *back_btn = ui_card(scr, 4, 3, 106, 22, AND_BG, AND_BG, 0, 5);
    ui_make_clickable(back_btn, AND_CARD_SEL, LV_OPA_COVER);
    ui_name(back_btn, "config_back_btn");
    ui_label(back_btn, LV_SYMBOL_LEFT, &lv_font_montserrat_14, UI_WHITE,
             4, 3, 16, LV_TEXT_ALIGN_LEFT);
    ui_label(back_btn, "Settings", &lv_font_montserrat_14, UI_WHITE,
             24, 3, 78, LV_TEXT_ALIGN_LEFT);
    ui_bubble_children(back_btn);
    lv_obj_add_event_cb(back_btn, back_clicked_cb, LV_EVENT_CLICKED, NULL);

    // Group 1 card in left sidebar (Connectivity & Environment: 3 rows)
    lv_obj_t *grp1 = ui_card(scr, 5, 28, 104, 90, AND_CARD, AND_CARD, 0, 8);
    lv_obj_set_style_clip_corner(grp1, true, 0);

    // Group 2 card in left sidebar (Device & System: 3 rows)
    lv_obj_t *grp2 = ui_card(scr, 5, 124, 104, 90, AND_CARD, AND_CARD, 0, 8);
    lv_obj_set_style_clip_corner(grp2, true, 0);

    static const struct {
        const char *title;
        const char *name;
        const char *icon;
        uint32_t badge_hex;
    } k_cats[CFG_CAT_COUNT] = {
        { "LoRa 433",  "cfg_tab_radio",   LV_SYMBOL_WIFI,       0x1D4ED8 },
        { "Weather",   "cfg_tab_weather", LV_SYMBOL_GPS,        0x0369A1 },
        { "AQI & Bar", "cfg_tab_bar",     LV_SYMBOL_EYE_OPEN,   0x047857 },
        { "Display",   "cfg_tab_display", LV_SYMBOL_IMAGE,      0xB45309 },
        { "Sound",     "cfg_tab_alerts",  LV_SYMBOL_VOLUME_MAX, 0x15803D },
        { "System",    "cfg_tab_system",  LV_SYMBOL_SETTINGS,   0x6D28D9 },
    };

    for (int i = 0; i < CFG_CAT_COUNT; i++) {
        lv_obj_t *parent_grp = (i < 3) ? grp1 : grp2;
        int local_i = i % 3;
        int32_t ry = local_i * 30;

        lv_obj_t *row = ui_card(parent_grp, 0, ry, 104, 30, AND_CARD, AND_CARD, 0, 6);
        ui_make_clickable(row, AND_CARD_SEL, LV_OPA_COVER);
        ui_name(row, k_cats[i].name);

        lv_color_t bc = lv_color_hex(k_cats[i].badge_hex);
        lv_obj_t *badge = ui_card(row, 6, 6, 18, 18, bc, bc, 0, 5);
        ui_label(badge, k_cats[i].icon, &lv_font_montserrat_12, UI_WHITE,
                 0, 2, 18, LV_TEXT_ALIGN_CENTER);

        lv_obj_t *lbl = ui_label(row, k_cats[i].title, &lv_font_montserrat_12,
                                 UI_WHITE, 29, 8, 72, LV_TEXT_ALIGN_LEFT);

        ui_bubble_children(row);
        lv_obj_add_event_cb(row, cat_clicked_cb, LV_EVENT_CLICKED, (void *)(intptr_t)i);

        s_cat_rows[i] = row;
        s_cat_lbls[i] = lbl;
    }

    // ==================================================================
    // RIGHT PANE (x = 115..319): Selected Category Detail Pane
    // ==================================================================
    s_right_title = ui_label(scr, "LoRa 433MHz", &lv_font_montserrat_14, UI_WHITE,
                             122, 6, 190, LV_TEXT_ALIGN_CENTER);
    ui_name(s_right_title, "config_pane_title");

    // Top primary toggle card (Row 0, h = 42)
    lv_obj_t *top_card = ui_card(scr, 120, 28, 194, 42, AND_CARD, AND_CARD, 0, 9);
    ui_make_clickable(top_card, AND_CARD_SEL, LV_OPA_COVER);
    ui_name(top_card, "cfg_row_0");

    s_r_titles[0] = ui_label(top_card, "", &lv_font_montserrat_12, UI_WHITE,
                             10, 4, 134, LV_TEXT_ALIGN_LEFT);
    s_r_subs[0] = ui_label(top_card, "", &lv_font_montserrat_12, AND_SUB,
                           10, 20, 134, LV_TEXT_ALIGN_LEFT);
    s_r_vals[0] = ui_label(top_card, "", &lv_font_montserrat_12, AND_SUB,
                           118, 13, 68, LV_TEXT_ALIGN_RIGHT);

    s_r_dd_boxes[0] = ui_card(top_card, 102, 9, 84, 24, AND_DD_BG, AND_DD_BDR, 1, 5);
    s_r_dd_lbls[0] = ui_label(s_r_dd_boxes[0], "", &lv_font_montserrat_12, UI_WHITE,
                              0, 3, 82, LV_TEXT_ALIGN_CENTER);

    s_r_sw_tracks[0] = ui_card(top_card, 152, 12, 33, 18, AND_BLUE, AND_BLUE, 0, 9);
    s_r_sw_knobs[0] = ui_card(s_r_sw_tracks[0], 17, 2, 14, 14, UI_WHITE, UI_WHITE, 0, 7);

    ui_bubble_children(top_card);
    lv_obj_add_event_cb(top_card, right_row_clicked_cb, LV_EVENT_CLICKED, (void *)(intptr_t)0);
    s_r_rows[0] = top_card;

    // Lower grouped settings card (Rows 1, 2, 3 inside one rounded card, h = 138)
    lv_obj_t *bot_card = ui_card(scr, 120, 76, 194, 138, AND_CARD, AND_CARD, 0, 9);
    lv_obj_set_style_clip_corner(bot_card, true, 0);

    static const char *const r_names[4] = {
        "cfg_row_0", "cfg_row_1", "cfg_row_2", "cfg_row_3"
    };

    // Row 1 (y = 0..50 inside bot_card, with subtitle)
    {
        lv_obj_t *r1 = ui_card(bot_card, 0, 0, 194, 50, AND_CARD, AND_CARD, 0, 0);
        ui_make_clickable(r1, AND_CARD_SEL, LV_OPA_COVER);
        ui_name(r1, r_names[1]);

        s_r_titles[1] = ui_label(r1, "", &lv_font_montserrat_12, UI_WHITE,
                                 10, 6, 126, LV_TEXT_ALIGN_LEFT);
        s_r_subs[1] = ui_label(r1, "", &lv_font_montserrat_12, AND_SUB,
                               10, 24, 126, LV_TEXT_ALIGN_LEFT);
        s_r_vals[1] = ui_label(r1, "", &lv_font_montserrat_12, AND_BLUE,
                               122, 16, 64, LV_TEXT_ALIGN_RIGHT);

        s_r_dd_boxes[1] = ui_card(r1, 102, 13, 84, 24, AND_DD_BG, AND_DD_BDR, 1, 5);
        s_r_dd_lbls[1] = ui_label(s_r_dd_boxes[1], "", &lv_font_montserrat_12, UI_WHITE,
                                  0, 3, 82, LV_TEXT_ALIGN_CENTER);

        s_r_sw_tracks[1] = ui_card(r1, 152, 16, 33, 18, AND_BLUE, AND_BLUE, 0, 9);
        s_r_sw_knobs[1] = ui_card(s_r_sw_tracks[1], 17, 2, 14, 14, UI_WHITE, UI_WHITE, 0, 7);

        ui_box(bot_card, 10, 50, 174, 1, AND_DIV, LV_OPA_COVER, AND_DIV, 0);
        ui_bubble_children(r1);
        lv_obj_add_event_cb(r1, right_row_clicked_cb, LV_EVENT_CLICKED, (void *)(intptr_t)1);
        s_r_rows[1] = r1;
    }

    // Rows 2 & 3 (y = 51..94 and y = 95..138 inside bot_card)
    for (int idx = 2; idx <= 3; idx++) {
        int32_t ry = 51 + (idx - 2) * 44;
        lv_obj_t *r = ui_card(bot_card, 0, ry, 194, 43, AND_CARD, AND_CARD, 0, 0);
        ui_make_clickable(r, AND_CARD_SEL, LV_OPA_COVER);
        ui_name(r, r_names[idx]);

        s_r_titles[idx] = ui_label(r, "", &lv_font_montserrat_12, UI_WHITE,
                                   10, 13, 92, LV_TEXT_ALIGN_LEFT);
        s_r_subs[idx] = ui_label(r, "", &lv_font_montserrat_12, AND_SUB,
                                 10, 24, 92, LV_TEXT_ALIGN_LEFT);
        lv_obj_set_hidden(s_r_subs[idx], true);

        s_r_vals[idx] = ui_label(r, "", &lv_font_montserrat_12, AND_SUB,
                                 100, 13, 86, LV_TEXT_ALIGN_RIGHT);

        // Bordered Dropdown box on the right ("17dBm SF7 v", "Chennai v", etc.)
        s_r_dd_boxes[idx] = ui_card(r, 96, 9, 90, 24, AND_DD_BG, AND_DD_BDR, 1, 5);
        s_r_dd_lbls[idx] = ui_label(s_r_dd_boxes[idx], "", &lv_font_montserrat_12, UI_WHITE,
                                    0, 3, 88, LV_TEXT_ALIGN_CENTER);

        s_r_sw_tracks[idx] = ui_card(r, 152, 12, 33, 18, AND_BLUE, AND_BLUE, 0, 9);
        s_r_sw_knobs[idx] = ui_card(s_r_sw_tracks[idx], 17, 2, 14, 14, UI_WHITE, UI_WHITE, 0, 7);

        if (idx == 2) {
            ui_box(bot_card, 10, 94, 174, 1, AND_DIV, LV_OPA_COVER, AND_DIV, 0);
        }

        ui_bubble_children(r);
        lv_obj_add_event_cb(r, right_row_clicked_cb, LV_EVENT_CLICKED, (void *)(intptr_t)idx);
        s_r_rows[idx] = r;
    }

    // ==================================================================
    // FLOATING DROPDOWN MENU OVERLAY (hidden until a dropdown row is tapped)
    // ==================================================================
    s_dd_backdrop = ui_box(scr, 0, 0, 320, 220, UI_BLACK, LV_OPA_50, UI_BLACK, 0);
    lv_obj_set_clickable(s_dd_backdrop, true);
    ui_name(s_dd_backdrop, "cfg_dd_backdrop");
    lv_obj_add_event_cb(s_dd_backdrop, dd_close_cb, LV_EVENT_CLICKED, NULL);

    s_dd_panel = ui_card(scr, 118, 28, 196, 188, AND_POPUP_BG, AND_POPUP_BDR, 1, 9);
    ui_name(s_dd_panel, "cfg_dd_menu");

    s_dd_title = ui_label(s_dd_panel, "Select Option", &lv_font_montserrat_12,
                          UI_CYAN, 10, 6, 154, LV_TEXT_ALIGN_LEFT);
    ui_label(s_dd_panel, LV_SYMBOL_CLOSE, &lv_font_montserrat_12, UI_MUTED,
             168, 6, 18, LV_TEXT_ALIGN_CENTER);
    ui_box(s_dd_panel, 8, 24, 178, 1, AND_DIV, LV_OPA_COVER, AND_DIV, 0);

    static const char *const opt_names[DD_MAX_OPTS] = {
        "cfg_opt_0", "cfg_opt_1", "cfg_opt_2", "cfg_opt_3", "cfg_opt_4", "cfg_opt_5"
    };

    for (int i = 0; i < DD_MAX_OPTS; i++) {
        int32_t oy = 27 + i * 26;
        lv_obj_t *opt = ui_card(s_dd_panel, 5, oy, 184, 24,
                                AND_POPUP_BG, AND_POPUP_BG, 0, 5);
        ui_make_clickable(opt, AND_OPT_SEL, LV_OPA_COVER);
        ui_name(opt, opt_names[i]);

        s_dd_opt_lbls[i] = ui_label(opt, "", &lv_font_montserrat_12, UI_WHITE,
                                    8, 4, 152, LV_TEXT_ALIGN_LEFT);
        s_dd_opt_chks[i] = ui_label(opt, LV_SYMBOL_OK, &lv_font_montserrat_12, UI_CYAN,
                                    162, 4, 16, LV_TEXT_ALIGN_CENTER);

        ui_bubble_children(opt);
        lv_obj_add_event_cb(opt, dd_opt_clicked_cb, LV_EVENT_CLICKED, (void *)(intptr_t)i);
        s_dd_opts[i] = opt;
    }

    ui_config_refresh_live();
}
