// Unified V4 Card UI layer for the SOS Emergency Transmitter.
// Pure LVGL 9.6: the same files compile in the headless simulator, the live
// display daemon, and on the ESP32-S3 firmware.

#ifndef SOS_UI_COMMON_H
#define SOS_UI_COMMON_H

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SERVICE_AMBULANCE = 0,
    SERVICE_FIRE_ENGINE,
    SERVICE_POLICE,
    SERVICE_EMERGENCY,
    SERVICE_COUNT
} service_id_t;

typedef struct {
    const char *name;          // "Ambulance"
    const char *code;          // "AMB"
    const char *prio_tag;      // "PRI-1"
    const char *cat_tag;       // "MED"
    const char *cta_text;      // "DISPATCH AMBULANCE"
    lv_color_t color;          // Primary gradient top
    lv_color_t color_dark;     // Primary gradient bottom
    lv_color_t border_color;   // 1px highlight border
    lv_color_t dot_color;      // Active page dot colour
    const lv_image_dsc_t *art; // 294x98 full-colour hero art
} service_info_t;

// Live Environment (OpenWeatherMap Weather + AQI) & LoRa Link State
typedef struct {
    int16_t temp_c;            // Temperature in °C (e.g. 29)
    uint8_t humidity;          // Relative humidity % (e.g. 62)
    uint16_t aqi;              // Air Quality Index 0..500 (e.g. 42)
    char condition[16];        // Short condition ("CLEAR", "CLOUDS", "RAIN")
    char city[16];             // City name ("Chennai", "Bengaluru", etc.)
    bool weather_synced;       // true once OpenWeatherMap data is fetched
    bool wifi_connected;       // true when WiFi station is connected
    bool lora_ok;              // true when SX1278 RegVersion (0x42) == 0x12
    uint32_t lora_tx_count;    // Total LoRa packets transmitted
} ui_status_t;

// User-tweakable Settings (Android Settings page model)
typedef struct {
    uint8_t node_id;           // 1..4 (Node 01 .. Node 04)
    uint8_t lora_tx_dbm;       // 11, 14, 17, 20 dBm
    uint8_t lora_sf;           // 7..10 (SF7..SF10)
    bool wifi_enabled;         // Enable WiFi + OpenWeatherMap sync
    uint8_t city_index;        // 0=Chennai, 1=Bengaluru, 2=Mumbai, 3=Delhi, 4=London, 5=Custom
    char custom_city[20];      // User-typed custom city name (e.g. "Coimbatore")
    bool temp_fahrenheit;      // false = °C, true = °F
    uint8_t owm_interval_min;  // 5, 15, 30, or 0 (Manual)
    bool buzzer_enabled;       // GPIO 18 buzzer ON / MUTE
    bool led_enabled;          // ESP32-S3 WS2812 RGB LED (GPIO 48) ON / OFF
    uint8_t rgb_mode;          // 0=Auto Service, 1=Police R/B, 2=Red, 3=Cyan, 4=Green, 5=Amber
    uint8_t call_duration_s;   // Fixed 5 seconds SOS duration
    uint8_t brightness_pct;    // 25, 50, 75, 100 %
    bool show_bottom_bar;      // Show/hide bottom Weather + AQI + LoRa strip
} ui_settings_t;

// Official LVGL 9.6 event-driven UI callbacks registered by the firmware.
typedef struct {
    void (*on_service_change)(service_id_t svc);
    void (*on_dispatch)(service_id_t svc);
    void (*on_cancel_request)(void);
    void (*on_open_config)(void);
    void (*on_close_config)(void);
    void (*on_open_slideshow)(void);
    void (*on_exit_slideshow)(void);
    void (*on_calibrate)(void);
    void (*on_settings_change)(const ui_settings_t *settings);
    void (*on_lora_ping)(void);
    void (*on_lora_reinit)(void);
    void (*on_weather_sync)(void);
    void (*on_test_io)(void);
} ui_callbacks_t;

extern const service_info_t ui_services[SERVICE_COUNT];
extern const lv_image_dsc_t ui_icon_phone_14;
extern const lv_image_dsc_t ui_icon_phone_22;

// ---------------------------------------------------------------------------
// V4 Obsidian / Linear Dark Palette
// ---------------------------------------------------------------------------
#define UI_BG        lv_color_hex(0x0E1015)
#define UI_BG_2      lv_color_hex(0x0E1015)
#define UI_TOPBAR    lv_color_hex(0x141821)
#define UI_PANEL     lv_color_hex(0x12141B)
#define UI_PANEL_2   lv_color_hex(0x1B1F28)
#define UI_PILL_BG   lv_color_hex(0x252A36)
#define UI_PILL_BDR  lv_color_hex(0x323948)
#define UI_GRID      lv_color_hex(0x161922)
#define UI_LINE      lv_color_hex(0x262B36)
#define UI_TEXT      lv_color_hex(0xF3F4F6)
#define UI_MUTED     lv_color_hex(0x9CA3AF)
#define UI_DIM       lv_color_hex(0x6B7280)
#define UI_CYAN      lv_color_hex(0x38BDF8)
#define UI_GREEN     lv_color_hex(0x10B981)
#define UI_AMBER     lv_color_hex(0xF59E0B)
#define UI_RED       lv_color_hex(0xEF4444)
#define UI_MAGENTA   lv_color_hex(0xA855F7)
#define UI_BLUE      lv_color_hex(0x3B82F6)
#define UI_WHITE     lv_color_hex(0xFFFFFF)
#define UI_BLACK     lv_color_hex(0x000000)

// ---------------------------------------------------------------------------
// Screen & Callback API
// ---------------------------------------------------------------------------
void ui_init(void);
void ui_set_callbacks(const ui_callbacks_t *cbs);
const ui_callbacks_t *ui_get_callbacks(void);

void ui_show_boot(void);
void ui_boot_set_progress(uint8_t percent, const char *status);
void ui_show_home(void);
void ui_show_slide(service_id_t svc);
void ui_show_service(service_id_t svc);
void ui_show_config(void);
void ui_show_calling(service_id_t svc);
void ui_show_slideshow(uint8_t slide);

// Update the displayed service slide on the home screen.
void ui_home_set_selected(service_id_t svc);
service_id_t ui_home_get_selected(void);

// Live Weather/AQI/LoRa status & Android Settings API.
void ui_set_status(const ui_status_t *status);
const ui_status_t *ui_get_status(void);
void ui_update_weather(int16_t temp_c, uint8_t humidity, uint16_t aqi,
                       const char *condition, const char *city, bool synced);
void ui_update_lora_status(bool lora_ok, uint32_t tx_count);
void ui_update_wifi_status(bool connected);

void ui_set_settings(const ui_settings_t *settings);
const ui_settings_t *ui_get_settings(void);
void ui_settings_defaults(ui_settings_t *out);
const char *ui_city_name(uint8_t city_index);

// Legacy telemetry hooks (kept compatible for callers).
void ui_update_pressure(uint16_t z);
void ui_update_uptime(uint32_t seconds);
void ui_telemetry_set_visible(bool visible);

uint16_t ui_pressure_get(void);
uint32_t ui_uptime_get(void);

// 0..100 while the user holds the slideshow; 0 hides the progress line.
void ui_slideshow_hold_progress(uint8_t percent);

// ---------------------------------------------------------------------------
// Shared V4 UI primitives
// ---------------------------------------------------------------------------
lv_obj_t *ui_screen_begin(lv_color_t top, lv_color_t bottom);
lv_obj_t *ui_top_bar(lv_obj_t *parent, const char *status_text, lv_color_t dot_color);

void ui_make_clickable(lv_obj_t *obj, lv_color_t pressed_bg, lv_opa_t pressed_opa);
void ui_bubble_children(lv_obj_t *parent);

void ui_animate_in(lv_obj_t *obj, int dir);
void ui_animate_slide_x(lv_obj_t *obj, int32_t from_x, int32_t to_x, uint32_t ms);

lv_obj_t *ui_box(lv_obj_t *parent, int32_t x, int32_t y, int32_t w, int32_t h,
                 lv_color_t bg, lv_opa_t bg_opa, lv_color_t border, int32_t border_w);
lv_obj_t *ui_card(lv_obj_t *parent, int32_t x, int32_t y, int32_t w, int32_t h,
                  lv_color_t bg, lv_color_t border, int32_t border_w, int32_t radius);
lv_obj_t *ui_label(lv_obj_t *parent, const char *text, const lv_font_t *font,
                   lv_color_t color, int32_t x, int32_t y, int32_t w,
                   lv_text_align_t align);

lv_obj_t *ui_panel(lv_obj_t *parent, int32_t x, int32_t y, int32_t w, int32_t h,
                   lv_color_t accent);
void ui_corner_brackets(lv_obj_t *parent, lv_color_t c);
void ui_hud_grid(lv_obj_t *parent, lv_color_t color);

void ui_set_gradient(lv_obj_t *obj, lv_color_t top, lv_color_t bottom);
void ui_set_glow(lv_obj_t *obj, lv_color_t color, int32_t width, lv_opa_t opa);
void ui_clear_glow(lv_obj_t *obj);
void ui_name(lv_obj_t *obj, const char *name);

#ifdef __cplusplus
}
#endif

#endif
