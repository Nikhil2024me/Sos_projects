// Headless-simulator entry points (V4 UI + official LVGL 9.6 event callbacks).
// The ESP32 firmware uses the same UI files; these wrappers choose which
// screen to build and wire the UI callbacks for interactive simulator tests.

#include "src/ui/ui_common.h"

static service_id_t sim_current_svc = SERVICE_AMBULANCE;

static uint32_t sim_tx_cnt = 0;

static void sim_on_svc(service_id_t svc)      { sim_current_svc = svc; }
static void sim_on_dispatch(service_id_t svc) { sim_current_svc = svc; sim_tx_cnt++; ui_update_lora_status(true, sim_tx_cnt); ui_show_calling(svc); }
static void sim_on_cancel(void)               { ui_show_home(); ui_home_set_selected(sim_current_svc); }
static void sim_on_open_cfg(void)             { ui_show_config(); }
static void sim_on_close_cfg(void)            { ui_show_home(); ui_home_set_selected(sim_current_svc); }
static void sim_on_open_demo(void)            { ui_show_slideshow((uint8_t)sim_current_svc); }
static void sim_on_exit_demo(void)            { ui_show_home(); ui_home_set_selected(sim_current_svc); }
static void sim_on_ping(void)                 { sim_tx_cnt++; ui_update_lora_status(true, sim_tx_cnt); }
static void sim_on_reinit(void)               { ui_update_lora_status(true, sim_tx_cnt); }
static void sim_on_sync(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    static const int16_t k_temps[6] = { 29, 24, 31, 27, 16, 30 };
    static const uint8_t k_hums[6]  = { 62, 54, 72, 45, 68, 58 };
    static const uint16_t k_aqis[6] = { 42, 38, 64, 118, 28, 35 };
    static const char *const k_cond[6] = { "CLEAR", "CLOUDS", "HUMID", "HAZE", "MIST", "CLEAR" };
    uint8_t idx = (cfg && cfg->city_index < 6) ? cfg->city_index : 0;
    ui_update_weather(k_temps[idx], k_hums[idx], k_aqis[idx], k_cond[idx], ui_city_name(idx), true);
}

static const ui_callbacks_t sim_cbs = {
    .on_service_change  = sim_on_svc,
    .on_dispatch        = sim_on_dispatch,
    .on_cancel_request  = sim_on_cancel,
    .on_open_config     = sim_on_open_cfg,
    .on_close_config    = sim_on_close_cfg,
    .on_open_slideshow  = sim_on_open_demo,
    .on_exit_slideshow  = sim_on_exit_demo,
    .on_calibrate       = sim_on_close_cfg,
    .on_lora_ping       = sim_on_ping,
    .on_lora_reinit     = sim_on_reinit,
    .on_weather_sync    = sim_on_sync,
};

static void sim_setup(void)
{
    ui_set_callbacks(&sim_cbs);
    ui_init();
}

void sim_boot(void)
{
    sim_setup();
    ui_show_boot();
}

void sim_home(void)
{
    sim_setup();
    sim_current_svc = SERVICE_AMBULANCE;
    ui_show_home();
    ui_home_set_selected(SERVICE_AMBULANCE);
    ui_update_uptime(42);
    ui_update_pressure(0);
}

void sim_home_fire(void)
{
    sim_setup();
    sim_current_svc = SERVICE_FIRE_ENGINE;
    ui_show_home();
    ui_home_set_selected(SERVICE_FIRE_ENGINE);
}

void sim_home_police(void)
{
    sim_setup();
    sim_current_svc = SERVICE_POLICE;
    ui_show_home();
    ui_home_set_selected(SERVICE_POLICE);
}

void sim_home_emergency(void)
{
    sim_setup();
    sim_current_svc = SERVICE_EMERGENCY;
    ui_show_home();
    ui_home_set_selected(SERVICE_EMERGENCY);
}

void sim_service_ambulance(void)
{
    sim_setup();
    ui_show_service(SERVICE_AMBULANCE);
}

void sim_service_fire(void)
{
    sim_setup();
    ui_show_service(SERVICE_FIRE_ENGINE);
}

void sim_service_police(void)
{
    sim_setup();
    ui_show_service(SERVICE_POLICE);
}

void sim_service_emergency(void)
{
    sim_setup();
    ui_show_service(SERVICE_EMERGENCY);
}

void sim_config(void)
{
    sim_setup();
    ui_update_pressure(500);
    ui_update_uptime(42);
    ui_show_config();
}

void sim_calling_ambulance(void)
{
    sim_setup();
    ui_show_calling(SERVICE_AMBULANCE);
}

void sim_calling_fire(void)
{
    sim_setup();
    ui_show_calling(SERVICE_FIRE_ENGINE);
}

void sim_calling_police(void)
{
    sim_setup();
    ui_show_calling(SERVICE_POLICE);
}

void sim_calling_emergency(void)
{
    sim_setup();
    ui_show_calling(SERVICE_EMERGENCY);
}

void sim_slideshow_1(void)
{
    sim_setup();
    ui_show_slideshow(0);
}

void sim_slideshow_2(void)
{
    sim_setup();
    ui_show_slideshow(1);
}

void sim_slideshow_3(void)
{
    sim_setup();
    ui_show_slideshow(2);
}

void sim_slideshow_4(void)
{
    sim_setup();
    ui_show_slideshow(3);
}

void sim_slideshow_hold(void)
{
    sim_setup();
    ui_show_slideshow(0);
    ui_slideshow_hold_progress(60);
}
