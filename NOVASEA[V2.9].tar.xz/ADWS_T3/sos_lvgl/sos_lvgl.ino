// SOS Emergency Transmitter — V4 Unified Card UI
// ESP32-S3-WROOM-1 N16R8 + ILI9341 320x240 + XPT2046 + SX1278
//
// LVGL 9.6 UI, partial render mode, 320x40 RGB565 draw buffer (25,600 bytes).
// Touch uses TFT_eSPI's stock XPT2046 getTouch() + calibrateTouch() wired into
// an official LVGL 9.6 LV_INDEV_TYPE_POINTER input device.

#include <Arduino.h>
#include <Preferences.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
#include <HTTPClient.h>

#include "lvgl.h"
#include "src/ui/ui_common.h"
#include "config/weather_config.h"

// ---------------------------------------------------------------------------
// Board pin map (ESP32-S3-WROOM-1 N16R8)
// ---------------------------------------------------------------------------
// TFT + XPT2046 (FSPI / SPI2) are configured in TFT_eSPI User_Setup.h:
//   SCLK 12  MOSI 11  MISO 13  CS 10  DC 7  RST 6  BL 21
//   TOUCH_CS 15  TOUCH_IRQ 16
#define PIN_BUTTON        1
#define PIN_NOTIFICATION  17
#define PIN_BUZZER        18

// SX1278 (HSPI / SPI3), standby only in this build.
// Avoid GPIO 6 (TFT_RST) and GPIO 7 (TFT_DC)!
#define LORA_SCK          5
#define LORA_MISO         14
#define LORA_MOSI         9
#define LORA_NSS          4
#define LORA_RST          8
#define LORA_DIO0         2

// ---------------------------------------------------------------------------
// Timing & Touch Constants
// ---------------------------------------------------------------------------
static const uint32_t LONG_PRESS_MS       = 2000;
static const uint32_t SHORT_PRESS_MIN_MS  = 30;
static const uint32_t BUZZER_TOGGLE_MS    = 500;
static const uint32_t CALL_DURATION_MS    = 5000;
static const uint32_t PRESSURE_UPDATE_MS  = 250;
static const uint32_t UPTIME_UPDATE_MS    = 1000;
static const uint16_t TOUCH_Z_THRESHOLD   = 600;

// ---------------------------------------------------------------------------
// Display, Touch & NVS
// ---------------------------------------------------------------------------
TFT_eSPI tft = TFT_eSPI();
static Preferences prefs;
static lv_display_t *disp = NULL;
static lv_indev_t *touch_indev = NULL;
static uint8_t draw_buf[320 * 40 * 2] __attribute__((aligned(4)));

static uint16_t touch_cal[5] = {450, 3432, 370, 3379, 3};
static bool touch_was_pressed = false;

// ---------------------------------------------------------------------------
// App state
// ---------------------------------------------------------------------------
enum app_state_t {
    APP_BOOT = 0,
    APP_MAIN,
    APP_SERVICE,
    APP_CONFIG,
    APP_CALLING,
    APP_SLIDESHOW,
};

static app_state_t state = APP_BOOT;
static service_id_t current_service = SERVICE_AMBULANCE;

static uint32_t boot_ms = 0;
static uint32_t last_pressure_ms = 0;
static uint32_t last_uptime_ms = 0;

static bool call_active = false;
static uint32_t call_start_ms = 0;
static bool buzzer_on = false;
static uint32_t buzzer_toggle_ms = 0;

// Physical button state (starts false so boot cannot fire a false release).
static bool button_was_down = false;
static bool button_long_fired = false;
static uint32_t button_press_ms = 0;

static SPIClass loraSPI(HSPI);

// ---------------------------------------------------------------------------
// LVGL tick & display flush
// ---------------------------------------------------------------------------
static uint32_t lv_tick_cb(void)
{
    return (uint32_t)millis();
}

static void flush_cb(lv_display_t *d, const lv_area_t *area, uint8_t *px_map)
{
    const int32_t w = lv_area_get_width(area);
    const int32_t h = lv_area_get_height(area);
    if (w > 0 && h > 0) {
        tft.startWrite();
        tft.setAddrWindow(area->x1, area->y1, w, h);
        tft.pushColors((uint16_t *)px_map, (uint32_t)w * (uint32_t)h, true);
        tft.endWrite();
    }
    lv_display_flush_ready(d);
}

// ---------------------------------------------------------------------------
// Official LVGL 9.6 Pointer Input Device + Stock TFT_eSPI Touch Calibration
// ---------------------------------------------------------------------------
static bool load_cal_from_ns(const char *ns)
{
    if (!prefs.begin(ns, true)) return false;
    bool ok = prefs.getBool("tc_ok", false);
    uint16_t tmp[5] = {0};
    if (ok) {
        for (int i = 0; i < 5; i++) {
            char key[5] = {'t', 'c', (char)('0' + i), '\0', '\0'};
            tmp[i] = prefs.getUShort(key, 0);
        }
        if (tmp[0] == 0 || tmp[1] == 0 || tmp[2] == 0 || tmp[3] == 0) {
            ok = false;
        }
    }
    prefs.end();
    if (ok) {
        memcpy(touch_cal, tmp, sizeof(touch_cal));
    }
    return ok;
}

static void touch_load_calibration(void)
{
    if (load_cal_from_ns("sos_ui") || load_cal_from_ns("weather")) {
        Serial.printf("TOUCH CAL (NVS): {%u, %u, %u, %u, %u}\n",
                      touch_cal[0], touch_cal[1], touch_cal[2],
                      touch_cal[3], touch_cal[4]);
    } else {
        Serial.printf("TOUCH CAL (default): {%u, %u, %u, %u, %u}\n",
                      touch_cal[0], touch_cal[1], touch_cal[2],
                      touch_cal[3], touch_cal[4]);
    }
    tft.setTouch(touch_cal);
}

static void touch_save_calibration(void)
{
    if (!prefs.begin("sos_ui", false)) return;
    prefs.putBool("tc_ok", true);
    for (int i = 0; i < 5; i++) {
        char key[5] = {'t', 'c', (char)('0' + i), '\0', '\0'};
        prefs.putUShort(key, touch_cal[i]);
    }
    prefs.end();
}

static void run_touch_calibration(void)
{
    Serial.println("TOUCH: starting 4-corner calibration...");
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(20, 8);
    tft.println("Touch corners as indicated");

    uint16_t cal[5];
    tft.calibrateTouch(cal, TFT_MAGENTA, TFT_BLACK, 15);
    memcpy(touch_cal, cal, sizeof(touch_cal));
    tft.setTouch(touch_cal);
    touch_save_calibration();

    Serial.printf("TOUCH CAL SAVED: {%u, %u, %u, %u, %u}\n",
                  touch_cal[0], touch_cal[1], touch_cal[2],
                  touch_cal[3], touch_cal[4]);

    tft.fillScreen(TFT_BLACK);
    if (disp != NULL) {
        lv_obj_invalidate(lv_screen_active());
    }
}

static void touch_read_cb(lv_indev_t *indev, lv_indev_data_t *data)
{
    (void)indev;
    if (state == APP_BOOT) {
        data->state = LV_INDEV_STATE_RELEASED;
        return;
    }

    static uint32_t last_valid_press_ms = 0;
    static int32_t last_x = 0;
    static int32_t last_y = 0;

    uint16_t x = 0, y = 0;
    bool raw_pressed = (tft.getTouch(&x, &y, TOUCH_Z_THRESHOLD) != 0);
    const uint32_t now = millis();

    if (raw_pressed) {
        last_valid_press_ms = now;
        last_x = (int32_t)x;
        last_y = (int32_t)y;
    }

    // Hold pressed state for 90 ms across brief resistive membrane dropouts
    // so a single finger press never splits into two separate click events.
    const bool pressed = raw_pressed || (touch_was_pressed && (now - last_valid_press_ms < 90));

    if (pressed) {
        data->point.x = last_x;
        data->point.y = last_y;
        data->state   = LV_INDEV_STATE_PRESSED;
    } else {
        data->state   = LV_INDEV_STATE_RELEASED;
    }

    if (pressed != touch_was_pressed) {
        if (pressed) {
            uint16_t z = tft.getTouchRawZ();
            ui_update_pressure(z);
            Serial.printf("TOUCH: %ld,%ld (z=%u)\n", (long)last_x, (long)last_y, (unsigned)z);
        } else {
            ui_update_pressure(0);
            Serial.println("TOUCH: release");
        }
        touch_was_pressed = pressed;
    }
}

// ---------------------------------------------------------------------------
// SX1278 433 MHz (433E6) LoRa init & packet transmitter
// ---------------------------------------------------------------------------
static bool lora_ok = false;
static uint32_t lora_seq = 0;

static void lora_write(uint8_t reg, uint8_t value)
{
    digitalWrite(LORA_NSS, LOW);
    loraSPI.transfer(reg | 0x80);
    loraSPI.transfer(value);
    digitalWrite(LORA_NSS, HIGH);
}

static uint8_t lora_read(uint8_t reg)
{
    digitalWrite(LORA_NSS, LOW);
    loraSPI.transfer(reg & 0x7F);
    uint8_t value = loraSPI.transfer(0x00);
    digitalWrite(LORA_NSS, HIGH);
    return value;
}

static void lora_apply_rf_config(void)
{
    if (!lora_ok) return;
    const ui_settings_t *cfg = ui_get_settings();
    uint8_t dbm = cfg ? cfg->lora_tx_dbm : 17;
    uint8_t sf  = cfg ? cfg->lora_sf : 7;
    if (sf < 7) sf = 7;
    if (sf > 10) sf = 10;

    loraSPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
    lora_write(0x01, 0x81); // Standby
    if (dbm >= 20) {
        lora_write(0x4D, 0x87); // RegPaDac: +20 dBm on PA_BOOST
        lora_write(0x0B, 0x32); // RegOcp: 150 mA
        lora_write(0x09, 0x8F);
    } else {
        lora_write(0x4D, 0x84); // RegPaDac: default
        lora_write(0x0B, 0x2B);
        uint8_t out_pwr = (dbm > 2) ? (uint8_t)(dbm - 2) : 15;
        if (out_pwr > 15) out_pwr = 15;
        lora_write(0x09, (uint8_t)(0x80 | out_pwr));
    }
    lora_write(0x1E, (uint8_t)((sf << 4) | 0x04)); // SF + CRC On
    loraSPI.endTransaction();
}

static void lora_init_433(void)
{
    pinMode(LORA_NSS, OUTPUT);
    digitalWrite(LORA_NSS, HIGH);
    pinMode(LORA_RST, OUTPUT);
    digitalWrite(LORA_RST, LOW);
    delay(10);
    digitalWrite(LORA_RST, HIGH);
    delay(10);
    pinMode(LORA_DIO0, INPUT);

    loraSPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_NSS);
    loraSPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));

    const uint8_t version = lora_read(0x42); // RegVersion
    lora_ok = (version == 0x12);
    if (lora_ok) {
        // 1. Sleep mode + LoRa Long Range bit (0x80)
        lora_write(0x01, 0x80);
        delay(5);
        // 2. Set frequency to 433.0 MHz (433E6 -> FRF = 0x6C4000)
        lora_write(0x06, 0x6C); // RegFrfMsb
        lora_write(0x07, 0x40); // RegFrfMid
        lora_write(0x08, 0x00); // RegFrfLsb
        // 3. FIFO base addresses
        lora_write(0x0E, 0x00); // RegFifoTxBaseAddr
        lora_write(0x0F, 0x00); // RegFifoRxBaseAddr
        // 4. LNA boost + Auto AGC + PA_BOOST 17 dBm
        lora_write(0x0C, lora_read(0x0C) | 0x03); // RegLna boost
        lora_write(0x26, 0x04); // RegModemConfig3: AgcAutoOn
        lora_write(0x4D, 0x84); // RegPaDac: default 17 dBm
        lora_write(0x0B, 0x2B); // RegOcp: 100 mA
        lora_write(0x09, 0x8F); // RegPaConfig: PA_BOOST, 17 dBm
        // 5. Modem config: BW 125 kHz, CR 4/5, Explicit Header, SF7, CRC On
        lora_write(0x1D, 0x72); // RegModemConfig1
        lora_write(0x1E, 0x74); // RegModemConfig2
        lora_write(0x31, 0xC3); // RegDetectionOptimize (SF7..12)
        lora_write(0x37, 0x0A); // RegDetectionThreshold (SF7..12)
        lora_write(0x20, 0x00); // RegPreambleMsb
        lora_write(0x21, 0x08); // RegPreambleLsb (8 symbols)
        lora_write(0x39, 0x12); // RegSyncWord (0x12 standard LoRa)
        // 6. Standby mode in LoRa
        lora_write(0x01, 0x81);
    }
    loraSPI.endTransaction();

    if (lora_ok) {
        lora_apply_rf_config();
    }
    ui_update_lora_status(lora_ok, lora_seq);

    Serial.printf("LoRa SX1278: version 0x%02X (%s @ 433.0 MHz)\n",
                  version, lora_ok ? "READY TX" : "not detected");
}

static bool lora_send_packet(const char *payload)
{
    if (!lora_ok || payload == NULL) {
        Serial.printf("LoRa TX skipped (radio not detected): %s\n",
                      payload ? payload : "");
        ui_update_lora_status(lora_ok, lora_seq);
        return false;
    }

    const size_t len = strlen(payload);
    if (len == 0 || len > 255) return false;

    loraSPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));

    // Enter LoRa Standby & clear IRQ flags
    lora_write(0x01, 0x81);
    lora_write(0x12, 0xFF);

    // Reset FIFO TX pointer and write payload bytes
    lora_write(0x0E, 0x00);
    lora_write(0x0D, 0x00);
    for (size_t i = 0; i < len; i++) {
        lora_write(0x00, (uint8_t)payload[i]);
    }
    lora_write(0x22, (uint8_t)len); // RegPayloadLength

    // Trigger LoRa TX (0x83 = LoRa + TX)
    lora_write(0x01, 0x83);

    // Poll RegIrqFlags (0x12) bit 3 (TxDone = 0x08) with 250 ms timeout
    const uint32_t t0 = millis();
    bool tx_done = false;
    while (millis() - t0 < 250) {
        if (lora_read(0x12) & 0x08) {
            tx_done = true;
            break;
        }
        delay(1);
    }

    // Clear IRQ flags and return to LoRa Standby
    lora_write(0x12, 0xFF);
    lora_write(0x01, 0x81);
    loraSPI.endTransaction();

    ui_update_lora_status(lora_ok, lora_seq);
    Serial.printf("LoRa TX @ 433E6 [%s, %u B]: %s\n",
                  tx_done ? "OK" : "TIMEOUT", (unsigned)len, payload);
    return tx_done;
}

// ---------------------------------------------------------------------------
// NVS Settings & OpenWeatherMap API (Weather + AQI)
// ---------------------------------------------------------------------------
static String nvs_wifi_ssid = ADWS_DEFAULT_WIFI_SSID;
static String nvs_wifi_pass = ADWS_DEFAULT_WIFI_PASS;
static String nvs_owm_key   = ADWS_DEFAULT_OWM_API_KEY;
static uint32_t last_owm_sync_ms = 0;

#define PIN_RGB_LED 48

static void s3_rgb_write(uint8_t r, uint8_t g, uint8_t b)
{
    rgbLedWrite(PIN_RGB_LED, r, g, b);
}

static void s3_rgb_apply_idle(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    if (cfg == NULL || !cfg->led_enabled) {
        s3_rgb_write(0, 0, 0);
        digitalWrite(PIN_NOTIFICATION, LOW);
        return;
    }
    switch (cfg->rgb_mode) {
    case 1:  s3_rgb_write(0, 4, 24);  break; // Police Strobe idle
    case 2:  s3_rgb_write(24, 0, 0);  break; // Crimson Alert
    case 3:  s3_rgb_write(0, 18, 28); break; // Cyber Cyan
    case 4:  s3_rgb_write(0, 24, 8);  break; // Emerald Green
    case 5:  s3_rgb_write(24, 14, 0); break; // Warm Amber
    default: s3_rgb_write(0, 14, 6);  break; // Auto (subtle standby green)
    }
}

static void s3_rgb_apply_alert(bool phase_a)
{
    const ui_settings_t *cfg = ui_get_settings();
    if (cfg == NULL || !cfg->led_enabled) {
        s3_rgb_write(0, 0, 0);
        digitalWrite(PIN_NOTIFICATION, LOW);
        return;
    }
    digitalWrite(PIN_NOTIFICATION, phase_a ? HIGH : LOW);
    if (cfg->rgb_mode == 1) {
        // Police Red / Blue alternating strobe
        if (phase_a) s3_rgb_write(255, 0, 0);
        else         s3_rgb_write(0, 40, 255);
        return;
    }
    if (!phase_a) {
        s3_rgb_write(0, 0, 0);
        return;
    }
    switch (cfg->rgb_mode) {
    case 2:  s3_rgb_write(255, 0, 0);   break;
    case 3:  s3_rgb_write(0, 190, 255); break;
    case 4:  s3_rgb_write(0, 230, 90);  break;
    case 5:  s3_rgb_write(255, 140, 0); break;
    default:
        // Auto (Service Color)
        if (current_service == SERVICE_AMBULANCE)        s3_rgb_write(255, 20, 40);
        else if (current_service == SERVICE_FIRE_ENGINE) s3_rgb_write(255, 110, 0);
        else if (current_service == SERVICE_POLICE)      s3_rgb_write(20, 90, 255);
        else                                             s3_rgb_write(0, 220, 130);
        break;
    }
}

static void apply_backlight_brightness(uint8_t pct)
{
#if defined(TFT_BL) && TFT_BL >= 0
    if (pct >= 100) {
        analogWrite(TFT_BL, 255);
    } else {
        uint32_t pwm = ((uint32_t)pct * 255u) / 100u;
        if (pwm < 24) pwm = 24;
        analogWrite(TFT_BL, pwm);
    }
#else
    (void)pct;
#endif
}

static void settings_load_nvs(void)
{
    ui_settings_t cfg;
    ui_settings_defaults(&cfg);
    if (prefs.begin("sos_ui", true)) {
        cfg.node_id          = prefs.getUChar("node_id", cfg.node_id);
        cfg.lora_tx_dbm      = prefs.getUChar("tx_dbm", cfg.lora_tx_dbm);
        cfg.lora_sf          = prefs.getUChar("lora_sf", cfg.lora_sf);
        cfg.wifi_enabled     = prefs.getBool("wifi_en", cfg.wifi_enabled);
        cfg.city_index       = prefs.getUChar("city_idx", cfg.city_index);
        cfg.temp_fahrenheit  = prefs.getBool("temp_f", cfg.temp_fahrenheit);
        cfg.owm_interval_min = prefs.getUChar("owm_int", cfg.owm_interval_min);
        cfg.buzzer_enabled   = prefs.getBool("buzz_en", cfg.buzzer_enabled);
        cfg.led_enabled      = prefs.getBool("led_en", cfg.led_enabled);
        cfg.rgb_mode         = prefs.getUChar("rgb_mode", cfg.rgb_mode);
        cfg.call_duration_s  = prefs.getUChar("call_dur", cfg.call_duration_s);
        cfg.brightness_pct   = prefs.getUChar("bright", cfg.brightness_pct);
        cfg.show_bottom_bar  = prefs.getBool("show_bar", cfg.show_bottom_bar);
        String s_city = prefs.getString("cust_city", "");
        if (s_city.length() > 0) {
            snprintf(cfg.custom_city, sizeof(cfg.custom_city), "%s", s_city.c_str());
        }
        String s_ssid = prefs.getString("wifi_ssid", "");
        String s_pass = prefs.getString("wifi_pass", "");
        String s_key  = prefs.getString("owm_key", "");
        if (s_ssid.length() > 0) nvs_wifi_ssid = s_ssid;
        if (s_pass.length() > 0) nvs_wifi_pass = s_pass;
        if (s_key.length() > 0)  nvs_owm_key   = s_key;
        prefs.end();
    }
    ui_set_settings(&cfg);
    apply_backlight_brightness(cfg.brightness_pct);
    s3_rgb_apply_idle();
}

static void settings_save_nvs(const ui_settings_t *cfg)
{
    if (cfg == NULL) return;
    if (prefs.begin("sos_ui", false)) {
        prefs.putUChar("node_id", cfg->node_id);
        prefs.putUChar("tx_dbm", cfg->lora_tx_dbm);
        prefs.putUChar("lora_sf", cfg->lora_sf);
        prefs.putBool("wifi_en", cfg->wifi_enabled);
        prefs.putUChar("city_idx", cfg->city_index);
        prefs.putString("cust_city", cfg->custom_city);
        prefs.putBool("temp_f", cfg->temp_fahrenheit);
        prefs.putUChar("owm_int", cfg->owm_interval_min);
        prefs.putBool("buzz_en", cfg->buzzer_enabled);
        prefs.putBool("led_en", cfg->led_enabled);
        prefs.putUChar("rgb_mode", cfg->rgb_mode);
        prefs.putUChar("call_dur", cfg->call_duration_s);
        prefs.putUChar("bright", cfg->brightness_pct);
        prefs.putBool("show_bar", cfg->show_bottom_bar);
        prefs.end();
    }
}

static bool json_extract_float(const String &body, const char *key, float *out)
{
    int idx = body.indexOf(key);
    if (idx < 0) return false;
    idx += (int)strlen(key);
    while (idx < (int)body.length() && (body[idx] == ' ' || body[idx] == ':')) idx++;
    *out = body.substring(idx).toFloat();
    return true;
}

static uint16_t pm25_to_aqi(float pm25)
{
    if (pm25 <= 12.0f) return (uint16_t)((50.0f / 12.0f) * pm25);
    if (pm25 <= 35.4f) return (uint16_t)(51.0f + ((49.0f / 23.4f) * (pm25 - 12.1f)));
    if (pm25 <= 55.4f) return (uint16_t)(101.0f + ((49.0f / 19.9f) * (pm25 - 35.5f)));
    if (pm25 <= 150.4f) return (uint16_t)(151.0f + ((49.0f / 94.9f) * (pm25 - 55.5f)));
    return 210;
}

static void owm_sync_weather(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    bool is_custom = (cfg && cfg->city_index == 5 && cfg->custom_city[0] != '\0');
    uint8_t cidx = (cfg && cfg->city_index < 5) ? cfg->city_index : 0;
    const adws_city_preset_t *city = &k_adws_cities[cidx];
    const char *active_name = is_custom ? cfg->custom_city : city->name;

    if (cfg && cfg->wifi_enabled && nvs_wifi_ssid.length() > 0 && nvs_owm_key.length() > 0) {
        if (WiFi.status() != WL_CONNECTED) {
            WiFi.mode(WIFI_STA);
            WiFi.begin(nvs_wifi_ssid.c_str(), nvs_wifi_pass.c_str());
            uint32_t t0 = millis();
            while (WiFi.status() != WL_CONNECTED && (millis() - t0 < 2500)) {
                lv_timer_handler();
                delay(20);
            }
        }
        if (WiFi.status() == WL_CONNECTED) {
            ui_update_wifi_status(true);
            HTTPClient http;
            char url[240];
            float q_lat = city->lat;
            float q_lon = city->lon;
            if (is_custom) {
                snprintf(url, sizeof(url),
                         "http://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric",
                         cfg->custom_city, nvs_owm_key.c_str());
            } else {
                snprintf(url, sizeof(url),
                         "http://api.openweathermap.org/data/2.5/weather?lat=%.4f&lon=%.4f&appid=%s&units=metric",
                         (double)q_lat, (double)q_lon, nvs_owm_key.c_str());
            }
            int16_t temp_c = city->fallback_temp_c;
            uint8_t hum = city->fallback_humidity;
            char cond[16];
            snprintf(cond, sizeof(cond), "%s", city->fallback_cond);

            if (http.begin(url)) {
                if (http.GET() == 200) {
                    String payload = http.getString();
                    float v = 0.0f;
                    if (json_extract_float(payload, "\"temp\"", &v)) temp_c = (int16_t)roundf(v);
                    if (json_extract_float(payload, "\"humidity\"", &v)) hum = (uint8_t)v;
                    if (json_extract_float(payload, "\"lat\"", &v)) q_lat = v;
                    if (json_extract_float(payload, "\"lon\"", &v)) q_lon = v;
                    int m_idx = payload.indexOf("\"main\":\"");
                    if (m_idx >= 0) {
                        m_idx += 8;
                        int end_idx = payload.indexOf('"', m_idx);
                        if (end_idx > m_idx) {
                            String c_str = payload.substring(m_idx, end_idx);
                            c_str.toUpperCase();
                            snprintf(cond, sizeof(cond), "%s", c_str.c_str());
                        }
                    }
                }
                http.end();
            }

            uint16_t aqi = city->fallback_aqi;
            snprintf(url, sizeof(url),
                     "http://api.openweathermap.org/data/2.5/air_pollution?lat=%.4f&lon=%.4f&appid=%s",
                     (double)q_lat, (double)q_lon, nvs_owm_key.c_str());
            if (http.begin(url)) {
                if (http.GET() == 200) {
                    String payload = http.getString();
                    float pm25 = -1.0f;
                    if (json_extract_float(payload, "\"pm2_5\"", &pm25) && pm25 >= 0.0f) {
                        aqi = pm25_to_aqi(pm25);
                    }
                }
                http.end();
            }

            ui_update_weather(temp_c, hum, aqi, cond, active_name, true);
            last_owm_sync_ms = millis();
            Serial.printf("OWM SYNC [%s]: %dC %s %u%% | AQI %u\n",
                          active_name, (int)temp_c, cond, (unsigned)hum, (unsigned)aqi);
            return;
        }
    }

    // Fallback to preset/custom city weather/AQI when WiFi or OWM key is not configured
    ui_update_weather(city->fallback_temp_c, city->fallback_humidity,
                      city->fallback_aqi, city->fallback_cond, active_name, true);
    last_owm_sync_ms = millis();
}

// ---------------------------------------------------------------------------
// Screen & State transitions (invoked by LVGL widget callbacks & button)
// ---------------------------------------------------------------------------
static void show_main(void)
{
    state = APP_MAIN;
    ui_show_home();
    ui_home_set_selected(current_service);
    ui_update_uptime((millis() - boot_ms) / 1000);
}

static void show_service(void)
{
    state = APP_SERVICE;
    ui_show_service(current_service);
}

static void show_config(void)
{
    state = APP_CONFIG;
    ui_show_config();
}

static void show_slideshow(void)
{
    state = APP_SLIDESHOW;
    ui_show_slideshow((uint8_t)current_service);
}

static void end_call(bool return_to_service)
{
    call_active = false;
    digitalWrite(PIN_NOTIFICATION, LOW);
    digitalWrite(PIN_BUZZER, LOW);
    buzzer_on = false;
    s3_rgb_apply_idle();
    if (return_to_service) {
        show_main();
    }
}

static void start_call(void)
{
    if (call_active) end_call(false);
    const ui_settings_t *cfg = ui_get_settings();
    call_active = true;
    call_start_ms = millis();
    buzzer_toggle_ms = millis();
    buzzer_on = cfg ? cfg->buzzer_enabled : true;
    digitalWrite(PIN_NOTIFICATION, (cfg == NULL || cfg->led_enabled) ? HIGH : LOW);
    digitalWrite(PIN_BUZZER, buzzer_on ? HIGH : LOW);
    s3_rgb_apply_alert(true);
    state = APP_CALLING;
    ui_show_calling(current_service);

    // Transmit LoRa SOS request packet @ 433.0 MHz (433E6)
    lora_seq++;
    const service_info_t *s = &ui_services[current_service];
    uint8_t nid = cfg ? cfg->node_id : 1;
    char pkt[96];
    snprintf(pkt, sizeof(pkt), "ADWS|NODE:%02u|REQ:%s|SERVICE:%s|PRI:%s|SEQ:%lu",
             (unsigned)nid, s->code, s->name, s->prio_tag, (unsigned long)lora_seq);
    lora_send_packet(pkt);
}

static void open_config(void)
{
    if (call_active) end_call(false);
    ui_slideshow_hold_progress(0);
    show_config();
}

// ---------------------------------------------------------------------------
// UI Event Callback Handlers
// ---------------------------------------------------------------------------
static void on_ui_service_change(service_id_t svc)
{
    current_service = svc;
}

static void on_ui_dispatch(service_id_t svc)
{
    current_service = svc;
    start_call();
}

static void on_ui_cancel_request(void)
{
    // Ignore any residual touch bounce within the first 800 ms of starting a request.
    if (call_active && (millis() - call_start_ms < 800)) {
        return;
    }
    const ui_settings_t *cfg = ui_get_settings();
    uint8_t nid = cfg ? cfg->node_id : 1;
    const service_info_t *s = &ui_services[current_service];
    char pkt[80];
    snprintf(pkt, sizeof(pkt), "ADWS|NODE:%02u|CANCEL:%s|SEQ:%lu",
             (unsigned)nid, s->code, (unsigned long)lora_seq);
    lora_send_packet(pkt);
    end_call(true);
}

static void on_ui_open_config(void)
{
    open_config();
}

static void on_ui_close_config(void)
{
    show_main();
}

static void on_ui_open_slideshow(void)
{
    show_slideshow();
}

static void on_ui_exit_slideshow(void)
{
    show_main();
}

static void on_ui_calibrate(void)
{
    run_touch_calibration();
    show_config();
}

static void on_ui_settings_change(const ui_settings_t *cfg)
{
    if (cfg == NULL) return;
    settings_save_nvs(cfg);
    apply_backlight_brightness(cfg->brightness_pct);
    lora_apply_rf_config();
    if (!call_active) s3_rgb_apply_idle();
}

static void on_ui_lora_ping(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    uint8_t nid = cfg ? cfg->node_id : 1;
    lora_seq++;
    char pkt[80];
    snprintf(pkt, sizeof(pkt), "ADWS|NODE:%02u|PING|SEQ:%lu",
             (unsigned)nid, (unsigned long)lora_seq);
    lora_send_packet(pkt);
}

static void on_ui_lora_reinit(void)
{
    lora_init_433();
}

static void on_ui_weather_sync(void)
{
    owm_sync_weather();
}

static void on_ui_test_io(void)
{
    s3_rgb_apply_alert(true);
    digitalWrite(PIN_BUZZER, HIGH);
    delay(120);
    digitalWrite(PIN_BUZZER, LOW);
    s3_rgb_apply_idle();
}

static const ui_callbacks_t app_ui_cbs = {
    .on_service_change  = on_ui_service_change,
    .on_dispatch        = on_ui_dispatch,
    .on_cancel_request  = on_ui_cancel_request,
    .on_open_config     = on_ui_open_config,
    .on_close_config    = on_ui_close_config,
    .on_open_slideshow  = on_ui_open_slideshow,
    .on_exit_slideshow  = on_ui_exit_slideshow,
    .on_calibrate       = on_ui_calibrate,
    .on_settings_change = on_ui_settings_change,
    .on_lora_ping       = on_ui_lora_ping,
    .on_lora_reinit     = on_ui_lora_reinit,
    .on_weather_sync    = on_ui_weather_sync,
    .on_test_io         = on_ui_test_io,
};

// ---------------------------------------------------------------------------
// Input: physical hardware button (GPIO 1)
// ---------------------------------------------------------------------------
static void handle_button(uint32_t now)
{
    const bool pressed = (digitalRead(PIN_BUTTON) == LOW);

    if (pressed && !button_was_down) {
        button_press_ms = now;
        button_long_fired = false;
    }

    if (pressed && !button_long_fired && (now - button_press_ms >= LONG_PRESS_MS)) {
        button_long_fired = true;
        open_config();
    }

    if (!pressed && button_was_down) {
        const uint32_t held = now - button_press_ms;
        if (!button_long_fired && held >= SHORT_PRESS_MIN_MS) {
            if (state == APP_MAIN || state == APP_SERVICE) {
                start_call();
            } else if (state == APP_CALLING) {
                end_call(true);
            }
        }
    }

    button_was_down = pressed;
}

// ---------------------------------------------------------------------------
// Periodic work
// ---------------------------------------------------------------------------
static void handle_call(uint32_t now)
{
    if (!call_active) return;

    const ui_settings_t *cfg = ui_get_settings();
    uint32_t dur_ms = (cfg && cfg->call_duration_s >= 2)
                          ? ((uint32_t)cfg->call_duration_s * 1000u)
                          : CALL_DURATION_MS;

    if (now - call_start_ms >= dur_ms) {
        end_call(true);
        return;
    }

    if (now - buzzer_toggle_ms >= BUZZER_TOGGLE_MS) {
        buzzer_toggle_ms = now;
        buzzer_on = !buzzer_on;
        digitalWrite(PIN_BUZZER, (buzzer_on && (cfg == NULL || cfg->buzzer_enabled)) ? HIGH : LOW);
        s3_rgb_apply_alert(buzzer_on);
    }
}

static void handle_serial_commands(void)
{
    if (!Serial.available()) return;
    String line = Serial.readStringUntil('\n');
    line.trim();
    if (line.startsWith("WIFI ")) {
        int sp = line.indexOf(' ', 5);
        if (sp > 5) {
            nvs_wifi_ssid = line.substring(5, sp);
            nvs_wifi_pass = line.substring(sp + 1);
            if (prefs.begin("sos_ui", false)) {
                prefs.putString("wifi_ssid", nvs_wifi_ssid);
                prefs.putString("wifi_pass", nvs_wifi_pass);
                prefs.end();
            }
            Serial.printf("Saved WiFi SSID: %s\n", nvs_wifi_ssid.c_str());
            owm_sync_weather();
        }
    } else if (line.startsWith("OWMKEY ")) {
        nvs_owm_key = line.substring(7);
        nvs_owm_key.trim();
        if (prefs.begin("sos_ui", false)) {
            prefs.putString("owm_key", nvs_owm_key);
            prefs.end();
        }
        Serial.println("Saved OpenWeatherMap API key.");
        owm_sync_weather();
    } else if (line.equalsIgnoreCase("OWMSYNC")) {
        owm_sync_weather();
    } else if (line.equalsIgnoreCase("PING")) {
        on_ui_lora_ping();
    }
}

static void handle_periodic(uint32_t now)
{
    if (touch_was_pressed && (now - last_pressure_ms >= PRESSURE_UPDATE_MS)) {
        last_pressure_ms = now;
        uint16_t z = tft.getTouchRawZ();
        ui_update_pressure(z);
    }

    if (now - last_uptime_ms >= UPTIME_UPDATE_MS) {
        last_uptime_ms = now;
        ui_update_uptime((now - boot_ms) / 1000);
    }

    const ui_settings_t *cfg = ui_get_settings();
    if (cfg && cfg->wifi_enabled && cfg->owm_interval_min > 0) {
        uint32_t interval_ms = (uint32_t)cfg->owm_interval_min * 60000UL;
        if (now - last_owm_sync_ms >= interval_ms) {
            owm_sync_weather();
        }
    }

    handle_serial_commands();
}

// ---------------------------------------------------------------------------
// setup / loop
// ---------------------------------------------------------------------------
static void pump_ui(uint32_t ms)
{
    const uint32_t t0 = millis();
    while (millis() - t0 < ms) {
        lv_timer_handler();
        delay(5);
    }
}

void setup()
{
    Serial.begin(115200);
    delay(50);
    Serial.println("\nSOS Emergency Transmitter - V4 Unified Card UI");

    pinMode(PIN_BUTTON, INPUT_PULLUP);
    pinMode(PIN_NOTIFICATION, OUTPUT);
    pinMode(PIN_BUZZER, OUTPUT);
    digitalWrite(PIN_NOTIFICATION, LOW);
    digitalWrite(PIN_BUZZER, LOW);

#if defined(TFT_BL) && TFT_BL >= 0
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, TFT_BACKLIGHT_ON);
#endif

    tft.init();
    tft.setRotation(1);
    tft.fillScreen(TFT_BLACK);
    tft.fillRect(0, 0, 40, 40, TFT_RED);
    tft.fillRect(140, 100, 40, 40, TFT_GREEN);
    tft.fillRect(280, 200, 40, 40, TFT_BLUE);
    uint16_t r_px = tft.readPixel(20, 20);
    uint16_t g_px = tft.readPixel(160, 120);
    uint16_t b_px = tft.readPixel(300, 220);
    Serial.printf("PANEL: readback %04X %04X %04X -> %s\n",
                  (unsigned)r_px, (unsigned)g_px, (unsigned)b_px,
                  (r_px == TFT_RED && g_px == TFT_GREEN && b_px == TFT_BLUE) ? "OK" : "MISMATCH");
    tft.fillScreen(TFT_BLACK);

    touch_load_calibration();

    lv_init();
    lv_tick_set_cb(lv_tick_cb);

    disp = lv_display_create(320, 240);
    lv_display_set_color_format(disp, LV_COLOR_FORMAT_RGB565);
    lv_display_set_flush_cb(disp, flush_cb);
    lv_display_set_buffers(disp, draw_buf, NULL, sizeof(draw_buf),
                           LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_default(disp);

    // Register official LVGL 9.6 pointer input device for XPT2046 touch.
    touch_indev = lv_indev_create();
    lv_indev_set_type(touch_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(touch_indev, touch_read_cb);
    lv_indev_set_display(touch_indev, disp);
    lv_indev_set_long_press_time(touch_indev, LONG_PRESS_MS);

    ui_set_callbacks(&app_ui_cbs);
    ui_init();
    settings_load_nvs();

    // ADWS splash driven by the real init steps.
    boot_ms = millis();
    state = APP_BOOT;
    ui_show_boot();
    ui_boot_set_progress(5, "Power on...");
    pump_ui(120);

    ui_boot_set_progress(18, "Display ready");
    pump_ui(140);

    lora_init_433();
    ui_boot_set_progress(45, lora_ok ? "LoRa 433MHz ready" : "LoRa offline");
    pump_ui(180);

    owm_sync_weather();
    ui_boot_set_progress(65, "Weather & AQI ready");
    pump_ui(140);

    ui_boot_set_progress(82, "UI ready");
    pump_ui(140);

    while (millis() - boot_ms < 2000) {
        lv_timer_handler();
        delay(5);
    }
    ui_boot_set_progress(100, "System online");
    pump_ui(250);

    show_main();
    last_pressure_ms = millis();
    last_uptime_ms = millis();
    Serial.println("Ready: COMMAND");
}

void loop()
{
    const uint32_t now = millis();

    lv_timer_handler();
    handle_button(now);
    handle_call(now);
    handle_periodic(now);

    delay(5);
}
