// Default WiFi & OpenWeatherMap configuration for ADWS Node.
// You can either edit the defaults below OR set them at runtime over USB Serial
// (saved persistently in ESP32-S3 NVS flash namespace "sos_ui"):
//   WIFI <ssid> <password>
//   OWMKEY <32_char_openweathermap_api_key>
//   OWMSYNC

#ifndef ADWS_WEATHER_CONFIG_H
#define ADWS_WEATHER_CONFIG_H

#ifndef ADWS_DEFAULT_WIFI_SSID
#define ADWS_DEFAULT_WIFI_SSID     ""
#endif

#ifndef ADWS_DEFAULT_WIFI_PASS
#define ADWS_DEFAULT_WIFI_PASS     ""
#endif

#ifndef ADWS_DEFAULT_OWM_API_KEY
#define ADWS_DEFAULT_OWM_API_KEY   ""
#endif

typedef struct {
    const char *name;
    float lat;
    float lon;
    int16_t fallback_temp_c;
    uint8_t fallback_humidity;
    uint16_t fallback_aqi;
    const char *fallback_cond;
} adws_city_preset_t;

static const adws_city_preset_t k_adws_cities[5] = {
    { "Chennai",   13.0827f, 80.2707f, 29, 62,  42, "CLEAR"  },
    { "Bengaluru", 12.9716f, 77.5946f, 24, 54,  38, "CLOUDS" },
    { "Mumbai",    19.0760f, 72.8777f, 31, 72,  64, "HUMID"  },
    { "Delhi",     28.6139f, 77.2090f, 27, 45, 118, "HAZE"   },
    { "London",    51.5072f, -0.1276f, 16, 68,  28, "MIST"   },
};

#endif
