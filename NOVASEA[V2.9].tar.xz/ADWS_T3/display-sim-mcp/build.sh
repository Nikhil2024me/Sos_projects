#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOS_DIR="/home/debian/ADWS_T3/sos_lvgl"
SIM_DIR="/home/debian/mcp-servers/lvgl-mcp-esp32/simulator"
LVGL_LIB="$SIM_DIR/build/lib/lvgl/liblvgl.a"
OUT_BIN="$HERE/display_daemon"
LOCK_FILE="$HERE/.build.lock"
IF_NEEDED=0

if [[ "${1:-}" == "--if-needed" ]]; then
  IF_NEEDED=1
fi

exec 9>"$LOCK_FILE"
flock 9

if [[ "$IF_NEEDED" -eq 1 && -x "$OUT_BIN" ]]; then
  stale=0
  for src in "$HERE/build.sh" "$HERE/display_daemon.c" \
             "$SOS_DIR"/src/ui/*.c "$SOS_DIR"/src/ui/*.h \
             "$SOS_DIR"/src/assets/*.c "$SOS_DIR"/src/assets/*.h; do
    [[ -e "$src" ]] || continue
    if [[ "$src" -nt "$OUT_BIN" ]]; then
      stale=1
      break
    fi
  done
  if [[ "$stale" -eq 0 ]]; then
    exit 0
  fi
fi

TMP_BIN="$HERE/.display_daemon.tmp.$$"
trap 'rm -f "$TMP_BIN"' EXIT

cc -O2 -std=c11 -Wall -Wextra \
  -DLV_CONF_INCLUDE_SIMPLE \
  -I"$SIM_DIR" \
  -I"$SIM_DIR/lib/lvgl" \
  -I"$SIM_DIR/lib/stb" \
  -I"$SOS_DIR" \
  "$HERE/display_daemon.c" \
  "$SOS_DIR"/src/ui/*.c \
  "$SOS_DIR"/src/assets/*.c \
  "$LVGL_LIB" \
  -lm \
  -o "$TMP_BIN"

mv -f "$TMP_BIN" "$OUT_BIN"
echo "Built $OUT_BIN successfully."
