// ADWS Live Display Daemon (v2) - real-time LVGL 9.6 device emulator.
//
// This process is NOT a screenshot renderer. It boots like the real board:
// ADWS splash -> HOME, then runs a free-running loop at ~30 FPS exactly like
// sos_lvgl.ino::loop() (lv_timer_handler + handle_button + handle_call +
// handle_periodic). Every visual change is streamed to the parent process as
// a PNG frame so the browser shows a live, continuous display.
//
// Wiring modeled 1:1 from sos_lvgl.ino:
//   LONG_PRESS_MS 2000, SHORT_PRESS_MIN_MS 30, BUZZER_TOGGLE_MS 500,
//   CALL_DURATION_MS 5000, PRESSURE_UPDATE_MS 250, UPTIME_UPDATE_MS 1000,
//   TOUCH_Z_THRESHOLD 600, 90 ms resistive dropout hold, 800 ms cancel guard,
//   PIN_BUTTON 1, PIN_NOTIFICATION 17, PIN_BUZZER 18, LoRa 433E6 TX.
//
// stdout protocol (binary safe):
//   #F<len>\n  followed by <len> PNG bytes   (live frame)
//   #J{json}\n                              (response to a stdin command)
// stdin protocol: one JSON command object per line, optional "id" is echoed.

#define _GNU_SOURCE
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#include "lvgl.h"
#include "src/ui/ui_common.h"

#include <errno.h>
#include <math.h>
#include <poll.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define DISP_W 320
#define DISP_H 240
#define FRAME_INTERVAL_MS 33 // ~30 FPS live stream

#define LONG_PRESS_MS      2000
#define SHORT_PRESS_MIN_MS 30
#define BUZZER_TOGGLE_MS   500
#define CALL_DURATION_MS   5000
#define PRESSURE_UPDATE_MS 250
#define UPTIME_UPDATE_MS   1000
#define CANCEL_GUARD_MS    800
#define TOUCH_DROPOUT_MS   90

void sim_assert_fail(void)
{
    fprintf(stderr, "[display-daemon] LVGL assert failed\n");
    fflush(stderr);
    exit(3);
}

// ---------------------------------------------------------------------------
// Device state (mirrors sos_lvgl.ino globals)
// ---------------------------------------------------------------------------
typedef enum {
    APP_BOOT = 0,
    APP_MAIN,
    APP_SERVICE,
    APP_CONFIG,
    APP_CALLING,
    APP_SLIDESHOW,
} app_state_t;

static lv_display_t *s_disp = NULL;
static lv_indev_t *s_ptr_indev = NULL;

static uint32_t s_sim_ms = 0;      // millis()
static uint64_t s_frames = 0;
static double s_time_scale = 1.0;
static double s_tick_frac = 0.0;

static app_state_t s_state = APP_BOOT;
static service_id_t s_current_service = SERVICE_AMBULANCE;

static uint32_t s_boot_ms = 0;
static uint32_t s_last_pressure_ms = 0;
static uint32_t s_last_uptime_ms = 0;

static bool s_call_active = false;
static uint32_t s_call_start_ms = 0;
static bool s_buzzer_on = false;
static uint32_t s_buzzer_toggle_ms = 0;

static bool s_button_pin_down = false; // GPIO 1, active LOW on the board
static bool s_button_was_down = false;
static bool s_button_long_fired = false;
static uint32_t s_button_press_ms = 0;

// Touch panel (XPT2046) simulation
static int32_t s_ptr_x = 0;
static int32_t s_ptr_y = 0;
static bool s_ptr_raw_pressed = false;
static uint32_t s_last_valid_press_ms = 0;
static int32_t s_last_x = 0;
static int32_t s_last_y = 0;
static bool s_touch_was_pressed = false;
static uint16_t s_pressure_z = 0;
static uint16_t s_pressure_base = 2400;

// Output pins
static bool s_pin_notification = false;
static bool s_pin_buzzer = false;

// LoRa 433E6 TX log
#define MAX_LORA_LOG 16
static char s_lora_log[MAX_LORA_LOG][96];
static int s_lora_count = 0;
static uint32_t s_lora_seq = 0;

// Framebuffer / PNG cache
static uint8_t *s_png = NULL;
static int s_png_len = 0;
static bool s_dirty = true;
static bool s_want_png = true;
static uint32_t s_last_frame_ms = 0;
static bool s_running = true;

// ---------------------------------------------------------------------------
// Time helpers
// ---------------------------------------------------------------------------
static uint32_t wall_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint32_t)((uint64_t)ts.tv_sec * 1000ULL + (uint64_t)ts.tv_nsec / 1000000ULL);
}

static const char *state_name(app_state_t st)
{
    switch (st) {
    case APP_BOOT:      return "BOOT";
    case APP_MAIN:      return "MAIN";
    case APP_SERVICE:   return "SERVICE";
    case APP_CONFIG:    return "DIAGNOSTICS";
    case APP_CALLING:   return "REQUEST";
    case APP_SLIDESHOW: return "SLIDESHOW";
    default:            return "UNKNOWN";
    }
}

// ---------------------------------------------------------------------------
// LVGL display / pointer indev
// ---------------------------------------------------------------------------
static void flush_cb(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map)
{
    LV_UNUSED(area);
    LV_UNUSED(px_map);
    s_dirty = true;
    lv_display_flush_ready(disp);
}

static void pointer_read_cb(lv_indev_t *indev, lv_indev_data_t *data)
{
    LV_UNUSED(indev);
    const uint32_t now = s_sim_ms;

    if (s_ptr_raw_pressed) {
        s_last_valid_press_ms = now;
        s_last_x = s_ptr_x;
        s_last_y = s_ptr_y;
    }

    // 90 ms hold across resistive membrane dropouts (same as firmware).
    const bool pressed = s_ptr_raw_pressed ||
                         (s_touch_was_pressed && (now - s_last_valid_press_ms < TOUCH_DROPOUT_MS));

    if (pressed) {
        data->point.x = s_last_x;
        data->point.y = s_last_y;
        data->state = LV_INDEV_STATE_PRESSED;
    } else {
        data->state = LV_INDEV_STATE_RELEASED;
    }

    if (pressed != s_touch_was_pressed) {
        if (pressed) {
            s_pressure_z = s_pressure_base;
            ui_update_pressure(s_pressure_z);
        } else {
            s_pressure_z = 0;
            ui_update_pressure(0);
        }
        s_touch_was_pressed = pressed;
    }
}

// ---------------------------------------------------------------------------
// LoRa TX simulation
// ---------------------------------------------------------------------------
static void log_lora_tx(const char *pkt)
{
    if (s_lora_count < MAX_LORA_LOG) {
        snprintf(s_lora_log[s_lora_count++], 96, "%s", pkt);
    } else {
        for (int i = 1; i < MAX_LORA_LOG; i++) {
            memcpy(s_lora_log[i - 1], s_lora_log[i], 96);
        }
        snprintf(s_lora_log[MAX_LORA_LOG - 1], 96, "%s", pkt);
    }
}

// ---------------------------------------------------------------------------
// Screen & state transitions (identical structure to the firmware)
// ---------------------------------------------------------------------------
static void show_main(void)
{
    s_state = APP_MAIN;
    ui_show_home();
    ui_home_set_selected(s_current_service);
    ui_update_uptime((s_sim_ms - s_boot_ms) / 1000);
}

static void show_config(void)
{
    s_state = APP_CONFIG;
    ui_show_config();
}

static void show_slideshow(void)
{
    s_state = APP_SLIDESHOW;
    ui_show_slideshow((uint8_t)s_current_service);
}

static void end_call(bool return_to_main)
{
    s_call_active = false;
    s_pin_notification = false;
    s_pin_buzzer = false;
    s_buzzer_on = false;
    if (return_to_main) {
        show_main();
    }
}

static void start_call(void)
{
    if (s_call_active) end_call(false);
    const ui_settings_t *cfg = ui_get_settings();
    s_call_active = true;
    s_call_start_ms = s_sim_ms;
    s_buzzer_toggle_ms = s_sim_ms;
    s_buzzer_on = cfg ? cfg->buzzer_enabled : true;
    s_pin_notification = cfg ? cfg->led_enabled : true;
    s_pin_buzzer = s_buzzer_on;
    s_state = APP_CALLING;
    ui_show_calling(s_current_service);

    s_lora_seq++;
    uint8_t nid = cfg ? cfg->node_id : 1;
    const service_info_t *s = &ui_services[s_current_service];
    char pkt[96];
    snprintf(pkt, sizeof(pkt), "ADWS|NODE:%02u|REQ:%s|SERVICE:%s|PRI:%s|SEQ:%lu",
             (unsigned)nid, s->code, s->name, s->prio_tag, (unsigned long)s_lora_seq);
    log_lora_tx(pkt);
    ui_update_lora_status(true, s_lora_seq);
}

static void open_config(void)
{
    if (s_call_active) end_call(false);
    ui_slideshow_hold_progress(0);
    show_config();
}

// ---------------------------------------------------------------------------
// UI callbacks
// ---------------------------------------------------------------------------
static void on_ui_service_change(service_id_t svc) { s_current_service = svc; }
static void on_ui_dispatch(service_id_t svc) { s_current_service = svc; start_call(); }

static void on_ui_cancel_request(void)
{
    // Ignore residual touch bounce within the first 800 ms of a request.
    if (s_call_active && (s_sim_ms - s_call_start_ms < CANCEL_GUARD_MS)) return;

    const ui_settings_t *cfg = ui_get_settings();
    uint8_t nid = cfg ? cfg->node_id : 1;
    const service_info_t *s = &ui_services[s_current_service];
    char pkt[80];
    snprintf(pkt, sizeof(pkt), "ADWS|NODE:%02u|CANCEL:%s|SEQ:%lu",
             (unsigned)nid, s->code, (unsigned long)s_lora_seq);
    log_lora_tx(pkt);
    ui_update_lora_status(true, s_lora_seq);
    end_call(true);
}

static void on_ui_open_config(void)    { open_config(); }
static void on_ui_close_config(void)   { show_main(); }
static void on_ui_open_slideshow(void) { show_slideshow(); }
static void on_ui_exit_slideshow(void) { show_main(); }
static void on_ui_calibrate(void)      { show_config(); }

static void on_ui_lora_ping(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    uint8_t nid = cfg ? cfg->node_id : 1;
    s_lora_seq++;
    char pkt[80];
    snprintf(pkt, sizeof(pkt), "ADWS|NODE:%02u|PING|SEQ:%lu",
             (unsigned)nid, (unsigned long)s_lora_seq);
    log_lora_tx(pkt);
    ui_update_lora_status(true, s_lora_seq);
}

static void on_ui_lora_reinit(void)
{
    const ui_status_t *st = ui_get_status();
    bool next_ok = st ? !st->lora_ok : true;
    ui_update_lora_status(next_ok, s_lora_seq);
}

static void on_ui_weather_sync(void)
{
    const ui_settings_t *cfg = ui_get_settings();
    static const int16_t k_temps[6] = { 29, 24, 31, 27, 16, 30 };
    static const uint8_t k_hums[6]  = { 62, 54, 72, 45, 68, 58 };
    static const uint16_t k_aqis[6] = { 42, 38, 64, 118, 28, 35 };
    static const char *const k_cond[6] = { "CLEAR", "CLOUDS", "HUMID", "HAZE", "MIST", "CLEAR" };
    uint8_t idx = (cfg && cfg->city_index < 6) ? cfg->city_index : 0;
    ui_update_weather(k_temps[idx], k_hums[idx], k_aqis[idx], k_cond[idx], ui_city_name(idx), true);
}

static void on_ui_test_io(void)
{
    s_pin_notification = !s_pin_notification;
    s_pin_buzzer = !s_pin_buzzer;
}

static const ui_callbacks_t s_ui_cbs = {
    .on_service_change = on_ui_service_change,
    .on_dispatch       = on_ui_dispatch,
    .on_cancel_request = on_ui_cancel_request,
    .on_open_config    = on_ui_open_config,
    .on_close_config   = on_ui_close_config,
    .on_open_slideshow = on_ui_open_slideshow,
    .on_exit_slideshow = on_ui_exit_slideshow,
    .on_calibrate      = on_ui_calibrate,
    .on_lora_ping      = on_ui_lora_ping,
    .on_lora_reinit    = on_ui_lora_reinit,
    .on_weather_sync   = on_ui_weather_sync,
    .on_test_io        = on_ui_test_io,
};

// ---------------------------------------------------------------------------
// Firmware periodic work
// ---------------------------------------------------------------------------
static void handle_button(uint32_t now)
{
    const bool pressed = s_button_pin_down;

    if (pressed && !s_button_was_down) {
        s_button_press_ms = now;
        s_button_long_fired = false;
    }

    if (pressed && !s_button_long_fired && (now - s_button_press_ms >= LONG_PRESS_MS)) {
        s_button_long_fired = true;
        open_config();
    }

    if (!pressed && s_button_was_down) {
        const uint32_t held = now - s_button_press_ms;
        if (!s_button_long_fired && held >= SHORT_PRESS_MIN_MS) {
            if (s_state == APP_MAIN || s_state == APP_SERVICE) {
                start_call();
            } else if (s_state == APP_CALLING) {
                end_call(true);
            }
        }
    }

    s_button_was_down = pressed;
}

static void handle_call(uint32_t now)
{
    if (!s_call_active) return;

    const ui_settings_t *cfg = ui_get_settings();
    uint32_t dur_ms = (cfg && cfg->call_duration_s >= 2)
                          ? ((uint32_t)cfg->call_duration_s * 1000u)
                          : CALL_DURATION_MS;

    if (now - s_call_start_ms >= dur_ms) {
        end_call(true);
        return;
    }

    if (now - s_buzzer_toggle_ms >= BUZZER_TOGGLE_MS) {
        s_buzzer_toggle_ms = now;
        if (cfg == NULL || cfg->buzzer_enabled) {
            s_buzzer_on = !s_buzzer_on;
            s_pin_buzzer = s_buzzer_on;
        } else {
            s_buzzer_on = false;
            s_pin_buzzer = false;
        }
    }
}

static void handle_periodic(uint32_t now)
{
    if (s_touch_was_pressed && (now - s_last_pressure_ms >= PRESSURE_UPDATE_MS)) {
        s_last_pressure_ms = now;
        // XPT2046 raw pressure jitter around the pressed baseline.
        int32_t jitter = (int32_t)((now * 37u) % 180u) - 90;
        int32_t z = (int32_t)s_pressure_base + jitter;
        if (z < 0) z = 0;
        if (z > 4095) z = 4095;
        s_pressure_z = (uint16_t)z;
        ui_update_pressure(s_pressure_z);
    }

    if (now - s_last_uptime_ms >= UPTIME_UPDATE_MS) {
        s_last_uptime_ms = now;
        ui_update_uptime((now - s_boot_ms) / 1000);
    }
}

// ---------------------------------------------------------------------------
// PNG encode of the active frame buffer
// ---------------------------------------------------------------------------
static unsigned char *encode_png(int *out_len)
{
    lv_draw_buf_t *buf = lv_display_get_buf_active(s_disp);
    if (!buf || !buf->data) return NULL;

    const uint32_t stride = buf->header.stride;
    const lv_color_format_t cf = buf->header.cf;
    uint8_t *rgb = (uint8_t *)malloc((size_t)DISP_W * DISP_H * 3);
    if (!rgb) return NULL;

    for (int y = 0; y < DISP_H; y++) {
        const uint8_t *src = buf->data + (size_t)y * stride;
        uint8_t *dst = rgb + (size_t)y * DISP_W * 3;
        if (cf == LV_COLOR_FORMAT_RGB565) {
            for (int x = 0; x < DISP_W; x++, src += 2, dst += 3) {
                uint16_t px = (uint16_t)(src[0] | (src[1] << 8));
                uint8_t r = (uint8_t)((px >> 11) & 0x1F);
                uint8_t g = (uint8_t)((px >> 5) & 0x3F);
                uint8_t b = (uint8_t)(px & 0x1F);
                dst[0] = (uint8_t)((r << 3) | (r >> 2));
                dst[1] = (uint8_t)((g << 2) | (g >> 4));
                dst[2] = (uint8_t)((b << 3) | (b >> 2));
            }
        } else if (cf == LV_COLOR_FORMAT_RGB888) {
            for (int x = 0; x < DISP_W; x++, src += 3, dst += 3) {
                dst[0] = src[2];
                dst[1] = src[1];
                dst[2] = src[0];
            }
        } else if (cf == LV_COLOR_FORMAT_XRGB8888 || cf == LV_COLOR_FORMAT_ARGB8888) {
            for (int x = 0; x < DISP_W; x++, src += 4, dst += 3) {
                dst[0] = src[2];
                dst[1] = src[1];
                dst[2] = src[0];
            }
        } else {
            free(rgb);
            return NULL;
        }
    }

    unsigned char *png = stbi_write_png_to_mem(rgb, DISP_W * 3, DISP_W, DISP_H, 3, out_len);
    free(rgb);
    return png;
}

// Emit the current frame if it changed (or when forced).
static bool emit_frame(bool force)
{
    if (!force) {
        if (!s_dirty) return false;
        const uint32_t now = wall_ms();
        if (now - s_last_frame_ms < FRAME_INTERVAL_MS) return false;
        s_last_frame_ms = now;
    } else {
        s_last_frame_ms = wall_ms();
    }

    lv_obj_update_layout(lv_screen_active());
    lv_obj_update_layout(lv_layer_top());
    lv_refr_now(s_disp);
    s_dirty = false;

    int len = 0;
    unsigned char *png = encode_png(&len);
    if (!png || len <= 0) return false;

    if (s_png) STBIW_FREE(s_png);
    s_png = png;
    s_png_len = len;
    s_frames++;

    fprintf(stdout, "#F%d\n", len);
    fwrite(png, 1, (size_t)len, stdout);
    fflush(stdout);
    return true;
}

// ---------------------------------------------------------------------------
// One iteration of the device main loop
// ---------------------------------------------------------------------------
static void tick_once(uint32_t wall_dt)
{
    // LVGL itself always runs in real time so layout, rendering and widget
    // animations keep working. Only the firmware clock (millis()) is scaled.
    if (wall_dt > 0) lv_tick_inc(wall_dt);

    double scaled = (double)wall_dt * s_time_scale + s_tick_frac;
    uint32_t ms = (uint32_t)scaled;
    s_tick_frac = scaled - (double)ms;
    s_sim_ms += ms;

    lv_timer_handler();
    handle_button(s_sim_ms);
    handle_call(s_sim_ms);
    handle_periodic(s_sim_ms);
}

static uint32_t s_last_wall = 0;

// Run the device loop for a real amount of wall-clock time (like pump_ui()).
static void pump_rt(uint32_t wall_ms_total)
{
    const uint32_t start = wall_ms();
    while (s_running) {
        const uint32_t now = wall_ms();
        if ((uint32_t)(now - start) >= wall_ms_total) break;

        uint32_t dt = (uint32_t)(now - s_last_wall);
        if (dt > 0) {
            s_last_wall = now;
            if (dt > 100) dt = 100;
            tick_once(dt);
        }
        emit_frame(false);
        usleep(1500);
    }
}

// ---------------------------------------------------------------------------
// JSON helpers
// ---------------------------------------------------------------------------
static void json_escape_print(FILE *out, const char *s)
{
    fputc('"', out);
    if (s) {
        for (; *s; s++) {
            unsigned char c = (unsigned char)*s;
            if (c == '"') fputs("\\\"", out);
            else if (c == '\\') fputs("\\\\", out);
            else if (c >= 32 && c < 127) fputc(c, out);
        }
    }
    fputc('"', out);
}

static bool json_str(const char *line, const char *key, char *out, size_t out_sz)
{
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(line, pat);
    if (!p) return false;
    p += strlen(pat);
    while (*p == ' ' || *p == ':') p++;
    if (*p != '"') return false;
    p++;
    size_t i = 0;
    while (*p && *p != '"' && i + 1 < out_sz) {
        if (*p == '\\' && p[1]) p++;
        out[i++] = *p++;
    }
    out[i] = '\0';
    return true;
}

static bool json_int(const char *line, const char *key, int32_t *out)
{
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(line, pat);
    if (!p) return false;
    p += strlen(pat);
    while (*p == ' ' || *p == ':') p++;
    if ((*p >= '0' && *p <= '9') || *p == '-') {
        *out = (int32_t)strtol(p, NULL, 10);
        return true;
    }
    return false;
}

static bool json_num(const char *line, const char *key, double *out)
{
    char pat[64];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = strstr(line, pat);
    if (!p) return false;
    p += strlen(pat);
    while (*p == ' ' || *p == ':') p++;
    char *end = NULL;
    double v = strtod(p, &end);
    if (end == p) return false;
    *out = v;
    return true;
}

// ---------------------------------------------------------------------------
// Widget lookup / dump
// ---------------------------------------------------------------------------
static lv_obj_t *find_by_name_rec(lv_obj_t *root, const char *name)
{
    if (!root || !name) return NULL;
    const char *n = lv_obj_get_name(root);
    if (n && strcmp(n, name) == 0) return root;
    uint32_t cnt = lv_obj_get_child_count(root);
    for (uint32_t i = 0; i < cnt; i++) {
        lv_obj_t *found = find_by_name_rec(lv_obj_get_child(root, (int32_t)i), name);
        if (found) return found;
    }
    return NULL;
}

static lv_obj_t *find_widget(const char *name)
{
    lv_obj_t *f = find_by_name_rec(lv_screen_active(), name);
    if (f) return f;
    return find_by_name_rec(lv_layer_top(), name);
}

static void dump_widgets_rec(FILE *out, lv_obj_t *obj, bool *first)
{
    if (!obj || lv_obj_is_hidden(obj)) return;

    const char *name = lv_obj_get_name(obj);
    const bool clickable = lv_obj_is_clickable(obj);
    const char *txt = NULL;
    if (lv_obj_check_type(obj, &lv_label_class)) txt = lv_label_get_text(obj);

    if ((name && name[0]) || clickable || (txt && txt[0])) {
        lv_area_t coords;
        lv_obj_get_coords(obj, &coords);
        int32_t w = lv_area_get_width(&coords);
        int32_t h = lv_area_get_height(&coords);

        if (!*first) fputc(',', out);
        *first = false;
        fputs("{\"name\":", out);
        json_escape_print(out, name ? name : "");
        fprintf(out,
                ",\"x\":%d,\"y\":%d,\"w\":%d,\"h\":%d,\"cx\":%d,\"cy\":%d,\"clickable\":%s",
                (int)coords.x1, (int)coords.y1, (int)w, (int)h,
                (int)(coords.x1 + w / 2), (int)(coords.y1 + h / 2),
                clickable ? "true" : "false");
        if (txt && txt[0]) {
            fputs(",\"text\":", out);
            json_escape_print(out, txt);
        }
        fputc('}', out);
    }

    uint32_t cnt = lv_obj_get_child_count(obj);
    for (uint32_t i = 0; i < cnt; i++) {
        dump_widgets_rec(out, lv_obj_get_child(obj, (int32_t)i), first);
    }
}

// ---------------------------------------------------------------------------
// Base64
// ---------------------------------------------------------------------------
static const char b64_table[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static void write_base64(FILE *out, const uint8_t *data, size_t len)
{
    size_t i = 0;
    while (i + 2 < len) {
        uint32_t v = ((uint32_t)data[i] << 16) | ((uint32_t)data[i + 1] << 8) | data[i + 2];
        fputc(b64_table[(v >> 18) & 0x3F], out);
        fputc(b64_table[(v >> 12) & 0x3F], out);
        fputc(b64_table[(v >> 6) & 0x3F], out);
        fputc(b64_table[v & 0x3F], out);
        i += 3;
    }
    if (i < len) {
        uint32_t v = (uint32_t)data[i] << 16;
        if (i + 1 < len) v |= (uint32_t)data[i + 1] << 8;
        fputc(b64_table[(v >> 18) & 0x3F], out);
        fputc(b64_table[(v >> 12) & 0x3F], out);
        fputc((i + 1 < len) ? b64_table[(v >> 6) & 0x3F] : '=', out);
        fputc('=', out);
    }
}

// ---------------------------------------------------------------------------
// Command response
// ---------------------------------------------------------------------------
static void send_response(int32_t id, bool ok, const char *note)
{
    fputs("#J{\"id\":", stdout);
    fprintf(stdout, "%d", (int)id);
    fputs(",\"ok\":", stdout);
    fputs(ok ? "true" : "false", stdout);
    fputs(",\"note\":", stdout);
    json_escape_print(stdout, note);
    fputs(",\"state\":", stdout);
    json_escape_print(stdout, state_name(s_state));
    fputs(",\"service\":", stdout);
    json_escape_print(stdout, ui_services[s_current_service].name);
    fprintf(stdout,
            ",\"service_id\":%d,\"elapsed_ms\":%u,\"uptime_s\":%u,\"pressure_z\":%u,"
            "\"call_active\":%s,\"call_remaining_ms\":%d,"
            "\"pin_notification\":%s,\"pin_buzzer\":%s,"
            "\"pressed\":%s,\"touch_x\":%d,\"touch_y\":%d,"
            "\"time_scale\":%.3f,\"frames\":%llu,\"lora_tx_count\":%u,\"lora_log\":[",
            (int)s_current_service,
            (unsigned)s_sim_ms,
            (unsigned)((s_sim_ms - s_boot_ms) / 1000),
            (unsigned)s_pressure_z,
            s_call_active ? "true" : "false",
            s_call_active ? (int)(CALL_DURATION_MS - (s_sim_ms - s_call_start_ms)) : 0,
            s_pin_notification ? "true" : "false",
            s_pin_buzzer ? "true" : "false",
            s_touch_was_pressed ? "true" : "false",
            (int)s_last_x, (int)s_last_y,
            s_time_scale,
            (unsigned long long)s_frames,
            (unsigned)s_lora_seq);

    for (int i = 0; i < s_lora_count; i++) {
        if (i > 0) fputc(',', stdout);
        json_escape_print(stdout, s_lora_log[i]);
    }

    fputs("],\"widgets\":[", stdout);
    bool first_w = true;
    dump_widgets_rec(stdout, lv_screen_active(), &first_w);
    dump_widgets_rec(stdout, lv_layer_top(), &first_w);
    fputs("]", stdout);

    if (s_want_png && s_png && s_png_len > 0) {
        fputs(",\"png_base64\":\"", stdout);
        write_base64(stdout, s_png, (size_t)s_png_len);
        fputc('"', stdout);
    }
    fputs("}\n", stdout);
    fflush(stdout);
}

// ---------------------------------------------------------------------------
// Input helpers
// ---------------------------------------------------------------------------
static bool resolve_target(const char *line, int32_t *x, int32_t *y,
                           char *resolved, size_t resolved_sz)
{
    resolved[0] = '\0';
    char target[64];
    if (json_str(line, "name", target, sizeof(target)) && target[0]) {
        lv_obj_t *obj = find_widget(target);
        if (!obj) return false;
        lv_area_t c;
        lv_obj_get_coords(obj, &c);
        *x = c.x1 + lv_area_get_width(&c) / 2;
        *y = c.y1 + lv_area_get_height(&c) / 2;
        snprintf(resolved, resolved_sz, "'%s'", target);
        return true;
    }
    if (json_int(line, "x", x) && json_int(line, "y", y)) {
        snprintf(resolved, resolved_sz, "(%d,%d)", (int)*x, (int)*y);
        return true;
    }
    return false;
}

static void touch_down(int32_t x, int32_t y)
{
    s_ptr_x = x;
    s_ptr_y = y;
    s_ptr_raw_pressed = true;
    lv_indev_read(s_ptr_indev);
}

static void touch_move(int32_t x, int32_t y)
{
    s_ptr_x = x;
    s_ptr_y = y;
    lv_indev_read(s_ptr_indev);
}

static void touch_up(void)
{
    s_ptr_raw_pressed = false;
    lv_indev_read(s_ptr_indev);
}

// ---------------------------------------------------------------------------
// Boot sequence (mirrors setup() in sos_lvgl.ino, in real time)
// ---------------------------------------------------------------------------
static void boot_sequence(void)
{
    // Power-on always runs in real time, even if the clock was frozen.
    const double saved_scale = s_time_scale;
    s_time_scale = 1.0;

    s_call_active = false;
    s_pin_notification = false;
    s_pin_buzzer = false;
    s_buzzer_on = false;
    s_button_pin_down = false;
    s_button_was_down = false;
    s_button_long_fired = false;
    s_ptr_raw_pressed = false;
    s_touch_was_pressed = false;
    s_pressure_z = 0;
    s_sim_ms = 0;
    s_tick_frac = 0.0;
    s_lora_count = 0;
    s_boot_ms = 0;
    s_last_pressure_ms = 0;
    s_last_uptime_ms = 0;
    s_current_service = SERVICE_AMBULANCE;

    s_state = APP_BOOT;
    ui_show_boot();
    ui_boot_set_progress(5, "Power on...");
    pump_rt(120);

    ui_boot_set_progress(18, "Display ready");
    pump_rt(140);

    ui_boot_set_progress(45, "LoRa 433MHz ready");
    pump_rt(180);

    ui_boot_set_progress(65, "Touch ready");
    pump_rt(140);

    ui_boot_set_progress(82, "UI ready");
    pump_rt(140);

    if (s_sim_ms < 2000) pump_rt(2000 - s_sim_ms);

    ui_boot_set_progress(100, "System online");
    pump_rt(250);

    show_main();
    pump_rt(180); // let the boot -> home transition settle
    s_last_pressure_ms = s_sim_ms;
    s_last_uptime_ms = s_sim_ms;
    s_dirty = true;
    emit_frame(true);

    s_time_scale = saved_scale;
}

static const char *boot_stage_for(int32_t pct)
{
    if (pct < 12) return "Power on...";
    if (pct < 32) return "Display ready";
    if (pct < 55) return "LoRa 433MHz ready";
    if (pct < 72) return "Touch ready";
    if (pct < 95) return "UI ready";
    return "System online";
}

// ---------------------------------------------------------------------------
// Command handling
// ---------------------------------------------------------------------------
static void handle_command(const char *line)
{
    int32_t id = -1;
    json_int(line, "id", &id);

    int32_t png_flag = 1;
    if (json_int(line, "png", &png_flag)) s_want_png = (png_flag != 0);
    else s_want_png = true;

    char note[192];
    char cmd[32] = {0};
    if (!json_str(line, "cmd", cmd, sizeof(cmd))) {
        snprintf(note, sizeof(note), "Missing \"cmd\"");
        send_response(id, false, note);
        return;
    }

    bool ok = true;
    snprintf(note, sizeof(note), "ok");

    if (strcmp(cmd, "state") == 0) {
        emit_frame(false);
        snprintf(note, sizeof(note), "State snapshot");
    } else if (strcmp(cmd, "screenshot") == 0) {
        emit_frame(true);
        snprintf(note, sizeof(note), "Live frame captured");
    } else if (strcmp(cmd, "click") == 0) {
        int32_t x = 0, y = 0, hold = 90, settle = 280;
        char target[64];
        json_int(line, "hold_ms", &hold);
        json_int(line, "settle_ms", &settle);
        if (!resolve_target(line, &x, &y, target, sizeof(target))) {
            ok = false;
            snprintf(note, sizeof(note), "Unknown widget name or missing (x, y)");
        } else {
            touch_down(x, y);
            pump_rt(hold > 20 ? (uint32_t)hold : 90);
            touch_up();
            pump_rt(settle > 0 ? (uint32_t)settle : 280);
            snprintf(note, sizeof(note), "Touched %s, held %d ms", target, (int)hold);
        }
    } else if (strcmp(cmd, "long_press") == 0) {
        int32_t x = 0, y = 0, hold = 2100, release = 1;
        char target[64];
        json_int(line, "hold_ms", &hold);
        json_int(line, "release", &release);
        if (!resolve_target(line, &x, &y, target, sizeof(target))) {
            ok = false;
            snprintf(note, sizeof(note), "Unknown widget name or missing (x, y)");
        } else {
            touch_down(x, y);
            pump_rt(hold > 0 ? (uint32_t)hold : 2100);
            if (release) {
                touch_up();
                pump_rt(200);
            }
            snprintf(note, sizeof(note), "Held %s for %d ms%s",
                     target, (int)hold, release ? " then released" : " (finger still down)");
        }
    } else if (strcmp(cmd, "touch") == 0) {
        char action[16] = "down";
        int32_t x = 0, y = 0;
        json_str(line, "action", action, sizeof(action));
        const bool have_xy = json_int(line, "x", &x) && json_int(line, "y", &y);
        if (strcmp(action, "down") == 0) {
            if (!have_xy) {
                ok = false;
                snprintf(note, sizeof(note), "touch down needs x and y");
            } else {
                touch_down(x, y);
                pump_rt(40);
                snprintf(note, sizeof(note), "Finger down at (%d,%d)", (int)x, (int)y);
            }
        } else if (strcmp(action, "move") == 0) {
            if (!have_xy) {
                ok = false;
                snprintf(note, sizeof(note), "touch move needs x and y");
            } else {
                touch_move(x, y);
                pump_rt(30);
                snprintf(note, sizeof(note), "Finger moved to (%d,%d)", (int)x, (int)y);
            }
        } else if (strcmp(action, "up") == 0) {
            touch_up();
            pump_rt(120);
            snprintf(note, sizeof(note), "Finger released");
        } else {
            ok = false;
            snprintf(note, sizeof(note), "Unknown touch action '%s'", action);
        }
    } else if (strcmp(cmd, "drag") == 0) {
        int32_t x1 = 0, y1 = 0, x2 = 0, y2 = 0, dur = 320;
        json_int(line, "from_x", &x1);
        json_int(line, "from_y", &y1);
        json_int(line, "to_x", &x2);
        json_int(line, "to_y", &y2);
        json_int(line, "duration_ms", &dur);
        if (dur < 60) dur = 60;
        const int steps = 12;
        touch_down(x1, y1);
        for (int i = 1; i <= steps; i++) {
            touch_move(x1 + ((x2 - x1) * i) / steps, y1 + ((y2 - y1) * i) / steps);
            pump_rt((uint32_t)(dur / steps));
        }
        touch_up();
        pump_rt(220);
        snprintf(note, sizeof(note), "Dragged (%d,%d) -> (%d,%d) over %d ms",
                 (int)x1, (int)y1, (int)x2, (int)y2, (int)dur);
    } else if (strcmp(cmd, "button") == 0 || strcmp(cmd, "gpio_button") == 0) {
        char mode[16] = "short";
        json_str(line, "mode", mode, sizeof(mode));
        if (strcmp(mode, "long") == 0) {
            s_button_pin_down = true;
            pump_rt(2300);
            s_button_pin_down = false;
            pump_rt(140);
            snprintf(note, sizeof(note), "GPIO1 held 2.3 s (long press) -> %s",
                     state_name(s_state));
        } else {
            s_button_pin_down = true;
            pump_rt(120);
            s_button_pin_down = false;
            pump_rt(140);
            snprintf(note, sizeof(note), "GPIO1 tapped (short press) -> %s",
                     state_name(s_state));
        }
    } else if (strcmp(cmd, "pressure") == 0) {
        int32_t z = 0;
        json_int(line, "z", &z);
        if (z < 0) z = 0;
        if (z > 4095) z = 4095;
        s_pressure_z = (uint16_t)z;
        if (z > 0) s_pressure_base = (uint16_t)z;
        ui_update_pressure(s_pressure_z);
        pump_rt(60);
        snprintf(note, sizeof(note), "XPT2046 raw pressure Z = %u", (unsigned)s_pressure_z);
    } else if (strcmp(cmd, "wait") == 0) {
        int32_t ms = 1000;
        json_int(line, "ms", &ms);
        if (ms < 0) ms = 0;
        if (ms > 30000) ms = 30000;
        pump_rt((uint32_t)ms);
        snprintf(note, sizeof(note), "Let the device run %d ms of real time", (int)ms);
    } else if (strcmp(cmd, "time_scale") == 0) {
        double scale = 1.0;
        if (json_num(line, "scale", &scale)) {
            if (scale < 0) scale = 0;
            if (scale > 20) scale = 20;
            s_time_scale = scale;
            snprintf(note, sizeof(note), "Simulated clock scale = %.2fx", s_time_scale);
        } else {
            ok = false;
            snprintf(note, sizeof(note), "Missing \"scale\"");
        }
    } else if (strcmp(cmd, "reset") == 0) {
        int32_t boot_pct = -1;
        char mode[16] = "home";
        json_str(line, "mode", mode, sizeof(mode));
        if (json_int(line, "boot_percent", &boot_pct) && boot_pct >= 0 && boot_pct <= 100) {
            s_state = APP_BOOT;
            ui_show_boot();
            ui_boot_set_progress((uint8_t)boot_pct, boot_stage_for(boot_pct));
            pump_rt(120);
            snprintf(note, sizeof(note), "Boot splash at %d%% (%s)", (int)boot_pct, boot_stage_for(boot_pct));
        } else if (strcmp(mode, "boot") == 0) {
            boot_sequence();
            snprintf(note, sizeof(note), "Cold boot: ADWS splash -> HOME (2.4 s)");
        } else {
            end_call(false);
            s_pressure_z = 0;
            s_touch_was_pressed = false;
            s_ptr_raw_pressed = false;
            s_current_service = SERVICE_AMBULANCE;
            show_main();
            pump_rt(160);
            snprintf(note, sizeof(note), "Reset to HOME (Ambulance)");
        }
    } else if (strcmp(cmd, "quit") == 0) {
        snprintf(note, sizeof(note), "Shutting down display daemon");
        send_response(id, true, note);
        s_running = false;
        return;
    } else {
        ok = false;
        snprintf(note, sizeof(note), "Unknown cmd '%s'", cmd);
    }

    send_response(id, ok, note);
}

static char s_inbuf[65536];
static size_t s_inlen = 0;

static void poll_commands(void)
{
    struct pollfd pfd;
    pfd.fd = 0;
    pfd.events = POLLIN;
    pfd.revents = 0;
    if (poll(&pfd, 1, 0) <= 0) return;
    if (pfd.revents & (POLLHUP | POLLERR | POLLNVAL)) {
        s_running = false;
        return;
    }
    if (s_inlen >= sizeof(s_inbuf) - 1) {
        s_inlen = 0; // drop oversized garbage
    }
    ssize_t n = read(0, s_inbuf + s_inlen, sizeof(s_inbuf) - s_inlen - 1);
    if (n <= 0) {
        s_running = false;
        return;
    }
    s_inlen += (size_t)n;
    s_inbuf[s_inlen] = '\0';

    size_t start = 0;
    for (size_t i = 0; i < s_inlen; i++) {
        if (s_inbuf[i] == '\n') {
            s_inbuf[i] = '\0';
            if (s_inbuf[start] != '\0') handle_command(s_inbuf + start);
            start = i + 1;
        }
    }
    if (start > 0) {
        memmove(s_inbuf, s_inbuf + start, s_inlen - start);
        s_inlen -= start;
    }
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------
int main(void)
{
    lv_init();

    s_disp = lv_display_create(DISP_W, DISP_H);
    lv_display_set_color_format(s_disp, LV_COLOR_FORMAT_RGB565);

    // Same 320x40 partial draw buffer as the firmware (25,600 bytes) is too
    // small to hold a full frame; use DIRECT so the active buffer always holds
    // the complete display contents.
    const uint32_t stride = lv_draw_buf_width_to_stride(DISP_W, LV_COLOR_FORMAT_RGB565);
    const uint32_t buf_size = stride * DISP_H;
    void *buf_mem = malloc((size_t)buf_size + LV_DRAW_BUF_ALIGN);
    if (!buf_mem) return 2;
    lv_display_set_buffers(s_disp, lv_draw_buf_align(buf_mem, LV_COLOR_FORMAT_RGB565),
                           NULL, buf_size, LV_DISPLAY_RENDER_MODE_DIRECT);
    lv_display_set_flush_cb(s_disp, flush_cb);
    lv_display_set_default(s_disp);

    s_ptr_indev = lv_indev_create();
    lv_indev_set_type(s_ptr_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(s_ptr_indev, pointer_read_cb);
    lv_indev_set_display(s_ptr_indev, s_disp);
    lv_indev_set_long_press_time(s_ptr_indev, LONG_PRESS_MS);

    ui_set_callbacks(&s_ui_cbs);
    ui_init();

    s_last_wall = wall_ms();
    boot_sequence();

    // Tell the parent we are alive and past the boot splash.
    fputs("#J{\"type\":\"ready\",\"state\":\"MAIN\",\"display\":\"320x240 RGB565\"}\n", stdout);
    fflush(stdout);

    while (s_running) {
        const uint32_t now = wall_ms();
        uint32_t dt = (uint32_t)(now - s_last_wall);
        if (dt > 0) {
            s_last_wall = now;
            if (dt > 100) dt = 100;
            tick_once(dt);
        }
        poll_commands();
        emit_frame(false);
        usleep(1000);
    }

    return 0;
}
