#!/usr/bin/env node
// ADWS Live Display — MCP server + continuous live device view.
//
// The real ESP32-S3 firmware UI (sos_lvgl/src/ui/*.c + src/assets/*.c) is
// compiled into a native LVGL 9.6 daemon that boots like the board and then
// runs a free-running loop, exactly like sos_lvgl.ino::loop(). Frames are
// streamed as they are drawn, so the browser view is a live display, not a
// slideshow of prerendered screenshots.
//
//   node index.mjs            MCP server over stdio + live view on :4320
//   node index.mjs --window   same, and opens a desktop window for the view
//   node index.mjs --gui-only only the web view (no MCP stdio)

import { Server } from "/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server/node_modules/@modelcontextprotocol/sdk/dist/esm/server/index.js";
import { StdioServerTransport } from "/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server/node_modules/@modelcontextprotocol/sdk/dist/esm/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js";

import { spawn, execFileSync } from "node:child_process";
import { existsSync, statSync, readdirSync } from "node:fs";
import * as http from "node:http";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DAEMON_BIN = path.join(HERE, "display_daemon");
const BUILD_SH = path.join(HERE, "build.sh");
const SOS_DIR = "/home/debian/ADWS_T3/sos_lvgl";
const GUI_PORT = Number(process.env.ADWS_SIM_PORT || 4320);
const GUI_PORT_EXPLICIT = Boolean(process.env.ADWS_SIM_PORT);
let activeGuiPort = GUI_PORT;
const WANT_WINDOW = process.argv.includes("--window");
const GUI_ONLY = process.argv.includes("--gui-only");
const MCP_STDIO = !GUI_ONLY;

const log = (...a) => process.stderr.write("[adws-display] " + a.join(" ") + "\n");

// ---------------------------------------------------------------------------
// Build (only when the daemon or any source file changed)
// ---------------------------------------------------------------------------
function newestMtime(dir) {
  let newest = 0;
  for (const f of readdirSync(dir)) {
    if (!f.endsWith(".c") && !f.endsWith(".h")) continue;
    newest = Math.max(newest, statSync(path.join(dir, f)).mtimeMs);
  }
  return newest;
}

function needsRebuild() {
  if (!existsSync(DAEMON_BIN)) return true;
  const bin = statSync(DAEMON_BIN).mtimeMs;
  if (statSync(BUILD_SH).mtimeMs > bin) return true;
  if (statSync(path.join(HERE, "display_daemon.c")).mtimeMs > bin) return true;
  if (newestMtime(path.join(SOS_DIR, "src/ui")) > bin) return true;
  if (newestMtime(path.join(SOS_DIR, "src/assets")) > bin) return true;
  return false;
}

function ensureBuilt() {
  if (!needsRebuild()) return;
  log("compiling display_daemon (firmware UI changed)...");
  try {
    execFileSync(BUILD_SH, ["--if-needed"], {
      cwd: HERE,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    });
    log("build ok");
  } catch (err) {
    const stderr = (err && typeof err.stderr === "string" ? err.stderr : "").trim();
    const stdout = (err && typeof err.stdout === "string" ? err.stdout : "").trim();
    const detail = [stderr, stdout].filter(Boolean).join("\n");
    if (detail) process.stderr.write(detail + "\n");
    const tail = detail.length > 1500 ? detail.slice(-1500) : detail;
    throw new Error(tail ? `display_daemon build failed:\n${tail}` : (err?.message || "build.sh failed"));
  }
}

// ---------------------------------------------------------------------------
// Daemon: long-lived device process
// ---------------------------------------------------------------------------
class Daemon {
  constructor() {
    this.proc = null;
    this.seq = 0;
    this.pending = new Map();
    this.buf = Buffer.alloc(0);
    this.frameRemaining = 0;
    this.frameChunks = [];
    this.ready = null;
    this.isReady = false;
    this._restarting = null;
    this._resolveReady = null;
    this._rejectReady = null;
    this.onFrame = null;
    this.containerW = 320;
    this.containerH = 240;
  }

  start() {
    if (this.proc) return;
    ensureBuilt();
    const proc = spawn(DAEMON_BIN, [], { cwd: HERE, stdio: ["pipe", "pipe", "pipe"] });
    this.proc = proc;
    this.buf = Buffer.alloc(0);
    this.frameRemaining = 0;
    this.frameChunks = [];
    this.isReady = false;
    this.ready = new Promise((resolve, reject) => {
      this._resolveReady = resolve;
      this._rejectReady = reject;
    });
    this.ready.catch(() => {});

    proc.stderr.on("data", (d) => process.stderr.write("[display_daemon] " + d));

    proc.stdout.on("data", (chunk) => {
      if (this.proc !== proc) return;
      this.buf = Buffer.concat([this.buf, chunk]);
      this._parse();
    });

    proc.on("error", (err) => {
      if (this.proc !== proc) return;
      this.proc = null;
      if (!this.isReady && this._rejectReady) {
        this._rejectReady(err);
        this._rejectReady = null;
      }
      for (const { reject } of this.pending.values()) reject(err);
      this.pending.clear();
    });

    proc.on("exit", (code) => {
      if (this.proc === proc) this.proc = null;
      if (!this.isReady && this._rejectReady) {
        this._rejectReady(new Error(`display_daemon exited with code ${code} before ready`));
        this._rejectReady = null;
      }
      for (const { reject } of this.pending.values()) reject(new Error("display_daemon exited"));
      this.pending.clear();
      if (code !== 0 && code !== null && MCP_STDIO) log("daemon exited with code " + code);
    });
  }

  async stop() {
    const proc = this.proc;
    if (!proc) return;
    await new Promise((resolve) => {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        resolve();
      };
      proc.once("exit", finish);
      try {
        if (proc.stdin?.writable) proc.stdin.write(JSON.stringify({ cmd: "quit" }) + "\n");
      } catch {}
      setTimeout(() => {
        try {
          proc.kill("SIGTERM");
        } catch {}
      }, 250).unref?.();
      setTimeout(finish, 800).unref?.();
    });
  }

  _parse() {
    for (;;) {
      if (this.frameRemaining > 0) {
        const take = Math.min(this.frameRemaining, this.buf.length);
        if (take === 0) return;
        this.frameChunks.push(this.buf.subarray(0, take));
        this.buf = this.buf.subarray(take);
        this.frameRemaining -= take;
        if (this.frameRemaining === 0) {
          const png = Buffer.concat(this.frameChunks);
          this.frameChunks = [];
          if (this.onFrame) this.onFrame(png);
        }
        continue;
      }
      const nl = this.buf.indexOf(10);
      if (nl < 0) {
        // Guard only against a runaway header (screenshot responses are large).
        if (this.buf.length > 8 * 1024 * 1024) this.buf = Buffer.alloc(0);
        return;
      }
      const header = this.buf.subarray(0, nl).toString("latin1");
      this.buf = this.buf.subarray(nl + 1);
      if (header.startsWith("#F")) {
        this.frameRemaining = Number(header.slice(2));
        this.frameChunks = [];
        if (!Number.isFinite(this.frameRemaining) || this.frameRemaining <= 0) {
          this.frameRemaining = 0;
          this.frameChunks = [];
        }
      } else if (header.startsWith("#J")) {
        let msg;
        try {
          msg = JSON.parse(header.slice(2));
        } catch {
          continue;
        }
        if (msg.type === "ready" && this._resolveReady) {
          this.isReady = true;
          this._resolveReady(msg);
          this._resolveReady = null;
          this._rejectReady = null;
        }
        const p = this.pending.get(msg.id);
        if (p) {
          this.pending.delete(msg.id);
          p.resolve(msg);
        }
      }
    }
  }

  async _reloadIfNeeded() {
    if (!this.proc || !needsRebuild()) return;
    if (!this._restarting) {
      this._restarting = (async () => {
        log("firmware UI changed — rebuilding display_daemon...");
        ensureBuilt();
        await this.stop();
        this.start();
      })().finally(() => {
        this._restarting = null;
      });
    }
    await this._restarting;
  }

  async send(cmd, { timeout = 20000, checkRebuild = true } = {}) {
    if (checkRebuild) {
      await this._reloadIfNeeded();
    }
    if (this._restarting) {
      await this._restarting;
    }
    this.start();
    if (!this.isReady) {
      let readyTimer;
      await Promise.race([
        this.ready,
        new Promise((_, reject) => {
          readyTimer = setTimeout(() => {
            reject(new Error(`display daemon boot timeout after ${timeout} ms`));
          }, timeout);
        }),
      ]).finally(() => clearTimeout(readyTimer));
    }
    if (!this.proc || !this.proc.stdin?.writable) {
      throw new Error("display_daemon is not running");
    }
    const id = ++this.seq;
    const payload = { ...cmd, id };
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`display daemon timeout after ${timeout} ms for ${cmd.cmd}`));
      }, timeout);
      this.pending.set(id, {
        resolve: (v) => {
          clearTimeout(timer);
          resolve(v);
        },
        reject: (e) => {
          clearTimeout(timer);
          reject(e);
        },
      });
      this.proc.stdin.write(JSON.stringify(payload) + "\n");
    });
  }

  // Fire-and-forget (used by the live view for pointer moves)
  post(cmd) {
    try {
      this.start();
    } catch {
      return;
    }
    if (!this.proc || !this.isReady || !this.proc.stdin?.writable) return;
    const id = ++this.seq;
    this.pending.set(id, { resolve: () => {}, reject: () => {} });
    try {
      this.proc.stdin.write(JSON.stringify({ ...cmd, id, png: 0 }) + "\n");
    } catch {
      this.pending.delete(id);
    }
  }
}

const daemon = new Daemon();

// ---------------------------------------------------------------------------
// Live frame distribution
// ---------------------------------------------------------------------------
const viewers = new Set();
let latestPng = null;
let latestState = null;
let fpsFrames = 0;
let fps = 0;

daemon.onFrame = (png) => {
  latestPng = png;
  fpsFrames++;
  const header = Buffer.alloc(4);
  header.writeUInt32LE(png.length, 0);
  for (const res of viewers) {
    try {
      res.write(header);
      res.write(png);
    } catch {
      viewers.delete(res);
    }
  }
};

setInterval(() => {
  fps = fpsFrames;
  fpsFrames = 0;
}, 1000).unref?.();

// Poll text telemetry a few times a second (cheap, no frames) for the panel.
setInterval(async () => {
  if (!daemon.proc || viewers.size === 0) return;
  try {
    latestState = await daemon.send({ cmd: "state", png: 0 }, { checkRebuild: false });
  } catch {
    /* ignore */
  }
}, 400).unref?.();

// ---------------------------------------------------------------------------
// Web view
// ---------------------------------------------------------------------------
const PAGE = String.raw`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>ADWS Node 01 — Live Display</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { color-scheme: dark; --panel:#14171f; --line:#242b39; --ink:#e8ecf3; --dim:#93a0b6; }
  * { box-sizing: border-box; }
  body {
    margin:0; min-height:100vh; background:radial-gradient(1200px 700px at 50% -10%, #131a26 0%, #070a10 60%);
    color:var(--ink); font:14px/1.45 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
    display:flex; flex-direction:column; align-items:center; padding:22px 18px 32px; gap:16px;
  }
  header { text-align:center; }
  h1 { margin:0; font-size:15px; letter-spacing:.14em; text-transform:uppercase; color:#cbd5e6; font-weight:700; }
  .hint { color:var(--dim); font-size:12px; margin-top:4px; }
  .stage { display:flex; gap:20px; align-items:flex-start; justify-content:center; flex-wrap:wrap; width:100%; max-width:1100px; }
  .device {
    background:linear-gradient(180deg,#171c26,#0e1219); border:1px solid #2b3446;
    border-radius:16px; padding:16px 16px 12px; box-shadow:0 24px 60px rgba(0,0,0,.65), inset 0 1px 0 rgba(255,255,255,.05);
    width:min(672px, 100%);
  }
  .brand { display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; font-size:10px;
           letter-spacing:.22em; color:#7b8aa3; text-transform:uppercase; }
  .pwr { display:flex; align-items:center; gap:6px; letter-spacing:.1em; }
  .pwr i { width:7px; height:7px; border-radius:50%; background:#22c55e; box-shadow:0 0 8px #22c55e; }
  .bezel {
    position:relative; border-radius:6px; padding:0; background:#000;
    border:6px solid #0b0e14; box-shadow:inset 0 0 0 1px #2a3242, 0 0 30px rgba(70,120,255,.08);
    cursor:crosshair; touch-action:none; user-select:none; line-height:0;
    width:min(640px, 100%, calc((100vh - 230px) * 4 / 3));
  }
  canvas { display:block; width:100%; height:auto; aspect-ratio:4/3; image-rendering:pixelated; border-radius:2px; }
  .under { display:flex; justify-content:space-between; margin-top:9px; font:11px/1 ui-monospace,monospace; color:#7f8ea6; }
  .panel {
    width:min(352px, 100%); background:var(--panel); border:1px solid var(--line); border-radius:12px;
    padding:14px; display:flex; flex-direction:column; gap:13px;
  }
  .panel h2 { margin:0 0 7px; font-size:10.5px; letter-spacing:.16em; text-transform:uppercase; color:#8fa0b8; font-weight:700; }
  .row { display:flex; gap:7px; flex-wrap:wrap; }
  button {
    background:#1b2130; color:#e6ebf4; border:1px solid #2e3749; border-radius:7px;
    padding:6px 10px; font-size:11.5px; font-weight:600; cursor:pointer; transition:.12s;
  }
  button:hover { background:#26304a; border-color:#3b4a68; }
  button.alert { background:#3a1220; border-color:#7a1d33; color:#ffd9e1; }
  button.alert:hover { background:#4d1729; }
  button.on { background:#164e2f; border-color:#2f9e63; }
  .kv { display:grid; grid-template-columns:auto 1fr; gap:3px 10px; font:11.5px/1.5 ui-monospace,monospace; }
  .kv span:nth-child(odd) { color:#7d8ca4; }
  .pill { display:inline-flex; align-items:center; gap:6px; background:#0f131b; border:1px solid #232b3a;
          border-radius:6px; padding:4px 8px; font:11px/1 ui-monospace,monospace; color:#b9c6d9; }
  .dot { width:8px; height:8px; border-radius:50%; background:#39445a; }
  .dot.g { background:#22c55e; box-shadow:0 0 9px #22c55e; }
  .dot.a { background:#f59e0b; box-shadow:0 0 9px #f59e0b; }
  .log { background:#080b11; border:1px solid #1d2431; border-radius:7px; padding:8px;
         font:11px/1.5 ui-monospace,monospace; color:#3ddc97; height:104px; overflow:auto; white-space:pre-wrap; }
  .targets { display:flex; flex-wrap:wrap; gap:5px; }
  .targets button { font:10.5px/1 ui-monospace,monospace; padding:5px 7px; }
  input[type=range] { width:100%; accent-color:#dc2638; }
</style>
</head>
<body>
<header>
  <h1>ADWS Node 01 · Live Device View</h1>
  <div class="hint">Real firmware LVGL running now — press, hold (2 s) and drag directly on the panel</div>
</header>

<div class="stage">
  <div class="device">
    <div class="brand"><span>ADWS · ESP32-S3</span><span class="pwr"><i></i>LIVE</span></div>
    <div class="bezel" id="bezel"><canvas id="screen" width="320" height="240"></canvas></div>
    <div class="under">
      <span id="cursor">(---, ---)</span>
      <span id="status">connecting…</span>
    </div>
  </div>

  <div class="panel">
    <div>
      <h2>State</h2>
      <div class="kv">
        <span>screen</span><b id="s-state">—</b>
        <span>service</span><b id="s-svc">—</b>
        <span>clock</span><b id="s-time">—</b>
        <span>request</span><b id="s-call">—</b>
        <span>touch z</span><b id="s-z">0</b>
        <span>fps</span><b id="s-fps">0</b>
      </div>
    </div>

    <div>
      <h2>Pins</h2>
      <div class="row">
        <span class="pill"><i class="dot" id="led-n"></i>17 NOTIFY</span>
        <span class="pill"><i class="dot" id="led-b"></i>18 BUZZER</span>
      </div>
    </div>

    <div>
      <h2>Hardware button (GPIO 1)</h2>
      <div class="row">
        <button onclick="cmd({cmd:'button',mode:'short',png:0})">Tap</button>
        <button onclick="cmd({cmd:'button',mode:'long',png:0})">Hold 2 s → Diagnostics</button>
        <button class="alert" onclick="cmd({cmd:'reset',png:0})">Reboot to Home</button>
        <button onclick="cmd({cmd:'reset',mode:'boot',png:0})">Replay boot</button>
      </div>
    </div>

    <div>
      <h2>Panel pressure (XPT2046)</h2>
      <input id="z" type="range" min="0" max="4095" value="2400">
    </div>

    <div>
      <h2>Touch targets</h2>
      <div class="targets" id="targets"></div>
    </div>

    <div>
      <h2>LoRa 433.0 MHz TX</h2>
      <div class="log" id="log">(idle)</div>
    </div>
  </div>
</div>

<script>
const canvas = document.getElementById('screen');
const ctx = canvas.getContext('2d', { alpha: false });
const bezel = document.getElementById('bezel');
ctx.imageSmoothingEnabled = false;

/* ---- live pixel stream (length-prefixed PNG frames, no polling) ---- */
let downFrames = 0, lastT = performance.now();
async function stream() {
  const res = await fetch('/stream');
  const reader = res.body.getReader();
  let acc = new Uint8Array(0);
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    const merged = new Uint8Array(acc.length + value.length);
    merged.set(acc); merged.set(value, acc.length);
    acc = merged;
    for (;;) {
      if (acc.length < 4) break;
      const len = new DataView(acc.buffer, acc.byteOffset, 4).getUint32(0, true);
      if (acc.length < 4 + len) break;
      const png = acc.slice(4, 4 + len);
      acc = acc.slice(4 + len);
      draw(png);
    }
  }
  document.getElementById('status').textContent = 'stream ended — reconnecting…';
  setTimeout(stream, 500);
}
async function draw(png) {
  try {
    const bmp = await createImageBitmap(new Blob([png], { type: 'image/png' }));
    ctx.drawImage(bmp, 0, 0);
    bmp.close();
    downFrames++;
  } catch (e) {}
}
setInterval(() => {
  const now = performance.now();
  const v = Math.round((downFrames * 1000) / (now - lastT));
  document.getElementById('s-fps').textContent = v === 0 ? 'idle' : String(v);
  downFrames = 0; lastT = now;
}, 1000);
stream();

/* ---- pointer = resistive touch panel ---- */
function toPanel(e) {
  const r = bezel.getBoundingClientRect();
  return {
    x: Math.max(0, Math.min(319, Math.floor(((e.clientX - r.left) / r.width) * 320))),
    y: Math.max(0, Math.min(239, Math.floor(((e.clientY - r.top) / r.height) * 240))),
  };
}
function send(path, body) {
  fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}
bezel.addEventListener('pointerdown', (e) => {
  try { bezel.setPointerCapture(e.pointerId); } catch (err) {}
  const p = toPanel(e);
  send('/input', { action: 'down', x: p.x, y: p.y });
});
bezel.addEventListener('pointermove', (e) => {
  const p = toPanel(e);
  document.getElementById('cursor').textContent = '(' + p.x + ', ' + p.y + ')';
  if (e.buttons) send('/input', { action: 'move', x: p.x, y: p.y });
});
bezel.addEventListener('pointerup', (e) => {
  const p = toPanel(e);
  send('/input', { action: 'up', x: p.x, y: p.y });
});
bezel.addEventListener('pointercancel', () => send('/input', { action: 'up' }));

/* ---- text telemetry ---- */
async function cmd(body) {
  body.png = 0;
  send('/api/cmd', body);
}
document.getElementById('z').addEventListener('change', (e) => {
  send('/api/cmd', { cmd: 'pressure', z: Number(e.target.value), png: 0 });
});

function paint(s) {
  if (!s) return;
  document.getElementById('s-state').textContent = s.state || '—';
  document.getElementById('s-svc').textContent = s.service ? s.service + ' (' + (s.service_id + 1) + '/4)' : '—';
  document.getElementById('s-time').textContent = (s.elapsed_ms / 1000).toFixed(1) + ' s';
  document.getElementById('s-call').textContent = s.call_active ? 'ACTIVE ' + (s.call_remaining_ms / 1000).toFixed(1) + ' s' : 'idle';
  document.getElementById('s-z').textContent = s.pressure_z;
  document.getElementById('led-n').className = 'dot' + (s.pin_notification ? ' g' : '');
  document.getElementById('led-b').className = 'dot' + (s.pin_buzzer ? ' a' : '');
  document.getElementById('status').textContent = s.state + ' · ' + (s.time_scale === 0 ? 'clock frozen' : 'realtime');
  const log = document.getElementById('log');
  log.textContent = (s.lora_log && s.lora_log.length) ? s.lora_log.join('\n') : '(idle)';
  const t = document.getElementById('targets');
  const names = (s.widgets || []).filter(w => w.clickable && w.name).map(w => w.name);
  if (t.dataset.sig !== names.join('|')) {
    t.dataset.sig = names.join('|');
    t.innerHTML = '';
    names.forEach(n => {
      const b = document.createElement('button');
      b.textContent = n;
      b.onclick = () => send('/api/cmd', { cmd: 'click', name: n, png: 0 });
      t.appendChild(b);
    });
  }
}
setInterval(async () => {
  try { paint(await (await fetch('/api/state')).json()); } catch (e) {}
}, 500);
</script>
</body>
</html>`;

function startWebServer() {
  const server = http.createServer((req, res) => {
    const url = req.url.split("?")[0];

    if (req.method === "GET" && (url === "/" || url === "/index.html")) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(PAGE);
      return;
    }

    if (req.method === "GET" && url === "/stream") {
      res.writeHead(200, {
        "Content-Type": "application/octet-stream",
        "Cache-Control": "no-store, no-transform",
        "X-Accel-Buffering": "no",
        Connection: "keep-alive",
      });
      viewers.add(res);
      if (latestPng) {
        const header = Buffer.alloc(4);
        header.writeUInt32LE(latestPng.length, 0);
        res.write(header);
        res.write(latestPng);
      }
      req.on("close", () => viewers.delete(res));
      return;
    }

    if (req.method === "GET" && url === "/api/state") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(latestState || {}));
      return;
    }

    if (req.method === "POST" && (url === "/api/cmd" || url === "/input")) {
      let body = "";
      req.on("data", (c) => (body += c));
      req.on("end", async () => {
        let payload = {};
        try {
          payload = JSON.parse(body || "{}");
        } catch {
          res.writeHead(400).end('{"ok":false}');
          return;
        }
        if (url === "/input") {
          if (process.env.ADWS_DEBUG) log("input", JSON.stringify(payload));
          daemon.post({ cmd: "touch", action: payload.action || "up", x: payload.x, y: payload.y });
          res.writeHead(204).end();
          return;
        }
        try {
          if (process.env.ADWS_DEBUG) log("cmd", JSON.stringify(payload));
          const out = await daemon.send({ ...payload, png: payload.png ?? 0 });
          latestState = out;
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(out));
        } catch (err) {
          res.writeHead(500, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ ok: false, error: String(err.message || err) }));
        }
      });
      return;
    }

    res.writeHead(404).end("not found");
  });

  let portToTry = GUI_PORT;
  const maxPort = GUI_PORT_EXPLICIT ? GUI_PORT : GUI_PORT + 10;

  server.on("error", (err) => {
    if (err.code === "EADDRINUSE" && portToTry < maxPort) {
      portToTry++;
      server.listen(portToTry, "127.0.0.1");
      return;
    }
    log(`web view: ${err.code === "EADDRINUSE" ? `port ${portToTry} already in use` : err.message}`);
  });
  server.listen(portToTry, "127.0.0.1", () => {
    activeGuiPort = portToTry;
    log(`live view: http://127.0.0.1:${activeGuiPort}`);
  });
  return server;
}

function openWindow() {
  const url = `http://127.0.0.1:${activeGuiPort}/`;
  const args = [`--app=${url}`, "--window-size=1060,720", "--window-position=80,60",
                "--class=ADWS-Display", "--no-first-run", "--no-default-browser-check"];
  try {
    spawn("google-chrome", args, { detached: true, stdio: "ignore" }).unref();
    log("desktop window opened");
  } catch {
    log("could not launch google-chrome; open " + url);
  }
}

// ---------------------------------------------------------------------------
// MCP presentation
// ---------------------------------------------------------------------------
function summary(res) {
  const clickable = (res.widgets || [])
    .filter((w) => w.clickable && w.name)
    .map((w) => `  - ${w.name}  centre (${w.cx}, ${w.cy})  box [${w.x},${w.y} ${w.w}x${w.h}]`)
    .join("\n");
  const texts = (res.widgets || []).filter((w) => w.text).map((w) => `"${w.text}"`).join(", ");
  const lora = (res.lora_log || []).length ? res.lora_log.map((l, i) => `  ${i + 1}. ${l}`).join("\n") : "  (none)";
  const clock = res.time_scale === 0 ? "FROZEN" : `${res.time_scale}x realtime`;

  return [
    `Device: ADWS Node 01 · 320x240 RGB565 · ${clock}`,
    `Action: ${res.note}`,
    `Screen: ${res.state} · service ${res.service} (${res.service_id + 1}/4) · t=${(res.elapsed_ms / 1000).toFixed(2)} s`,
    `Request: ${res.call_active ? `ACTIVE (${(res.call_remaining_ms / 1000).toFixed(1)} s left)` : "idle"} · buzzer ${res.pin_buzzer ? "ON" : "off"} · notify ${res.pin_notification ? "ON" : "off"}`,
    `Touch: ${res.pressed ? `down at (${res.touch_x}, ${res.touch_y})` : "up"} · pressure Z ${res.pressure_z}`,
    `LoRa 433.0 MHz TX (${res.lora_tx_count}):\n${lora}`,
    `On screen: ${texts}`,
    `Targets:\n${clickable || "  (none)"}`,
    `Live view: http://127.0.0.1:${activeGuiPort} (~${fps} fps streaming)`,
  ].join("\n");
}

const tools = [
  {
    name: "display_screenshot",
    description:
      "Capture the current state of the live 320x240 display (the real firmware LVGL running in realtime), including widget geometry, pin states and the LoRa TX log.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "display_click",
    description:
      "Touch the live display at (x, y) or by widget name, e.g. 'home_prev_btn', 'home_next_btn', 'home_call_bar', 'home_demo', 'top_gear_btn', 'calling_abort_btn', 'config_cal_btn'. Real touch: press, hold, release, then return the updated screen.",
    inputSchema: {
      type: "object",
      properties: {
        x: { type: "integer", minimum: 0, maximum: 319 },
        y: { type: "integer", minimum: 0, maximum: 239 },
        name: { type: "string", description: "Widget name instead of coordinates" },
        hold_ms: { type: "integer", minimum: 20, maximum: 5000, default: 90 },
        settle_ms: { type: "integer", minimum: 0, maximum: 5000, default: 140 },
      },
    },
  },
  {
    name: "display_long_press",
    description:
      "Press and hold the panel for hold_ms (e.g. 1200 ms on the slideshow card to see the 2 s hold-to-exit progress bar, or 2100 ms to exit).",
    inputSchema: {
      type: "object",
      properties: {
        x: { type: "integer", minimum: 0, maximum: 319 },
        y: { type: "integer", minimum: 0, maximum: 239 },
        name: { type: "string" },
        hold_ms: { type: "integer", minimum: 50, maximum: 10000, default: 2100 },
        release: { type: "boolean", default: true, description: "false keeps the finger down" },
      },
    },
  },
  {
    name: "display_touch",
    description:
      "Raw single-finger panel control: action 'down' (x,y), 'move' (x,y) or 'up'. Use it for multi-step gestures; the stream updates between calls.",
    inputSchema: {
      type: "object",
      properties: {
        action: { type: "string", enum: ["down", "move", "up"] },
        x: { type: "integer", minimum: 0, maximum: 319 },
        y: { type: "integer", minimum: 0, maximum: 239 },
      },
      required: ["action"],
    },
  },
  {
    name: "display_drag",
    description: "Drag across the panel from (from_x, from_y) to (to_x, to_y) over duration_ms.",
    inputSchema: {
      type: "object",
      properties: {
        from_x: { type: "integer", minimum: 0, maximum: 319 },
        from_y: { type: "integer", minimum: 0, maximum: 239 },
        to_x: { type: "integer", minimum: 0, maximum: 319 },
        to_y: { type: "integer", minimum: 0, maximum: 239 },
        duration_ms: { type: "integer", minimum: 60, maximum: 5000, default: 320 },
      },
      required: ["from_x", "from_y", "to_x", "to_y"],
    },
  },
  {
    name: "display_gpio_button",
    description:
      "Press the physical GPIO 1 button: 'short' tap dispatches a request on Home / cancels while requesting; 'long' (2 s) opens Diagnostics.",
    inputSchema: {
      type: "object",
      properties: { mode: { type: "string", enum: ["short", "long"], default: "short" } },
    },
  },
  {
    name: "display_set_pressure",
    description: "Set the simulated XPT2046 touch pressure Z (0..4095) shown in the telemetry strip and Diagnostics gauge.",
    inputSchema: {
      type: "object",
      properties: { z: { type: "integer", minimum: 0, maximum: 4095 } },
      required: ["z"],
    },
  },
  {
    name: "display_wait",
    description:
      "Let the device run for ms of real time (e.g. 1500 ms during a 5 s request to watch the countdown bar and buzzer toggle).",
    inputSchema: {
      type: "object",
      properties: { ms: { type: "integer", minimum: 0, maximum: 30000, default: 1000 } },
    },
  },
  {
    name: "display_time_scale",
    description:
      "Set the device clock speed. 1 = realtime, 0 = freeze the clock (screens stay interactive), 2..20 = fast-forward.",
    inputSchema: {
      type: "object",
      properties: { scale: { type: "number", minimum: 0, maximum: 20 } },
      required: ["scale"],
    },
  },
  {
    name: "display_reset",
    description: "Reboot the device: 'home' for a clean Home screen, 'boot' to replay the real 2.4 s ADWS splash, or boot_percent 0..100 to park on the splash.",
    inputSchema: {
      type: "object",
      properties: {
        mode: { type: "string", enum: ["home", "boot"], default: "home" },
        boot_percent: { type: "integer", minimum: 0, maximum: 100 },
      },
    },
  },
  {
    name: "display_open_window",
    description: "Open the live device view in its own desktop window (Chrome app window) and return the URL.",
    inputSchema: { type: "object", properties: {} },
  },
];

function toMcpResponse(res) {
  const content = [{ type: "text", text: summary(res) }];
  if (res.png_base64) {
    content.push({ type: "image", data: res.png_base64, mimeType: "image/png" });
  }
  return { isError: res.ok === false, content };
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
startWebServer();

if (MCP_STDIO) {
  const server = new Server(
    { name: "adws-display", version: "2.0.0" },
    { capabilities: { tools: {} } }
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools }));

  server.setRequestHandler(CallToolRequestSchema, async (req) => {
    const { name, arguments: args = {} } = req.params;

    try {
      switch (name) {
        case "display_screenshot":
          return toMcpResponse(await daemon.send({ cmd: "screenshot" }));
        case "display_click":
          return toMcpResponse(
            await daemon.send({ cmd: "click", x: args.x, y: args.y, name: args.name, hold_ms: args.hold_ms ?? 90, settle_ms: args.settle_ms ?? 280 })
          );
        case "display_long_press":
          return toMcpResponse(
            await daemon.send({
              cmd: "long_press",
              x: args.x,
              y: args.y,
              name: args.name,
              hold_ms: args.hold_ms ?? 2100,
              release: args.release === false ? 0 : 1,
            })
          );
        case "display_touch":
          return toMcpResponse(
            await daemon.send({ cmd: "touch", action: args.action, x: args.x, y: args.y })
          );
        case "display_drag":
          return toMcpResponse(
            await daemon.send({
              cmd: "drag",
              from_x: args.from_x,
              from_y: args.from_y,
              to_x: args.to_x,
              to_y: args.to_y,
              duration_ms: args.duration_ms ?? 320,
            })
          );
        case "display_gpio_button":
          return toMcpResponse(await daemon.send({ cmd: "button", mode: args.mode || "short" }));
        case "display_set_pressure":
          return toMcpResponse(await daemon.send({ cmd: "pressure", z: args.z ?? 0 }));
        case "display_wait":
          return toMcpResponse(await daemon.send({ cmd: "wait", ms: args.ms ?? 1000 }, { timeout: 40000 }));
        case "display_time_scale":
          return toMcpResponse(await daemon.send({ cmd: "time_scale", scale: args.scale ?? 1 }));
        case "display_reset":
          return toMcpResponse(
            await daemon.send({ cmd: "reset", mode: args.mode || "home", boot_percent: args.boot_percent })
          );
        case "display_open_window": {
          openWindow();
          const st = await daemon.send({ cmd: "state", png: 0 });
          return toMcpResponse({ ...st, note: `Live device window opened at http://127.0.0.1:${activeGuiPort}/` });
        }
        default:
          throw new Error(`Unknown tool: ${name}`);
      }
    } catch (err) {
      return {
        isError: true,
        content: [{ type: "text", text: `adws-display error: ${err?.message || String(err)}` }],
      };
    }
  });

  await server.connect(new StdioServerTransport());
  log("MCP server ready (stdio)");

  try {
    daemon.start();
  } catch (err) {
    log("initial daemon start deferred: " + (err?.message || err));
  }
  if (WANT_WINDOW) setTimeout(openWindow, 700);
} else {
  daemon.start();
  if (WANT_WINDOW) setTimeout(openWindow, 700);
  log(`GUI only — open http://127.0.0.1:${activeGuiPort}`);
}

const shutdown = () => {
  try {
    daemon.proc?.stdin.write(JSON.stringify({ cmd: "quit" }) + "\n");
  } catch {}
  setTimeout(() => process.exit(0), 150);
};
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
