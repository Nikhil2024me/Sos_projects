# ADWS Live Display — device emulator + MCP server

A live, interactive stand-in for the physical board, not a screenshot renderer.
The **real firmware UI** (`sos_lvgl/src/ui/*.c` + `src/assets/*.c`) is compiled
into a native LVGL 9.6 process that boots like the ESP32-S3 and then runs the
same `loop()` forever: touching it changes it, animations run on their own, and
every drawn frame is streamed out as it happens.

```
sos_lvgl/src/ui/*.c ──┐
sos_lvgl/src/assets ──┼──> display_daemon (native LVGL 9.6) ──frames──> index.mjs ──> browser / MCP
firmware state machine ┘        boot → home → service → request → diagnostics
```

## Run

```bash
node index.mjs            # MCP server over stdio + live view on http://127.0.0.1:4320
node index.mjs --window   # same, and opens the live view in its own desktop window
node index.mjs --gui-only --window   # only the device view (no MCP)
ADWS_SIM_PORT=4399 node index.mjs    # different port
```

The daemon is rebuilt automatically whenever `display_daemon.c`,
`sos_lvgl/src/ui/*` or `sos_lvgl/src/assets/*` is newer than the binary.

## What it emulates (1:1 with `sos_lvgl.ino`)

| Behaviour | Value |
| :-- | :-- |
| Touch | `LV_INDEV_TYPE_POINTER`, 90 ms resistive dropout hold, long-press 2000 ms |
| Request | `CALL_DURATION_MS` 5000, 800 ms cancel guard, buzzer toggle every 500 ms |
| GPIO 1 button | tap = dispatch / cancel, 2 s hold = Diagnostics |
| Pins | `PIN_NOTIFICATION` (GPIO 17), `PIN_BUZZER` (GPIO 18) |
| XPT2046 | raw pressure Z sampled every 250 ms while pressed (jitter included) |
| Uptime | updated every 1000 ms |
| LoRa | 433E6 TX packet log (`ADWS|NODE:01|REQ:...` / `...|CANCEL:...`) |
| Boot | ADWS splash with the real 2.4 s progress sequence |

## MCP tools (`adws-display`)

| Tool | Purpose |
| :-- | :-- |
| `display_screenshot` | Current frame + widget geometry, pins, LoRa log |
| `display_click` | Touch by `{x,y}` or `{name}` (e.g. `home_call_bar`, `calling_abort_btn`) |
| `display_long_press` | Hold for `hold_ms` (`release:false` keeps the finger down) |
| `display_touch` | Raw `down` / `move` / `up` for multi-step gestures |
| `display_drag` | Drag over `duration_ms` |
| `display_gpio_button` | Physical button `short` / `long` |
| `display_set_pressure` | XPT2046 raw Z 0..4095 |
| `display_wait` | Let the device run for `ms` of real time |
| `display_time_scale` | `1` realtime, `0` freeze the firmware clock, `2..20` fast-forward |
| `display_reset` | `home`, or `boot` to replay the splash (`boot_percent` 0..100) |
| `display_open_window` | Open the live view in a desktop window |

Registered in `~/.config/opencode/opencode.jsonc` as `adws-display`; restart
OpenCode after editing the server for the tool list to reload.

## Live view

`http://127.0.0.1:4320` shows the panel in a device bezel. Frames arrive over a
length-prefixed PNG stream (`GET /stream`) and are drawn to a canvas — no
polling, no page reloads. Press, hold (2 s) and drag on the panel; the browser
sends `pointerdown/move/up` to `POST /input`.

* `GET /api/state` — latest telemetry JSON
* `POST /api/cmd` — any daemon command (`{"cmd":"click","name":"home_next_btn"}`)
* `POST /input` — `{action:"down"|"move"|"up", x, y}`

## Files

| File | Role |
| :-- | :-- |
| `display_daemon.c` | LVGL device: display + pointer indev, firmware state machine, PNG frames on stdout, JSON commands on stdin |
| `build.sh` | Builds the daemon against the simulator's `liblvgl.a` and `sos_lvgl` sources |
| `index.mjs` | MCP server, frame fan-out, HTTP live view, window launcher |

Wire protocol between daemon and server: `#F<len>\n<PNG bytes>` for a frame and
`#J<json>\n` for a command reply (`id` echoed, `png:0` suppresses base64).
