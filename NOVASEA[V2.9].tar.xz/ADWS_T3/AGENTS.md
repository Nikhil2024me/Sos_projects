# AGENTS.md

The Arduino sketch and all project files live in `sos_lvgl/` (not the workspace root). Read `sos_lvgl/CONTEXT.md` and `sos_lvgl/README.md` for full hardware, pinout, and state-machine details.

## Commands (run from `sos_lvgl/`)

### 1. Sync library configs before compiling firmware
`arduino-cli` reads `lv_conf.h` and `User_Setup.h` from `~/Arduino/libraries/`, not from `sos_lvgl/config/`. Use `cmp` before copying so unchanged headers do not re-trigger a full LVGL rebuild:
```bash
cmp -s config/User_Setup.h ~/Arduino/libraries/TFT_eSPI/User_Setup.h || cp config/User_Setup.h ~/Arduino/libraries/TFT_eSPI/User_Setup.h
cmp -s config/lv_conf.h ~/Arduino/libraries/lv_conf.h || cp config/lv_conf.h ~/Arduino/libraries/lv_conf.h
cmp -s config/lv_conf.h ~/Arduino/libraries/lvgl/lv_conf.h || cp config/lv_conf.h ~/Arduino/libraries/lvgl/lv_conf.h
```

### 2. Compile firmware
Pass `--build-path ./build` to reuse the cached core/LVGL object files in `sos_lvgl/build/`:
```bash
arduino-cli compile --build-path ./build \
  --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB" \
  .
```

### 3. Headless LVGL 9.6 simulator & screenshots
- **Single screen / fast verification (via `lvgl-simulator` MCP tool):**
  Call `lvgl_render_project` with:
  - `root`: `"/home/debian/ADWS_T3/sos_lvgl"`
  - `entry`: any function in `sim/sim_ui_init.c` (e.g., `sim_boot`, `sim_home`, `sim_service_ambulance`, `sim_calling_ambulance`, `sim_config`, `sim_slideshow_1`, `sim_slideshow_hold`)
  - `width`: `320`, `height`: `240`, `board`: `"generic-320x240"`, `color_format`: `"rgb565"`, `mem_budget_kb`: `64`
  - `fonts`: `["montserrat_12", "montserrat_14", "montserrat_16", "montserrat_20", "montserrat_28"]`
- **Regenerate all screenshots and HTML gallery:**
  ```bash
  node tools/render_screenshots.mjs
  python3 tools/make_gallery.py
  ```
  (`render_screenshots.mjs` requires `/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server/dist/index.js`.)

### 3b. Live device emulator (`adws-display` MCP + browser view)
`display-sim-mcp/` compiles the real `src/ui/` + `src/assets/` code into a native
LVGL daemon that boots like the board and then runs `loop()` continuously, so
touch, the 5 s request timer, buzzer toggling, the GPIO 1 button and the LoRa TX
log all behave in real time.
```bash
node display-sim-mcp/index.mjs --window   # live view on http://127.0.0.1:4320
```
MCP tools: `display_click` / `display_long_press` / `display_touch` /
`display_drag` (by `{x,y}` or widget `name`), `display_gpio_button`,
`display_set_pressure`, `display_wait`, `display_time_scale` (0 = freeze the
firmware clock), `display_reset` (`home` or `boot`), `display_screenshot`,
`display_open_window`. The daemon rebuilds automatically when the UI sources
change; see `display-sim-mcp/README.md` for the stdout/stdin frame protocol.

### 4. Regenerate C image assets (do not hand-edit `src/assets/*.c`)
```bash
python3 tools/gen_color_art.py      # Renders SVGs -> art/raw/*.png
python3 tools/gen_color_assets.py   # art/raw/*.png -> src/assets/color_*.c + assets.h
python3 tools/gen_boot_assets.py    # art/raw/adws_boot.png -> src/assets/boot_*.c + boot_assets.h
```

### 5. Package release bundle
```bash
tools/package_release.sh            # Writes zip + preview to /home/debian/Downloads/Saves/
```

## Architecture & Non-Obvious Wiring

- **Dual-target UI layer (`src/ui/`):** Written in pure C against LVGL 9.6 so the exact same files compile into `sos_lvgl.ino` (ESP32-S3 firmware) and `sim/sim_ui_init.c` (headless simulator). Do not include Arduino or hardware headers inside `src/ui/`.
- **Official LVGL 9.6 `lv_indev` pointer & event-driven callbacks (`ui_callbacks_t`):** Firmware registers an `LV_INDEV_TYPE_POINTER` input device (`touch_read_cb` calling `tft.getTouch(&x, &y, 600)`) and wires `ui_set_callbacks(&app_ui_cbs)` (`src/ui/ui_common.h`). Interactive widgets use `ui_make_clickable()`, `ui_bubble_children()`, and `lv_obj_add_event_cb()` (`LV_EVENT_CLICKED` / `LV_EVENT_SHORT_CLICKED` / `LV_EVENT_PRESSING`). Touch calibration is persisted in NVS (`Preferences` namespace `"sos_ui"`, fallback `"weather"` or `{450, 3432, 370, 3379, 3}`) and can be re-run from the `CAL` button on the Diagnostics screen.
- **Shared Service / Slideshow screen:** `ui_show_service()` (`src/ui/screen_service.c`) and `ui_show_slideshow()` (`src/ui/screen_slideshow.c`) both delegate to `ui_show_slide()`.
- **Screen lifecycle & static pointers:** `ui_screen_begin()` calls `lv_obj_clean(lv_screen_active())` and invokes `ui_home_reset()`, `ui_config_reset()`, `ui_boot_reset()`, and `ui_slide_reset()`. Any screen storing static `lv_obj_t *` pointers for live telemetry/clock updates must null them in its reset hook so `ui_update_pressure()` / `ui_update_uptime()` never dereference freed objects.
- **Persistent top-layer overlays:** `ui_init()` builds the telemetry strip (`y = 225..239`) and slideshow hold-progress bar (`y = 223..224`) on `lv_layer_top()`. Screens that leave telemetry visible must keep content within `y = 0..224`.

## Constraints & Gotchas

- **Strict 64 KB LVGL heap (`LV_MEM_SIZE = 65536`):**
  - Never use `transform_scale` / `transform_zoom` on medium or large objects (a scaled 150 px ring allocates a ~224 KB layer buffer and blows the heap). Animate width/height and position instead (see `src/ui/screen_calling.c`).
- **LVGL 9.6 API rules:**
  - `lv_obj_add_flag` / `lv_obj_remove_flag` are deprecated in this setup; use `lv_obj_set_hidden()`, `lv_obj_set_scrollable()`, and `lv_obj_set_clickable()`.
  - Name widgets via `ui_name(obj, "...")` (`LV_USE_OBJ_NAME = 1`) for simulator inspection and diagnostics.
  - Enabled widgets in `config/lv_conf.h`: only `arc`, `bar`, `image`, `label`, and `line` (`LV_USE_BUTTON` is `0`; buttons/cards are styled `lv_obj` boxes via `ui_box`/`ui_card`).
  - Enabled fonts: only `lv_font_montserrat_12`, `_14`, `_16`, `_20`, and `_28`.
  - Account for border widths when sizing child labels (a `2 px` border reduces the parent content width by `4 px` and will trigger simulator `OUTSIDE_PARENT` warnings if ignored).
- **Hardware pin & radio constraints (ESP32-S3 N16R8):**
  - Never assign GPIOs `26..32` (SPI flash) or `33..37` (Octal PSRAM).
  - Canonical display & touch pinout on this physical board (`config/User_Setup.h`): `TFT_SCLK=12`, `TFT_MOSI=11`, `TFT_MISO=13`, `TFT_CS=10`, `TFT_DC=7`, `TFT_RST=6`, `TFT_BL=21`, `TOUCH_CS=15`, `TOUCH_IRQ=16`, `TFT_RGB_ORDER=TFT_BGR`. Never assign LoRa or other I/O to GPIO 6 (`TFT_RST`) or GPIO 7 (`TFT_DC`).
  - **`#define USE_FSPI_PORT` in `config/User_Setup.h` is mandatory on ESP32-S3 with Arduino-ESP32 3.x + TFT_eSPI 2.5.43:** Without it, `TFT_eSPI_ESP32_S3.h` sets `SPI_PORT` to `FSPI` (`0` in core 3.x), making `REG_SPI_BASE(0)` evaluate to `0x0` and crashing with `StoreProhibited` (`EXCVADDR: 0x00000010`) inside `tft.init()`.
