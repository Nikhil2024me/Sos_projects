// ADWS 433 MHz LoRa Test Receiver (ESP32 + SX1278 + 128x32 SSD1306 OLED)
// Location: /home/debian/ADWS_T3/Rev/Rev.ino
// Target:   Standard ESP32 (esp32:esp32:esp32)
//
// Receives LoRa packets at 433.0 MHz (433E6, SF7, BW 125 kHz, CR 4/5, Sync 0x12),
// displays the received message on the 128x32 I2C OLED for a full 5.0 seconds
// (5000 ms) with a live bottom progress bar, and then clears the display.

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------------------------------------------------------------------------
// 1. Pin Map (Standard ESP32)
// ---------------------------------------------------------------------------
// 128x32 SSD1306 I2C OLED
#define OLED_SDA      21
#define OLED_SCL      22
#define OLED_ADDR     0x3C
#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 32

// SX1278 LoRa Module (VSPI)
#define LORA_SCK      18
#define LORA_MISO     19
#define LORA_MOSI     23
#define LORA_NSS      5
#define LORA_RST      14   // Also pulses GPIO 4 in case RST is wired to D4
#define LORA_RST_ALT  4
#define LORA_DIO0     2

static const uint32_t CLEAR_TIMEOUT_MS = 5000UL; // 5.0 seconds (5000 ms)

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

static bool oled_ok = false;
static bool lora_ok = false;
static bool msg_showing = false;
static uint32_t msg_rx_ms = 0;
static uint32_t last_bar_draw_ms = 0;
static char active_msg[256] = {0};
static int active_rssi = 0;

// ---------------------------------------------------------------------------
// SX1278 Register-Level 433 MHz Continuous Receiver
// ---------------------------------------------------------------------------
static void lora_write(uint8_t reg, uint8_t value)
{
    digitalWrite(LORA_NSS, LOW);
    SPI.transfer(reg | 0x80);
    SPI.transfer(value);
    digitalWrite(LORA_NSS, HIGH);
}

static uint8_t lora_read(uint8_t reg)
{
    digitalWrite(LORA_NSS, LOW);
    SPI.transfer(reg & 0x7F);
    uint8_t val = SPI.transfer(0x00);
    digitalWrite(LORA_NSS, HIGH);
    return val;
}

static bool lora_init_rx_433(void)
{
    pinMode(LORA_NSS, OUTPUT);
    digitalWrite(LORA_NSS, HIGH);

    pinMode(LORA_RST, OUTPUT);
    pinMode(LORA_RST_ALT, OUTPUT);
    digitalWrite(LORA_RST, LOW);
    digitalWrite(LORA_RST_ALT, LOW);
    delay(15);
    digitalWrite(LORA_RST, HIGH);
    digitalWrite(LORA_RST_ALT, HIGH);
    delay(15);

    pinMode(LORA_DIO0, INPUT);

    SPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_NSS);
    SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));

    uint8_t ver = lora_read(0x42); // RegVersion
    if (ver == 0x12) {
        // 1. LoRa Sleep mode
        lora_write(0x01, 0x80);
        delay(5);
        // 2. Frequency = 433.0 MHz (433E6 -> FRF = 0x6C4000)
        lora_write(0x06, 0x6C);
        lora_write(0x07, 0x40);
        lora_write(0x08, 0x00);
        // 3. FIFO pointers
        lora_write(0x0E, 0x00);
        lora_write(0x0F, 0x00);
        lora_write(0x0D, 0x00);
        // 4. LNA max gain + Auto AGC
        lora_write(0x0C, lora_read(0x0C) | 0x03);
        lora_write(0x26, 0x04);
        // 5. BW 125 kHz, CR 4/5, Explicit Header, SF7, CRC On
        lora_write(0x1D, 0x72);
        lora_write(0x1E, 0x74);
        lora_write(0x31, 0xC3);
        lora_write(0x37, 0x0A);
        lora_write(0x20, 0x00);
        lora_write(0x21, 0x08);
        lora_write(0x39, 0x12); // SyncWord = 0x12
        lora_write(0x12, 0xFF); // Clear all IRQ flags
        // 6. Enter LoRa Continuous RX mode (0x85)
        lora_write(0x01, 0x85);
    }
    SPI.endTransaction();

    Serial.printf("LoRa SX1278 RX: version 0x%02X (%s @ 433.0 MHz)\n",
                  ver, ver == 0x12 ? "LISTENING" : "not detected");
    return (ver == 0x12);
}

static void extract_field(const char *src, const char *key, char *out, size_t out_sz)
{
    out[0] = '\0';
    const char *p = strstr(src, key);
    if (!p) return;
    p += strlen(key);
    size_t i = 0;
    while (p[i] != '\0' && p[i] != '|' && i + 1 < out_sz) {
        out[i] = p[i];
        i++;
    }
    out[i] = '\0';
}

static void render_active_message(uint32_t elapsed_ms)
{
    if (!oled_ok) return;

    char service[24] = {0};
    char prio[16]    = {0};
    char seq[12]     = {0};
    char cancel[16]  = {0};

    extract_field(active_msg, "SERVICE:", service, sizeof(service));
    extract_field(active_msg, "PRI:", prio, sizeof(prio));
    extract_field(active_msg, "SEQ:", seq, sizeof(seq));
    extract_field(active_msg, "CANCEL:", cancel, sizeof(cancel));

    uint32_t rem_ms = (elapsed_ms < CLEAR_TIMEOUT_MS) ? (CLEAR_TIMEOUT_MS - elapsed_ms) : 0;
    int bar_w = (int)((rem_ms * 128UL) / CLEAR_TIMEOUT_MS);

    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);

    if (cancel[0] != '\0') {
        display.setTextSize(1);
        display.setCursor(0, 0);
        display.printf("CANCEL #%s (%lu.%lus)", seq[0] ? seq : "?",
                       (unsigned long)(rem_ms / 1000),
                       (unsigned long)((rem_ms % 1000) / 100));
        display.setTextSize(2);
        display.setCursor(0, 11);
        display.print(cancel);
    } else if (service[0] != '\0') {
        display.setTextSize(1);
        display.setCursor(0, 0);
        display.printf("%s #%s %ddBm %lu.%lus",
                       prio[0] ? prio : "SOS",
                       seq[0] ? seq : "1",
                       active_rssi,
                       (unsigned long)(rem_ms / 1000),
                       (unsigned long)((rem_ms % 1000) / 100));
        display.setTextSize(2);
        display.setCursor(0, 11);
        display.print(service);
    } else {
        display.setTextSize(1);
        display.setCursor(0, 0);
        display.printf("RX %ddBm (%lu.%lus):", active_rssi,
                       (unsigned long)(rem_ms / 1000),
                       (unsigned long)((rem_ms % 1000) / 100));
        display.setCursor(0, 12);
        display.print(active_msg);
    }

    if (bar_w > 0) {
        display.fillRect(0, 30, bar_w, 2, SSD1306_WHITE);
    }
    display.display();
}

static void show_boot_status(void)
{
    if (!oled_ok) return;
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("ADWS 433MHz RECEIVER");
    display.setCursor(0, 12);
    display.println(lora_ok ? "LoRa SX1278: READY" : "LoRa: CHECK WIRING");
    display.setCursor(0, 22);
    display.println("Waiting for SOS...");
    display.display();
}

static void poll_lora_rx(void)
{
    if (!lora_ok) return;

    SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
    uint8_t irq = lora_read(0x12); // RegIrqFlags

    // Bit 6 (0x40) = RxDone
    if (irq & 0x40) {
        bool crc_err = (irq & 0x20) != 0;
        uint8_t len  = lora_read(0x13); // RegRxNbBytes
        uint8_t addr = lora_read(0x10); // RegFifoRxCurrentAddr
        lora_write(0x0D, addr);         // RegFifoAddrPtr

        char buf[256];
        for (uint8_t i = 0; i < len; i++) {
            buf[i] = (char)lora_read(0x00);
        }
        buf[len] = '\0';

        // RSSI in dBm for LF port (433 MHz): -164 + PktRssi
        int rssi = (int)lora_read(0x1A) - 164;

        // Clear all IRQ flags
        lora_write(0x12, 0xFF);
        SPI.endTransaction();

        if (!crc_err && len > 0) {
            Serial.printf("LoRa RX @ 433E6 [%u B, RSSI %d dBm]: %s\n",
                          (unsigned)len, rssi, buf);
            strncpy(active_msg, buf, sizeof(active_msg) - 1);
            active_msg[sizeof(active_msg) - 1] = '\0';
            active_rssi = rssi;
            msg_showing = true;
            msg_rx_ms = millis();
            last_bar_draw_ms = msg_rx_ms;
            render_active_message(0);
        } else {
            Serial.println("LoRa RX: CRC error, packet dropped");
        }
        return;
    }

    SPI.endTransaction();
}

void setup()
{
    Serial.begin(115200);
    delay(100);
    Serial.println("\nADWS 433MHz LoRa Receiver (ESP32 + SX1278 + 128x32 OLED)");

    Wire.begin(OLED_SDA, OLED_SCL);
    oled_ok = display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);
    if (!oled_ok) {
        Serial.println("OLED 128x32 not found at 0x3C");
    }

    lora_ok = lora_init_rx_433();
    show_boot_status();

    // Show boot splash for 2 seconds, then clear until a LoRa message arrives
    delay(2000);
    if (oled_ok) {
        display.clearDisplay();
        display.display();
    }
}

void loop()
{
    const uint32_t now = millis();

    // Retry LoRa init every 3 seconds if module was hot-plugged
    static uint32_t last_retry_ms = 0;
    if (!lora_ok && (now - last_retry_ms >= 3000)) {
        last_retry_ms = now;
        lora_ok = lora_init_rx_433();
    }

    poll_lora_rx();

    // Keep the received message on screen for the full 5000 ms (5.0 seconds)
    if (msg_showing) {
        uint32_t elapsed = now - msg_rx_ms;
        if (elapsed >= CLEAR_TIMEOUT_MS) {
            msg_showing = false;
            if (oled_ok) {
                display.clearDisplay();
                display.display();
            }
            Serial.println("OLED cleared after 5000 ms");
        } else if (now - last_bar_draw_ms >= 100) {
            last_bar_draw_ms = now;
            render_active_message(elapsed);
        }
    }

    delay(10);
}
