#include "src/ui/ui_common.h"
#include "src/assets/boot_assets.h"

// ---------------------------------------------------------------------------
// Boot splash: the ADWS wordmark (cropped from the source artwork) over a
// striped blue progress bar.  The fill width, percentage and status line all
// follow the boot progress.
// ---------------------------------------------------------------------------
#define BOOT_BAR_X   75
#define BOOT_BAR_Y   161
#define BOOT_BAR_W   170
#define BOOT_BAR_H   14

static lv_obj_t *boot_fill;
static lv_obj_t *boot_pct;
static lv_obj_t *boot_status;

void ui_boot_reset(void)
{
    boot_fill = NULL;
    boot_pct = NULL;
    boot_status = NULL;
}

static const char *boot_stage_text(int32_t v)
{
    if (v < 10) return "Power on...";
    if (v < 35) return "Display ready";
    if (v < 60) return "LoRa init...";
    if (v < 85) return "Touch ready";
    if (v < 100) return "Finalising...";
    return "System online";
}

// Apply a progress value to the bar, percentage and status text.
static void boot_apply(int32_t percent, const char *status)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    if (boot_fill != NULL) {
        lv_obj_set_width(boot_fill, 1 + (percent * (BOOT_BAR_W - 1)) / 100);
    }
    if (boot_pct != NULL) {
        lv_label_set_text_fmt(boot_pct, "%d%%.", (int)percent);
    }
    if (boot_status != NULL) {
        lv_label_set_text(boot_status, status != NULL ? status
                                                      : boot_stage_text(percent));
    }
}

static void boot_tick_cb(void *var, int32_t v)
{
    (void)var;
    boot_apply(v, boot_stage_text(v));
}

static void boot_deleted(lv_event_t *e)
{
    lv_obj_t *pct = lv_event_get_target(e);
    lv_anim_delete(pct, boot_tick_cb);
    ui_boot_reset();
}

void ui_boot_set_progress(uint8_t percent, const char *status)
{
    if (boot_pct != NULL) lv_anim_delete(boot_pct, boot_tick_cb);
    boot_apply(percent, status);
}

void ui_show_boot(void)
{
    lv_obj_t *scr = ui_screen_begin(lv_color_hex(0x000000), lv_color_hex(0x000000));
    ui_telemetry_set_visible(false);

    // ------------------------------------------------------------- wordmark
    lv_obj_t *logo = lv_image_create(scr);
    lv_image_set_src(logo, &boot_adws);
    lv_obj_set_pos(logo, 30, 30);
    lv_obj_set_scrollable(logo, false);
    ui_name(logo, "boot_logo");

    // ------------------------------------------------------------- bar holder
    lv_obj_t *holder = ui_card(scr, 70, 156, 180, 24, lv_color_hex(0x1D1D1D),
                               lv_color_hex(0x1D1D1D), 0, 8);
    ui_name(holder, "boot_bar_holder");

    // Light track inside the holder.
    ui_card(scr, BOOT_BAR_X, BOOT_BAR_Y, BOOT_BAR_W, BOOT_BAR_H,
            lv_color_hex(0xE3F1FD), lv_color_hex(0xE3F1FD), 0, 7);

    // Blue striped fill, revealed by animating its width.
    boot_fill = ui_card(scr, BOOT_BAR_X, BOOT_BAR_Y, 1, BOOT_BAR_H,
                        lv_color_hex(0x2695F2), lv_color_hex(0x2695F2), 0, 7);
    lv_obj_set_style_bg_image_src(boot_fill, &boot_stripe, 0);
    lv_obj_set_style_bg_image_tiled(boot_fill, true, 0);
    lv_obj_set_style_bg_image_opa(boot_fill, LV_OPA_COVER, 0);
    lv_obj_set_clickable(boot_fill, false);
    ui_name(boot_fill, "boot_bar_fill");

    // ------------------------------------------------------------- status row
    boot_status = ui_label(scr, "Power on...", &lv_font_montserrat_14,
                           UI_WHITE, 70, 188, 0, LV_TEXT_ALIGN_LEFT);
    ui_name(boot_status, "boot_status");

    boot_pct = ui_label(scr, "0%.", &lv_font_montserrat_14, UI_WHITE,
                        176, 188, 74, LV_TEXT_ALIGN_RIGHT);
    ui_name(boot_pct, "boot_pct");

    boot_apply(0, boot_stage_text(0));

    // -------------------------------------------------------------- animation
    lv_anim_t pa;
    lv_anim_init(&pa);
    lv_anim_set_var(&pa, boot_pct);
    lv_anim_set_values(&pa, 0, 100);
    lv_anim_set_duration(&pa, 1800);
    lv_anim_set_path_cb(&pa, lv_anim_path_linear);
    lv_anim_set_exec_cb(&pa, boot_tick_cb);
    lv_anim_start(&pa);

    lv_obj_add_event_cb(boot_pct, boot_deleted, LV_EVENT_DELETE, NULL);
}
