#include "src/ui/ui_common.h"

// ---------------------------------------------------------------------------
// V4 Home Screen: Unified Hero Card with official LVGL 9.6 event callbacks
// ---------------------------------------------------------------------------
static lv_obj_t *home_art;
static lv_obj_t *home_prio_lbl;
static lv_obj_t *home_cat_lbl;
static lv_obj_t *home_idx_lbl;
static lv_obj_t *home_title_lbl;
static lv_obj_t *home_cta_btn;
static lv_obj_t *home_cta_lbl;
static lv_obj_t *home_dots[SERVICE_COUNT];
static service_id_t home_selected = SERVICE_AMBULANCE;

void ui_home_reset(void)
{
    home_art = NULL;
    home_prio_lbl = NULL;
    home_cat_lbl = NULL;
    home_idx_lbl = NULL;
    home_title_lbl = NULL;
    home_cta_btn = NULL;
    home_cta_lbl = NULL;
    for (int i = 0; i < SERVICE_COUNT; i++) {
        home_dots[i] = NULL;
    }
}

static void apply_selection(service_id_t svc)
{
    if (svc >= SERVICE_COUNT) svc = SERVICE_AMBULANCE;
    home_selected = svc;
    const service_info_t *s = &ui_services[svc];

    if (home_art != NULL) {
        lv_image_set_src(home_art, s->art);
    }
    if (home_prio_lbl != NULL) {
        lv_label_set_text(home_prio_lbl, s->prio_tag);
    }
    if (home_cat_lbl != NULL) {
        lv_label_set_text(home_cat_lbl, s->cat_tag);
    }
    if (home_idx_lbl != NULL) {
        lv_label_set_text_fmt(home_idx_lbl, "%d / %d", (int)svc + 1, (int)SERVICE_COUNT);
    }
    if (home_title_lbl != NULL) {
        lv_label_set_text(home_title_lbl, s->name);
    }
    if (home_cta_btn != NULL) {
        ui_set_gradient(home_cta_btn, s->color, s->color_dark);
        lv_obj_set_style_border_color(home_cta_btn, s->border_color, 0);
        lv_obj_set_style_bg_color(home_cta_btn, s->color_dark, LV_STATE_PRESSED);
    }
    if (home_cta_lbl != NULL) {
        lv_label_set_text(home_cta_lbl, s->cta_text);
    }
    for (int i = 0; i < SERVICE_COUNT; i++) {
        if (home_dots[i] != NULL) {
            const bool act = (i == (int)svc);
            const lv_color_t dc = act ? s->dot_color : lv_color_hex(0x3F4654);
            lv_obj_set_style_bg_color(home_dots[i], dc, 0);
            lv_obj_set_style_border_color(home_dots[i], dc, 0);
        }
    }
}

void ui_home_set_selected(service_id_t svc)
{
    if (svc >= SERVICE_COUNT) return;
    apply_selection(svc);
}

service_id_t ui_home_get_selected(void)
{
    return home_selected;
}

static void home_prev_cb(lv_event_t *e)
{
    (void)e;
    service_id_t next = (service_id_t)((home_selected + SERVICE_COUNT - 1) % SERVICE_COUNT);
    apply_selection(next);
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_service_change != NULL) {
        cbs->on_service_change(next);
    }
}

static void home_next_cb(lv_event_t *e)
{
    (void)e;
    service_id_t next = (service_id_t)((home_selected + 1) % SERVICE_COUNT);
    apply_selection(next);
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_service_change != NULL) {
        cbs->on_service_change(next);
    }
}

static void home_dispatch_cb(lv_event_t *e)
{
    (void)e;
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_dispatch != NULL) {
        cbs->on_dispatch(home_selected);
    }
}

static void home_demo_cb(lv_event_t *e)
{
    (void)e;
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_open_slideshow != NULL) {
        cbs->on_open_slideshow();
    }
}

void ui_show_home(void)
{
    const service_info_t *s = &ui_services[home_selected];

    lv_obj_t *scr = ui_screen_begin(UI_BG, UI_BG_2);
    ui_telemetry_set_visible(true);

    // ------------------------------------------------------------------
    // 1. Top Status Bar (y = 0..27)
    // ------------------------------------------------------------------
    ui_top_bar(scr, "Node 01 - Ready", UI_GREEN);

    // ------------------------------------------------------------------
    // 2. Center Unified Hero Card (x = 12, y = 38, w = 296, h = 132)
    // ------------------------------------------------------------------
    lv_obj_t *card = ui_card(scr, 12, 38, 296, 132, UI_PANEL,
                             lv_color_hex(0x2A303C), 1, 10);
    lv_obj_set_style_clip_corner(card, true, 0);
    ui_name(card, "home_card");

    home_art = lv_image_create(card);
    lv_image_set_src(home_art, s->art);
    lv_obj_set_pos(home_art, 0, 0);
    lv_obj_set_scrollable(home_art, false);
    ui_name(home_art, "home_art");

    // Clickable Left (<) and Right/Body (>) touch targets over the artwork
    lv_obj_t *prev_btn = ui_box(card, 0, 0, 56, 98, UI_BLACK, LV_OPA_TRANSP,
                                UI_BLACK, 0);
    ui_make_clickable(prev_btn, UI_WHITE, LV_OPA_10);
    ui_name(prev_btn, "home_prev_btn");
    lv_obj_add_event_cb(prev_btn, home_prev_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *next_btn = ui_box(card, 56, 0, 238, 98, UI_BLACK, LV_OPA_TRANSP,
                                UI_BLACK, 0);
    ui_make_clickable(next_btn, UI_WHITE, LV_OPA_10);
    ui_name(next_btn, "home_next_btn");
    lv_obj_add_event_cb(next_btn, home_next_cb, LV_EVENT_CLICKED, NULL);

    // Attached Card Footer Bar (y = 98..130 inside card)
    lv_obj_t *cfoot = ui_box(card, 0, 98, 294, 32, UI_PANEL_2, LV_OPA_COVER,
                             UI_LINE, 0);
    ui_name(cfoot, "home_card_footer");
    ui_box(card, 0, 98, 294, 1, UI_LINE, LV_OPA_COVER, UI_LINE, 0);

    // Pill 1: Priority tag
    lv_obj_t *p1 = ui_card(cfoot, 8, 7, 44, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    home_prio_lbl = ui_label(p1, s->prio_tag, &lv_font_montserrat_12, UI_TEXT,
                             0, 1, 42, LV_TEXT_ALIGN_CENTER);
    ui_name(home_prio_lbl, "home_prio");

    // Pill 2: Category tag
    lv_obj_t *p2 = ui_card(cfoot, 56, 7, 40, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    home_cat_lbl = ui_label(p2, s->cat_tag, &lv_font_montserrat_12, UI_TEXT,
                            0, 1, 38, LV_TEXT_ALIGN_CENTER);
    ui_name(home_cat_lbl, "home_cat");

    // Pill 3: Slide index
    lv_obj_t *p3 = ui_card(cfoot, 100, 7, 40, 18, lv_color_hex(0x1F2430),
                           lv_color_hex(0x3B4354), 1, 4);
    home_idx_lbl = ui_label(p3, "1 / 4", &lv_font_montserrat_12, UI_MUTED,
                            0, 1, 38, LV_TEXT_ALIGN_CENTER);
    ui_name(home_idx_lbl, "home_idx");

    // Service Title
    home_title_lbl = ui_label(cfoot, s->name, &lv_font_montserrat_16, UI_WHITE,
                              148, 6, 138, LV_TEXT_ALIGN_LEFT);
    ui_name(home_title_lbl, "home_title");

    // ------------------------------------------------------------------
    // 3. Bottom Action Dock (y = 177..215)
    // ------------------------------------------------------------------
    ui_box(scr, 12, 177, 296, 1, lv_color_hex(0x1C2029), LV_OPA_COVER,
           lv_color_hex(0x1C2029), 0);

    home_cta_btn = ui_card(scr, 12, 183, 212, 32, s->color, s->border_color, 1, 8);
    ui_set_gradient(home_cta_btn, s->color, s->color_dark);
    ui_make_clickable(home_cta_btn, s->color_dark, LV_OPA_COVER);
    lv_obj_set_flex_flow(home_cta_btn, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(home_cta_btn, LV_FLEX_ALIGN_CENTER,
                          LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(home_cta_btn, 7, 0);
    ui_name(home_cta_btn, "home_call_bar");

    lv_obj_t *phone_ico = lv_image_create(home_cta_btn);
    lv_image_set_src(phone_ico, &ui_icon_phone_14);
    ui_name(phone_ico, "home_call_icon");

    home_cta_lbl = lv_label_create(home_cta_btn);
    lv_label_set_text(home_cta_lbl, s->cta_text);
    lv_obj_set_style_text_font(home_cta_lbl, &lv_font_montserrat_12, 0);
    lv_obj_set_style_text_color(home_cta_lbl, UI_WHITE, 0);
    ui_name(home_cta_lbl, "home_call_label");

    ui_bubble_children(home_cta_btn);
    lv_obj_add_event_cb(home_cta_btn, home_dispatch_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *dots_pill = ui_card(scr, 232, 183, 76, 32,
                                  lv_color_hex(0x14171F), UI_LINE, 1, 8);
    ui_make_clickable(dots_pill, lv_color_hex(0x252A36), LV_OPA_COVER);
    ui_name(dots_pill, "home_demo");
    for (int i = 0; i < SERVICE_COUNT; i++) {
        home_dots[i] = ui_card(dots_pill, 9 + i * 12, 12, 6, 6,
                               lv_color_hex(0x3F4654), lv_color_hex(0x3F4654), 0, 3);
    }
    ui_label(dots_pill, LV_SYMBOL_RIGHT, &lv_font_montserrat_12, UI_MUTED,
             56, 8, 14, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(dots_pill);
    lv_obj_add_event_cb(dots_pill, home_demo_cb, LV_EVENT_CLICKED, NULL);

    apply_selection(home_selected);
    ui_animate_in(scr, 0);
}
