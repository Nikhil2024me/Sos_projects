#include "src/ui/ui_common.h"

// The service detail and the demo slideshow share the app-style slide layout
// (see screen_slideshow.c / ui_show_slide).
void ui_show_service(service_id_t svc)
{
    ui_show_slide(svc);
}