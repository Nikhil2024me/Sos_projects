#include "src/ui/ui_common.h"

// ---------------------------------------------------------------------------
// V4 Diagnostics Screen: Unified Hero Card with live touch-pressure gauge,
// 2x2 Bento hardware health cells, metadata footer, and LVGL-clickable Return
// & Calibrate buttons.
// ---------------------------------------------------------------------------
static lv_obj_t *cfg_arc;
static lv_obj_t *cfg_pressure;
static lv_obj_t *cfg_state;
static lv_obj_t *cfg_uptime;

void ui_config_reset(void)
{
    cfg_arc = NULL;
    cfg_pressure = NULL;
    cfg_state = NULL;
    cfg_uptime = NULL;
}

void ui_config_update_pressure(uint16_t z)
{
    if (cfg_arc == NULL) return;
    if (z > 4095) z = 4095;
    lv_arc_set_value(cfg_arc, z);

    lv_color_t c;
    const char *state;
    if (z == 0) {
        c = UI_MUTED;
        state = "IDLE";
    } else if (z < 600) {
        c = UI_AMBER;
        state = "LOW";
    } else {
        c = UI_GREEN;
        state = "OK";
    }
    lv_label_set_text_fmt(cfg_pressure, "%u", (unsigned)z);
    lv_obj_set_style_text_color(cfg_pressure, UI_WHITE, 0);
    lv_label_set_text(cfg_state, state);
    lv_obj_set_style_text_color(cfg_state, c, 0);
    lv_obj_set_style_arc_color(cfg_arc, c, LV_PART_INDICATOR);
}

void ui_config_update_uptime(uint32_t seconds)
{
    if (cfg_uptime == NULL) return;
    lv_label_set_text_fmt(cfg_uptime, "%02lu:%02lu",
                          (unsigned long)(seconds / 60u),
                          (unsigned long)(seconds % 60u));
}

static lv_obj_t *bento_cell(lv_obj_t *parent, int32_t x, int32_t y, int32_t w,
                            const char *k, const char *v, lv_color_t vc)
{
    lv_obj_t *cell = ui_card(parent, x, y, w, 38, lv_color_hex(0x161B24),
                             lv_color_hex(0x262C3A), 1, 6);
    ui_label(cell, k, &lv_font_montserrat_12, UI_MUTED, 6, 3, w - 10,
             LV_TEXT_ALIGN_LEFT);
    return ui_label(cell, v, &lv_font_montserrat_12, vc, 6, 18, w - 10,
                    LV_TEXT_ALIGN_LEFT);
}

static void config_return_cb(lv_event_t *e)
{
    (void)e;
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_close_config != NULL) {
        cbs->on_close_config();
    }
}

static void config_cal_cb(lv_event_t *e)
{
    (void)e;
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_calibrate != NULL) {
        cbs->on_calibrate();
    }
}

void ui_show_config(void)
{
    lv_obj_t *scr = ui_screen_begin(UI_BG, UI_BG_2);
    ui_telemetry_set_visible(true);

    // ------------------------------------------------------------------
    // 1. Top Status Bar (y = 0..27)
    // ------------------------------------------------------------------
    ui_top_bar(scr, "Node 01 - Diagnostics", UI_GREEN);

    // ------------------------------------------------------------------
    // 2. Center Unified Diagnostics Card (x = 12, y = 38, w = 296, h = 132)
    // ------------------------------------------------------------------
    lv_obj_t *card = ui_card(scr, 12, 38, 296, 132, UI_PANEL,
                             lv_color_hex(0x2A303C), 1, 10);
    lv_obj_set_style_clip_corner(card, true, 0);
    ui_make_clickable(card, lv_color_hex(0x181C26), LV_OPA_COVER);
    ui_name(card, "config_card");

    // Left Pressure Gauge (78x78 arc at x=12, y=10)
    cfg_arc = lv_arc_create(card);
    lv_obj_set_size(cfg_arc, 78, 78);
    lv_obj_set_pos(cfg_arc, 12, 10);
    lv_obj_set_style_bg_opa(cfg_arc, LV_OPA_TRANSP, 0);
    lv_obj_set_style_border_width(cfg_arc, 0, 0);
    lv_obj_set_style_pad_all(cfg_arc, 0, 0);
    lv_obj_set_style_arc_width(cfg_arc, 6, LV_PART_MAIN);
    lv_obj_set_style_arc_color(cfg_arc, UI_LINE, LV_PART_MAIN);
    lv_obj_set_style_arc_width(cfg_arc, 6, LV_PART_INDICATOR);
    lv_obj_set_style_arc_color(cfg_arc, UI_AMBER, LV_PART_INDICATOR);
    lv_obj_set_style_arc_rounded(cfg_arc, true, LV_PART_INDICATOR);
    lv_obj_remove_style(cfg_arc, NULL, LV_PART_KNOB);
    lv_arc_set_bg_angles(cfg_arc, 135, 45);
    lv_arc_set_range(cfg_arc, 0, 4095);
    lv_arc_set_value(cfg_arc, 0);
    ui_name(cfg_arc, "config_pressure_arc");

    cfg_pressure = ui_label(card, "0", &lv_font_montserrat_16, UI_WHITE,
                            16, 30, 70, LV_TEXT_ALIGN_CENTER);
    ui_name(cfg_pressure, "config_pressure_value");

    cfg_state = ui_label(card, "IDLE", &lv_font_montserrat_12, UI_MUTED,
                         16, 52, 70, LV_TEXT_ALIGN_CENTER);
    ui_name(cfg_state, "config_pressure_state");

    ui_label(card, "RAW-Z", &lv_font_montserrat_12, UI_MUTED,
             16, 74, 70, LV_TEXT_ALIGN_CENTER);

    // Right 2x2 Bento Telemetry Grid (x = 102..284, y = 8..90)
    cfg_uptime = bento_cell(card, 102, 8, 88, "UPTIME", "00:42", UI_CYAN);
    ui_name(cfg_uptime, "config_uptime");
    bento_cell(card, 196, 8, 88, "RADIO", "433MHz TX", UI_GREEN);
    bento_cell(card, 102, 52, 88, "THRESH", "600 Z", UI_WHITE);
    bento_cell(card, 196, 52, 88, "LINK MODE", "LORA 433", UI_AMBER);

    // Attached Card Footer Bar (y = 98..130 inside card)
    lv_obj_t *cfoot = ui_box(card, 0, 98, 294, 32, UI_PANEL_2, LV_OPA_COVER,
                             UI_LINE, 0);
    ui_box(card, 0, 98, 294, 1, UI_LINE, LV_OPA_COVER, UI_LINE, 0);

    // Pill 1: [SYS-OK]
    lv_obj_t *p1 = ui_card(cfoot, 8, 7, 54, 18, lv_color_hex(0x064E3B),
                           UI_GREEN, 1, 4);
    ui_label(p1, "SYS-OK", &lv_font_montserrat_12, UI_TEXT, 0, 1, 52,
             LV_TEXT_ALIGN_CENTER);

    // Pill 2: [SX1278]
    lv_obj_t *p2 = ui_card(cfoot, 66, 7, 50, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    ui_label(p2, "SX1278", &lv_font_montserrat_12, UI_TEXT, 0, 1, 48,
             LV_TEXT_ALIGN_CENTER);

    // Pill 3: [V4.0]
    lv_obj_t *p3 = ui_card(cfoot, 120, 7, 38, 18, lv_color_hex(0x1F2430),
                           lv_color_hex(0x3B4354), 1, 4);
    ui_label(p3, "V4.0", &lv_font_montserrat_12, UI_MUTED, 0, 1, 36,
             LV_TEXT_ALIGN_CENTER);

    ui_label(cfoot, "Diagnostics", &lv_font_montserrat_16, UI_WHITE,
             164, 6, 124, LV_TEXT_ALIGN_LEFT);

    ui_bubble_children(card);
    lv_obj_add_event_cb(card, config_return_cb, LV_EVENT_CLICKED, NULL);

    // ------------------------------------------------------------------
    // 3. Bottom Action Dock (y = 177..215)
    // ------------------------------------------------------------------
    ui_box(scr, 12, 177, 296, 1, lv_color_hex(0x1C2029), LV_OPA_COVER,
           lv_color_hex(0x1C2029), 0);

    lv_obj_t *hint = ui_card(scr, 12, 183, 212, 32, UI_PILL_BG,
                             UI_PILL_BDR, 1, 8);
    ui_make_clickable(hint, lv_color_hex(0x323948), LV_OPA_COVER);
    ui_name(hint, "config_hint");
    ui_label(hint, "TOUCH ANYWHERE TO RETURN", &lv_font_montserrat_12,
             UI_WHITE, 0, 8, 210, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(hint);
    lv_obj_add_event_cb(hint, config_return_cb, LV_EVENT_CLICKED, NULL);

    lv_obj_t *cal_pill = ui_card(scr, 232, 183, 76, 32,
                                 lv_color_hex(0x14171F), UI_LINE, 1, 8);
    ui_make_clickable(cal_pill, lv_color_hex(0x252A36), LV_OPA_COVER);
    ui_name(cal_pill, "config_cal_btn");
    ui_card(cal_pill, 8, 12, 6, 6, UI_CYAN, UI_CYAN, 0, 3);
    ui_label(cal_pill, "CAL", &lv_font_montserrat_12, UI_CYAN,
             20, 8, 48, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(cal_pill);
    lv_obj_add_event_cb(cal_pill, config_cal_cb, LV_EVENT_CLICKED, NULL);

    ui_config_update_pressure(ui_pressure_get());
    ui_config_update_uptime(ui_uptime_get());
    ui_animate_in(scr, 0);
}
