// Unified V4 Card UI layer for the SOS Emergency Transmitter.
// Pure LVGL 9.6: the same files compile in the headless simulator and on the
// ESP32-S3 firmware.

#ifndef SOS_UI_COMMON_H
#define SOS_UI_COMMON_H

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    SERVICE_AMBULANCE = 0,
    SERVICE_FIRE_ENGINE,
    SERVICE_POLICE,
    SERVICE_EMERGENCY,
    SERVICE_COUNT
} service_id_t;

typedef struct {
    const char *name;          // "Ambulance"
    const char *code;          // "AMB"
    const char *prio_tag;      // "PRI-1"
    const char *cat_tag;       // "MED"
    const char *cta_text;      // "DISPATCH AMBULANCE"
    lv_color_t color;          // Primary gradient top
    lv_color_t color_dark;     // Primary gradient bottom
    lv_color_t border_color;   // 1px highlight border
    lv_color_t dot_color;      // Active page dot colour
    const lv_image_dsc_t *art; // 294x98 full-colour hero art
} service_info_t;

// Official LVGL 9.6 event-driven UI callbacks registered by the firmware.
typedef struct {
    void (*on_service_change)(service_id_t svc);
    void (*on_dispatch)(service_id_t svc);
    void (*on_cancel_request)(void);
    void (*on_open_config)(void);
    void (*on_close_config)(void);
    void (*on_open_slideshow)(void);
    void (*on_exit_slideshow)(void);
    void (*on_calibrate)(void);
} ui_callbacks_t;

extern const service_info_t ui_services[SERVICE_COUNT];
extern const lv_image_dsc_t ui_icon_phone_14;
extern const lv_image_dsc_t ui_icon_phone_22;

// ---------------------------------------------------------------------------
// V4 Obsidian / Linear Dark Palette
// ---------------------------------------------------------------------------
#define UI_BG        lv_color_hex(0x0E1015)
#define UI_BG_2      lv_color_hex(0x0E1015)
#define UI_TOPBAR    lv_color_hex(0x141821)
#define UI_PANEL     lv_color_hex(0x12141B)
#define UI_PANEL_2   lv_color_hex(0x1B1F28)
#define UI_PILL_BG   lv_color_hex(0x252A36)
#define UI_PILL_BDR  lv_color_hex(0x323948)
#define UI_GRID      lv_color_hex(0x161922)
#define UI_LINE      lv_color_hex(0x262B36)
#define UI_TEXT      lv_color_hex(0xF3F4F6)
#define UI_MUTED     lv_color_hex(0x9CA3AF)
#define UI_DIM       lv_color_hex(0x6B7280)
#define UI_CYAN      lv_color_hex(0x38BDF8)
#define UI_GREEN     lv_color_hex(0x10B981)
#define UI_AMBER     lv_color_hex(0xF59E0B)
#define UI_RED       lv_color_hex(0xEF4444)
#define UI_MAGENTA   lv_color_hex(0xA855F7)
#define UI_BLUE      lv_color_hex(0x3B82F6)
#define UI_WHITE     lv_color_hex(0xFFFFFF)
#define UI_BLACK     lv_color_hex(0x000000)

// ---------------------------------------------------------------------------
// Screen & Callback API
// ---------------------------------------------------------------------------
void ui_init(void);
void ui_set_callbacks(const ui_callbacks_t *cbs);
const ui_callbacks_t *ui_get_callbacks(void);

void ui_show_boot(void);
void ui_boot_set_progress(uint8_t percent, const char *status);
void ui_show_home(void);
void ui_show_slide(service_id_t svc);
void ui_show_service(service_id_t svc);
void ui_show_config(void);
void ui_show_calling(service_id_t svc);
void ui_show_slideshow(uint8_t slide);

// Update the displayed service slide on the home screen.
void ui_home_set_selected(service_id_t svc);
service_id_t ui_home_get_selected(void);

// Live telemetry (persistent bottom strip + top bar clock + diagnostics).
void ui_update_pressure(uint16_t z);
void ui_update_uptime(uint32_t seconds);
void ui_telemetry_set_visible(bool visible);

// Last values pushed to the UI (for freshly built screens to initialise from).
uint16_t ui_pressure_get(void);
uint32_t ui_uptime_get(void);

// 0..100 while the user holds the slideshow; 0 hides the progress line.
void ui_slideshow_hold_progress(uint8_t percent);

// ---------------------------------------------------------------------------
// Shared V4 UI primitives
// ---------------------------------------------------------------------------
lv_obj_t *ui_screen_begin(lv_color_t top, lv_color_t bottom);
lv_obj_t *ui_top_bar(lv_obj_t *parent, const char *status_text, lv_color_t dot_color);

// Configure an lv_obj as an interactive touch button with a flat pressed style
// and bubble-enabled children.
void ui_make_clickable(lv_obj_t *obj, lv_color_t pressed_bg, lv_opa_t pressed_opa);
void ui_bubble_children(lv_obj_t *parent);

void ui_animate_in(lv_obj_t *obj, int dir);
void ui_animate_slide_x(lv_obj_t *obj, int32_t from_x, int32_t to_x, uint32_t ms);

lv_obj_t *ui_box(lv_obj_t *parent, int32_t x, int32_t y, int32_t w, int32_t h,
                 lv_color_t bg, lv_opa_t bg_opa, lv_color_t border, int32_t border_w);
lv_obj_t *ui_card(lv_obj_t *parent, int32_t x, int32_t y, int32_t w, int32_t h,
                  lv_color_t bg, lv_color_t border, int32_t border_w, int32_t radius);
lv_obj_t *ui_label(lv_obj_t *parent, const char *text, const lv_font_t *font,
                   lv_color_t color, int32_t x, int32_t y, int32_t w,
                   lv_text_align_t align);

lv_obj_t *ui_panel(lv_obj_t *parent, int32_t x, int32_t y, int32_t w, int32_t h,
                   lv_color_t accent);
void ui_corner_brackets(lv_obj_t *parent, lv_color_t c);
void ui_hud_grid(lv_obj_t *parent, lv_color_t color);

void ui_set_gradient(lv_obj_t *obj, lv_color_t top, lv_color_t bottom);
void ui_set_glow(lv_obj_t *obj, lv_color_t color, int32_t width, lv_opa_t opa);
void ui_clear_glow(lv_obj_t *obj);
void ui_name(lv_obj_t *obj, const char *name);

#ifdef __cplusplus
}
#endif

#endif
