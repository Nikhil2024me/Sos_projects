#include "src/ui/ui_common.h"

// ---------------------------------------------------------------------------
// V4 Unified Hero Card Slide (shared by Service Detail & Demo Slideshow)
// Driven by official LVGL 9.6 widget events (CLICKED, SHORT_CLICKED,
// PRESSING, LONG_PRESSED, RELEASED).
// ---------------------------------------------------------------------------
static service_id_t slide_current = SERVICE_AMBULANCE;
static uint32_t hold_start_tick = 0;
static bool hold_fired = false;

void ui_slide_reset(void)
{
    hold_start_tick = 0;
    hold_fired = false;
}

void ui_slide_update_clock(uint32_t seconds)
{
    (void)seconds;
}

static void slide_prev_cb(lv_event_t *e)
{
    (void)e;
    if (hold_fired) return;
    service_id_t prev = (service_id_t)((slide_current + SERVICE_COUNT - 1) % SERVICE_COUNT);
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_service_change != NULL) {
        cbs->on_service_change(prev);
    }
    ui_show_slide(prev);
}

static void slide_next_cb(lv_event_t *e)
{
    (void)e;
    if (hold_fired) return;
    service_id_t next = (service_id_t)((slide_current + 1) % SERVICE_COUNT);
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_service_change != NULL) {
        cbs->on_service_change(next);
    }
    ui_show_slide(next);
}

static void slide_hold_event_cb(lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_PRESSED) {
        hold_start_tick = lv_tick_get();
        hold_fired = false;
        ui_slideshow_hold_progress(0);
    } else if (code == LV_EVENT_PRESSING) {
        if (!hold_fired) {
            uint32_t elapsed = lv_tick_elaps(hold_start_tick);
            if (elapsed >= 2000) {
                hold_fired = true;
                ui_slideshow_hold_progress(0);
                const ui_callbacks_t *cbs = ui_get_callbacks();
                if (cbs->on_exit_slideshow != NULL) {
                    cbs->on_exit_slideshow();
                }
            } else if (elapsed > 150) {
                ui_slideshow_hold_progress((uint8_t)((elapsed * 100u) / 2000u));
            }
        }
    } else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
        ui_slideshow_hold_progress(0);
    }
}

static void slide_dispatch_cb(lv_event_t *e)
{
    (void)e;
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_dispatch != NULL) {
        cbs->on_dispatch(slide_current);
    }
}

void ui_show_slide(service_id_t svc)
{
    if (svc >= SERVICE_COUNT) svc = SERVICE_AMBULANCE;
    slide_current = svc;
    const service_info_t *s = &ui_services[svc];

    lv_obj_t *scr = ui_screen_begin(UI_BG, UI_BG_2);
    ui_telemetry_set_visible(true);

    // ------------------------------------------------------------------
    // 1. Top Status Bar (y = 0..27)
    // ------------------------------------------------------------------
    ui_top_bar(scr, "Node 01 - Ready", UI_GREEN);

    // ------------------------------------------------------------------
    // 2. Center Unified Hero Card (x = 12, y = 38, w = 296, h = 132)
    // ------------------------------------------------------------------
    lv_obj_t *card = ui_card(scr, 12, 38, 296, 132, UI_PANEL,
                             lv_color_hex(0x2A303C), 1, 10);
    lv_obj_set_style_clip_corner(card, true, 0);
    ui_name(card, "slide_card");

    // Upper artwork viewport (294 x 98 inside 1px border)
    lv_obj_t *art = lv_image_create(card);
    lv_image_set_src(art, s->art);
    lv_obj_set_pos(art, 0, 0);
    lv_obj_set_scrollable(art, false);
    ui_name(art, "slide_art");

    // Clickable Left (<) and Right/Body (>) zones with 2 s hold-to-exit support
    lv_obj_t *prev_btn = ui_box(card, 0, 0, 56, 98, UI_BLACK, LV_OPA_TRANSP,
                                UI_BLACK, 0);
    ui_make_clickable(prev_btn, UI_WHITE, LV_OPA_10);
    ui_name(prev_btn, "slide_prev_arrow");
    lv_obj_add_event_cb(prev_btn, slide_hold_event_cb, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(prev_btn, slide_prev_cb, LV_EVENT_SHORT_CLICKED, NULL);

    lv_obj_t *next_btn = ui_box(card, 56, 0, 238, 98, UI_BLACK, LV_OPA_TRANSP,
                                UI_BLACK, 0);
    ui_make_clickable(next_btn, UI_WHITE, LV_OPA_10);
    ui_name(next_btn, "slide_next_arrow");
    lv_obj_add_event_cb(next_btn, slide_hold_event_cb, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(next_btn, slide_next_cb, LV_EVENT_SHORT_CLICKED, NULL);

    // Attached Card Footer Bar (y = 98..130 inside card)
    lv_obj_t *cfoot = ui_box(card, 0, 98, 294, 32, UI_PANEL_2, LV_OPA_COVER,
                             UI_LINE, 0);
    ui_name(cfoot, "slide_card_footer");
    ui_box(card, 0, 98, 294, 1, UI_LINE, LV_OPA_COVER, UI_LINE, 0);

    // Pill 1: Priority tag (e.g. [PRI-1])
    lv_obj_t *p1 = ui_card(cfoot, 8, 7, 44, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    ui_label(p1, s->prio_tag, &lv_font_montserrat_12, UI_TEXT, 0, 1, 42,
             LV_TEXT_ALIGN_CENTER);

    // Pill 2: Category tag (e.g. [MED])
    lv_obj_t *p2 = ui_card(cfoot, 56, 7, 40, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    ui_label(p2, s->cat_tag, &lv_font_montserrat_12, UI_TEXT, 0, 1, 38,
             LV_TEXT_ALIGN_CENTER);

    // Pill 3: Slide index ([1 / 4] .. [4 / 4])
    char idx_buf[12];
    lv_snprintf(idx_buf, sizeof(idx_buf), "%d / %d", (int)svc + 1, (int)SERVICE_COUNT);
    lv_obj_t *p3 = ui_card(cfoot, 100, 7, 40, 18, lv_color_hex(0x1F2430),
                           lv_color_hex(0x3B4354), 1, 4);
    ui_label(p3, idx_buf, &lv_font_montserrat_12, UI_MUTED, 0, 1, 38,
             LV_TEXT_ALIGN_CENTER);

    // Service Title
    lv_obj_t *title = ui_label(cfoot, s->name, &lv_font_montserrat_16, UI_WHITE,
                               148, 6, 138, LV_TEXT_ALIGN_LEFT);
    ui_name(title, "slide_title");

    // ------------------------------------------------------------------
    // 3. Bottom Action Dock (y = 177..215)
    // ------------------------------------------------------------------
    ui_box(scr, 12, 177, 296, 1, lv_color_hex(0x1C2029), LV_OPA_COVER,
           lv_color_hex(0x1C2029), 0);

    // Left Dispatch CTA Button (x = 12, y = 183, w = 212, h = 32)
    lv_obj_t *cta = ui_card(scr, 12, 183, 212, 32, s->color, s->border_color, 1, 8);
    ui_set_gradient(cta, s->color, s->color_dark);
    ui_make_clickable(cta, s->color_dark, LV_OPA_COVER);
    lv_obj_set_flex_flow(cta, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(cta, LV_FLEX_ALIGN_CENTER,
                          LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
    lv_obj_set_style_pad_column(cta, 7, 0);
    ui_name(cta, "slide_call");

    lv_obj_t *phone_ico = lv_image_create(cta);
    lv_image_set_src(phone_ico, &ui_icon_phone_14);
    ui_name(phone_ico, "slide_call_icon");

    lv_obj_t *cta_lbl = lv_label_create(cta);
    lv_label_set_text(cta_lbl, s->cta_text);
    lv_obj_set_style_text_font(cta_lbl, &lv_font_montserrat_12, 0);
    lv_obj_set_style_text_color(cta_lbl, UI_WHITE, 0);

    ui_bubble_children(cta);
    lv_obj_add_event_cb(cta, slide_dispatch_cb, LV_EVENT_CLICKED, NULL);

    // Right Slide Indicator Pill (x = 232, y = 183, w = 76, h = 32)
    lv_obj_t *dots_pill = ui_card(scr, 232, 183, 76, 32,
                                  lv_color_hex(0x14171F), UI_LINE, 1, 8);
    ui_make_clickable(dots_pill, lv_color_hex(0x252A36), LV_OPA_COVER);
    ui_name(dots_pill, "slide_dots");
    for (int i = 0; i < SERVICE_COUNT; i++) {
        const bool act = (i == (int)svc);
        const lv_color_t dc = act ? s->dot_color : lv_color_hex(0x3F4654);
        ui_card(dots_pill, 9 + i * 12, 12, 6, 6, dc, dc, 0, 3);
    }
    ui_label(dots_pill, LV_SYMBOL_RIGHT, &lv_font_montserrat_12, UI_MUTED,
             56, 8, 14, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(dots_pill);
    lv_obj_add_event_cb(dots_pill, slide_hold_event_cb, LV_EVENT_ALL, NULL);
    lv_obj_add_event_cb(dots_pill, slide_next_cb, LV_EVENT_SHORT_CLICKED, NULL);

    ui_animate_slide_x(art, 24, 0, 260);
    ui_animate_in(scr, 0);
}

void ui_show_slideshow(uint8_t slide)
{
    if (slide >= SERVICE_COUNT) slide = 0;
    ui_show_slide((service_id_t)slide);
}
