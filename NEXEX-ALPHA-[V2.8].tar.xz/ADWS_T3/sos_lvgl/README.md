# SOS Emergency Transmitter — Mission Control HUD (V3)

A ground-up redesign of the offline SOS transmitter UI for an
**ESP32-S3-WROOM-1 N16R8** with an **ILI9341 320×240** panel, **XPT2046**
touch and an **SX1278** LoRa module.

V1/V2 were a colour skin over the original layout. V3 throws that out and
builds a **mission-control HUD**: near-black navy, neon cyan/amber/red,
a live radar ring, sonar pulses, a countdown arc, a pressure gauge and a
persistent telemetry strip. The navigation is new too — service selection is
a radial ring, not a list of cards.

> **Hardware status:** no board was connected. The firmware is compiled and
> simulator-verified, not flashed. Touch calibration is a stock starting point
> (see [Touch calibration](#touch-calibration)).

---

## 1. Target hardware

| Item | Part / configuration |
|---|---|
| MCU | ESP32-S3-WROOM-1 **N16R8** (16 MB flash, 8 MB octal PSRAM) |
| Display | ILI9341 2.4″ 320×240, SPI |
| Touch | XPT2046 resistive, shares the display SPI bus |
| Radio | SX1278 433/868/915 MHz module (3.3 V logic) |
| UI | LVGL 9.6, RGB565, partial render mode |
| Framework | Arduino-ESP32 3.3.12, TFT_eSPI 2.5.43 |

The UI uses a 64 KB LVGL heap and a 25,600-byte draw buffer; PSRAM is not
required.

---

## 2. Pin map

### 2.1 Display and touch — FSPI / SPI2

| Signal | GPIO | Notes |
|---|---:|---|
| TFT_SCLK | 12 | FSPI clock |
| TFT_MOSI | 11 | FSPI MOSI |
| TFT_MISO | 13 | FSPI MISO |
| TFT_CS | 10 | display chip select |
| TFT_DC | 9 | data/command |
| TFT_RST | 14 | display reset |
| TFT_BL | 21 | backlight, active HIGH |
| TOUCH_CS | 15 | XPT2046 chip select |
| TOUCH_IRQ | 16 | wired but optional; firmware polls pressure |

TFT and touch share the bus through TFT_eSPI’s built-in XPT2046 support
(`getTouchRawZ`, `getTouch`, `setTouch`); there is no second touch driver.

### 2.2 SX1278 — HSPI / SPI3

| Signal | GPIO |
|---|---:|
| LORA_SCK | 5 |
| LORA_MOSI | 6 |
| LORA_MISO | 7 |
| LORA_NSS | 4 |
| LORA_RST | 8 |
| LORA_DIO0 | 2 |

Standby only, no transmit. The antenna should still be connected before power.

### 2.3 Local I/O

| Signal | GPIO | Notes |
|---|---:|---|
| BUTTON | 1 | active LOW, `INPUT_PULLUP` |
| NOTIFICATION | 17 | HIGH during a call, LOW on exit |
| BUZZER | 18 | active HIGH, toggled every 500 ms during a call |

GPIO 26–32 (flash), 33–37 (octal PSRAM), 19/20 (USB), 39–42 (JTAG) and
43/44 (UART0) are avoided.

---

## 3. The HUD

### 3.1 Design language

- Background: `#02060D` → `#061225` vertical gradient, subtle technical grid.
- Accents: cyan `#34F5FF`, green `#2BFFAE`, amber `#FFB020`, red `#FF2D45`,
  magenta `#C05CFF`.
- Thin 1 px rules, corner brackets, uppercase micro-labels, glass panels.
- Motion: radar sweep, pulsing core, sonar rings, countdown arc, boot spinner,
  screen fade/slide entrances.

### 3.2 Screen flow

```
BOOT (2 s)
   ↓
COMMAND ── tap DEMO ──────────────→ SLIDESHOW
   │  tap node = select               │ release = next
   │  tap core / CALL = call          │ hold 2 s = back
   ↓                                  │
SERVICE DETAIL ←── touch cancel ── CALLING (5 s / abort)
   │  PREV / CALL / NEXT              ↑
   └── short button ─────────────────┘

2 s button hold (any state) → DIAGNOSTICS → touch = COMMAND
```

**BOOT** is the ADWS splash: the wordmark is cropped from the supplied
artwork into an RGB565 asset on black, with a dark bar holder, a light track
and a blue diagonal-stripe fill. The bar, `NN%.` read-out and status line all
follow the same progress value. The timed demo runs 0→100 % in 1.8 s with
`Power on → Display ready → LoRa init → Touch ready → Finalising → System
online`. Firmware drives it from the real init steps via
`ui_boot_set_progress()` (5 % power, 18 % display, 45 % LoRa standby, 65 %
touch, 82 % UI, 100 % system online) and holds the splash for 2 s.

### 3.3 COMMAND home

- Radar ring of four 90° service arcs with a rotating cyan sweep.
- Service nodes: **AMB** top-right, **FIRE** top-left, **PD** bottom-left,
  **EMG** bottom-right.
- Centre `SOS / CALL` core with a breathing glow.
- Bottom `CALL <service>` gradient bar and a `DEMO >` tab.
- Tapping a node selects it; the arcs, node glow and CALL bar update without a
  screen rebuild.

### 3.4 Service detail

The app-style slide from the supplied reference, rebuilt in LVGL and shared with
the slideshow (`ui_show_slide()`):

- Black top bar: `Node 1`, green online dot, `ADWS Online`, gear, and a live
  `MM:SS` clock (uptime).
- Large centred service title with the red `01 / 04` counter underneath.
- Full-width 320×120 hero art at y=60.
- Large white `<` and `>` chevrons drawn with `lv_line` at x 18..42 and
  278..302, y 108..156.
- Grey `Call` pill bottom-left with a green phone disc and `CALL`.
- Dark page-dot capsule showing the current slide, plus the iOS home bar.
- Tapping the body advances; the gear opens diagnostics.

### 3.5 Calling

- Amber `OFFLINE • LOCAL ALERT ONLY` banner.
- Three expanding sonar rings (size-based, not transform-scaled).
- 5 s countdown arc around a service-coloured core.
- `CALLING`, service code, `LOCAL ALERT`.
- Depleting bar, `T-5.0` → `T-0.0`, blinking red LIVE dot,
  `TOUCH TO ABORT`.

### 3.6 Diagnostics

- 270° pressure arc gauge (0..4606) with numeric value and IDLE/LOW/OK.
- Live read-outs: UPTIME, MODE, LINK, RADIO STANDBY, THRESHOLD, FIRMWARE.
- `TOUCH ANYWHERE TO RETURN`.

### 3.7 Slideshow

- Renders the same app-style slide as §3.4 (`ui_show_slideshow()` calls
  `ui_show_slide()`), so all four services stitch together with no visual jump.
- Arrows / Call / dots / clock / gear all work inside the demo.
- Manual advance only. The release that enters is ignored. A yellow line grows
  above the telemetry strip while holding to exit.

### 3.8 Persistent telemetry

Top-layer strip at y=225..239 on every screen except boot:

- `P nnnn [LOW/OK/---]` raw XPT2046 pressure.
- `T+MM:SS` uptime.
- Green LOCAL link dot.
- 2 px pressure gauge along the bottom.

---

## 4. Build

### 4.1 Libraries

- **LVGL 9.6.0**
- **TFT_eSPI 2.5.43**
- **ESP32 core 3.3.12**

### 4.2 Configuration files

```bash
cp config/User_Setup.h ~/Arduino/libraries/TFT_eSPI/User_Setup.h
cp config/lv_conf.h ~/Arduino/libraries/lv_conf.h
cp config/lv_conf.h ~/Arduino/libraries/lvgl/lv_conf.h
```

The supplied `lv_conf.h` enables RGB565, a 64 KB heap, Montserrat 12/14/16/20/28,
object names, **arc** and **bar** widgets, and disables unused widgets/decoders.

### 4.3 Compile

```bash
arduino-cli compile \
  --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB" \
  .
```

Arduino IDE: **ESP32S3 Dev Module**, 16 MB flash, OPI PSRAM, QIO 80 MHz,
**16M Flash (3MB APP/9.9MB FATFS)**, upload speed 921600.

**Verified build** (Arduino CLI, ESP32 core 3.3.12, LVGL 9.6.0,
TFT_eSPI 2.5.43, **0 warnings**):

| Resource | Used | Available |
|---|---:|---:|
| Application flash | 1,039,588 B (33%) | 3,145,728 B |
| Global RAM | 114,872 B (35%) | 327,680 B |
| Free RAM | 212,808 B | — |

Artefacts: `build/sos_lvgl.ino.bin` (1,016 KB), `build/sos_lvgl.ino.elf`,
`build/sos_lvgl.ino.map`.

### 4.4 Flash

```bash
arduino-cli upload -p /dev/ttyACM0 \
  --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB" \
  .
```

Use `/dev/ttyUSB0` for a USB-UART bridge.

---

## 5. Touch calibration

The firmware uses TFT_eSPI’s stock XPT2046 calibration:

```c
uint16_t cal_data[5] = {300, 3600, 300, 3600, 0};
tft.setTouch(cal_data);
```

The fifth value is a bit field: bit0 swap axes, bit1 invert X, bit2 invert Y.
Try `1` first for a landscape panel, then add inversion bits if mirrored.

For a real calibration, temporarily add after `tft.setRotation(1)`:

```c
uint16_t cal[5];
tft.calibrateTouch(cal, TFT_WHITE, TFT_BLACK, 15);
for (int i = 0; i < 5; i++) Serial.println(cal[i]);
```

`TOUCH_THRESHOLD` is **4300** and the check is strict (`z > 4300`).

---

## 6. Interaction

| State | Touch | Short button | 2 s button |
|---|---|---|---|
| COMMAND | tap node = select; core/CALL = call; DEMO = slideshow | call current service | diagnostics |
| SERVICE | arrows = prev/next; Call pill = call; gear = diagnostics; body = next | call current service | diagnostics |
| CALLING | anywhere = abort | — | cancel call + diagnostics |
| DIAGNOSTICS | anywhere = COMMAND | — | diagnostics |
| SLIDESHOW | arrows = prev/next; Call pill = call; gear = diagnostics; release = next | — | cancel + diagnostics |
| Boot | ignored (2 s) | ignored | ignored |

The button edge detector starts released, so an idle button at boot cannot
trigger a spurious call.

### Call lifecycle

- `start_call()` sets notification HIGH, buzzer HIGH, starts a fresh 5 s timer.
- Buzzer toggles every 500 ms.
- Timeout or touch abort: notification and buzzer LOW, call flag cleared,
  service screen restored.
- Opening diagnostics during a call cancels the call first.

---

## 7. LoRa SX1278

`lora_standby_init()` runs once in `setup()`:

1. NSS high, reset low 10 ms, high 10 ms.
2. Start HSPI on SCK 5 / MISO 7 / MOSI 6 / NSS 4.
3. Read `RegVersion` (0x42).
4. If `0x12`, write sleep then standby to `RegOpMode`.
5. Print `LoRa SX1278: version 0x12 (standby), no TX`.

There is no transmit path in this build.

---

## 8. Memory and rendering

| Item | Value |
|---|---:|
| Display | 320×240 RGB565 |
| Render mode | `LV_DISPLAY_RENDER_MODE_PARTIAL` |
| Draw buffer | `320 × 40 × 2` = **25,600 bytes** |
| LVGL heap | **65,536 bytes** |
| Simulator peak | ≈ **39.6 KB** (home), ≈ **36.7 KB** (calling) |
| Hero art | 4 × 320×136 RGB565 = **348,160 bytes flash** |
| Boot logo | 260×111 RGB565 = **57,720 bytes flash** + 16×16 stripe tile |
| Animations | Sweep 2.8 s, core pulse 1.1 s, sonar 1.5 s, countdown 5 s |

The calling pulses animate object **size and position**, not
`transform_scale`. A scaled 150 px ring required a 224 KB intermediate draw
buffer and exceeded the 64 KB heap; size animation brings it back to ~36.7 KB.

---

## 9. Clean-mode fixes retained

V1–V10 and L1–L10 from the rebuild spec are still fixed:

- V1/V2: service SOS/name live in the coloured header, drawn once.
- V3: config text no longer cut by a border.
- V4: calling ring is a clean countdown arc, not a detached circle.
- V5: headers/titles are centred.
- V6–V8: slideshow header, 320×136 art and solid footer.
- V9: boot subtitle clear of the ring.
- V10: telemetry/bar hidden on boot.
- L1: short button calls the current service.
- L2: notification LOW on timeout/cancel/config.
- L3: fresh call timestamp per call.
- L4: diagnostics during a call cancels first.
- L5: touch maps the full 240 px.
- L6: slideshow reachable and exits on 2 s hold.
- L7: no false 3 s auto-advance.
- L8: uptime refreshed every second.
- L9: button on GPIO1.
- L10: dead code removed.

Extra guard: the button edge detector starts released, so boot cannot trigger a
call.

---

## 10. Simulator verification

The UI files compile in the LVGL 9.6 headless simulator at **320×240 RGB565**
with the device fonts and a 64 KB heap budget.

- All screens: **0 compiler warnings**, **0 warning/error diagnostics**.
- Only intentional `OVERLAP` **info** remains for decorative arcs, grid lines
  and full-width labels.
- Heap peak: home 39,632 B, calling 36,744 B, config 28,976 B, slide 23,760 B
  (budget 65,536 B).
- No clipped labels, off-screen objects or overflow.

Screenshots are saved in [`screenshots/`](screenshots/) — open
`screenshots/index.html` for a captioned gallery. The folder also contains
`contact_sheet.png` and 2× upscales in `screenshots/2x/`.

Regenerate them with:

```bash
node tools/render_screenshots.mjs
python3 tools/make_gallery.py
```

`render_screenshots.mjs` drives the same `lvgl-simulator` MCP server over stdio
and writes the returned PNGs to disk. It expects the server checkout at
`/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server`.

### Regenerating the art

```bash
python3 tools/gen_color_art.py      # SVG → art/raw/*.png (640×272 + 320×136)
python3 tools/gen_color_assets.py   # PNG → src/assets/color_*.c + assets.h
python3 tools/gen_boot_assets.py    # art/raw/adws_boot.png → boot logo + stripe tile
```

Requires Python 3, PyGObject, GdkPixbuf and librsvg.

---

## 11. Known limitations

- **Not flashed.** Bench-check the panel, touch axes and buzzer polarity.
- **Touch calibration** is a starting point, not a per-panel calibration.
- **Buzzer** is assumed active HIGH; invert the writes if the module is active
  LOW.
- **Backlight** is assumed active HIGH; set `TFT_BL` to `-1` / remove it if tied
  to 3.3 V.
- **Pressure** is raw Z, not calibrated force.
- **No LoRa transmit** by design.
- **PSRAM unused**; the UI fits in internal RAM.

---

## 12. Serial output

At 115200 baud:

```text
SOS Emergency Transmitter - Mission Control HUD
LoRa SX1278: version 0x12 (standby), no TX
Ready: COMMAND
```