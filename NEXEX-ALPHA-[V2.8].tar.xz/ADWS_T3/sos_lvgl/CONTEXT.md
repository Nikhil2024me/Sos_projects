# SOS Emergency Transmitter — Mission Control HUD (V3)

**Date:** 2026-11-06  
**Project:** `/home/debian/ADWS_T3/sos_lvgl`  
**Target:** ESP32-S3-WROOM-1 N16R8 + ILI9341 2.4" (320×240) + XPT2046 + SX1278  
**Stack:** Arduino-ESP32 3.3.12, LVGL 9.6.0, TFT_eSPI 2.5.43

---

## 1. What the user asked for

> "I'm tired of this boring UI/UX with the V1 setup. I need to push it to the
> limits — completely design a new UI which is good."

Two design decisions were confirmed:

1. **Visual language:** *Mission-control / HUD* — near-black navy, neon cyan /
   amber / red accents, radar rings, telemetry readouts, animated sweeps and
   glass panels.
2. **Scope:** *Flow + visuals* — rethink navigation, not just restyle the old
   screens, while keeping the required hardware behaviour (pins, LoRa standby,
   buzzer/notification, 5 s call, manual slideshow, 2 s hold-to-exit).

A follow-up request replaced the boot splash with an **exact copy of the
supplied `/home/debian/Downloads/ADWS.png` artwork**: black background, huge
white ADWS wordmark, dark bar holder, light track, blue diagonal-stripe fill,
and the `LoRa init...` / `NN%` status row. That image is copied into
`art/raw/adws_boot.png`; `tools/gen_boot_assets.py` crops the wordmark into
`boot_adws` and generates the striped `boot_stripe` tile.

This document is the hand-off context for the resulting **V3 HUD** firmware.

---

## 2. What is new compared with the old V2 colour UI

The old V2 screens were a colour skin over the original V1 layout. V3 replaces
the structure and interaction model:

| Old V2 | New V3 HUD |
|---|---|
| Logo splash with ring | Animated boot sequence: spinner, boot log, progress bar |
| Main menu with 3 status cards + NOTE box | **COMMAND** radar: 4 service nodes on a ring, pulsing SOS core, CALL bar, DEMO tab |
| Service screen: header + art + action bar | **App slide**: black status bar (Node / ADWS Online / gear / clock), huge title, red counter, full-width art, `lv_line` chevrons, Call pill, page dots |
| Calling: static circle + progress line | Sonar pulse rings, 5 s countdown arc, T-x.x timer, LIVE indicator, abort hint |
| Config: two cards | **DIAGNOSTICS**: live pressure arc gauge + 6 live read-outs |
| Slideshow: title + art + footer | Same app slide reused for all four services, so the demo stitches seamlessly with the service screen |
| Persistent pressure bar | Persistent telemetry strip: pressure, uptime, LOCAL link |
| Touch anywhere cycles service | Tap a service node to select, tap core/CALL to call, PREV/NEXT on service screen |

All screens animate in (fade + 18 px slide, 240–300 ms). The radar sweep and
core glow loop continuously. The calling screen uses size-based sonar pulses
(not `transform_scale`) to stay inside the 64 KB LVGL heap.

---

## 3. Screen-by-screen

### 3.1 Boot (`src/ui/screen_logo.c`)
- Black ADWS splash copied from the supplied artwork.
- `boot_adws` asset is the wordmark cropped from `ADWS.png` (260×111 RGB565).
- Dark bar holder, light track, blue fill with a tiled diagonal-stripe asset.
- The fill width, `NN%.` read-out and status line share one progress value.
- Timed demo: 0→100 % in 1.8 s, stages `Power on → Display ready → LoRa init
  → Touch ready → Finalising → System online`.
- Firmware can take over with `ui_boot_set_progress(percent, status)`; setup()
  reports 5 % power, 18 % display, 45 % LoRa standby, 65 % touch, 82 % UI,
  100 % system online, then enters COMMAND.
- Telemetry strip hidden.

### 3.2 COMMAND / home (`src/ui/screen_main.c`)
- Header: `SOS // COMMAND`, blinking green READY dot, LOCAL MODE.
- Radar ring (4 × 90° arcs, service colours) with a 2.8 s rotating cyan sweep.
- Four service nodes at the diagonals:
  - AMB (top-right), FIRE (top-left), PD (bottom-left), EMG (bottom-right).
- Centre core: `SOS / CALL`, pulsing cyan glow.
- Bottom: `CALL <service>` bar (service gradient) + `DEMO >` tab.
- Tapping a node selects it and instantly updates the arcs, node glow and CALL
  bar without rebuilding the screen (`ui_home_set_selected`).

### 3.3 Service slide (`src/ui/screen_service.c` → `screen_slideshow.c`)
The app-style slide from the supplied reference, rendered entirely in LVGL:
- Black 22 px top bar: `Node` (magenta) `1` (orange), green online dot,
  `ADWS Online` (cyan), gear glyph (grey) at x=208, and a live `MM:SS` clock
  (blue, uptime) right-aligned.
- Huge centred service title (Montserrat 28) with a red `01 / 04` counter.
- Full-width 320×120 hero art at y=60 (rounded, clipped corners).
- White 6 px rounded chevrons drawn with `lv_line` at x 18..42 / 278..302.
- Grey `Call` pill (x 10..126, y 200..232) containing a green phone disc with
  `LV_SYMBOL_CALL` and a white `Call` label.
- Dark page-dot capsule (four dots, current one white) and the home bar.
- The slide body fades/slides in; the art slides horizontally on entry.

### 3.4 Calling (`src/ui/screen_calling.c`)
- Amber `OFFLINE • LOCAL ALERT ONLY` banner.
- Three expanding sonar rings (150→230 px, 1.5 s, staggered 0/500/1000 ms).
- 5 s countdown arc (100→0) around a service-coloured core.
- `CALLING`, service code, `LOCAL ALERT`.
- Depleting bar, `T-5.0` → `T-0.0` timer, blinking red LIVE dot,
  `TOUCH TO ABORT`.
- Firmware owns the real 5 s call; the UI animation mirrors it.

### 3.5 Diagnostics (`src/ui/screen_config.c`)
- 270° pressure arc gauge (0..4606) with numeric value and IDLE/LOW/OK state.
- Right column: UPTIME, MODE, LINK, RADIO STANDBY, THRESHOLD, FIRMWARE HUD 2.0.
- Live updates via `ui_config_update_pressure()` / `ui_config_update_uptime()`
  called from the shared telemetry path.
- `TOUCH ANYWHERE TO RETURN` pill.

### 3.6 Slideshow (`src/ui/screen_slideshow.c`)
- `ui_show_slideshow()` simply calls `ui_show_slide()`, so the demo is the exact
  same app slide as the service screen — all four services stitch with no
  layout jump.
- Arrows, Call pill, gear and page dots stay live during the demo.
- Entry: tap `DEMO >` on COMMAND. The release that enters is ignored.
- Manual advance only; 2 s hold exits to COMMAND. A yellow hold-progress line
  grows above the telemetry strip.

### 3.7 Persistent telemetry (`src/ui/ui_common.c`)
Top-layer strip at y=225..239, visible on every screen except boot:
- `P nnnn [LOW/OK/---]` — raw XPT2046 Z, 0 idle, ≤4300 LOW, >4300 OK.
- `T+MM:SS` uptime.
- Green LOCAL link dot.
- A 2 px pressure gauge across the bottom.

---

## 4. Interaction model (firmware)

| State | Touch | Short button | 2 s button |
|---|---|---|---|
| COMMAND | tap node = select; core/CALL = call; DEMO = slideshow | call current service | config |
| SERVICE | PREV / CALL / NEXT zones | call current service | config |
| CALLING | anywhere = abort | — | cancel call + config |
| DIAGNOSTICS | anywhere = COMMAND | — | config |
| SLIDESHOW | release = next slide | — | cancel + config |
| Boot | ignored (2 s) | ignored | ignored |

The old spurious boot call guard is retained: the button edge detector starts
released, so the first idle loop cannot fire a call.

---

## 5. Key source files

```
sos_lvgl.ino                 firmware: display flush, touch, state machine, LoRa
src/ui/ui_common.h/.c        palette, HUD primitives, telemetry, hit tests
src/ui/screen_logo.c         boot sequence
src/ui/screen_main.c         COMMAND radar home + selection
src/ui/screen_service.c      service detail
src/ui/screen_calling.c      sonar calling screen
src/ui/screen_config.c       diagnostics
src/ui/screen_slideshow.c    cinematic slideshow
src/assets/color_*.c         4 × 320×136 RGB565 hero images
sim/sim_ui_init.c            simulator entry points
tools/render_screenshots.mjs MCP-driven PNG capture
tools/make_gallery.py        HTML gallery builder
screenshots/                 final PNGs, 2× copies, contact sheet, index.html
```

Geometry shared between UI and firmware:
- Home centre `(160,118)`, node radius 22, core radius 30.
- Node centres: AMB (212,66), FIRE (108,66), PD (108,170), EMG (212,170).
- CALL bar: x 6..230, y 198..224. DEMO: x 234..314, y 198..224.
- Service slide touch zones (`ui_slide_hit`): gear x 206..244, y 0..26;
  chevrons x 2..72 / 248..318, y 92..172; Call pill x 6..130, y 194..240.
- The same slide is used by `ui_show_service()` and `ui_show_slideshow()`;
  `ui_show_slide()` lives in `screen_slideshow.c`.

---

## 6. Performance notes / gotchas found

1. **`transform_scale` on a 150 px ring blew the heap.** Scaling to 1.78× made
   the simulator report a **224 KB** LVGL peak (budget 64 KB). It was replaced
   with size + position animation (150→230 px), dropping the calling screen to
   **≈36.7 KB**.
2. **LVGL 9.6 deprecations:** `lv_obj_add_flag/remove_flag` are deprecated; use
   `lv_obj_set_hidden`, `lv_obj_set_scrollable`, `lv_obj_set_clickable`.
   `lv_obj_set_style_transform_zoom` is aliased to `transform_scale` in 9.6;
   the HUD avoids it for large objects.
3. **Labels must account for borders.** A 2 px border shrinks the content box by
   4 px; labels were sized/positioned accordingly to remove every
   `OUTSIDE_PARENT` warning.
4. **Telemetry strip height** is 15 px so a Montserrat 12 line box fits without
   clipping; screens end at y=224, strip at 225..239.
5. Arc angles in LVGL: 0° = 3 o'clock, increasing clockwise. Sector map:
   top-right 272..358, top-left 182..268, bottom-left 92..178,
   bottom-right 2..88.

---

## 7. Verification status

- Simulator: all screens compile with **0 compiler warnings** and **0
  warning/error diagnostics**. Only intentional `OVERLAP` info remains for
  decorative arcs, HUD grid lines and full-width labels.
- Heap peaks: home ≈39.6 KB, calling ≈36.7 KB, config ≈29 KB, slideshow ≈23 KB,
  against the 64 KB device budget.
- Firmware: Arduino CLI build **0 warnings**, **1,039,588 B flash (33%)**,
  **114,872 B RAM (35%)**, 212,808 B free; binary `build/sos_lvgl.ino.bin`.
- No board was connected, so the firmware was **not flashed**; touch
  calibration remains the stock `{300, 3600, 300, 3600, 0}` starting point.

---

## 8. Reproduce

```bash
# firmware
arduino-cli compile \
  --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB" \
  .

# screenshots (drives the same lvgl-simulator MCP server over stdio)
node tools/render_screenshots.mjs
python3 tools/make_gallery.py
```

Open `screenshots/index.html` for the gallery.

---

## 9. Known limitations / next steps

- **Not flashed:** bench-test the panel, touch axes and buzzer polarity first.
- **Touch calibration** is a stock starting point; use `tft.calibrateTouch()`
  or change the fifth `setTouch` value (bit0 rotate, bit1 invert X, bit2 invert Y).
- **Pressure** is raw Z, not calibrated force.
- **LoRa** stays in standby; no TX path exists by design.
- **Boot screen** uses infinite spinner/progress animations; on real hardware
  the 2 s splash may end mid-spin (expected).
- Possible future polish: per-node selection animation, a real radar blip
  trail, and a swipe gesture between services.