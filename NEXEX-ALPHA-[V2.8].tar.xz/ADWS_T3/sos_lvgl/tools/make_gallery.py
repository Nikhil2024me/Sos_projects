#!/usr/bin/env python3
"""Build a simple HTML gallery for the simulator screenshots.

Scans sos_lvgl/screenshots/*.png and writes screenshots/index.html with one
caption per image (file name made readable).  Run after render_screenshots.mjs.

Usage:  python3 tools/make_gallery.py
"""

import html
import re
from pathlib import Path

here = Path(__file__).resolve().parent
shots = here.parent / "screenshots"
pngs = sorted(p for p in shots.glob("*.png"))


def caption(name: str) -> str:
    stem = name[:-4]
    m = re.match(r"^(\d+)_(.*?)(?:_(\d+))?$", stem)
    if m:
        num, title, frame = m.groups()
        title = title.replace("_", " ")
        if frame:
            title += f"  (frame {frame})"
        return f"{num}. {title}"
    return stem.replace("_", " ")


rows = []
for p in pngs:
    rel = html.escape(p.name)
    rows.append(
        f'  <figure>\n'
        f'    <img src="{rel}" alt="{html.escape(caption(p.name))}" loading="lazy">\n'
        f'    <figcaption>{html.escape(caption(p.name))}<br><code>{rel}</code></figcaption>\n'
        f'  </figure>'
    )

doc = f"""<!doctype html>
<html lang="en">
<meta charset="utf-8">
<title>SOS Emergency Transmitter - colour V2 screenshots</title>
<style>
  :root {{ color-scheme: dark; }}
  body {{ background:#0a0f1a; color:#e8eefc; font:16px/1.4 system-ui, sans-serif; margin:24px; }}
  h1 {{ font-size:22px; }}
  p  {{ color:#9fb0cc; }}
  .grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(340px,1fr)); gap:20px; }}
  figure {{ margin:0; background:#111a2b; border:1px solid #22314f; border-radius:10px; padding:12px; }}
  img {{ width:100%; height:auto; image-rendering:pixelated; border-radius:6px; background:#000; }}
  figcaption {{ margin-top:8px; color:#c7d4ea; font-size:14px; }}
  code {{ color:#8fa1bd; font-size:12px; }}
</style>
<h1>SOS Emergency Transmitter - colour V2</h1>
<p>LVGL 9.6 simulator renders, 320x240 RGB565, device fonts (montserrat 12/14/16/20/28), 64 KB heap budget. {len(pngs)} image(s).</p>
<div class="grid">
""" + "\n".join(rows) + "\n</div>\n</html>\n"

(shots / "index.html").write_text(doc, encoding="utf-8")
print(f"wrote {shots / 'index.html'} ({len(pngs)} images)")
