#!/usr/bin/env python3
"""Generate the four 294x98 service hero illustrations for the Unified Hero Card.

All four slides share the same visual composition from the V4 reference design:
  * Deep obsidian oscilloscope grid (#0E1015 background, #161A23 grid hairlines)
  * Glowing left & right telemetry waveform in the service's semantic colour
  * Crisp 3/4-perspective emergency vehicle centered in the viewport
  * Built-in subtle dark nav-button pads on the left/right edges

Outputs:
  art/raw/<service>_2x.png   588x196 master
  art/raw/<service>.png      294x98 final
"""

import os
import shutil
import gi

gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "art", "raw")
W, H = 588, 196
OW, OH = 294, 98


def grid_svg():
    lines = []
    for x in range(28, W, 28):
        lines.append(f'<line x1="{x}" y1="0" x2="{x}" y2="{H}" stroke="#161922" stroke-width="1"/>')
    for y in range(28, H, 28):
        lines.append(f'<line x1="0" y1="{y}" x2="{W}" y2="{y}" stroke="#161922" stroke-width="1"/>')
    return "\n  ".join(lines)


def nav_buttons_svg():
    return """
  <!-- Subtle left/right nav button pads matching the reference card -->
  <g>
    <rect x="10" y="76" width="38" height="38" rx="8" fill="#151821" fill-opacity="0.88" stroke="#252A36" stroke-width="1.5"/>
    <polyline points="32,87 24,95 32,103" fill="none" stroke="#687082" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="540" y="76" width="38" height="38" rx="8" fill="#151821" fill-opacity="0.88" stroke="#252A36" stroke-width="1.5"/>
    <polyline points="556,87 564,95 556,103" fill="none" stroke="#687082" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
  </g>"""


def scene(accent, accent_bright, wave_pts_left, wave_pts_right, vehicle_svg):
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#0B0D12"/>
    <stop offset="0.6" stop-color="#10131B"/>
    <stop offset="1" stop-color="#0C0E14"/>
  </linearGradient>
  <radialGradient id="glow" cx="0.52" cy="0.52" r="0.46">
    <stop offset="0" stop-color="{accent}" stop-opacity="0.32"/>
    <stop offset="0.55" stop-color="{accent}" stop-opacity="0.10"/>
    <stop offset="1" stop-color="{accent}" stop-opacity="0"/>
  </radialGradient>
  <radialGradient id="beaconGlow" cx="0.5" cy="0.5" r="0.5">
    <stop offset="0" stop-color="#FFFFFF" stop-opacity="0.95"/>
    <stop offset="0.25" stop-color="{accent_bright}" stop-opacity="0.85"/>
    <stop offset="0.65" stop-color="{accent}" stop-opacity="0.25"/>
    <stop offset="1" stop-color="{accent}" stop-opacity="0"/>
  </radialGradient>
  <linearGradient id="whiteBody" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#FFFFFF"/>
    <stop offset="0.6" stop-color="#DCE4F0"/>
    <stop offset="1" stop-color="#9BA8BC"/>
  </linearGradient>
  <linearGradient id="glass" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#4A6B8C"/>
    <stop offset="0.45" stop-color="#1E2F44"/>
    <stop offset="1" stop-color="#0E1622"/>
  </linearGradient>
  <linearGradient id="chrome" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0" stop-color="#F1F5F9"/>
    <stop offset="0.5" stop-color="#94A3B8"/>
    <stop offset="1" stop-color="#475569"/>
  </linearGradient>
  <filter id="blur4" x="-30%" y="-30%" width="160%" height="160%">
    <feGaussianBlur stdDeviation="4"/>
  </filter>
  <filter id="blur2" x="-20%" y="-20%" width="140%" height="140%">
    <feGaussianBlur stdDeviation="2"/>
  </filter>
</defs>

<rect width="{W}" height="{H}" fill="url(#bg)"/>
<g opacity="0.85">
  {grid_svg()}
</g>
<ellipse cx="306" cy="104" rx="220" ry="86" fill="url(#glow)"/>

<!-- Glowing background telemetry waveform -->
<g filter="url(#blur4)" opacity="0.75">
  <polyline points="{wave_pts_left}" fill="none" stroke="{accent}" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"/>
  <polyline points="{wave_pts_right}" fill="none" stroke="{accent}" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"/>
</g>
<polyline points="{wave_pts_left}" fill="none" stroke="{accent_bright}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>
<polyline points="{wave_pts_right}" fill="none" stroke="{accent_bright}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>

<!-- Ground shadow -->
<ellipse cx="306" cy="182" rx="148" ry="10" fill="#000000" opacity="0.75" filter="url(#blur4)"/>

{vehicle_svg}

{nav_buttons_svg()}
</svg>"""


def police_svg():
    return """<g id="police_car">
  <!-- Main 3/4 interceptor body (angled left-front at x=165..280, right-side x=280..455) -->
  <!-- Rear & side lower body -->
  <path d="M168 124 L176 98 L216 90 L254 56 Q262 50 278 50 H396 Q410 50 422 62 L446 92 L458 104 V162 Q458 170 448 170 H178 Q168 170 168 160 Z" fill="#141B29" stroke="#2E3B52" stroke-width="1.5"/>
  <!-- Upper cabin & roof -->
  <path d="M218 90 L254 56 Q262 50 278 50 H394 Q408 50 418 62 L440 90 Z" fill="#1E293B"/>
  <!-- Windshield (3/4 front-left angle) -->
  <polygon points="222,88 256,58 318,58 294,88" fill="url(#glass)" stroke="#475569" stroke-width="1.5"/>
  <polygon points="232,84 258,61 286,61 268,84" fill="#93C5FD" opacity="0.22"/>
  <!-- Side windows -->
  <polygon points="304,88 326,58 374,58 374,88" fill="url(#glass)" stroke="#475569" stroke-width="1.2"/>
  <polygon points="380,88 380,58 412,60 432,88" fill="url(#glass)" stroke="#475569" stroke-width="1.2"/>

  <!-- White police door panels on side -->
  <polygon points="296,94 424,94 424,154 292,154" fill="url(#whiteBody)"/>
  <!-- Bright blue tactical stripe along side & front fender -->
  <polygon points="170,130 288,126 456,126 456,138 288,138 170,140" fill="#2563EB"/>
  <polygon points="170,130 288,126 456,126 456,130 288,130 170,133" fill="#60A5FA"/>
  <text x="328" y="122" fill="#0F172A" font-family="DejaVu Sans, sans-serif" font-weight="bold" font-size="14" letter-spacing="1">POLICE</text>

  <!-- Front hood & interceptor fascia (x=166..292) -->
  <polygon points="174,98 220,88 294,88 276,106" fill="#263349" stroke="#475569" stroke-width="1"/>
  <!-- Front grille & push-bumper -->
  <rect x="182" y="108" width="68" height="34" rx="4" fill="#0B0F17" stroke="#475569" stroke-width="2"/>
  <line x1="188" y1="116" x2="244" y2="116" stroke="#334155" stroke-width="2"/>
  <line x1="188" y1="124" x2="244" y2="124" stroke="#334155" stroke-width="2"/>
  <line x1="188" y1="132" x2="244" y2="132" stroke="#334155" stroke-width="2"/>
  <!-- Red/Blue grille strobes -->
  <rect x="192" y="118" width="16" height="7" rx="2" fill="#EF4444"/>
  <rect x="224" y="118" width="16" height="7" rx="2" fill="#3B82F6"/>
  <!-- Left & right headlights -->
  <rect x="168" y="108" width="14" height="16" rx="3" fill="#FEF08A" stroke="#CA8A04" stroke-width="1"/>
  <rect x="252" y="106" width="22" height="18" rx="3" fill="#FEF08A" stroke="#CA8A04" stroke-width="1"/>
  <rect x="254" y="108" width="18" height="8" rx="2" fill="#FFFFFF"/>
  <!-- Front bumper & bullbar -->
  <rect x="162" y="144" width="124" height="18" rx="4" fill="#334155" stroke="#64748B" stroke-width="1.5"/>
  <rect x="186" y="102" width="60" height="58" rx="4" fill="none" stroke="#1E293B" stroke-width="5"/>
  <rect x="204" y="148" width="24" height="10" rx="2" fill="#F8FAFC"/>

  <!-- Roof Police Lightbar (Red + Blue) -->
  <rect x="270" y="36" width="106" height="14" rx="6" fill="#0F172A" stroke="#475569" stroke-width="1.5"/>
  <rect x="274" y="39" width="46" height="8" rx="4" fill="#EF4444"/>
  <rect x="326" y="39" width="46" height="8" rx="4" fill="#3B82F6"/>
  <ellipse cx="296" cy="43" rx="46" ry="18" fill="#EF4444" opacity="0.45" filter="url(#blur4)"/>
  <ellipse cx="350" cy="43" rx="52" ry="20" fill="url(#beaconGlow)" opacity="0.85"/>

  <!-- Wheels (3/4 front wheel @ x=298, rear wheel @ x=424, front-left tire @ x=190) -->
  <ellipse cx="192" cy="168" rx="18" ry="14" fill="#090D14"/>
  <ellipse cx="300" cy="164" rx="22" ry="24" fill="#090D14" stroke="#334155" stroke-width="2"/>
  <ellipse cx="300" cy="164" rx="12" ry="14" fill="url(#chrome)"/>
  <ellipse cx="424" cy="164" rx="20" ry="22" fill="#090D14" stroke="#334155" stroke-width="2"/>
  <ellipse cx="424" cy="164" rx="11" ry="13" fill="url(#chrome)"/>
</g>"""


def fire_engine_svg():
    return """<g id="fire_truck">
  <!-- Rear apparatus body (3/4 perspective, x=300..464) -->
  <polygon points="300,32 462,38 462,164 300,168" fill="#B91C1C" stroke="#F87171" stroke-width="1.5"/>
  <!-- Roll-up equipment compartments on side -->
  <rect x="344" y="64" width="52" height="66" rx="3" fill="#CBD5E1" stroke="#64748B" stroke-width="1.5"/>
  <rect x="404" y="64" width="48" height="66" rx="3" fill="#CBD5E1" stroke="#64748B" stroke-width="1.5"/>
  <g stroke="#94A3B8" stroke-width="2">
    <line x1="346" y1="76" x2="394" y2="76"/><line x1="346" y1="88" x2="394" y2="88"/>
    <line x1="346" y1="100" x2="394" y2="100"/><line x1="346" y1="112" x2="394" y2="112"/>
    <line x1="406" y1="76" x2="450" y2="76"/><line x1="406" y1="88" x2="450" y2="88"/>
    <line x1="406" y1="100" x2="450" y2="100"/><line x1="406" y1="112" x2="450" y2="112"/>
  </g>
  <!-- Roof aluminum ladder rack -->
  <rect x="310" y="20" width="148" height="12" rx="2" fill="none" stroke="#E2E8F0" stroke-width="3"/>
  <g stroke="#CBD5E1" stroke-width="2">
    <line x1="326" y1="20" x2="326" y2="32"/><line x1="346" y1="20" x2="346" y2="32"/>
    <line x1="366" y1="20" x2="366" y2="32"/><line x1="386" y1="20" x2="386" y2="32"/>
    <line x1="406" y1="20" x2="406" y2="32"/><line x1="426" y1="20" x2="426" y2="32"/>
  </g>

  <!-- 3/4 Front Cab (x=166..336) -->
  <polygon points="168,54 278,44 336,48 336,166 168,164" fill="#DC2626" stroke="#FCA5A5" stroke-width="1.5"/>
  <!-- White upper cab stripe & gold reflective band -->
  <polygon points="168,128 336,128 462,130 462,144 336,144 168,142" fill="#FEF3C7"/>
  <polygon points="168,132 336,132 462,134 462,140 336,140 168,138" fill="#F59E0B"/>

  <!-- Cab Front Windshield (split two-pane fire cab) -->
  <polygon points="176,62 224,58 224,96 174,98" fill="url(#glass)" stroke="#E2E8F0" stroke-width="1.5"/>
  <polygon points="230,58 282,54 282,96 230,96" fill="url(#glass)" stroke="#E2E8F0" stroke-width="1.5"/>
  <!-- Cab Side Door Window -->
  <polygon points="292,58 328,60 328,96 292,96" fill="url(#glass)" stroke="#E2E8F0" stroke-width="1.5"/>

  <!-- Chrome Fire Grille & Headlights -->
  <rect x="184" y="104" width="84" height="36" rx="4" fill="url(#chrome)" stroke="#475569" stroke-width="1.5"/>
  <g stroke="#334155" stroke-width="2">
    <line x1="190" y1="112" x2="262" y2="112"/><line x1="190" y1="120" x2="262" y2="120"/>
    <line x1="190" y1="128" x2="262" y2="128"/><line x1="190" y1="134" x2="262" y2="134"/>
  </g>
  <rect x="196" y="114" width="16" height="8" rx="2" fill="#F59E0B"/>
  <rect x="240" y="114" width="16" height="8" rx="2" fill="#EF4444"/>
  <!-- Dual Headlight bezels -->
  <rect x="168" y="110" width="16" height="22" rx="3" fill="#FEF08A" stroke="#94A3B8" stroke-width="1.5"/>
  <rect x="268" y="108" width="20" height="24" rx="3" fill="#FEF08A" stroke="#94A3B8" stroke-width="1.5"/>
  <rect x="270" y="110" width="16" height="10" rx="2" fill="#FFFFFF"/>

  <!-- Heavy Chrome Front Bumper -->
  <rect x="160" y="144" width="134" height="18" rx="4" fill="url(#chrome)" stroke="#64748B" stroke-width="1.5"/>
  <rect x="208" y="148" width="32" height="10" rx="2" fill="#F59E0B"/>

  <!-- Roof Amber/Red Lightbars -->
  <rect x="192" y="34" width="104" height="14" rx="6" fill="#451A03" stroke="#F59E0B" stroke-width="1.5"/>
  <rect x="198" y="37" width="44" height="8" rx="4" fill="#F59E0B"/>
  <rect x="246" y="37" width="44" height="8" rx="4" fill="#EF4444"/>
  <ellipse cx="244" cy="40" rx="70" ry="22" fill="url(#beaconGlow)" opacity="0.9"/>

  <!-- Wheels -->
  <ellipse cx="192" cy="168" rx="18" ry="14" fill="#090D14"/>
  <ellipse cx="308" cy="164" rx="22" ry="24" fill="#090D14" stroke="#475569" stroke-width="2"/>
  <ellipse cx="308" cy="164" rx="12" ry="14" fill="url(#chrome)"/>
  <ellipse cx="430" cy="164" rx="21" ry="23" fill="#090D14" stroke="#475569" stroke-width="2"/>
  <ellipse cx="430" cy="164" rx="11" ry="13" fill="url(#chrome)"/>
</g>"""


def emergency_svg():
    return """<g id="emergency_command_unit">
  <!-- 3/4 Armored All-Hazard Command SUV / Responder Truck -->
  <!-- Rear Command Module (x=290..456) -->
  <polygon points="286,38 454,44 454,162 286,166" fill="#2E1065" stroke="#A855F7" stroke-width="1.5"/>
  <!-- Side Hazard Striping & Command Pod -->
  <rect x="336" y="60" width="104" height="54" rx="6" fill="#1E1B4B" stroke="#7E22CE" stroke-width="1.5"/>
  <!-- Glowing SOS Emblem on side pod -->
  <circle cx="388" cy="87" r="18" fill="#581C87" stroke="#E879F9" stroke-width="2"/>
  <text x="388" y="92" text-anchor="middle" fill="#FFFFFF" font-family="DejaVu Sans, sans-serif" font-weight="bold" font-size="13">SOS</text>

  <!-- Roof Satcom Dish & Dual Beacons -->
  <ellipse cx="396" cy="30" rx="26" ry="8" fill="#CBD5E1" stroke="#64748B" stroke-width="1.5"/>
  <line x1="396" y1="30" x2="408" y2="16" stroke="#E879F9" stroke-width="2.5"/>
  <circle cx="408" cy="15" r="4" fill="#F0ABFC"/>

  <!-- 3/4 Front Armored Cab (x=168..326) -->
  <path d="M168 110 L178 86 L216 78 L248 48 Q256 42 272 42 H326 V164 H168 Z" fill="#3B0764" stroke="#C084FC" stroke-width="1.5"/>
  <!-- Neon Violet + White Hazard Stripe -->
  <polygon points="168,128 290,126 454,128 454,142 290,140 168,140" fill="#A855F7"/>
  <polygon points="168,132 290,130 454,132 454,136 290,134 168,136" fill="#F5D0FE"/>

  <!-- Windshield & Side Armored Glass -->
  <polygon points="220,78 250,50 306,50 286,78" fill="url(#glass)" stroke="#C084FC" stroke-width="1.5"/>
  <polygon points="294,78 312,50 344,50 344,78" fill="url(#glass)" stroke="#C084FC" stroke-width="1.2"/>

  <!-- Front Fascia, Winch Grille & Strobes -->
  <rect x="182" y="96" width="70" height="36" rx="4" fill="#0F0720" stroke="#7E22CE" stroke-width="2"/>
  <rect x="192" y="106" width="18" height="8" rx="2" fill="#E879F9"/>
  <rect x="224" y="106" width="18" height="8" rx="2" fill="#38BDF8"/>
  <!-- Headlights -->
  <rect x="168" y="98" width="14" height="18" rx="3" fill="#FEF08A" stroke="#C084FC" stroke-width="1"/>
  <rect x="254" y="96" width="22" height="20" rx="3" fill="#FEF08A" stroke="#C084FC" stroke-width="1"/>
  <rect x="256" y="98" width="18" height="9" rx="2" fill="#FFFFFF"/>
  <!-- Heavy Bumper -->
  <rect x="160" y="142" width="128" height="18" rx="4" fill="#1E1B4B" stroke="#A855F7" stroke-width="1.5"/>
  <rect x="202" y="146" width="28" height="10" rx="2" fill="#F0ABFC"/>

  <!-- Roof Violet/Cyan Strobe Bar -->
  <rect x="254" y="28" width="96" height="14" rx="6" fill="#1E1B4B" stroke="#E879F9" stroke-width="1.5"/>
  <rect x="260" y="31" width="40" height="8" rx="4" fill="#D946EF"/>
  <rect x="304" y="31" width="40" height="8" rx="4" fill="#38BDF8"/>
  <ellipse cx="302" cy="34" rx="68" ry="22" fill="url(#beaconGlow)" opacity="0.9"/>

  <!-- Wheels -->
  <ellipse cx="192" cy="168" rx="18" ry="14" fill="#090D14"/>
  <ellipse cx="298" cy="164" rx="22" ry="24" fill="#090D14" stroke="#7E22CE" stroke-width="2"/>
  <ellipse cx="298" cy="164" rx="12" ry="14" fill="url(#chrome)"/>
  <ellipse cx="422" cy="164" rx="21" ry="23" fill="#090D14" stroke="#7E22CE" stroke-width="2"/>
  <ellipse cx="422" cy="164" rx="11" ry="13" fill="url(#chrome)"/>
</g>"""


SERVICES = [
    (
        "fire_engine",
        "#D97706",
        "#F59E0B",
        "48,96 76,96 88,82 98,112 112,38 124,132 136,74 148,104 166,96",
        "464,96 482,96 494,48 506,126 518,78 530,96 540,96",
        fire_engine_svg(),
    ),
    (
        "police",
        "#2563EB",
        "#60A5FA",
        "48,96 74,96 84,68 94,124 106,42 118,136 130,76 142,108 166,96",
        "460,96 480,96 492,52 504,128 516,80 528,96 540,96",
        police_svg(),
    ),
    (
        "emergency",
        "#9333EA",
        "#E879F9",
        "48,96 72,96 84,58 96,128 108,34 120,140 132,68 144,112 166,96",
        "458,96 478,96 490,44 502,132 514,72 526,96 540,96",
        emergency_svg(),
    ),
]


def render(svg_text, path):
    tmp = path + ".svg"
    with open(tmp, "w") as f:
        f.write(svg_text)
    p = GdkPixbuf.Pixbuf.new_from_file_at_scale(tmp, W, H, False)
    p.savev(path, "png", [], [])
    os.remove(tmp)


def main():
    os.makedirs(OUT, exist_ok=True)

    # 1. All 4 services use the exact 3/4 reference artworks when present
    for ref_name in ("ambulance", "police", "fire_engine", "emergency"):
        ref_2x = os.path.join(OUT, f"{ref_name}_ref_2x.png")
        if os.path.exists(ref_2x):
            p = GdkPixbuf.Pixbuf.new_from_file(ref_2x)
            p2x = p.scale_simple(W, H, GdkPixbuf.InterpType.BILINEAR)
            p2x.savev(os.path.join(OUT, f"{ref_name}_2x.png"), "png", [], [])
            p1x = p.scale_simple(OW, OH, GdkPixbuf.InterpType.BILINEAR)
            p1x.savev(os.path.join(OUT, f"{ref_name}.png"), "png", [], [])
            print(f"  {ref_name}: {os.path.join(OUT, f'{ref_name}.png')} (from reference)")

    # 2. Remaining services rendered in matching 294x98 style
    for name, accent, accent_bright, wl, wr, vehicle in SERVICES:
        if os.path.exists(os.path.join(OUT, f"{name}_ref_2x.png")):
            continue
        svg = scene(accent, accent_bright, wl, wr, vehicle)
        master = os.path.join(OUT, f"{name}_2x.png")
        final = os.path.join(OUT, f"{name}.png")
        render(svg, master)
        p = GdkPixbuf.Pixbuf.new_from_file(master)
        scaled = p.scale_simple(OW, OH, GdkPixbuf.InterpType.BILINEAR)
        scaled.savev(final, "png", [], [])
        print(f"  {name}: {final}")


if __name__ == "__main__":
    main()
