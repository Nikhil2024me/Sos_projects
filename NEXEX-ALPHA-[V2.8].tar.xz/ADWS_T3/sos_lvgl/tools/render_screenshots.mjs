#!/usr/bin/env node
// Render every SOS V2 screen through the real LVGL 9.6 simulator that backs the
// lvgl-simulator MCP server, and write the PNGs to sos_lvgl/screenshots/.
//
// The MCP render tools hand images back inline to the chat client, which does
// not persist them.  The same MCP server over stdio is used here as a plain
// client so the base64 PNGs can be written to disk where they can be opened.
//
// Usage:  node tools/render_screenshots.mjs
//
// Requires the lvgl-mcp-server checkout at
//   /home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server (built with `npm run build`).

import { Client } from "/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js";
import { StdioClientTransport } from "/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server/node_modules/@modelcontextprotocol/sdk/dist/esm/client/stdio.js";
import { mkdirSync, writeFileSync } from "node:fs";
import { existsSync } from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(here, "..");
const outDir = path.join(projectRoot, "screenshots");
mkdirSync(outDir, { recursive: true });

const MCP_DIR = "/home/debian/mcp-servers/lvgl-mcp-esp32/mcp-server";
const serverEntry = path.join(MCP_DIR, "dist", "index.js");
if (!existsSync(serverEntry)) {
  console.error(`Missing ${serverEntry} - run "npm run build" in ${MCP_DIR}`);
  process.exit(1);
}

const fonts = ["montserrat_12", "montserrat_14", "montserrat_16", "montserrat_20", "montserrat_28"];

// name -> entry function; `frames` shows animation progress over time.
const SCREENS = [
  { file: "01_boot", entry: "sim_boot", frames: [0, 450, 900, 1350, 1800] },
  { file: "02_home", entry: "sim_home", ms: 400 },
  { file: "03_home_fire", entry: "sim_home_fire", ms: 400 },
  { file: "04_home_police", entry: "sim_home_police", ms: 400 },
  { file: "05_home_emergency", entry: "sim_home_emergency", ms: 400 },
  { file: "06_service_ambulance", entry: "sim_service_ambulance", ms: 400 },
  { file: "07_service_fire_engine", entry: "sim_service_fire", ms: 400 },
  { file: "08_service_police", entry: "sim_service_police", ms: 400 },
  { file: "09_service_emergency", entry: "sim_service_emergency", ms: 400 },
  { file: "10_configuration", entry: "sim_config", ms: 400 },
  { file: "11_calling_ambulance", entry: "sim_calling_ambulance", frames: [0, 1000, 2500, 5000, 6000] },
  { file: "12_calling_fire_engine", entry: "sim_calling_fire", frames: [0, 2500, 5000] },
  { file: "13_calling_police", entry: "sim_calling_police", frames: [0, 2500, 5000] },
  { file: "14_calling_emergency", entry: "sim_calling_emergency", frames: [0, 2500, 5000] },
  { file: "15_slideshow_ambulance", entry: "sim_slideshow_1", ms: 400 },
  { file: "16_slideshow_fire_engine", entry: "sim_slideshow_2", ms: 400 },
  { file: "17_slideshow_police", entry: "sim_slideshow_3", ms: 400 },
  { file: "18_slideshow_emergency", entry: "sim_slideshow_4", ms: 400 },
  { file: "19_slideshow_hold_to_exit", entry: "sim_slideshow_hold", ms: 400 },
];

const transport = new StdioClientTransport({
  command: process.execPath,
  args: [serverEntry],
  cwd: MCP_DIR,
  env: {
    ...process.env,
    LVGL_PROJECT_ROOT: "/home/debian/mcp-servers/lvgl-mcp-esp32",
    LVGL_ALLOWED_ROOTS: projectRoot,
  },
  stderr: "inherit",
});

const client = new Client({ name: "sos-screenshots", version: "1.0.0" });
await client.connect(transport);

const callOpts = { timeout: 20 * 60_000 };
const textOf = (r) => (r.content ?? []).filter((c) => c.type === "text").map((c) => c.text).join("\n");

let failures = 0;
for (const s of SCREENS) {
  const args = {
    root: projectRoot,
    entry: s.entry,
    width: 320,
    height: 240,
    board: "generic-320x240",
    color_format: "rgb565",
    fonts,
    mem_budget_kb: 64,
    include_tree: "none",
  };
  if (s.frames) args.frames = s.frames;
  else args.time_ms = s.ms ?? 100;

  process.stdout.write(`[${s.file}] ${s.entry} ... `);
  let r;
  try {
    r = await client.callTool({ name: "lvgl_render_project", arguments: args }, undefined, callOpts);
  } catch (err) {
    failures++;
    console.log(`FAILED: ${err.message}`);
    continue;
  }
  if (r.isError) {
    failures++;
    console.log(`FAILED:\n${textOf(r)}`);
    continue;
  }
  const imgs = (r.content ?? []).filter((c) => c.type === "image");
  if (!imgs.length) {
    failures++;
    console.log("FAILED: no PNG in the result");
    continue;
  }
  imgs.forEach((img, i) => {
    const label = imgs.length === 1 ? s.file : `${s.file}_${i + 1}`;
    const file = path.join(outDir, `${label}.png`);
    writeFileSync(file, Buffer.from(img.data, "base64"));
  });
  console.log(`${imgs.length} PNG${imgs.length > 1 ? "s" : ""} -> ${path.relative(process.cwd(), path.join(outDir, s.file))}*.png`);
}

await client.close();

console.log(`\nSaved to: ${outDir}`);
if (failures) {
  console.error(`${failures} screen(s) failed`);
  process.exit(1);
}
