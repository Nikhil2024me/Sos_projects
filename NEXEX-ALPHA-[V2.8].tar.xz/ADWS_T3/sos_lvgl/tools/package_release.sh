#!/usr/bin/env bash
# Package the Mission Control HUD project, firmware, screenshots and context
# into /home/debian/Downloads/Saves.
#
# Usage:  tools/package_release.sh
set -euo pipefail

PROJ="$(cd "$(dirname "$0")/.." && pwd)"
OUT="/home/debian/Downloads/Saves"
STAMP="$(date +%F)"
ZIP="$OUT/SOS_HUD_V3_${STAMP}.zip"

mkdir -p "$OUT"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
DEST="$STAGE/SOS_HUD_V3"
mkdir -p "$DEST/logs" "$DEST/screenshots" "$DEST/sos_lvgl"

cp "$PROJ/README.md" "$PROJ/CONTEXT.md" "$DEST/"
cp "$PROJ/sos_lvgl.ino" "$DEST/sos_lvgl/"
cp -r "$PROJ/src" "$PROJ/config" "$PROJ/sim" "$PROJ/tools" "$DEST/sos_lvgl/"
cp -r "$PROJ/art" "$DEST/sos_lvgl/"
cp -r "$PROJ/screenshots/." "$DEST/screenshots/"

cp /tmp/opencode/sos_hud_compile_final.log "$DEST/logs/build.log" 2>/dev/null || true
cp /tmp/opencode/sos_hud_screenshots_final.log "$DEST/logs/screenshots.log" 2>/dev/null || true
cp "$PROJ/build/sos_lvgl.ino.bin" "$DEST/firmware.bin" 2>/dev/null || true
cp "$OUT/SOS_HUD_V3_hero.png" "$DEST/preview_hero.png" 2>/dev/null || true

cat > "$DEST/START_HERE.txt" <<'EOF'
SOS Emergency Transmitter - Mission Control HUD (V3)
=====================================================

What is in this archive:
  screenshots/index.html   Captioned gallery; open this first.
  screenshots/*.png        Every screen, 320x240 RGB565.
  screenshots/2x/          640x480 upscales for easier viewing.
  screenshots/contact_sheet.png  All screens in one grid.
  preview_hero.png         Boot / home / service / calling preview.
  firmware.bin             Compiled ESP32-S3 application image.
  sos_lvgl/                Arduino sketch (sos_lvgl.ino + src/, config/, sim/).
  CONTEXT.md               Design brief, architecture, decisions, gotchas.
  README.md                Build, wiring, calibration and behaviour.
  logs/build.log           Arduino CLI build output.
  logs/screenshots.log     Simulator screenshot run.

Quick build:
  cp config/lv_conf.h ~/Arduino/libraries/lv_conf.h
  cp config/User_Setup.h ~/Arduino/libraries/TFT_eSPI/User_Setup.h
  arduino-cli compile --fqbn "esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,FlashMode=qio,CDCOnBoot=default,PartitionScheme=app3M_fat9M_16MB" .

Hardware status: compiled and simulator-verified, not flashed.
EOF

# Drop caches and build junk from the packaged tree.
find "$DEST" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
find "$DEST" -name '*.pyc' -delete 2>/dev/null || true

rm -f "$ZIP"
( cd "$STAGE" && python3 -m zipfile -c "$ZIP" SOS_HUD_V3 )
cp "$PROJ/screenshots/contact_sheet.png" "$OUT/SOS_HUD_V3_preview.png" 2>/dev/null || true

echo "Wrote: $ZIP"
echo "Preview: $OUT/SOS_HUD_V3_preview.png"
ls -lh "$ZIP" "$OUT/SOS_HUD_V3_preview.png" 2>/dev/null || true