// SOS Emergency Transmitter — TFT_eSPI configuration
// Target: ESP32-S3-WROOM-1 N16R8 + ILI9341 2.4" (320x240) + XPT2046
//
// Canonical pin map for this physical board (verified against hardware.json
// and ADWS_T2):
//   TFT_SCLK 12   TFT_MOSI 11   TFT_MISO 13
//   TFT_CS   10   TFT_DC    7   TFT_RST   6   TFT_BL 21
//   TOUCH_CS 15   TOUCH_IRQ 16

#define USER_SETUP_ID 701

#define ILI9341_DRIVER

// ------------------- TFT pins (FSPI / SPI2) -------------------
#define TFT_MISO 13
#define TFT_MOSI 11
#define TFT_SCLK 12
#define TFT_CS   10
#define TFT_DC    7
#define TFT_RST   6

// Backlight (active HIGH on GPIO 21)
#define TFT_BL   21
#define TFT_BACKLIGHT_ON HIGH

// ------------------- Touch (same SPI bus) ---------------------
#define TOUCH_CS 15

// ------------------- SPI speed --------------------------------
#define SPI_FREQUENCY        40000000
#define SPI_READ_FREQUENCY   16000000
#define SPI_TOUCH_FREQUENCY   2500000

// Force TFT_eSPI onto GPSPI2 (SPI_PORT = 2 -> DR_REG_SPI2_BASE) while
// constructing SPIClass on FSPI (0) for Arduino-ESP32 3.x compatibility.
#define USE_FSPI_PORT

// ILI9341 panel colour order on this board
#define TFT_RGB_ORDER TFT_BGR
