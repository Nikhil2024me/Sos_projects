#include "src/ui/ui_common.h"

// ---------------------------------------------------------------------------
// V4 Simple Request Screen: Minimalist Unified Card with status pill, bold
// red '!' alert icon + REQUEST + countdown readout, wide smooth progress bar,
// matching card footer, and an LVGL-clickable CANCEL REQUEST button.
// ---------------------------------------------------------------------------

static void timer_cb(void *var, int32_t v)
{
    lv_obj_t *lbl = (lv_obj_t *)var;
    const int32_t tenths = v;
    lv_label_set_text_fmt(lbl, "%d.%ds", (int)(tenths / 10), (int)(tenths % 10));
}

static void blink_cb(void *var, int32_t v)
{
    lv_obj_set_style_opa((lv_obj_t *)var, (lv_opa_t)v, 0);
}

static void cancel_request_cb(lv_event_t *e)
{
    (void)e;
    const ui_callbacks_t *cbs = ui_get_callbacks();
    if (cbs->on_cancel_request != NULL) {
        cbs->on_cancel_request();
    }
}

void ui_show_calling(service_id_t svc)
{
    if (svc >= SERVICE_COUNT) svc = SERVICE_AMBULANCE;
    const service_info_t *s = &ui_services[svc];

    lv_obj_t *scr = ui_screen_begin(UI_BG, UI_BG_2);
    ui_telemetry_set_visible(true);

    // ------------------------------------------------------------------
    // 1. Top Status Bar (y = 0..27)
    // ------------------------------------------------------------------
    ui_top_bar(scr, "Node 01 - Request", s->dot_color);

    // ------------------------------------------------------------------
    // 2. Center Unified Request Card (x = 12, y = 38, w = 296, h = 132)
    // ------------------------------------------------------------------
    lv_obj_t *card = ui_card(scr, 12, 38, 296, 132, UI_PANEL,
                             lv_color_hex(0x2A303C), 1, 10);
    lv_obj_set_style_clip_corner(card, true, 0);
    ui_make_clickable(card, lv_color_hex(0x181C26), LV_OPA_COVER);
    ui_name(card, "calling_card");

    // Top status pill inside viewport: [ ● LOCAL ALERT ]
    lv_obj_t *badge = ui_card(card, 20, 14, 156, 20, lv_color_hex(0x191D26),
                              lv_color_hex(0x2A303C), 1, 10);
    ui_name(badge, "calling_banner");

    lv_obj_t *live_dot = ui_card(badge, 9, 6, 6, 6, s->dot_color, s->dot_color, 0, 3);
    ui_name(live_dot, "calling_live_dot");

    lv_anim_t la;
    lv_anim_init(&la);
    lv_anim_set_var(&la, live_dot);
    lv_anim_set_values(&la, LV_OPA_30, LV_OPA_COVER);
    lv_anim_set_duration(&la, 500);
    lv_anim_set_reverse_duration(&la, 500);
    lv_anim_set_repeat_count(&la, LV_ANIM_REPEAT_INFINITE);
    lv_anim_set_exec_cb(&la, blink_cb);
    lv_anim_start(&la);

    ui_label(badge, "LOCAL ALERT", &lv_font_montserrat_12, UI_MUTED,
             22, 2, 124, LV_TEXT_ALIGN_LEFT);

    // Main row: Red '!' alert icon badge + "REQUEST" on left, countdown on right
    lv_obj_t *core = ui_card(card, 20, 42, 28, 28, lv_color_hex(0x281117),
                             UI_RED, 2, 7);
    ui_name(core, "calling_core");
    ui_label(core, "!", &lv_font_montserrat_20, UI_RED,
             0, 1, 24, LV_TEXT_ALIGN_CENTER);

    ui_label(card, "REQUEST", &lv_font_montserrat_20, UI_WHITE,
             56, 44, 120, LV_TEXT_ALIGN_LEFT);

    lv_obj_t *timer = ui_label(card, "5.0s", &lv_font_montserrat_20,
                               s->dot_color, 194, 44, 80, LV_TEXT_ALIGN_RIGHT);
    ui_name(timer, "calling_timer");

    lv_anim_t ta;
    lv_anim_init(&ta);
    lv_anim_set_var(&ta, timer);
    lv_anim_set_values(&ta, 50, 0);
    lv_anim_set_duration(&ta, 5000);
    lv_anim_set_path_cb(&ta, lv_anim_path_linear);
    lv_anim_set_exec_cb(&ta, timer_cb);
    lv_anim_start(&ta);

    // Clean full-width progress bar across the card (x = 20..274, y = 78)
    ui_card(card, 20, 78, 254, 8, lv_color_hex(0x1F2430), UI_LINE, 0, 4);
    lv_obj_t *bar = ui_card(card, 20, 78, 254, 8, s->dot_color, s->dot_color, 0, 4);
    ui_name(bar, "calling_bar");

    lv_anim_t ba;
    lv_anim_init(&ba);
    lv_anim_set_var(&ba, bar);
    lv_anim_set_values(&ba, 254, 2);
    lv_anim_set_duration(&ba, 5000);
    lv_anim_set_path_cb(&ba, lv_anim_path_linear);
    lv_anim_set_exec_cb(&ba, (lv_anim_exec_xcb_t)lv_obj_set_width);
    lv_anim_start(&ba);

    // Attached Card Footer Bar (y = 98..130 inside card — identical to service slide)
    lv_obj_t *cfoot = ui_box(card, 0, 98, 294, 32, UI_PANEL_2, LV_OPA_COVER,
                             UI_LINE, 0);
    ui_box(card, 0, 98, 294, 1, UI_LINE, LV_OPA_COVER, UI_LINE, 0);

    // Pill 1: Priority tag
    lv_obj_t *p1 = ui_card(cfoot, 8, 7, 44, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    ui_label(p1, s->prio_tag, &lv_font_montserrat_12, UI_TEXT, 0, 1, 42,
             LV_TEXT_ALIGN_CENTER);

    // Pill 2: Category tag
    lv_obj_t *p2 = ui_card(cfoot, 56, 7, 40, 18, UI_PILL_BG, UI_PILL_BDR, 1, 4);
    ui_label(p2, s->cat_tag, &lv_font_montserrat_12, UI_TEXT, 0, 1, 38,
             LV_TEXT_ALIGN_CENTER);

    // Pill 3: [LIVE]
    lv_obj_t *p3 = ui_card(cfoot, 100, 7, 40, 18, s->color, s->border_color, 1, 4);
    ui_label(p3, "LIVE", &lv_font_montserrat_12, UI_WHITE, 0, 1, 38,
             LV_TEXT_ALIGN_CENTER);

    // Service Title
    ui_label(cfoot, s->name, &lv_font_montserrat_16, UI_WHITE,
             148, 6, 138, LV_TEXT_ALIGN_LEFT);

    ui_bubble_children(card);
    lv_obj_add_event_cb(card, cancel_request_cb, LV_EVENT_CLICKED, NULL);

    // ------------------------------------------------------------------
    // 3. Bottom Action Dock (y = 177..215) — Simple single Cancel button
    // ------------------------------------------------------------------
    ui_box(scr, 12, 177, 296, 1, lv_color_hex(0x1C2029), LV_OPA_COVER,
           lv_color_hex(0x1C2029), 0);

    lv_obj_t *abort_btn = ui_card(scr, 12, 183, 296, 32,
                                  lv_color_hex(0x1B1F28),
                                  lv_color_hex(0x323948), 1, 8);
    ui_make_clickable(abort_btn, lv_color_hex(0x281117), LV_OPA_COVER);
    ui_name(abort_btn, "calling_abort_btn");
    ui_label(abort_btn, "CANCEL REQUEST", &lv_font_montserrat_12,
             UI_TEXT, 0, 8, 294, LV_TEXT_ALIGN_CENTER);
    ui_bubble_children(abort_btn);
    lv_obj_add_event_cb(abort_btn, cancel_request_cb, LV_EVENT_CLICKED, NULL);

    ui_animate_in(scr, 0);
}
