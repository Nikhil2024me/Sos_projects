// SOS Emergency Transmitter — V4 Unified Card UI
// ESP32-S3-WROOM-1 N16R8 + ILI9341 320x240 + XPT2046 + SX1278
//
// LVGL 9.6 UI, partial render mode, 320x40 RGB565 draw buffer (25,600 bytes).
// Touch uses TFT_eSPI's stock XPT2046 getTouch() + calibrateTouch() wired into
// an official LVGL 9.6 LV_INDEV_TYPE_POINTER input device.

#include <Arduino.h>
#include <Preferences.h>
#include <SPI.h>
#include <TFT_eSPI.h>

#include "lvgl.h"
#include "src/ui/ui_common.h"

// ---------------------------------------------------------------------------
// Board pin map (ESP32-S3-WROOM-1 N16R8)
// ---------------------------------------------------------------------------
// TFT + XPT2046 (FSPI / SPI2) are configured in TFT_eSPI User_Setup.h:
//   SCLK 12  MOSI 11  MISO 13  CS 10  DC 7  RST 6  BL 21
//   TOUCH_CS 15  TOUCH_IRQ 16
#define PIN_BUTTON        1
#define PIN_NOTIFICATION  17
#define PIN_BUZZER        18

// SX1278 (HSPI / SPI3), standby only in this build.
// Avoid GPIO 6 (TFT_RST) and GPIO 7 (TFT_DC)!
#define LORA_SCK          5
#define LORA_MISO         14
#define LORA_MOSI         9
#define LORA_NSS          4
#define LORA_RST          8
#define LORA_DIO0         2

// ---------------------------------------------------------------------------
// Timing & Touch Constants
// ---------------------------------------------------------------------------
static const uint32_t LONG_PRESS_MS       = 2000;
static const uint32_t SHORT_PRESS_MIN_MS  = 30;
static const uint32_t BUZZER_TOGGLE_MS    = 500;
static const uint32_t CALL_DURATION_MS    = 5000;
static const uint32_t PRESSURE_UPDATE_MS  = 250;
static const uint32_t UPTIME_UPDATE_MS    = 1000;
static const uint16_t TOUCH_Z_THRESHOLD   = 600;

// ---------------------------------------------------------------------------
// Display, Touch & NVS
// ---------------------------------------------------------------------------
TFT_eSPI tft = TFT_eSPI();
static Preferences prefs;
static lv_display_t *disp = NULL;
static lv_indev_t *touch_indev = NULL;
static uint8_t draw_buf[320 * 40 * 2] __attribute__((aligned(4)));

static uint16_t touch_cal[5] = {450, 3432, 370, 3379, 3};
static bool touch_was_pressed = false;

// ---------------------------------------------------------------------------
// App state
// ---------------------------------------------------------------------------
enum app_state_t {
    APP_BOOT = 0,
    APP_MAIN,
    APP_SERVICE,
    APP_CONFIG,
    APP_CALLING,
    APP_SLIDESHOW,
};

static app_state_t state = APP_BOOT;
static service_id_t current_service = SERVICE_AMBULANCE;

static uint32_t boot_ms = 0;
static uint32_t last_pressure_ms = 0;
static uint32_t last_uptime_ms = 0;

static bool call_active = false;
static uint32_t call_start_ms = 0;
static bool buzzer_on = false;
static uint32_t buzzer_toggle_ms = 0;

// Physical button state (starts false so boot cannot fire a false release).
static bool button_was_down = false;
static bool button_long_fired = false;
static uint32_t button_press_ms = 0;

static SPIClass loraSPI(HSPI);

// ---------------------------------------------------------------------------
// LVGL tick & display flush
// ---------------------------------------------------------------------------
static uint32_t lv_tick_cb(void)
{
    return (uint32_t)millis();
}

static void flush_cb(lv_display_t *d, const lv_area_t *area, uint8_t *px_map)
{
    const int32_t w = lv_area_get_width(area);
    const int32_t h = lv_area_get_height(area);
    if (w > 0 && h > 0) {
        tft.startWrite();
        tft.setAddrWindow(area->x1, area->y1, w, h);
        tft.pushColors((uint16_t *)px_map, (uint32_t)w * (uint32_t)h, true);
        tft.endWrite();
    }
    lv_display_flush_ready(d);
}

// ---------------------------------------------------------------------------
// Official LVGL 9.6 Pointer Input Device + Stock TFT_eSPI Touch Calibration
// ---------------------------------------------------------------------------
static bool load_cal_from_ns(const char *ns)
{
    if (!prefs.begin(ns, true)) return false;
    bool ok = prefs.getBool("tc_ok", false);
    uint16_t tmp[5] = {0};
    if (ok) {
        for (int i = 0; i < 5; i++) {
            char key[5] = {'t', 'c', (char)('0' + i), '\0', '\0'};
            tmp[i] = prefs.getUShort(key, 0);
        }
        if (tmp[0] == 0 || tmp[1] == 0 || tmp[2] == 0 || tmp[3] == 0) {
            ok = false;
        }
    }
    prefs.end();
    if (ok) {
        memcpy(touch_cal, tmp, sizeof(touch_cal));
    }
    return ok;
}

static void touch_load_calibration(void)
{
    if (load_cal_from_ns("sos_ui") || load_cal_from_ns("weather")) {
        Serial.printf("TOUCH CAL (NVS): {%u, %u, %u, %u, %u}\n",
                      touch_cal[0], touch_cal[1], touch_cal[2],
                      touch_cal[3], touch_cal[4]);
    } else {
        Serial.printf("TOUCH CAL (default): {%u, %u, %u, %u, %u}\n",
                      touch_cal[0], touch_cal[1], touch_cal[2],
                      touch_cal[3], touch_cal[4]);
    }
    tft.setTouch(touch_cal);
}

static void touch_save_calibration(void)
{
    if (!prefs.begin("sos_ui", false)) return;
    prefs.putBool("tc_ok", true);
    for (int i = 0; i < 5; i++) {
        char key[5] = {'t', 'c', (char)('0' + i), '\0', '\0'};
        prefs.putUShort(key, touch_cal[i]);
    }
    prefs.end();
}

static void run_touch_calibration(void)
{
    Serial.println("TOUCH: starting 4-corner calibration...");
    tft.fillScreen(TFT_BLACK);
    tft.setTextColor(TFT_WHITE, TFT_BLACK);
    tft.setTextSize(1);
    tft.setCursor(20, 8);
    tft.println("Touch corners as indicated");

    uint16_t cal[5];
    tft.calibrateTouch(cal, TFT_MAGENTA, TFT_BLACK, 15);
    memcpy(touch_cal, cal, sizeof(touch_cal));
    tft.setTouch(touch_cal);
    touch_save_calibration();

    Serial.printf("TOUCH CAL SAVED: {%u, %u, %u, %u, %u}\n",
                  touch_cal[0], touch_cal[1], touch_cal[2],
                  touch_cal[3], touch_cal[4]);

    tft.fillScreen(TFT_BLACK);
    if (disp != NULL) {
        lv_obj_invalidate(lv_screen_active());
    }
}

static void touch_read_cb(lv_indev_t *indev, lv_indev_data_t *data)
{
    (void)indev;
    if (state == APP_BOOT) {
        data->state = LV_INDEV_STATE_RELEASED;
        return;
    }

    uint16_t x = 0, y = 0;
    const bool pressed = (tft.getTouch(&x, &y, TOUCH_Z_THRESHOLD) != 0);

    if (pressed) {
        data->point.x = (int32_t)x;
        data->point.y = (int32_t)y;
        data->state   = LV_INDEV_STATE_PRESSED;
    } else {
        data->state   = LV_INDEV_STATE_RELEASED;
    }

    if (pressed != touch_was_pressed) {
        if (pressed) {
            uint16_t z = tft.getTouchRawZ();
            ui_update_pressure(z);
            Serial.printf("TOUCH: %u,%u (z=%u)\n", (unsigned)x, (unsigned)y, (unsigned)z);
        } else {
            ui_update_pressure(0);
            Serial.println("TOUCH: release");
        }
        touch_was_pressed = pressed;
    }
}

// ---------------------------------------------------------------------------
// SX1278 standby init (no transmit)
// ---------------------------------------------------------------------------
static void lora_write(uint8_t reg, uint8_t value)
{
    digitalWrite(LORA_NSS, LOW);
    loraSPI.transfer(reg | 0x80);
    loraSPI.transfer(value);
    digitalWrite(LORA_NSS, HIGH);
}

static uint8_t lora_read(uint8_t reg)
{
    digitalWrite(LORA_NSS, LOW);
    loraSPI.transfer(reg & 0x7F);
    uint8_t value = loraSPI.transfer(0x00);
    digitalWrite(LORA_NSS, HIGH);
    return value;
}

static void lora_standby_init(void)
{
    pinMode(LORA_NSS, OUTPUT);
    digitalWrite(LORA_NSS, HIGH);
    pinMode(LORA_RST, OUTPUT);
    digitalWrite(LORA_RST, LOW);
    delay(10);
    digitalWrite(LORA_RST, HIGH);
    delay(10);
    pinMode(LORA_DIO0, INPUT);

    loraSPI.begin(LORA_SCK, LORA_MISO, LORA_MOSI, LORA_NSS);
    loraSPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));

    const uint8_t version = lora_read(0x42); // RegVersion
    if (version == 0x12) {
        lora_write(0x01, 0x00); // sleep
        delay(5);
        lora_write(0x01, 0x01); // standby
    }
    loraSPI.endTransaction();

    Serial.printf("LoRa SX1278: version 0x%02X (%s), no TX\n",
                  version, version == 0x12 ? "standby" : "not detected");
}

// ---------------------------------------------------------------------------
// Screen & State transitions (invoked by LVGL widget callbacks & button)
// ---------------------------------------------------------------------------
static void show_main(void)
{
    state = APP_MAIN;
    ui_show_home();
    ui_home_set_selected(current_service);
    ui_update_uptime((millis() - boot_ms) / 1000);
}

static void show_service(void)
{
    state = APP_SERVICE;
    ui_show_service(current_service);
}

static void show_config(void)
{
    state = APP_CONFIG;
    ui_show_config();
}

static void show_slideshow(void)
{
    state = APP_SLIDESHOW;
    ui_show_slideshow((uint8_t)current_service);
}

static void end_call(bool return_to_service)
{
    call_active = false;
    digitalWrite(PIN_NOTIFICATION, LOW);
    digitalWrite(PIN_BUZZER, LOW);
    buzzer_on = false;
    if (return_to_service) {
        show_main();
    }
}

static void start_call(void)
{
    if (call_active) end_call(false);
    call_active = true;
    call_start_ms = millis();
    buzzer_toggle_ms = millis();
    buzzer_on = true;
    digitalWrite(PIN_NOTIFICATION, HIGH);
    digitalWrite(PIN_BUZZER, HIGH);
    state = APP_CALLING;
    ui_show_calling(current_service);
}

static void open_config(void)
{
    if (call_active) end_call(false);
    ui_slideshow_hold_progress(0);
    show_config();
}

// ---------------------------------------------------------------------------
// UI Event Callback Handlers
// ---------------------------------------------------------------------------
static void on_ui_service_change(service_id_t svc)
{
    current_service = svc;
}

static void on_ui_dispatch(service_id_t svc)
{
    current_service = svc;
    start_call();
}

static void on_ui_cancel_request(void)
{
    end_call(true);
}

static void on_ui_open_config(void)
{
    open_config();
}

static void on_ui_close_config(void)
{
    show_main();
}

static void on_ui_open_slideshow(void)
{
    show_slideshow();
}

static void on_ui_exit_slideshow(void)
{
    show_main();
}

static void on_ui_calibrate(void)
{
    run_touch_calibration();
    show_config();
}

static const ui_callbacks_t app_ui_cbs = {
    .on_service_change = on_ui_service_change,
    .on_dispatch       = on_ui_dispatch,
    .on_cancel_request = on_ui_cancel_request,
    .on_open_config    = on_ui_open_config,
    .on_close_config   = on_ui_close_config,
    .on_open_slideshow = on_ui_open_slideshow,
    .on_exit_slideshow = on_ui_exit_slideshow,
    .on_calibrate      = on_ui_calibrate,
};

// ---------------------------------------------------------------------------
// Input: physical hardware button (GPIO 1)
// ---------------------------------------------------------------------------
static void handle_button(uint32_t now)
{
    const bool pressed = (digitalRead(PIN_BUTTON) == LOW);

    if (pressed && !button_was_down) {
        button_press_ms = now;
        button_long_fired = false;
    }

    if (pressed && !button_long_fired && (now - button_press_ms >= LONG_PRESS_MS)) {
        button_long_fired = true;
        open_config();
    }

    if (!pressed && button_was_down) {
        const uint32_t held = now - button_press_ms;
        if (!button_long_fired && held >= SHORT_PRESS_MIN_MS) {
            if (state == APP_MAIN || state == APP_SERVICE) {
                start_call();
            } else if (state == APP_CALLING) {
                end_call(true);
            }
        }
    }

    button_was_down = pressed;
}

// ---------------------------------------------------------------------------
// Periodic work
// ---------------------------------------------------------------------------
static void handle_call(uint32_t now)
{
    if (!call_active) return;

    if (now - call_start_ms >= CALL_DURATION_MS) {
        end_call(true);
        return;
    }

    if (now - buzzer_toggle_ms >= BUZZER_TOGGLE_MS) {
        buzzer_toggle_ms = now;
        buzzer_on = !buzzer_on;
        digitalWrite(PIN_BUZZER, buzzer_on ? HIGH : LOW);
    }
}

static void handle_periodic(uint32_t now)
{
    if (touch_was_pressed && (now - last_pressure_ms >= PRESSURE_UPDATE_MS)) {
        last_pressure_ms = now;
        uint16_t z = tft.getTouchRawZ();
        ui_update_pressure(z);
    }

    if (now - last_uptime_ms >= UPTIME_UPDATE_MS) {
        last_uptime_ms = now;
        ui_update_uptime((now - boot_ms) / 1000);
    }
}

// ---------------------------------------------------------------------------
// setup / loop
// ---------------------------------------------------------------------------
static void pump_ui(uint32_t ms)
{
    const uint32_t t0 = millis();
    while (millis() - t0 < ms) {
        lv_timer_handler();
        delay(5);
    }
}

void setup()
{
    Serial.begin(115200);
    delay(50);
    Serial.println("\nSOS Emergency Transmitter - V4 Unified Card UI");

    pinMode(PIN_BUTTON, INPUT_PULLUP);
    pinMode(PIN_NOTIFICATION, OUTPUT);
    pinMode(PIN_BUZZER, OUTPUT);
    digitalWrite(PIN_NOTIFICATION, LOW);
    digitalWrite(PIN_BUZZER, LOW);

#if defined(TFT_BL) && TFT_BL >= 0
    pinMode(TFT_BL, OUTPUT);
    digitalWrite(TFT_BL, TFT_BACKLIGHT_ON);
#endif

    tft.init();
    tft.setRotation(1);
    tft.fillScreen(TFT_BLACK);
    tft.fillRect(0, 0, 40, 40, TFT_RED);
    tft.fillRect(140, 100, 40, 40, TFT_GREEN);
    tft.fillRect(280, 200, 40, 40, TFT_BLUE);
    uint16_t r_px = tft.readPixel(20, 20);
    uint16_t g_px = tft.readPixel(160, 120);
    uint16_t b_px = tft.readPixel(300, 220);
    Serial.printf("PANEL: readback %04X %04X %04X -> %s\n",
                  (unsigned)r_px, (unsigned)g_px, (unsigned)b_px,
                  (r_px == TFT_RED && g_px == TFT_GREEN && b_px == TFT_BLUE) ? "OK" : "MISMATCH");
    tft.fillScreen(TFT_BLACK);

    touch_load_calibration();

    lv_init();
    lv_tick_set_cb(lv_tick_cb);

    disp = lv_display_create(320, 240);
    lv_display_set_color_format(disp, LV_COLOR_FORMAT_RGB565);
    lv_display_set_flush_cb(disp, flush_cb);
    lv_display_set_buffers(disp, draw_buf, NULL, sizeof(draw_buf),
                           LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_default(disp);

    // Register official LVGL 9.6 pointer input device for XPT2046 touch.
    touch_indev = lv_indev_create();
    lv_indev_set_type(touch_indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(touch_indev, touch_read_cb);
    lv_indev_set_display(touch_indev, disp);
    lv_indev_set_long_press_time(touch_indev, LONG_PRESS_MS);

    ui_set_callbacks(&app_ui_cbs);
    ui_init();

    // ADWS splash driven by the real init steps.
    boot_ms = millis();
    state = APP_BOOT;
    ui_show_boot();
    ui_boot_set_progress(5, "Power on...");
    pump_ui(120);

    ui_boot_set_progress(18, "Display ready");
    pump_ui(140);

    lora_standby_init();
    ui_boot_set_progress(45, "LoRa standby");
    pump_ui(180);

    ui_boot_set_progress(65, "Touch ready");
    pump_ui(140);

    ui_boot_set_progress(82, "UI ready");
    pump_ui(140);

    while (millis() - boot_ms < 2000) {
        lv_timer_handler();
        delay(5);
    }
    ui_boot_set_progress(100, "System online");
    pump_ui(250);

    show_main();
    last_pressure_ms = millis();
    last_uptime_ms = millis();
    Serial.println("Ready: COMMAND");
}

void loop()
{
    const uint32_t now = millis();

    lv_timer_handler();
    handle_button(now);
    handle_call(now);
    handle_periodic(now);

    delay(5);
}
